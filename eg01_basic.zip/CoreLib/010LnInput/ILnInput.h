// Interface for the ILnInput class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILnInput_H_
#define _ILnInput_H_

#ifndef interface
#define interface struct
#endif




interface ILnInput
{
	virtual INT		Create(void* p1/*In put value*/)=0;
	virtual void	Destroy()=0;

	virtual INT		FrameMove()=0;
	virtual void	Render()=0;


	virtual INT		Query(char* sCmd, void* pData)=0;
};


INT LnObj_CreateInput(char* sCmd, ILnInput** pData);


#ifdef _DEBUG
	#pragma comment(lib, "LnInput_.lib")
#else
	#pragma comment(lib, "LnInput.lib")
#endif


#endif

