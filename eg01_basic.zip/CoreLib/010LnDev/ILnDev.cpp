// Implementation of the ILnDev class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include "ILnDev.h"
#include "LnDevBase.h"
#include "LnDevD3D9.h"


INT LnObj_CreateDevice(char* sCmd, ILnDev** pData)
{
	(*pData) = NULL;

	if(0==_stricmp("Create Direct3D9", sCmd))
	{
		CLnDevD3D9* pObj = NULL;

		pObj = new CLnDevD3D9;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}


	return -1;
}
