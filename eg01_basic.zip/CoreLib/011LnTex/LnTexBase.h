// Interface for the CLnTex class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnTex_H_
#define _LnTex_H_


class CLnTex : public ILnTex
{
protected:
	INT		nId;

public:
	CLnTex();
	virtual ~CLnTex();
	
	virtual INT		Create(void* p1);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		Query(char* sCmd, void* pData);
};

#endif
