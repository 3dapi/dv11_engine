// Implementation of the ILnTex class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include "ILnTex.h"
#include "LnTexBase.h"


INT LnObj_CreateTex(char* sCmd, ILnTex** pData)
{
	(*pData) = NULL;

	if(0==_stricmp("Create Texture", sCmd))
	{
		CLnTex* pObj = NULL;

		pObj = new CLnTex;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}

	return -1;
}
