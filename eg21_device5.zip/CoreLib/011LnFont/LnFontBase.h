// Interface for the CLnFont class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnFont_H_
#define _LnFont_H_


class CLnFont : public ILnFont
{
protected:
	INT		nId;

public:
	CLnFont();
	virtual ~CLnFont();
	
	virtual INT		Create(void* p1);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		Query(char* sCmd, void* pData);
};

#endif
