// Implementation of the CLnDevD3D9 class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "ILnDev.h"
#include "LnDevBase.h"
#include "LnDevD3D9.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


CLnDevD3D9* g_pD3DApp=NULL;


CLnDevD3D9::CLnDevD3D9()
{
	pFuncInit		= NULL;
	pFuncDestroy	= NULL;
	pFuncRestore	= NULL;
	pFuncInvalidate	= NULL;
	pFuncFrameMove	= NULL;
	pFuncRender		= NULL;

	g_pD3DApp		= this;



	strcpy(m_sCls, "LnEngine for D3D9");

	m_hInst			= NULL;
	m_hWnd			= NULL;
	m_dWinStyle		= WS_OVERLAPPED| WS_CAPTION| WS_SYSMENU| WS_VISIBLE;
	m_dScnX			= 800;
	m_dScnY			= 600;

	m_bShowCusor	= TRUE;
	m_bWindow		= TRUE;			// Window mode

	m_pD3D			= NULL;			// D3D
	m_pd3dDevice	= NULL;			// Device
	m_pd3dSprite	= NULL;			// 2D Sprite
	m_bAlive		= TRUE;
}

CLnDevD3D9::~CLnDevD3D9()
{
}

INT CLnDevD3D9::Create(void* p1)
{
	printf("CLnDevD3D9 Create\n");

	LnDev* pLnDev = (LnDev*)p1;

	if( strlen(pLnDev->sCls))
	{
		strcpy(m_sCls, pLnDev->sCls);
	}

	if(pLnDev->hInst)
		m_hInst	= pLnDev->hInst;
	else
		m_hInst = GetModuleHandle(NULL);

	if(pLnDev->hWnd)
		m_hWnd = pLnDev->hWnd;

	
	pLnDev->hInst = m_hInst;
	m_dScnX	= pLnDev->ScnX;
	m_dScnY	= pLnDev->ScnY;


	RECT rc;									//Create the application's window
		
	SetRect( &rc, 0, 0, m_dScnX, m_dScnY);
	AdjustWindowRect( &rc, m_dWinStyle, false );
		
	int iScnSysW = ::GetSystemMetrics(SM_CXSCREEN);
	int iScnSysH = ::GetSystemMetrics(SM_CYSCREEN);


	if(-1==pLnDev->PosX)
		pLnDev->PosX = (iScnSysW - (rc.right-rc.left))/2;

	if(-1==pLnDev->PosY)
		pLnDev->PosY = (iScnSysH - (rc.bottom-rc.top))/2;

	
	m_dPosX	= pLnDev->PosX;
	m_dPosY	= pLnDev->PosY;


	if(NULL== m_hWnd)
	{
		WNDCLASS wc =								// Register the window class
		{
			CS_CLASSDC
			, WndProc
			, 0L
			, 0L
			, m_hInst
			, NULL
			, LoadCursor(NULL,IDC_ARROW)
			, (HBRUSH)GetStockObject(WHITE_BRUSH)
			, NULL
			, m_sCls
		};

		RegisterClass( &wc );
	
		m_hWnd = CreateWindow( m_sCls
			, m_sCls
			, m_dWinStyle
			, m_dPosX
			, m_dPosY
			, (rc.right-rc.left)
			, (rc.bottom-rc.top)
			, NULL
			, NULL
			, m_hInst
			, NULL );

		pLnDev->hWnd = m_hWnd;
	}



	// D3D����
	if( NULL == ( m_pD3D = Direct3DCreate9( D3D_SDK_VERSION ) ) )
		return -1;


	// D3D�� ���ؼ� ȭ�� ��带 ã�´�.
	D3DDISPLAYMODE d3ddm;
    if( FAILED( m_pD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &d3ddm ) ) )
        return E_FAIL;
	
	
	// ����̽��� �����ϱ� ���ؼ��� ������Ʈ �Ķ���� ����ü�� �ʿ�
	// ���� 0���� �����Ѵ��� �Ϻθ� ��������
	
	
	memset(&m_d3dpp, 0, sizeof(m_d3dpp));
	m_d3dpp.Windowed				= m_bWindow;
	m_d3dpp.SwapEffect				= D3DSWAPEFFECT_DISCARD;
	m_d3dpp.BackBufferFormat		= d3ddm.Format;
	m_d3dpp.BackBufferCount			= 2;
	m_d3dpp.BackBufferWidth			= m_dScnX;
	m_d3dpp.BackBufferHeight		= m_dScnY;
	m_d3dpp.EnableAutoDepthStencil	= TRUE;
	m_d3dpp.AutoDepthStencilFormat	= D3DFMT_D16;
	
	
	// D3DADAPTER_DEFAULT: ��κ��� �׷���ī��� ��� ����� ��� �̺κ��� ����
	// D3DDEVTYPE_HAL : �ϵ���� ����(���� ū �ӵ�)�� ���� ���ΰ�.. �ϵ���� ��
	// ���� ���� ��� D3D�� ����Ʈ����� �̸� ��ü �� �� �ִ�.
	
	if( FAILED( m_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, m_hWnd,
		D3DCREATE_MIXED_VERTEXPROCESSING, &m_d3dpp, &m_pd3dDevice ) ) )
	{
		if( FAILED( m_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, m_hWnd,
		D3DCREATE_SOFTWARE_VERTEXPROCESSING, &m_d3dpp, &m_pd3dDevice ) ) )
		{
			SAFE_RELEASE(	m_pd3dDevice	);
			SAFE_RELEASE(	m_pD3D			);
			return -1;
		}
	}
	
	// DX�� ��������Ʈ�� ����̽��� ������ �Ŀ� ������ �Ѵ�.
	if(FAILED(D3DXCreateSprite(m_pd3dDevice, &m_pd3dSprite)))
	{
		SAFE_RELEASE(	m_pd3dDevice	);
		SAFE_RELEASE(	m_pD3D			);
		return -1;
	}

	
	ShowWindow( m_hWnd, SW_SHOW );
	UpdateWindow( m_hWnd );
	::ShowCursor(m_bShowCusor);

	

	if(pFuncInit)
		return pFuncInit();

	return 0;
}

void CLnDevD3D9::Destroy()
{
	printf("CLnDevD3D9 Destroy\n");

	if(pFuncDestroy)
		pFuncDestroy();
}


INT CLnDevD3D9::Restore()
{
	printf("CLnDevD3D9 Restore\n");

	if(pFuncInit)
		return pFuncRestore();

	return 0;
}

void CLnDevD3D9::Invalidate()
{
	printf("CLnDevD3D9 Invalidate\n");

	if(pFuncInvalidate)
		pFuncInvalidate();
}


INT	CLnDevD3D9::FrameMove()
{
	printf("CLnDevD3D9 FrameMove\n");

	if(pFuncFrameMove)
		return pFuncFrameMove();
	
	return 0;
}

INT CLnDevD3D9::Render()
{
	printf("CLnDevD3D9 Render\n");

	if(pFuncRender)
		return pFuncRender();

	return 0;
}




INT CLnDevD3D9::Query(char* sCmd, void* pData)
{
	printf("CLnDevD3D9 Query:%s\n", sCmd);

	if     (0==_stricmp("SetFuncInit",	 sCmd))		{	pFuncInit		= (int (__cdecl *)(void))pData;	return 0;	}
	else if(0==_stricmp("SetFuncDestoy", sCmd))		{	pFuncDestroy	= (int (__cdecl *)(void))pData;	return 0;	}
	else if(0==_stricmp("SetFuncRestore", sCmd))	{	pFuncRestore	= (int (__cdecl *)(void))pData;	return 0;	}
	else if(0==_stricmp("SetFuncInvalidate", sCmd))	{	pFuncInvalidate	= (int (__cdecl *)(void))pData;	return 0;	}
	else if(0==_stricmp("SetFuncFrameMove", sCmd))	{	pFuncFrameMove	= (int (__cdecl *)(void))pData;	return 0;	}
	else if(0==_stricmp("SetFuncRender", sCmd))		{	pFuncRender		= (int (__cdecl *)(void))pData;	return 0;	}
	
	return 0;
}






INT CLnDevD3D9::Run()
{	    
	MSG msg;
	memset( &msg, 0, sizeof(msg) );
	
	while( msg.message!=WM_QUIT )
	{
		if( PeekMessage( &msg, NULL, 0U, 0U, PM_REMOVE ) )
		{
			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}

		if(!m_bAlive)
			break;
		
		if(FAILED(FrameMove()))
			break;

		if(FAILED(Render()))
			break;

		// �ĸ���� ������� ��ü( flipping)
		m_pd3dDevice->Present( 0, 0, 0, 0);
	}


	Destroy();
	
	UnregisterClass( m_sCls, m_hInst);
	
	return 1;
}



LRESULT WINAPI CLnDevD3D9::WndProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	if(g_pD3DApp)
		return g_pD3DApp->MsgProc(hWnd, msg, wParam, lParam);
	
	
	return DefWindowProc( hWnd, msg, wParam, lParam );	
}



LRESULT CLnDevD3D9::MsgProc(HWND hWnd,UINT msg,WPARAM wParam,LPARAM lParam)
{
	switch( msg )
	{
		case WM_KEYDOWN:
		{
			
			switch(wParam)
			{
				case VK_ESCAPE:
				{
					SendMessage(hWnd, WM_DESTROY, 0,0);
					break;
				}
			}
			
			break;

		}

		case WM_CLOSE:
		case WM_DESTROY:
		{
			m_bAlive = FALSE;
			PostQuitMessage( 0 );
			break;
		}
	}
	
	return DefWindowProc( hWnd, msg, wParam, lParam );
}






INT CLnDevD3D9::BeginScene()
{
	return m_pd3dDevice->BeginScene();
}

INT CLnDevD3D9::EndScene()
{
	return m_pd3dDevice->EndScene();
}


INT CLnDevD3D9::Clear(DWORD Count,CONST RECT* pRects,DWORD Flags, DWORD Color,float Z,DWORD Stencil)
{
	return m_pd3dDevice->Clear(Count, (D3DRECT*)pRects,Flags,Color,Z,Stencil);
}



LPDIRECT3DDEVICE9 CLnDevD3D9::GetDevice()
{
	return m_pd3dDevice;
}