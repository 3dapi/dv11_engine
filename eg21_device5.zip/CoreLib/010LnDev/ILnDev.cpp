// Implementation of the ILnDev class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include <d3d9.h>
#include <d3dx9.h>

#include "ILnDev.h"
#include "LnDevBase.h"
#include "LnDevD3D9.h"
#include "LnDevOpenGL.h"
#include "LnDevSoftware.h"



LnDev::LnDev()
{
	PosX	= 0;
	PosY	= 0;
	ScnX	= 0;
	ScnY	= 0;

	hInst	= NULL;
	hWnd	= NULL;
	memset(sCls, 0, sizeof sCls);
}


LnDev::LnDev(INT _PosX, INT _PosY, INT _Wx, INT _Wy, const char* _sCls, HINSTANCE _hInst, HWND _hWnd)
{
	PosX	= _PosX;
	PosY	= _PosY;
	ScnX	= _Wx;
	ScnY	= _Wy;

	hInst	= _hInst;
	hWnd	= _hWnd;
	memset(sCls, 0, sizeof sCls);

	if(_sCls && strlen(_sCls))
		strcpy(sCls, _sCls);
}


INT LnDev_CreateDevice(char* sCmd, ILnDev** pData)
{
	(*pData) = NULL;

	if(0==_stricmp("Create Direct3D9", sCmd))
	{
		CLnDevD3D9* pObj = NULL;

		pObj = new CLnDevD3D9;

//		if(FAILED(pObj->Create(NULL)))
//		{
//			// Return Error Notification
//			delete pObj;
//			return -1;
//		}

		(*pData) = pObj;
		
		return 0;
	}

	else if(0==_stricmp("Create OpenGL", sCmd))
	{
		CLnDevOpenGL* pObj = NULL;

		pObj = new CLnDevOpenGL;

//		if(FAILED(pObj->Create(NULL)))
//		{
//			// Return Error Notification
//			delete pObj;
//			return -1;
//		}

		(*pData) = pObj;
		
		return 0;
	}

	else if(0==_stricmp("Create Software Device", sCmd))
	{
		CLnDevSoftwafe* pObj = NULL;

		pObj = new CLnDevSoftwafe;
		(*pData) = pObj;
		
		return 0;
	}


	return -1;
}




void* LnDev_GetD3Device(ILnDev** pData)
{
	if(!pData)
		return NULL;


	CLnDevD3D9* pDev = (CLnDevD3D9*)(*pData);
	
	return pDev->GetDevice();
}