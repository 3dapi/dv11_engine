// Implementation of the CLnDevSoftwafe class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnDev.h"
#include "LnDevBase.h"
#include "LnDevSoftware.h"



CLnDevSoftwafe::CLnDevSoftwafe()
{
	
}

CLnDevSoftwafe::~CLnDevSoftwafe()
{
	Destroy();
}

INT CLnDevSoftwafe::Create(void* p1)
{
	printf("CLnDevSoftwafe Create\n");
	return 0;
}

void CLnDevSoftwafe::Destroy()
{
	printf("CLnDevSoftwafe Destroy\n");
}

INT	CLnDevSoftwafe::FrameMove()
{
	printf("CLnDevSoftwafe FrameMove\n");
	return 0;
}

INT CLnDevSoftwafe::Render()
{
	printf("CLnDevSoftwafe Render\n");
	return 0;
}
