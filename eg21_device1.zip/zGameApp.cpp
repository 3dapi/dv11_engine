
#include <windows.h>
#include <stdio.H>

#include "include/LnLib/ILnDev.h"


void main()
{
	ILnDev* pDev;

	LnInst_CreateDevice("Create Direct3D9", &pDev);

	pDev->FrameMove();
	pDev->Render();
	pDev->Query("Hello world", NULL);

	delete pDev;

	printf("\n--------------\n\n");


	LnInst_CreateDevice("Create OpenGL", &pDev);

	pDev->FrameMove();
	pDev->Render();
	pDev->Query("Hi", NULL);

	delete pDev;

	printf("\n--------------\n\n");


	LnInst_CreateDevice("Create Software Device", &pDev);

	pDev->FrameMove();
	pDev->Render();
	pDev->Query("Hi", NULL);

	delete pDev;

	printf("\n--------------\n\n");

	return;
}




