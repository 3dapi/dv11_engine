// Interface for the CLnDevOpenGL class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnDevOpenGL_H_
#define _LnDevOpenGL_H_


class CLnDevOpenGL : public CLnDev
{
protected:
	INT		nId;

public:
	CLnDevOpenGL();
	virtual ~CLnDevOpenGL();

	virtual INT		Create(void* p1);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();
};

#endif