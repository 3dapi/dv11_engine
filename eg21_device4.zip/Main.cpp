// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Windows.h>
#include <stdio.h>


#include "Main.h"


CMain*	g_pAppMain;

CMain::CMain()
{
	g_pAppMain = this;
}


CMain::~CMain()
{
}


INT CMain::Init()
{
	printf("Call CMain::Init()\n");
	return 0;
}

void CMain::Destroy()
{
	printf("Call CMain::Destroy()\n");
}


INT CMain::Restore()
{
	printf("Call CMain::Restore()\n");

	return 0;
}


void  CMain::Invalidate()
{
	printf("Call CMain::Invalidate()\n");
}


INT  CMain::FrameMove()
{
	printf("Call CMain::FrameMove()\n");
	return 0;
}


void  CMain::Render()
{
	printf("Call CMain::Render()\n");
}



INT CMain::pFuncInit()
{
	if(g_pAppMain)
		return g_pAppMain->Init();

	return 0;
}

void CMain::pFuncDestroy()
{
	if(g_pAppMain)
		g_pAppMain->Destroy();
}

INT CMain::pFuncRestore()
{
	if(g_pAppMain)
		return g_pAppMain->Restore();
	
	return 0;
}

void CMain::pFuncInvalidate()
{
	if(g_pAppMain)
		g_pAppMain->Invalidate();
}

INT CMain::pFuncFrameMove()
{
	if(g_pAppMain)
		return g_pAppMain->FrameMove();
	
	return 0;
}

void CMain::pFuncRender()
{
	if(g_pAppMain)
		g_pAppMain->Render();
}
