// Interface for the CLnDev class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnDev_H_
#define _LnDev_H_


class CLnDev : public ILnDev
{
protected:
	INT		nId;

public:
	CLnDev();
	virtual ~CLnDev();
	
	virtual INT		Create(void* p1);
	virtual void	Destroy();

	virtual INT		Restore();
	virtual void	Invalidate();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual	INT		Run();

	virtual INT		Query(char* sCmd, void* pData);
};

#endif
