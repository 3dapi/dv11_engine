// Implementation of the CLnDevD3D9 class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnDev.h"
#include "LnDevBase.h"
#include "LnDevD3D9.h"


CLnDevD3D9::CLnDevD3D9()
{
	pFuncInit		= NULL;
	pFuncDestroy	= NULL;
	pFuncRestore	= NULL;
	pFuncInvalidate	= NULL;
	pFuncFrameMove	= NULL;
	pFuncRender		= NULL;
}

CLnDevD3D9::~CLnDevD3D9()
{
	Destroy();
}

INT CLnDevD3D9::Create(void* p1)
{
	printf("CLnDevD3D9 Create\n");

	if(pFuncInit)
		return pFuncInit();

	return 0;
}

void CLnDevD3D9::Destroy()
{
	printf("CLnDevD3D9 Destroy\n");

	if(pFuncDestroy)
		pFuncDestroy();
}


INT CLnDevD3D9::Restore()
{
	printf("CLnDevD3D9 Restore\n");

	if(pFuncInit)
		return pFuncRestore();

	return 0;
}

void CLnDevD3D9::Invalidate()
{
	printf("CLnDevD3D9 Invalidate\n");

	if(pFuncInvalidate)
		pFuncInvalidate();
}


INT	CLnDevD3D9::FrameMove()
{
	printf("CLnDevD3D9 FrameMove\n");

	if(pFuncFrameMove)
		return pFuncFrameMove();
	
	return 0;
}

void CLnDevD3D9::Render()
{
	printf("CLnDevD3D9 Render\n");

	if(pFuncRender)
		pFuncRender();
}



INT CLnDevD3D9::Run()
{
	printf("CLnDevD3D9 Run\n");

	static int c=0;

	while(1)
	{
		if(++c> 10)
			return 0;

		Sleep(800);
		printf("\nTest Count: %d\n", c);

		FrameMove();
		Render();
	}

	return 0;
}





INT CLnDevD3D9::Query(char* sCmd, void* pData)
{
	printf("CLnDevD3D9 Query:%s\n", sCmd);

	if     (0==_stricmp("SetFuncInit",	 sCmd))		{	pFuncInit		= (int (__cdecl *)(void))pData;	return 0;	}
	else if(0==_stricmp("SetFuncDestoy", sCmd))		{	pFuncDestroy	= (int (__cdecl *)(void))pData;	return 0;	}
	else if(0==_stricmp("SetFuncRestore", sCmd))	{	pFuncRestore	= (int (__cdecl *)(void))pData;	return 0;	}
	else if(0==_stricmp("SetFuncInvalidate", sCmd))	{	pFuncInvalidate	= (int (__cdecl *)(void))pData;	return 0;	}
	else if(0==_stricmp("SetFuncFrameMove", sCmd))	{	pFuncFrameMove	= (int (__cdecl *)(void))pData;	return 0;	}
	else if(0==_stricmp("SetFuncRender", sCmd))		{	pFuncRender		= (int (__cdecl *)(void))pData;	return 0;	}
	
	return 0;
}