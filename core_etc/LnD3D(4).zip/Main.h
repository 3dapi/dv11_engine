// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


// Custom D3D vertex format used by the vertex buffer
struct VtxN
{
    D3DXVECTOR3 position;       // vertex position
    D3DXVECTOR3 normal;         // vertex normal

	enum{ FVF = (D3DFVF_XYZ|D3DFVF_NORMAL),};
};




struct UserInput
{
    // TODO: change as needed
    BOOL bRotateUp;
    BOOL bRotateDown;
    BOOL bRotateLeft;
    BOOL bRotateRight;
};


class CMain : public CD3DApplication
{
    LPDIRECT3DVERTEXBUFFER9 m_pVB;                  // Vextex buffer 
    ID3DXFont*              m_pD3DXFont;            // D3DX font    

    UserInput               m_UserInput;            // Struct for storing user input 

    FLOAT                   m_fWorldRotX;           // World rotation state X-axis
    FLOAT                   m_fWorldRotY;           // World rotation state Y-axis

protected:
    virtual HRESULT Init();
    virtual HRESULT Destroy();

    virtual HRESULT Restore();
    virtual HRESULT Invalidate();

    virtual HRESULT FrameMove();
    virtual HRESULT Render();



    HRESULT RenderText();

    void    UpdateInput( UserInput* pUserInput );

public:
	CMain();
    LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );


};


extern CMain* g_pApp;

#endif



