// ClientCtrl.h: interface for the CNetClient class.
//
//////////////////////////////////////////////////////////////////////
#pragma once

#include "IOBuffer.h"
#include <Nave/CriticalSection/Sync.h>

namespace Nave { namespace Net {

	#define MAX_PACKET				128		// �� 128���� Packet ����.

	#define WM_CONNECT				WM_APP + 0x1001
	#define WM_RECV_MSG				WM_APP + 0x1002
	#define WM_SOCK_CLOSE			WM_APP + 0x1003

	typedef struct tag_PacketQueue
	{
		struct INDEX
		{
			INDEX*	pNext;
			CPacket	Packet;
			INDEX()
			{
				pNext = NULL;
				Packet.Init();
			}
		};
	protected:
		INDEX* pList;
		INDEX* pHead;
		INDEX* pTail;
		int		nQueueCnt;
		int		nMaxQueueCnt;

		CriticalSection::CSync cs;
	public:
		tag_PacketQueue()
		{
			pList = NULL;
			pHead = NULL;
			pTail = NULL;
			nQueueCnt = 0;
			nMaxQueueCnt = 0;
		}

		~tag_PacketQueue()
		{
			Release();
		}
		
		VOID Release()
		{
			Nave::CriticalSection::CLive CL(&cs);

			if(pList)
			{
				delete [] pList;
				pList = NULL;
			}
		}

		BOOL Create(int nMAXCnt = 10)
		{
			Nave::CriticalSection::CLive CL(&cs);

			if(nMAXCnt <= 0) return FALSE;

			if(pList)
			{
				delete [] pList;
				pList = NULL;
			}

			nMaxQueueCnt = nMAXCnt;

			if((pList = new INDEX[nMaxQueueCnt]) == NULL)
			{
				nMaxQueueCnt = 0;
				return FALSE;
			}

			for(int i = nMaxQueueCnt - 1; i >= 0 ; i--)
			{
				if( (i+1) == nMaxQueueCnt)
				{
					pList[i].pNext = &pList[0];
					continue;
				}
				pList[i].pNext = &pList[i+1];		
			}
			pHead = pTail = &pList[0];
			return TRUE;
		}

		int GetQueCnt()
		{
			Nave::CriticalSection::CLive CL(&cs);
			return nQueueCnt;
		}

		void Reset()
		{
			Nave::CriticalSection::CLive CL(&cs);
			pHead = pTail = &pList[0];
			nQueueCnt = 0;
		}

		BOOL Add(CPacket& Packet)
		{
			Nave::CriticalSection::CLive CL(&cs);

			if(!pList) return FALSE;
			if(nQueueCnt == nMaxQueueCnt)
			{
				nQueueCnt = 0;
				pHead = pTail = &pList[0];
				return FALSE;
			}
			//if(szData[0] == NULL) return FALSE;
			if(Packet.m_Header.Size <= 0) return FALSE;
			if(Packet.m_Header.Size >= DEF_MAXPACKETSIZE) return FALSE;

			// Head�� Size�� Header ������ ������ �������.
			int PacketSize = Packet.m_Header.Size-sizeof(Packet.m_Header);

			// ���缭 ����.. 
			CopyMemory(&pTail->Packet.m_Header, &Packet.m_Header, sizeof(Packet.m_Header));
			CopyMemory(pTail->Packet.m_Packet,Packet.m_Packet,PacketSize);
			pTail->Packet.m_Packet[PacketSize] = 0;


			pTail = pTail->pNext;

			InterlockedIncrement((LONG*)&nQueueCnt);

			return TRUE;
		}

		int GetPnt(CPacket** Packet)
		{
			Nave::CriticalSection::CLive CL(&cs);

			if(!pList) return -1;
			if(nQueueCnt == 0) return -1;

			int nLen = -1;
			*Packet = &pHead->Packet;
			nLen = pHead->Packet.m_Header.Size;

			return nLen;
		}
		void Del()
		{
			Nave::CriticalSection::CLive CL(&cs);

			if(!pList) return;
			if(nQueueCnt == 0) return;

			int nLen = -1;

			pHead->Packet.Init();
			pHead = pHead->pNext;

			InterlockedDecrement((LONG*)&nQueueCnt);
		}

		int Get(CPacket& Packet)
		{
			Nave::CriticalSection::CLive CL(&cs);

			if(!pList) return -1;
			if(nQueueCnt == 0) return -1;

			int nLen = -1;
			int PacketSize = pHead->Packet.m_Header.Size-sizeof(pHead->Packet.m_Header);

			CopyMemory(&Packet.m_Header, &pHead->Packet.m_Header, sizeof(Packet.m_Header));
			CopyMemory(Packet.m_Packet, pHead->Packet.m_Packet, PacketSize);
			Packet.m_Packet[PacketSize] = 0;

			nLen = Packet.m_Header.Size;

			pHead->Packet.Init();
			pHead = pHead->pNext;

			InterlockedDecrement((LONG*)&nQueueCnt);

			return nLen;
		}
	} SPacketQueue;

	class CNetClient  
	{
	public:
		HWND				m_hWnd;				// �θ� ������ �ڵ� 

		SOCKET				m_hSocket;			// Ŭ���̾�Ʈ ���� 
		UINT				m_nPort;			// ��Ʈ 
		char				m_strIPAddr[20];	// Server IP���� 

		HANDLE				m_hRecvThread;		// Recv ������ �ڵ� 
		SPacketQueue		m_RecvQueue;		// Recv Queue

		SPacketQueue		m_SendQueue;		// Send Queue

		WSAEVENT			m_hEvent;			// ��Ʈ��ũ �̺�Ʈ �ڵ鷯 

		BOOL				m_bClose;
		BOOL				m_bConnect;			// ���� ���� �÷��� 

		CPacketIOBuffer		m_RecvIO;
		CPacket				m_RecvPacket;

		char				m_RecvBuffer[DEF_MAXPACKETSIZE];

		HANDLE				m_hEventThread;		// Recv ������ �ڵ� 

	private:
		static DWORD WINAPI EventThreadProc(LPVOID lParam);	// Main Thread 
		static DWORD WINAPI RecvThreadProc(LPVOID lParam);	// Main Thread 

		VOID	OnReadPacketData();
	
		int		GetQueCnt();
		int		GetPacket(CPacket** Packet);
		void	PopPacket();
		
		void	UpdateQue();

		//////////////////
		// MessageHandling
		BOOL OnConnect();					// On Connect ��ȣ��	
		BOOL OnClose();						// On Close   ��ȣ��

		/////////////////
		// ���� ó�� �Լ� 
		BOOL Connect();										// C-S ���� 
		BOOL WinSockInit();

	protected:
		virtual void OnSocketEvent(DWORD dID, DWORD dEvent) {};

		BOOL NetworkEventHanlder(long lEvent);						// �޼��� �б� �Լ� 

	public:
		void	GetLocalIP(char* LocalIP);

		BOOL	IsConnect() { return m_bConnect; }

		virtual BOOL	SendPost(CPacket& Packet);

		// ���� �����Լ�.
		BOOL	Init(HWND hWnd, char* szIP, int nPort);	// �ʱ�ȭ 
		virtual void	Disconnect();

		virtual void	Update();
		virtual void	ProcessPacket(CPacket* Packet, int PacketLen) { };

		void	Stop();									// Ŭ���̾�Ʈ ���� 
		void	CloseAll();
		void	SetParent(HWND hWnd);

	public:
		CNetClient();
		virtual ~CNetClient();

	};


}}