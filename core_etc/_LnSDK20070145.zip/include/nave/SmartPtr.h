#pragma once

#include <windows.h>
#include <stdio.h>
#include <assert.h>

/*************************************************************************
// ����..
#include "SmartPtr.h"

class Test
{
public:
	Test()
	{
		printf("Test::Test()\n");
	}
	~Test()
	{
		printf("Test::~Test()\n");
	}
};

int _tmain(int argc, _TCHAR* argv[])
{
	printf("new Test\n");

	SmartPtr<Test> a = new Test();
	SmartPtr<Test> b = new Test();
	a = new Test();
	a = b;

	printf("return main\n");
	return 0;
}

*************************************************************************/

/*************************************************************************
 FILE :			SmartPtr.h
 Date :			20 December 1998

 Author :		Stefan Tchekanov  (stefant@iname.com)

 Description:	The template class SmartPtr performs Reference Counting
				Garbage Collection and/or Object Level Thread Synchronization.

 Classes :		SmartPtr		-	The SmartPtr class
				RefCountPtr		-	Reference Counting Garbage Collection
				SmartPtrBase	-	The base of all above classes. Used as a common base so
									an assignment between different pointers is able.
				
				For examples how to use these classes look at the end
				of this file.

				Implementation classes that SHOULD NEVER be used directly.
 					CRefCountRep

Copyright notice:
	Written by Stefan Tchekanov (stefant@iname.com)
	Copyright(c) 1998,1999,2000

This code may be used in compiled form in any way you desire. This
file may be redistributed unmodified by any means PROVIDING it is 
not sold for profit without the authors written consent, and 
providing that this notice and the authors name is included. If 
the source code in this file is used in any commercial application 
then a simple email would be nice.

This file is provided "as is" with no expressed or implied warranty.
The author accepts no liability if it causes any damage to your
computer.

*************************************************************************/
/* #    Revisions    # */

/*************************************************************************
  REVISION ON 7.January.2000 14:31:34  By Stefan Tchekanov
 
  Comments  : SmartPtr objects can point to objects of other types
			  not only to objects of their type.
 
 *************************************************************************/


/*************************************************************************
  REVISION ON 09 April 1999 11:24:38 By Stefan Tchekanov
 
  Comments  : SmartPtr objects now have size of a real pointer, Which
			  means that passing a SmartPtr as a function parameter is 
			  as efficient as passing an int or a pointer.
 
 *************************************************************************/


/////////////////////////////////////////////////////////////////////////////
//	If you wrap a non-class with the SmartPtr class, you will receive 
//	this warning. i.e.  int, short, etc...
//	It is a warning you may ignore.
#pragma warning( disable : 4284 )
//
//	This warning is generated when compiling in debug mode.
//	Debug symbols cannot be longer than 255 but when using templates
//	it is usual to have debug symbols longer tahn 255.
//	You may ignore this warning.
#pragma warning( disable : 4786 )

/////////////////////////////////////////////////////////////////////////////

namespace Nave {

	/////////////////////////////////////////////////////////////////////////////
	//	Representation class just for reference counting
	/////////////////////////////////////////////////////////////////////////////
	template<class T>
	class CRefCountRep {

	//	Constructors and destructor
	public:
		CRefCountRep( const T* ptr );
		~CRefCountRep();


	//	Operations
	public:
		long	incrRefCount();
		long	decrRefCount();

		T*		getPointer() const;
		T*		getRealPointer() const;

		bool	isNull() const;


	//	Implementation
	private:
		T*		m_pRealPtr;
		long	m_counter;
	};
	/////////////////////////////////////////////////////////////////////////////

	template<class T>
	CRefCountRep<T>::CRefCountRep( const T* ptr )
	: m_pRealPtr( (T*)ptr ), m_counter( 0 ) {
	}

	template<class T>
	CRefCountRep<T>::~CRefCountRep() {
		assert( m_counter <= 0 );
		delete	m_pRealPtr;
	}

	template<class T>
	long	CRefCountRep<T>::incrRefCount() {
		return	::InterlockedIncrement( &m_counter );
	}

	template<class T>
	long	CRefCountRep<T>::decrRefCount() {
		return	::InterlockedDecrement( &m_counter );
	}

	template<class T>
	T*	CRefCountRep<T>::getPointer() const {
		return	m_pRealPtr;
	}

	template<class T>
	T*	CRefCountRep<T>::getRealPointer() const {
		return	m_pRealPtr;
	}

	template<class T>
	bool	CRefCountRep<T>::isNull() const {
		return m_pRealPtr == NULL;
	}
	/////////////////////////////////////////////////////////////////////////////



	/////////////////////////////////////////////////////////////////////////////
	//	The SmartPtr class
	/////////////////////////////////////////////////////////////////////////////

	class	SmartPtrBase {
	public:
		SmartPtrBase() : m_rep( NULL )
		{};

		void*	m_rep;
	};
	/////////////////////////////////////////////////////////////////////////////

	//template<class T, class REP, class ACCESS = T*>
	//class SmartPtr : public SmartPtrBase {
	template<class T, class REP = CRefCountRep<T>, class ACCESS = T*>
	class	SmartPtr : public SmartPtrBase {

	//	Constructors and destructor
	public:
		//	Default constructor and destructor
		SmartPtr();
		~SmartPtr();

		//	Copy constructor
		SmartPtr( const SmartPtr& ptr );

		//	Other constructors
		SmartPtr( const T* ptr );
		SmartPtr( const SmartPtrBase& ptr );


	//	Assignment Operators
	public:
		SmartPtr& operator = ( const SmartPtr& ptr );
		SmartPtr& operator = ( const T* ptr );
		SmartPtr& operator = ( const SmartPtrBase& ptr );


	//	Operators
	public:
		ACCESS	operator -> ();
		T&		operator * ();

		//	Casting operator
		operator T* ();

		//	Comparison Operators
		bool	operator == ( const SmartPtrBase& ptr );
		bool	operator == ( const T* ptr );
		bool	operator != ( const SmartPtrBase& ptr );
		bool	operator != ( const T* ptr );


	//	Attributes
	public:
		bool	IsNull() const;
		long	GetRefCount() const;
		REP*	GetRepPtr() const;


	//	Helper methods
	protected:
		void	CopyFrom( const SmartPtrBase& ptr );
		void	CopyFrom( const T* ptr );


	//	Implementation
	private:
		void	IncrRefCount();
		void	DecrRefCount();
	};
	/////////////////////////////////////////////////////////////////////////////
			
	template<class T, class REP, class ACCESS>
	SmartPtr<T,REP,ACCESS>::SmartPtr()
	{
	}
	template<class T, class REP, class ACCESS>
	SmartPtr<T,REP,ACCESS>::~SmartPtr()
	{
		DecrRefCount();
	}
	template<class T, class REP, class ACCESS>
	SmartPtr<T,REP,ACCESS>::SmartPtr( const SmartPtr& ptr )
	{
		CopyFrom( ptr );
	}
	template<class T, class REP, class ACCESS>
	SmartPtr<T,REP,ACCESS>::SmartPtr( const T* ptr )
	{
		CopyFrom( ptr );
	}
	template<class T, class REP, class ACCESS>
	SmartPtr<T,REP,ACCESS>::SmartPtr( const SmartPtrBase& ptr )
	{
		CopyFrom( ptr );
	}

	template<class T, class REP, class ACCESS>
	void	SmartPtr<T,REP,ACCESS>::CopyFrom( const SmartPtrBase& ptr )
	{
		if( m_rep != ptr.m_rep ) {
			DecrRefCount();
			m_rep = ptr.m_rep;
			IncrRefCount();
		}
	}
	template<class T, class REP, class ACCESS>
	void	SmartPtr<T,REP,ACCESS>::CopyFrom( const T* ptr )
	{
		DecrRefCount();
		m_rep = (ptr != NULL) ? new REP( ptr ) : NULL;
		IncrRefCount();
	}

	template<class T, class REP, class ACCESS>
	SmartPtr<T,REP,ACCESS>& SmartPtr<T,REP,ACCESS>::operator = ( const SmartPtr& ptr ) {
		CopyFrom( ptr );
		return	*this;
	}
	template<class T, class REP, class ACCESS>
	SmartPtr<T,REP,ACCESS>& SmartPtr<T,REP,ACCESS>::operator = ( const T* ptr ) {
		CopyFrom( ptr );
		return	*this;
	}
	template<class T, class REP, class ACCESS>
	SmartPtr<T,REP,ACCESS>& SmartPtr<T,REP,ACCESS>::operator = ( const SmartPtrBase& ptr ) {
		CopyFrom( ptr );
		return	*this;
	}

	template<class T, class REP, class ACCESS>
	ACCESS	SmartPtr<T,REP,ACCESS>::operator -> () {
		assert( ! IsNull() );
		return GetRepPtr()->getPointer();
	}

	template<class T, class REP, class ACCESS>
	T& SmartPtr<T,REP,ACCESS>::operator * () {
		assert( ! IsNull() );
		return *(GetRepPtr()->getRealPointer());
	}

	template<class T, class REP, class ACCESS>
	SmartPtr<T,REP,ACCESS>::operator T* () {
		return	( IsNull() ) ? NULL : GetRepPtr()->getRealPointer();
	}

	template<class T, class REP, class ACCESS>
	bool	SmartPtr<T,REP,ACCESS>::operator == ( const SmartPtrBase& ptr ) {
		return	m_rep == ptr.m_rep;
	}
	template<class T, class REP, class ACCESS>
	bool	SmartPtr<T,REP,ACCESS>::operator == ( const T* ptr ) {
		if( ! IsNull() ) {
			return	GetRepPtr()->getRealPointer() == ptr;
		}
		return	ptr == NULL;
	}
	template<class T, class REP, class ACCESS>
	bool SmartPtr<T,REP,ACCESS>::operator != ( const SmartPtrBase& ptr ) {
		return	m_rep != ptr.m_rep;
	}
	template<class T, class REP, class ACCESS>
	bool SmartPtr<T,REP,ACCESS>::operator != ( const T* ptr ) {
		return	! (operator ==( ptr ));
	}

	template<class T, class REP, class ACCESS>
	bool	SmartPtr<T,REP,ACCESS>::IsNull() const {
		return	m_rep == NULL;
	}

	template<class T, class REP, class ACCESS>
	long	SmartPtr<T,REP,ACCESS>::GetRefCount() const {
		assert( ! IsNull() );
		return	GetRepPtr()->m_counter;
	}

	template<class T, class REP, class ACCESS>
	REP*	SmartPtr<T,REP,ACCESS>::GetRepPtr() const {
		return	(REP*)m_rep;
	}

	template<class T, class REP, class ACCESS>
	void	SmartPtr<T,REP,ACCESS>::IncrRefCount() {
		if( ! IsNull() ) {
			GetRepPtr()->incrRefCount();
		}
	}
	template<class T, class REP, class ACCESS>
	void	SmartPtr<T,REP,ACCESS>::DecrRefCount() {
		if( ! IsNull() ) {
			if( GetRepPtr()->decrRefCount() <= 0 ) {
				REP*	rep = (REP*)m_rep;
				delete	rep;
			}
			m_rep = NULL;
		}
	}
	/////////////////////////////////////////////////////////////////////////////

}