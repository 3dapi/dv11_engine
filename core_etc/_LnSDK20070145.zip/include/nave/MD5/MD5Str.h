#pragma once

namespace Nave { namespace MD5 { 

		class MD5Str
		{
			typedef struct 
			{
				UINT state[4];        /* state (ABCD) */
				UINT count[2];        /* number of bits, modulo 2^64 (lsb first) */
				BYTE buffer[64];      /* input buffer */
			} MD5_CTX;

		public:
			MD5Str(void);
			virtual ~MD5Str(void);

			Nave::String GetString( const char* key, int size );

		protected:
			void MD5Init( MD5_CTX* ctx );
			void MD5Update( MD5_CTX* ctx, BYTE* input, UINT inputlen );
			void MD5Final( BYTE* digest, MD5_CTX* ctx );
		};

} }