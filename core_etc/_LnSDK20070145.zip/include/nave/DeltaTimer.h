#pragma once

#include <windows.h>

namespace Nave {

	/*
		�ð��� �ð� ������ �ð� ���� �������� Ÿ�̸� ��ƾ

		DeltaTimer<float> timer(0, 5);
		float dt = timer.GetTimeDelta();
	*/
	template <typename TPrecision> class DeltaTimer {
		TPrecision freq;
		TPrecision minDelta;
		TPrecision maxDelta;
		__int64 last;
	public:
		DeltaTimer(TPrecision minDelta=0.001, TPrecision maxDelta=0.2) {
			__int64 largo;
			this->minDelta=minDelta;
			this->maxDelta=maxDelta;
			QueryPerformanceFrequency((LARGE_INTEGER*)&largo);

			freq=TPrecision(largo);	
		}

		TPrecision GetAbsoluteTime() {
			__int64 largo;
			QueryPerformanceCounter((LARGE_INTEGER*)&largo);
			return TPrecision((TPrecision)largo / freq);
		}

		TPrecision GetTimeDelta() {
			__int64 largo;
			QueryPerformanceCounter((LARGE_INTEGER*)&largo);
			__int64 diff= largo-last;
			last=largo;
			TPrecision dif=TPrecision((TPrecision)diff / freq);
			if ( dif > maxDelta) dif=maxDelta;
			if ( dif < minDelta) dif=minDelta;
			return dif;

		}
	};

}
