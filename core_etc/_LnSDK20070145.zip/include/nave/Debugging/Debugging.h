#pragma once

#include <stdio.h>
#include <stdarg.h>
#include <string>

#define _VC6

namespace Nave { namespace Debugging {

	// Message�� ����� ������ �ڵ��� �����Ѵ�.
	void SetLogHandel(HWND hListWnd);

	// ȭ�鿡 �ΰ��� ��������
	void EnableLogPrint(bool enable = true);
	// ���Ϸ� �α׸� ��������
	void EnableLogFile(bool enable = true);

	// Message�����쿡 �α׸� ����Ѵ�.
	void LogPrintf( char *msg, ... );
	void LogPrintf( int group, char *msg );
	void LogPrintf( int group, const char* pFile, int pLinenum, const char* pFunc, char *msg );

	void SetLogFile( char *strFile = NULL);

	void SetLogLimit(int limit);
	void SetLogDetail(bool detail);

	void CloseLogFile();

		namespace Private 
		{
			struct Proxy 
			{
				enum Groups {
					Info = 1 << 0,
					Warning = 1 << 1,
					Error = 1 << 2,
					Exception = 1 << 3,
					Important = 1 << 4,
				};
				const char* func;
				const char* file;
				int			linenum;
				int			group;

				Proxy(int pGroup, const char* pFile, int pLinenum, const char* pFunc);
				void Log(const char* msg, ...);
			};
		}

	}
}


/**
Macros that can be used for logging purposes
*/
#ifdef _VC6
	#define NAVE_INFO(LOGMESSAGE) {Nave::Debugging::Private::Proxy(Nave::Debugging::Private::Proxy::Info, __FILE__, __LINE__,"").Log LOGMESSAGE;} 
	#define NAVE_WARNING(LOGMESSAGE) {Nave::Debugging::Private::Proxy(Nave::Debugging::Private::Proxy::Warning,__FILE__, __LINE__,"").Log LOGMESSAGE;} 
	#define NAVE_ERROR(LOGMESSAGE) {Nave::Debugging::Private::Proxy(Nave::Debugging::Private::Proxy::Error,__FILE__, __LINE__,"").Log LOGMESSAGE;} 
	#define NAVE_EXCEPTION(LOGMESSAGE) {Nave::Debugging::Private::Proxy(Nave::Debugging::Private::Proxy::Exception,__FILE__, __LINE__,"").Log LOGMESSAGE;}
	#define NAVE_IMPORTANT(LOGMESSAGE) {Nave::Debugging::Private::Proxy(Nave::Debugging::Private::Proxy::Important,__FILE__, __LINE__,"").Log LOGMESSAGE;} 
#else
	#define NAVE_INFO(LOGMESSAGE) {Nave::Debugging::Private::Proxy(Nave::Debugging::Private::Proxy::Info, __FILE__, __LINE__,__FUNCSIG__).Log LOGMESSAGE;} 
	#define NAVE_WARNING(LOGMESSAGE) {Nave::Debugging::Private::Proxy(Nave::Debugging::Private::Proxy::Warning,__FILE__, __LINE__,__FUNCSIG__).Log LOGMESSAGE;} 
	#define NAVE_ERROR(LOGMESSAGE) {Nave::Debugging::Private::Proxy(Nave::Debugging::Private::Proxy::Error,__FILE__, __LINE__,__FUNCSIG__).Log LOGMESSAGE;} 
	#define NAVE_EXCEPTION(LOGMESSAGE) {Nave::Debugging::Private::Proxy(Nave::Debugging::Private::Proxy::Exception,__FILE__, __LINE__,__FUNCSIG__).Log LOGMESSAGE;}
	#define NAVE_IMPORTANT(LOGMESSAGE) {Nave::Debugging::Private::Proxy(Nave::Debugging::Private::Proxy::Important,__FILE__, __LINE__,__FUNCSIG__).Log LOGMESSAGE;} 
#endif