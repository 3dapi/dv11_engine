#pragma once

#include <string>
#include <d3dx9math.h>

namespace Nave {

	/* basic value types */
	typedef char			   int8;
	typedef short			   int16;
	typedef int                int32;
	typedef __int64            int64;

	typedef unsigned char      uint8;		// 0 ~ 255
	typedef unsigned short int uint16;		// 0 ~ 65535
	typedef unsigned int       uint32;		// 0 ~ 
	typedef unsigned __int64   uint64;		// 0 ~ 

	typedef std::string		   String;

	typedef D3DXVECTOR3		   float3;		// 3vector float
	typedef D3DXVECTOR2		   float2;		// 2vector float
}