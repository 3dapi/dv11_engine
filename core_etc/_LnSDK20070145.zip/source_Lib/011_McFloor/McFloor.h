// Interface for the CMcFloor class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCFLOOR_H_
#define _MCFLOOR_H_

#include <windows.h>

class CMcFloor
{
protected:
	PDEV	m_pDev;
	PDTX	m_pTx;

public:
	CMcFloor();
	virtual ~CMcFloor();
	
	INT		Create(PDEV pDev, PDTX	pTx=NULL);
	void	Destroy();

	INT		FrameMove();
	void	Render();

};

#endif
