// Interface for the CLnEuclid class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _LNEUCLID_H_
#define _LNEUCLID_H_

//class CLnEuclid
//{
//public:
//	CLnEuclid();
//	virtual ~CLnEuclid();
//
//};

#pragma warning( disable : 4786)

#include <vector>

#include <windows.h>
#include <stdio.h>
#include <d3dx9math.h>


typedef D3DXVECTOR2								VEC2;
typedef	D3DXVECTOR3								VEC3;
typedef D3DXVECTOR4								VEC4;
typedef D3DXMATRIX								MATA;
typedef D3DXQUATERNION							QUAT;
typedef D3DXPLANE								DPLN;



#define ONE_RADtoDEG	57.295779513082321f
#define ONE_DEGtoRAD	0.0174532925199433f
#define PI_RAD			3.1415926535897932f
#define DEG90toRAD		1.5707963267948966f
#define RADtoDEG(p)		( (p)*ONE_RADtoDEG)
#define DEGtoRAD(p)		( (p)*ONE_DEGtoRAD)


#define LN_ROUNDING_DELTA	0.0001f



//2D, or 3D Math
struct INT2
{
	union	{	struct	{	INT x, y;	};	INT m[2];	};
	INT2();
	INT2(INT X,INT Y);
	operator INT* ();
	operator const INT* () const;
};


struct VEC2i : public INT2
{
	VEC2i();
	VEC2i(INT _x,INT _y);
	VEC2i(const VEC2i& rhs );
	VEC2i(const INT *_m );
	VEC2i(D3DXVECTOR2 p);

	operator INT*();
	operator const INT*() const;
	
	bool operator==(const VEC2i& v) const;
	bool operator!=(const VEC2i& v) const;

	const VEC2i& operator=(const VEC2i& rhs);

	// assignment operators
	VEC2i& operator+=(const VEC2i& rhs);
	VEC2i& operator-=(const VEC2i& rhs);
	VEC2i& operator*=(INT f );
	VEC2i& operator/=(INT f );

	// unary operators
	VEC2i operator+() const;
	VEC2i operator-() const;

	// binary operators
	VEC2i operator+(const VEC2i& rhs) const;
	VEC2i operator-(const VEC2i& rhs) const;
	VEC2i operator*(const INT& f) const;
	VEC2i operator/(const INT& f) const;

	friend VEC2i operator*(INT f,const VEC2i& v){	return VEC2i(f * v.x, f * v.y);		}
};


typedef	std::vector<VEC2i>	lsVEC2i;
typedef	lsVEC2i::iterator	itVEC2i;

struct INT3
{
	union{	struct{	INT x, y, z;	};	INT m[3];};

	INT3();
	INT3(INT X,INT Y,INT Z);
	operator INT* ();
	operator const INT* () const;
};

struct VEC3i : public INT3
{
	VEC3i();
	VEC3i(const INT *_m);
	VEC3i(const VEC3i& rhs);
	VEC3i(INT _x,INT _y, INT _z);
	VEC3i(const D3DXVECTOR3 p);
	VEC3i(FLOAT _x, FLOAT _y, FLOAT _z);
	
	operator INT*();
	operator const INT*() const;

	bool operator==(const VEC3i& v) const;
	bool operator!=(const VEC3i& v) const;

	const VEC3i& operator=(const VEC3i& rhs);
	
	VEC3i& operator+=(const VEC3i& v);
	VEC3i& operator-=(const VEC3i& v);
	VEC3i& operator*=(INT f );
	VEC3i& operator/=(INT f );
	
	VEC3i operator+() const;
	VEC3i operator-() const;
	
	VEC3i operator+(const VEC3i& v)const;
	VEC3i operator-(const VEC3i& v)const;
	VEC3i operator*(INT f) const		;
	VEC3i operator/(INT f) const		;
	
	friend VEC3i operator*(INT f,const VEC3i& v)
	{	return VEC3i(f * v.x, f * v.y, f * v.z);	}
};


typedef	std::vector<VEC3i>	lsVEC3i;
typedef	lsVEC3i::iterator	itVEC3i;


struct INT4
{
	union	{	struct	{	INT x, y, z, w;	};	INT m[4];	};

	INT4();
	INT4(INT X,INT Y,INT Z,INT W);
	operator INT* ();
	operator const INT* () const;
};


struct VEC4i : public INT4
{
	VEC4i();
	VEC4i(const INT *_m );
	VEC4i(const VEC4i& r);
	VEC4i(INT X,INT Y,INT Z,INT W);
	VEC4i(const D3DXVECTOR4 p);
	
	operator INT*();
	operator const INT*() const;

	bool operator==(const VEC4i& v) const;
	bool operator!=(const VEC4i& v) const;

	const VEC4i& operator=(const VEC4i& rhs);
	
	// assignment operators
	VEC4i& operator+=(const VEC4i& v);
	VEC4i& operator-=(const VEC4i& v);
	VEC4i& operator*=(INT f )		;
	VEC4i& operator/=(INT f )		;
	
	// unary operators
	VEC4i operator+() const			;
	VEC4i operator-() const			;
	
	// binary operators
	VEC4i operator+(const VEC4i& v)const;
	VEC4i operator-(const VEC4i& v)const;
	VEC4i operator*(INT f) const		;
	VEC4i operator/(INT f) const		;
	
	friend VEC4i operator*(INT f,const VEC4i& v)
	{	return VEC4i(f*v.x,f*v.y,f*v.z,f*v.w);	}
};


typedef	std::vector<VEC4i>	lsVEC4i;
typedef	lsVEC4i::iterator	itVEC4i;



struct WORD2
{
	union{	struct{WORD x, y;	};	WORD m[2];	};

	WORD2();
	WORD2(WORD X,WORD Y);
	operator WORD* ();
	operator const WORD* () const;
};

struct VEC2w : public WORD2
{
	VEC2w();
	VEC2w(WORD X,WORD Y);

};

typedef	std::vector<VEC2w>	lsVEC2w;
typedef	lsVEC2w::iterator	itVEC2w;


struct WORD3
{
	union{	struct{	WORD x, y, z;	};	WORD m[3];};

	WORD3();
	WORD3(WORD X,WORD Y,WORD Z);
	operator WORD* ()			;
	operator const WORD* () const;
};

struct VEC3w : public WORD3
{
	VEC3w();
	VEC3w(WORD X,WORD Y, WORD Z, WORD W);

};

typedef	std::vector<VEC3w>	lsVEC3w;
typedef	lsVEC3w::iterator	itVEC3w;



struct WORD4
{
	union{	struct{	WORD x,y,z,w;	};	WORD m[4];	};

	WORD4();
	WORD4(WORD X,WORD Y,WORD Z,WORD W);
	operator WORD* ();
	operator const WORD* () const;
};

struct VEC4w : public WORD4
{
	VEC4w();
	VEC4w(WORD X,WORD Y, WORD Z, WORD W);

};

typedef	std::vector<VEC4w>	lsVEC4w;
typedef	lsVEC4w::iterator	itVEC4w;



struct DOUBLE2
{
	union	{	struct	{	DOUBLE x, y;	};	DOUBLE m[2];	};
	
	DOUBLE2();
	DOUBLE2(DOUBLE X,DOUBLE Y);
};


struct DOUBLE3
{
	union	{	struct	{	DOUBLE x, y, z;	};	DOUBLE m[3];	};

	DOUBLE3();
	DOUBLE3(DOUBLE X,DOUBLE Y,DOUBLE Z,DOUBLE W);
};


struct DOUBLE4
{
	union	{	struct	{	DOUBLE x, y, z, w;	};	DOUBLE m[4];	};

	DOUBLE4();
	DOUBLE4(DOUBLE X,DOUBLE Y,DOUBLE Z,DOUBLE W);
};


struct LnRc
{
	union	{	struct	{	FLOAT x0, y0, x1, y1;	};	FLOAT m[4];		};
	
	LnRc();
	LnRc(const FLOAT*_m);
	LnRc(const LnRc& _rh );
	
	LnRc( FLOAT fx0,FLOAT fy0,FLOAT fx1,FLOAT fy1);
	
	LnRc( D3DXVECTOR2 p0, D3DXVECTOR2 p1);
	
	D3DXVECTOR2  Get00()	 const	;
	D3DXVECTOR2  Get10()	 const	;
	D3DXVECTOR2  Get01()	 const	;
	D3DXVECTOR2  Get11()	 const	;

	RECT   GetRECT()				;
	D3DRECT GetRectD3()				;
	
	FLOAT	GetWidth()				;
	FLOAT	GetHeight()				;
	D3DXVECTOR2	GetCenter() const	;
	
	// casting
	operator FLOAT*()				;
	operator const FLOAT*() const	;

//	const LnRc& operator=(const LnRc& v)	;

	bool operator==(const LnRc& v) const	;
	bool operator!=(const LnRc& v) const	;
	
	// assignment operators
	LnRc& operator+=(const LnRc& v)			;
	LnRc& operator-=(const LnRc& v)			;
	LnRc& operator*=(FLOAT f )				;
	LnRc& operator/=(FLOAT f )				;
	
	// unary operators
	LnRc operator+() const					;
	LnRc operator-() const					;
	
	// binary operators
	LnRc operator+(const LnRc& v)const		;
	LnRc operator-(const LnRc& v)const		;
	LnRc operator*(FLOAT f) const			;
	LnRc operator/(FLOAT f) const			;
	
	friend LnRc operator*(FLOAT f,const LnRc& v){	return LnRc(f * v.x0, f * v.y0, f * v.x1, f * v.y1);			}
	
	LnRc operator+(const D3DXVECTOR2& v)		;
	LnRc operator-(const D3DXVECTOR2& v)		;
	LnRc operator+=(const D3DXVECTOR2& v)		;
	LnRc operator-=(const D3DXVECTOR2& v)		;

	bool IsValid() const;


	bool IsCollided(const D3DXVECTOR2& v) const;

	bool IsCollided(const LnRc& v) const;
	
	void ClipAgainst(const LnRc& v);
	
	void SetCorrection();

};

typedef	std::vector<LnRc>	lsLnRc;
typedef	lsLnRc::iterator	itLnRc;


struct LnLine																	// ������ ������
{
	// Start Pointer, Tranverse Vector
	union	{	struct	{	D3DXVECTOR3 p;	D3DXVECTOR3 t;	};	FLOAT m[6];	};
	
	LnLine();
	LnLine(const FLOAT*_m)		;
	LnLine(const LnLine& rhs)	;

	LnLine(FLOAT Px,FLOAT Py,FLOAT Pz,FLOAT Tx,FLOAT Ty,FLOAT Tz);
	LnLine(const D3DXVECTOR3& P, const D3DXVECTOR3& T);
	
	// casting
	operator FLOAT*()						;
	operator const FLOAT*() const			;
	
	// unary operators
	LnLine operator+() const				;
	LnLine operator-() const				;

	bool operator==(const LnLine& v) const	;
	bool operator!=(const LnLine& v) const	;
};


typedef	std::vector<LnLine>	lsLnLine;
typedef	lsLnRc::iterator	itLnLine;


struct LnPlane																	// ����� ������
{
	union	{	struct	{	D3DXVECTOR3 n;	FLOAT d;	};	FLOAT m[4];	};			// Normal Vector, -Distance
	
	LnPlane();
	LnPlane(const FLOAT*_m)					;
	LnPlane(const LnPlane& _rh)				;
	LnPlane( FLOAT a,FLOAT b,FLOAT c,FLOAT d);
	
	// casting
	operator FLOAT*()						;
	operator const FLOAT*() const			;

	bool operator==(const LnPlane& v) const	;
	bool operator!=(const LnPlane& v) const	;
};

typedef	std::vector<LnPlane>	lsLnPlane;
typedef	lsLnRc::iterator		itLnPlane;


struct LnSphere																	// ��
{
	union	{	struct	{	D3DXVECTOR3 p;	FLOAT r;};	FLOAT m[4];	};					// center, Radius
	
	LnSphere();
	LnSphere(const FLOAT*_m)				;
	LnSphere(const LnSphere& _rh)			;
	LnSphere( FLOAT X,FLOAT Y,FLOAT Z,FLOAT R);
	
	// casting
	operator FLOAT*()						;
	operator const FLOAT*() const			;

	// unary operators
	LnSphere operator+() const				;
	LnSphere operator-() const				;

	bool operator==(const LnSphere& v) const;
	bool operator!=(const LnSphere& v) const;
};

typedef	std::vector<LnSphere>	lsLnSphere;
typedef	lsLnRc::iterator		itLnSphere;







////////////////////////////////////////////////////////////////////////////////
//
// Hexahedron
//
//					Max
//		5------------7
//	   /|           /|
//	  / |          / |
//	 /  |         /  |
//	1---+--------3   |
//	|   |        |   |
//	|   4--------+---6
//	|  /         |  /
//	| /          | /
//	|/           |/
//	0------------2
//	Min
//
//
////////////////////////////////////////////////////////////////////////////////

struct LnCubeH
{
	union
	{
		D3DVECTOR	m[8];

		struct
		{
			VEC3 _0;	VEC3 _1;	VEC3 _2;	VEC3 _3;
			VEC3 _4;	VEC3 _5;	VEC3 _6;	VEC3 _7;
		};// struct
	}; // union

	
	LnCubeH();
	LnCubeH(const VEC3* _m);
	LnCubeH(	  const VEC3& __0
				, const VEC3& __1
				, const VEC3& __2
				, const VEC3& __3
				, const VEC3& __4
				, const VEC3& __5
				, const VEC3& __6
				, const VEC3& __7);

	operator FLOAT*();
	operator const FLOAT*() const;

//	VEC3* operator[](int nIdx) const
//	{
//		return (VEC3*)(&_0.x + nIdx * sizeof( VEC3));
//	}

	BOOL operator==(const LnCubeH& v) const;
	BOOL operator !=(const LnCubeH& v) const;

	void Set(const VEC3* _m);
	void Set(const LnCubeH& r);
};




////////////////////////////////////////////////////////////////////////////////
//
// Cuboid Axis Aligned Bounding Box
//
//	Edges
//
//					 
//		5------------7(Max)
//	y  /|           /|
//	| / |   z      / |
//	|/  |  /      /  |
//	1------------3   |
//	|   |/       |   |
//	|   4--------|---6
//	|  /         |  /
//	| /          | /
//	|/           |/
//	0(Min)-------2----- x
//	
//
////////////////////////////////////////////////////////////////////////////////

struct LnCubeAA
{
	union
	{
		D3DVECTOR	m[2];

		struct
		{
			VEC3 vcMin;
			VEC3 vcMax;
		};// struct
	}; // union

	
	LnCubeAA();
	LnCubeAA(const VEC3* _m);
	LnCubeAA(const VEC3& _min, const VEC3& _max);
	LnCubeAA(const VEC3& vc0);
	LnCubeAA(FLOAT* _p);
	LnCubeAA(FLOAT x0, FLOAT y0, FLOAT z0, FLOAT x1, FLOAT y1, FLOAT z1);
	
	BOOL operator==(const LnCubeAA& v) const { return vcMin == v.vcMin && v.vcMax == vcMax;}
	BOOL operator!=(const LnCubeAA& v) const { return vcMin != v.vcMin || v.vcMax != vcMax;}
	
	void AddPoint(const VEC3* pV);
	void AddPoint(FLOAT x, FLOAT y, FLOAT z);	
	void AddPoint(const LnCubeAA* b);
	
	void Set(FLOAT x, FLOAT y, FLOAT z);	
	void Set(const VEC3* pV);
	void Set(const LnCubeAA& pV);
	
	BOOL IsInside(const VEC3* pV);
	VEC3 GetCenter() const;
	VEC3 GetExtent() const;
	
	void GetEdge(VEC3* pvcEdge);
	void GetLine(VEC3* pvcLine);	
	BOOL IsEmpty() const;	
	void Repair();
};





////////////////////////////////////////////////////////////////////////////////
//
// Simple Triangle
//
////////////////////////////////////////////////////////////////////////////////

struct LnTri
{
	union
	{
		D3DVECTOR	m[3];

		struct
		{
			VEC3	_0;
			VEC3	_1;
			VEC3	_2;
		};// struct
	}; // union
	

	LnTri();	
	LnTri(const VEC3*_m);
	LnTri(VEC3 __0,VEC3 __1,VEC3 __2);

	LnTri(const LnTri& _r);
	LnTri(const FLOAT* _p);
	
	LnTri(FLOAT _0x,FLOAT _0y,FLOAT _0z
		, FLOAT _1x,FLOAT _1y,FLOAT _1z
		, FLOAT _2x,FLOAT _2y,FLOAT _2z);
	
	// casting
	operator FLOAT*();
	operator const FLOAT*() const;
	
	bool operator==(const LnTri& v) const;
	bool operator!=(const LnTri& v) const;


	void Set(VEC3 __0, VEC3 __1, VEC3 __2);
};



////////////////////////////////////////////////////////////////////////////////
//
// Picking Trangle
//
////////////////////////////////////////////////////////////////////////////////


struct TpckTri
{
	union
	{
		D3DVECTOR	vcT3[3];			// Picking Triangle Positions

		struct
		{
			VEC3	p0;
			VEC3	p1;
			VEC3	p2;
		};
	};

	VEC3		vcPck;					// Picking Position or Bound Center
	FLOAT		fStlSrtR;				// Distance from Camera for Sorting or Bound Radius
	
	// Attributessss.
	INT			nId;					// Triangle Index
	INT			nAt;					// Attribute. Floor, Stair, Wall, Ceiling...
	

	TpckTri();
	TpckTri(FLOAT fR, VEC3* vcC, VEC3* vcT0, VEC3* vcT1, VEC3* vcT2);
	TpckTri(INT nIdx, INT nAttrib, FLOAT fR, VEC3* vcC, VEC3* vcT0, VEC3* vcT1, VEC3* vcT2);

	FLOAT	GetBoundRadius();
	VEC3	GetBoundCenter();
};


typedef std::vector<TpckTri >	lsPckT;
typedef	TpckTri					BndTri;




////////////////////////////////////////////////////////////////////////////////
//
// Pikcing Quad from Outdoor Map
//
////////////////////////////////////////////////////////////////////////////////

struct TpckRc
{
	VEC3	vcQ[4];				// Picking Quad
};

typedef std::vector<TpckRc >	lsMcRect;
typedef lsMcRect::iterator		itMcRect;




////////////////////////////////////////////////////////////////////////////////
//
// Cylinder
//
////////////////////////////////////////////////////////////////////////////////

struct LnCylinder
{
	union{ struct{	VEC3 p;	VEC3 t;	FLOAT r; FLOAT h; };	FLOAT m[8];	};
	
	LnCylinder();	
	LnCylinder(const FLOAT*_m);
	LnCylinder(const LnCylinder& v);
	LnCylinder(FLOAT Px,FLOAT Py,FLOAT Pz,FLOAT Tx,FLOAT Ty,FLOAT Tz, FLOAT R, FLOAT H);
	LnCylinder(const VEC3& P, const VEC3& T, FLOAT R, FLOAT H);
	
	// casting
	operator FLOAT*();
	operator const FLOAT*() const;
	
	// unary operators
	bool operator==(const LnCylinder& v) const;
	bool operator!=(const LnCylinder& v) const;

	// ������ ������ �ݰ�� ����
	void Set(const VEC3& p0, const VEC3& p1, FLOAT R, FLOAT H);
};




#endif

