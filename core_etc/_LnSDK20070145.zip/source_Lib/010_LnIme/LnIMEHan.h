// Interface for the CLnIMEHan class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNIMEHAN_H_
#define _LNIMEHAN_H_


#define MAX_CHAT_LEN	120														// �ִ� ä�� ����


typedef enum tagEImeState
{
	IHS_ENG = 0,
	IHS_KOR,
}EImeState;




class CLnIMEHan
{
protected:
	DWORD	m_dHrshift;
	DWORD	m_dHrctrl;
	DWORD	m_dHrtabback;

	INT		m_iM;																// Max Length
	HWND	m_hWnd;
	INT		m_iMode;															// 0 : ��, ��, ���� ��� ó��, 1 : ���ڸ� ó��
	INT		m_isIME;

	BOOL	m_bEnt;																// Enter Ű Ȯ��
	BOOL	m_bTab;																// Tab Ű Ȯ��
	BOOL	m_bTabB;															// Back Tab
	
	TCHAR	m_sWrd[4];															// �������� ����!!
	TCHAR	m_sStr[512];														// Output buffer..
	TCHAR	m_sOut[512];														// Output buffer..
	BOOL	m_bUse;																// ���� IME�� ����ϰ� �ִ��� üũ
	BOOL	m_bCmp;																// ���� ������������ ��Ÿ���� �÷���

public:
	CLnIMEHan();
	
	LRESULT	MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );

	INT		Init(INT iMode = 0);
	void	Destroy();
	BOOL	IsUse()				{ return m_bUse;	}
	void	SetUse(BOOL use)	{ m_bUse = use;		}

	void	SetMax(INT _iM)		{ m_iM = _iM;		}
	INT		GetMax()			{ return m_iM;		}

	INT		OutStringBeam(TCHAR* sOut);
	void	OutStringStar(TCHAR* sOut);
	INT		OutString(TCHAR* sOut);

	void	SetLength(INT iLen)	{ m_iM = iLen;		}
	INT		GetLength()			{ return m_iM;		}

	INT		GetWrd();
	INT		IsHanStart(INT nIdx);

	void	setIMEmode(INT mode);
	INT		GetHanState()		{ return m_isIME;	}
	void	SetStr(char* pszMsg);

protected:
	void	DeleteChar();
};

#define GIMEHAN			g_pImeHan
extern	CLnIMEHan*		g_pImeHan;

#endif