// Implementation of the CLnIMEHan class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>

#include "LnIMEHan.h"


CLnIMEHan*		g_pImeHan;


CLnIMEHan::CLnIMEHan()
{
	g_pImeHan	=this;

	m_dHrshift	= NULL;
	m_dHrctrl	= NULL;
	m_dHrtabback= NULL;

	m_hWnd		= NULL;
	m_iM		= MAX_CHAT_LEN;

	memset(m_sWrd, 0, sizeof(m_sWrd));
	memset(m_sStr, 0, sizeof(m_sStr));
	memset(m_sOut, 0, sizeof(m_sOut));

	m_bEnt	= FALSE;
	m_bTab	= FALSE;
	m_bTabB = FALSE;
	m_bUse	= TRUE;
	
	m_isIME = 0;
}


INT CLnIMEHan::GetWrd()
{
	if( m_sWrd[0] < 0 )
		return 1;																// �ѱ��� ���(2 ����Ʈ ����)
	
	return 0;																	// �ѱ� �̿��� ����(1 ����Ʈ ����)
}


INT CLnIMEHan::IsHanStart(INT nIdx)
{
	INT  nCnt = 0;

	char cTmp = m_sStr[nIdx];
	
	if( cTmp < 0 )
	{
		for( INT i = nIdx + 1; i < (int)strlen(m_sStr); ++i )
		{
			if( m_sStr[i] >= 0 )
				break;
			++nCnt;	
		}

		if( nCnt % 2 == 0 )
			return 2;															// ����Ʈ ������ �ѱ��̱� �ѵ� ������ �߰��κ�
		else
			return 1;															// ����Ʈ ������ �ѱ��̸� ������ ���ۺκ�
	}

	return 0;
}


INT CLnIMEHan::Init(INT iMode)
{
	m_iMode = iMode;															// ���ڸ��� ó���� ������ ��,��,���� ��� ó���� ������ ����

	m_bEnt	= FALSE;
	m_bTab	= FALSE;
	m_bTabB = FALSE;
	m_bUse	= TRUE;
	
	memset(m_sWrd, 0, sizeof(m_sWrd));
	memset(m_sStr, 0, sizeof(m_sStr));
	memset(m_sOut, 0, sizeof(m_sOut));

	m_iM	= MAX_CHAT_LEN;
	
	return 1;
}


void CLnIMEHan::Destroy()
{
	m_iMode = 0;

	m_bEnt	= FALSE;
	m_bTab	= FALSE;
	m_bTabB = FALSE;
	m_bUse	= FALSE;
	
	memset(m_sWrd, 0, sizeof(m_sWrd));
	memset(m_sStr, 0, sizeof(m_sStr));
	memset(m_sOut, 0, sizeof(m_sOut));

	m_iM	= MAX_CHAT_LEN;
}



LRESULT CLnIMEHan::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	if(!m_bUse && !(uMsg == WM_KEYDOWN || uMsg == WM_IME_KEYDOWN))
		return 0;
	
	m_hWnd = hWnd;

	INT  len;
	HIMC hIMC;			
	
	switch (uMsg)
	{
		case WM_IME_KEYDOWN :
		case WM_KEYDOWN :
			if (((lParam >> 16) & 0xff) == 0xf2)
			{
				m_isIME ^= 1;

			}
			break;		

		case WM_COMMAND:
		{
			WPARAM wLo = LOWORD(wParam);

			if(m_dHrshift && m_dHrshift == wLo)
			{
				return 0;
			}

			if(m_dHrctrl && m_dHrctrl == wLo)
			{
				return 0;
			}

			if(m_dHrtabback && m_dHrtabback == wLo)
			{
				m_bTab = FALSE;
				m_bTabB= TRUE;
				return 1;
			}
			
			return 0;
		}
		
		case WM_IME_STARTCOMPOSITION:											//IMEâ ���ֱ�.
			return 1;

		case WM_IME_COMPOSITION:												// �۾� ���� ��
		{
			if( m_iMode == 1 )
				break;															// ���� ���� ���� ����
			
			hIMC = ImmGetContext(hWnd);											// Get IME Handle
			
			if (lParam & GCS_RESULTSTR)
			{
				// �۾��� ������ �Ǿ�����
				if ((len = ImmGetCompositionString(hIMC, GCS_RESULTSTR, NULL, 0)) > 0)
				{
					// ���� IME�� ��Ʈ�� ���̸� ��´�;
					ImmGetCompositionString(hIMC, GCS_RESULTSTR, m_sWrd, len);

					if( (int)strlen(m_sStr) <= m_iM )
						(int)strcat(m_sStr, m_sWrd);

					memset(m_sWrd,0, sizeof(m_sWrd));
				}
			}
			
			else if (lParam & GCS_COMPSTR)  // �������̸�;
			{
				len = ImmGetCompositionString(hIMC, GCS_COMPSTR, NULL, 0);		// �������� ���̸� ��´�.
				ImmGetCompositionString(hIMC, GCS_COMPSTR, m_sWrd, len);		// str��  �������� ���ڸ� ��´�.
			}
			
			ImmReleaseContext(hWnd, hIMC);										// IME �ڵ� ��ȯ
			
			return 1;
		}
		
		case WM_CHAR:
		{
			switch(wParam)
			{
				case VK_BACK:
					DeleteChar();
					break;

				case VK_ESCAPE:
//					ZeroMemory(m_sWrd, sizeof(m_sWrd));
//					ZeroMemory(m_sStr, sizeof(m_sStr));
					break;
			

				case VK_TAB:
				{
					m_bTab = TRUE;
					m_bTabB= FALSE;
					break;
				}
				
				case VK_RETURN:
				{
					m_bEnt = TRUE;
					break;
				}

				default:			
					if( (int)strlen(m_sStr) <= m_iM && wParam>=0x20 && wParam <=0x7E )
					{
						if( m_iMode == 0 )												// ����, ���� ȥ�� ����
							m_sStr[strlen(m_sStr)] = wParam;
						else															// ���� ����
						{
							if( wParam >= 48 && wParam <= 57 )
								m_sStr[strlen(m_sStr)] = wParam;
						}
					}
			}

			break;
		}
	}
	
	return 0;
}




void CLnIMEHan::DeleteChar()
{
	if( strlen(m_sWrd) )
		memset(m_sWrd, 0, sizeof(m_sWrd));
	
	else
	{
		INT iLength = strlen(m_sStr);
		
		if( iLength > 0)
		{
			// �ѱ��� 2����Ʈ �ڵ�...
			if(m_sStr[iLength - 1] < 0)
			{
				m_sStr[iLength - 1] = 0;
				m_sStr[iLength - 2] = 0;
			}
			
			// 1����Ʈ �ڵ��...
			else
				m_sStr[iLength - 1] = 0;
		}
	}
}


INT CLnIMEHan::OutStringBeam(TCHAR* sOut)
{
	strcpy(m_sOut, m_sStr);
	strcat(m_sOut, m_sWrd);
	strcpy(sOut, m_sOut);	

	static DWORD start = timeGetTime();
	static DWORD end;
	
	end = timeGetTime();
	
	if(end-start>1000)
		start = end;
	
	if(end-start>500)
		strcat(sOut, " ");
	
	else
		strcat(sOut, "|");

	return strlen(m_sOut);
}



void CLnIMEHan::OutStringStar(TCHAR* sOut)
{
	TCHAR sOut1[512];
	memset(sOut1, 0, sizeof(sOut1));
	
	strcpy(sOut1, m_sStr);
	strcat(sOut1, m_sWrd);
	
	memset(sOut, '*', strlen(sOut1));
	
	static DWORD start = timeGetTime();
	static DWORD end;
	
	end = timeGetTime();
	
	if(end-start>1000)
		start = end;
	
	if(end-start>500)
		strcat(sOut, "|");

	else
		strcat(sOut, " ");
}


INT CLnIMEHan::OutString(TCHAR* sOut)
{
	strcpy(m_sOut, m_sStr);
	strcat(m_sOut, m_sWrd);
	strcpy(sOut, m_sOut);

	return strlen(m_sOut);
}


void CLnIMEHan::setIMEmode(INT mode) 
{
	switch (mode) 
	{
		case 'ENG' :
			if (!m_isIME)
				return;

			break;
		case 'KOR' :
			if (m_isIME)
				return;

			break;
	}

	m_isIME ^= 1;
	ImmSimulateHotKey(m_hWnd, IME_KHOTKEY_ENGLISH);
}


void CLnIMEHan::SetStr(char* pszMsg)
{
	if( pszMsg && strlen(pszMsg) < 512 )
	{
		strcpy(m_sStr, pszMsg);
	}
}