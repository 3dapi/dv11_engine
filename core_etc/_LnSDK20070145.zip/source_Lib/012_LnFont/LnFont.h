// Interface for the CLnFont class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNFONT2D_H_
#define _LNFONT2D_H_

#pragma warning( disable : 4786)



typedef enum tagEFntAlgn														// Font Align
{
	FNT_ALIGN_H_L	= 0x00000000,												// Horizontal Left align
	FNT_ALIGN_H_C	= 0x00000001,												// Horizontal center
	FNT_ALIGN_H_R	= 0x00000002,												// Horizontal Right align

	FNT_ALIGN_V_T	= 0x00000000,												// vertical Top
	FNT_ALIGN_V_C	= 0x00000004,												// vertical center
	FNT_ALIGN_V_B	= 0x00000008,												// vertical bottom
}EFntAlgn;




struct TlnFnt
{
	INT		iHeight	;															// Height
	INT		iWeight	;															// Weight, Normal, Bold, thin...
	INT		iItalic	;															// Is Italic
	INT		iThckX	;															// Girth of thick X
	INT		iThckY	;															// Girth of thick Y
	DWORD	dString	;															// String color
	DWORD	dGirth	;															// Girth of Font color
	char	sName	[LF_FACESIZE];

	TlnFnt();

	TlnFnt(		char*	_sName								// Font Name
			,	INT		_iHeight=18							// Height
			,	INT		_iWeight=FW_NORMAL					// Weight, Normal, Bold, thin...
			,	INT		_iItalic=0							// Is Italic
			,	INT		_iThckX=1							// Girth of thick X
			,	INT		_iThckY=1							// Girth of thick Y
			,	DWORD	_dString=0xFFFFFFFF					// String color
			,	DWORD	_dGirth=0xFF000099					// Girth of Font color
		);
	

	const TlnFnt& operator=(const TlnFnt& r);	// r: right hand side(rhs)
	const TlnFnt& operator=(const TlnFnt* r);
};


class CLnFont : public IMtFont
{
protected:
	PDEV			m_pDev;														// Device
	PDSP			m_pSprt;													// Sprite
	PDTX			m_pTxD;
	INT				m_iH;														// Font Height
	INT				m_iW;														// String Width
	INT				m_iLen;														// String Length

	std::string		m_sStr;														// String
	RECT			m_rt;														// Texture Rect

	HFONT			m_hFnt;

	DWORD			m_dFrn;														// front color
	DWORD			m_dBck;														// back color
	DWORD			m_dAln;														// Alignment

	INT				m_iTcX;														// thick X
	INT				m_iTcY;														// thick Y

	VEC2			m_vcP;														// String Pos
	VEC2			m_vcA;														// Align pos

public:
	CLnFont();
	virtual ~CLnFont();

	INT		Create(		PDSP	pSprt								// Sprite
					,	char*	sName="Arial"						// Font Name
					,	INT		iHeight=18							// Height
					,	INT		iWeight=FW_NORMAL					// Weight, Normal, Bold, thin...
					,	INT		iItalic=0							// Is Italic
					,	INT		iThckX =0							// Girth of thick X
					,	INT		iThckY =0							// Girth of thick Y
					,	DWORD	dString=0xFFFFFFFF					// String color
					,	DWORD	dGirth =0xFF000099					// Girth of Font color
					);



	INT		Create(PDSP pSprt, const TlnFnt* pFnt);
	void	Destroy();
	INT		SetString(char* sStr);

	void	SetThickX(INT iThickX=1);
	void	SetThickY(INT iThickY=1);
	void	SetThick(INT iThick=1);
	void	SetHeight(INT Height);

	void	SetPos(D3DXVECTOR2 vcPos=D3DXVECTOR2(0, 100));
	void	SetPosAlign(DWORD dwAlign = (FNT_ALIGN_H_L| FNT_ALIGN_V_T));

	INT		SetColor(DWORD	dwFrnt = 0xFF00FFFF,  DWORD	dwBack = 0x00323200);
	INT		SetColorFrnt(DWORD dwFrnt = 0xFF00FFFF);
	INT		SetColorBack(DWORD dwBack = 0xFF333333);
	
	void	DrawTxt(D3DXCOLOR dColor= D3DXCOLOR(1,1,1,1));
	void	DrawTxt(char* pString, CONST D3DXVECTOR2* vcPos=NULL, INT nAlign=FNT_ALIGN_H_L, D3DXCOLOR dColor= D3DXCOLOR(1,1,1,1));

protected:
	INT		SetTexture();
	BYTE*	GetColorFromARGB(DWORD& argb);
};


typedef std::vector<CLnFont*>		lsLnFnt;
typedef lsLnFnt::iterator			itLnFnt;


#endif


