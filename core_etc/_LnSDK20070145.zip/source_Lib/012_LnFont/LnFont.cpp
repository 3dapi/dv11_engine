// Implementation of the CLnFont class.
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning( disable : 4786)

#include <string>
#include <vector>

#include <windows.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnArch.h>
#include <Ln/_Cmm/LnType.h>

#include "LnFont.h"




TlnFnt::TlnFnt()
: iHeight	(12)
, iWeight	(FW_NORMAL)
, iItalic	(0)
, iThckX	(0)
, iThckY	(0)
, dString	(0xFFFFFFFF)
, dGirth	(0xFF000099)
{
	sName[0] =0;
}

TlnFnt::TlnFnt(	char*	_sN						// Font Name
			,	INT		_iHeight				// Height
			,	INT		_iWeight				// Weight, Normal, Bold, thin...
			,	INT		_iItalic				// Is Italic
			,	INT		_iThckX					// Girth of thick X
			,	INT		_iThckY					// Girth of thick Y
			,	DWORD	_dString				// String color
			,	DWORD	_dGirth					// Girth of Font color
			)
			: iHeight	(_iHeight)
			, iWeight	(_iWeight)
			, iItalic	(_iItalic)
			, iThckX	(_iThckX)
			, iThckY	(_iThckY)
			, dString	(_dString)
			, dGirth	(_dGirth)
{
	strcpy(sName, _sN);
}

const TlnFnt& TlnFnt::operator=(const TlnFnt& r)	// r: right hand side(rhs)
{	
	iHeight	= r.iHeight;
	iWeight	= r.iWeight;
	iItalic	= r.iItalic;
	iThckX	= r.iThckX;
	iThckY	= r.iThckY;
	dString	= r.dString;
	dGirth	= r.dGirth;
	strcpy(sName, r.sName);
	return *this;
}

const TlnFnt& TlnFnt::operator=(const TlnFnt* r)
{	
	iHeight	= r->iHeight;
	iWeight	= r->iWeight;
	iItalic	= r->iItalic;
	iThckX	= r->iThckX;
	iThckY	= r->iThckY;
	dString	= r->dString;
	dGirth	= r->dGirth;
	strcpy(sName, r->sName);
	return *this;
}





CLnFont::CLnFont()
{
	m_pDev = NULL;
	m_pSprt= NULL;
	
	m_pTxD	= NULL;
	
	m_hFnt	= NULL;
	
	m_iH	= 12;
	m_iW	= 0;
	m_dFrn = 0xFFFFFFFF;
	m_dBck = 0xFF000099;
	m_iTcX	= 0;
	m_iTcY	= 0;
	
	m_vcP.x = 0;
	m_vcP.y = m_iH-2;
	m_vcA.x = 0;
	m_vcA.y = 0;
}

CLnFont::~CLnFont()
{
	Destroy();
}


INT CLnFont::Create(	PDSP	pSprt											// Sprite
					,	char*	sName											// Font Name
					,	INT		iHeight											// Height
					,	INT		iWeight											// Weight, Normal, Bold, thin...
					,	INT		iItalic											// Is Italic
					,	INT		iThckX											// Girth of thick X
					,	INT		iThckY											// Girth of thick Y
					,	DWORD	dString											// String color
					,	DWORD	dGirth											// Girth of Font color
					)
{
	m_pSprt= pSprt;
	
	if(FAILED(m_pSprt->GetDevice(&m_pDev)))
		return -1;
	
	if(m_hFnt)
	{
		DeleteObject(m_hFnt);
	}
	
	m_iH	= iHeight	;

	m_iTcX	= iThckX	;
	m_iTcY	= iThckY	;
	m_dFrn	= dString	;
	m_dBck	= dGirth	;

	m_hFnt = CreateFont(
		-m_iH
		, 0
		, 0
		, 0
		, iWeight
		, iItalic
		, FALSE
		, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS
		, CLIP_DEFAULT_PRECIS
		, ANTIALIASED_QUALITY
		, FF_DONTCARE
		, sName);
	
	return 1;
}


INT	CLnFont::Create(PDSP pSprt, const TlnFnt* pFnt)
{
	m_pSprt= pSprt;
	
	if(FAILED(m_pSprt->GetDevice(&m_pDev)))
		return -1;
	
	if(m_hFnt)
	{
		DeleteObject(m_hFnt);
	}

	m_iH	= pFnt->iHeight	;

	m_iTcX	= pFnt->iThckX	;
	m_iTcY	= pFnt->iThckY	;
	m_dFrn	= pFnt->dString	;
	m_dBck	= pFnt->dGirth	;

	m_hFnt = CreateFont(
		-m_iH
		, 0
		, 0
		, 0
		, pFnt->iWeight
		, pFnt->iItalic
		, FALSE
		, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS
		, CLIP_DEFAULT_PRECIS
		, ANTIALIASED_QUALITY
		, FF_DONTCARE
		, pFnt->sName);
	
	return 1;
}


void CLnFont::Destroy()
{
	if(m_hFnt)
	{
		DeleteObject(	m_hFnt	);
		m_hFnt	= NULL;
	}
	
	if(	m_pTxD	)
	{
		m_pTxD->Release();
		m_pTxD	= NULL;
	}
	
	if(m_pDev)
	{
		m_pDev->Release();
		m_pDev = NULL;
	}
}


void CLnFont::DrawTxt(D3DXCOLOR dColor)
{
	D3DXVECTOR2 pos;
	
	pos = m_vcP + m_vcA;
	
	if(NULL==m_pTxD)
		return;
	
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	
	if(m_pTxD)
		m_pSprt->Draw(m_pTxD, &m_rt, NULL, NULL, 0, &pos, dColor);
	
	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
}



void CLnFont::DrawTxt(char* pString, CONST D3DXVECTOR2* vcPos, INT nAlign, D3DXCOLOR dColor)
{
	this->SetString(pString);
//	this->SetColorFrnt(dColor);
	this->SetPosAlign(nAlign);

	D3DXVECTOR2 pos;

	if(vcPos)
		m_vcP = *vcPos;

	pos = m_vcP + m_vcA;
	
	if(NULL==m_pTxD)
		return;
	
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_FOGENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	
	if(m_pTxD)
		m_pSprt->Draw(m_pTxD, &m_rt, NULL, NULL, 0, &pos, dColor);
	
	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
}






INT	CLnFont::SetString(TCHAR* sStr)
{
	HDC			hDC=0;
	
	SIZE		sz;
	TEXTMETRIC	tm;
		
	if(NULL ==sStr || 0==strlen(sStr))
	{
		if(m_pTxD)
		{
			m_pTxD->Release();
			m_pTxD	= NULL;
		}
		
		m_iLen= 0;
		
		return 1;
	}
	
	if(m_sStr==sStr)
		return 1;
	
	m_sStr = sStr;
	m_iLen	= m_sStr.length();
	
	hDC = NULL;
	hDC = GetDC(NULL);
	SelectObject(hDC, m_hFnt);													// Parent window�� DC�� �̿��� ��Ʈ���� ��Ȯ�� �ȼ� ����� ��� �´�.
	GetTextExtentPoint32(hDC, m_sStr.c_str(), m_iLen, &sz);
	m_iW = sz.cx;
	
	GetTextMetrics(hDC, &tm);
	m_iW -= tm.tmOverhang;
	ReleaseDC(NULL, hDC);
	
	
	m_iW += m_iTcX*2+1;
	
	return SetTexture();
}


void CLnFont::SetThickX(INT iThickX)
{
	m_iTcX	= iThickX;
}

void CLnFont::SetThickY(INT iThickY)
{
	m_iTcY	= iThickY;
}

void CLnFont::SetThick(INT iThick)
{
	m_iTcX	= m_iTcY = iThick;
}

void CLnFont::SetHeight(INT Height)
{
	m_iH	= Height;
}



void CLnFont::SetPos(D3DXVECTOR2 vcPos)
{
	m_vcP = vcPos;
}


void CLnFont::SetPosAlign(DWORD dwAlign)
{
	m_dAln = dwAlign;
	
	m_vcA.x = 0.f;
	m_vcA.y = 0.f;
	
	if( dwAlign & FNT_ALIGN_H_R)
		m_vcA.x = -m_iW*1.f;
	
	if( dwAlign & FNT_ALIGN_H_C)
		m_vcA.x = -m_iW/2.f;
	
	if( dwAlign & FNT_ALIGN_V_B)
		m_vcA.y = -m_iH*1.f;
	
	if( dwAlign & FNT_ALIGN_V_C)
		m_vcA.y = -m_iH/2.f;
}


INT	CLnFont::SetColor(DWORD dwFrnt,  DWORD dwBack)
{
	bool bUdate =false;

	if(m_dFrn != dwFrnt || m_dBck != dwBack)
		bUdate = true;

	if(false == bUdate)
		return 1;

	m_dFrn	= dwFrnt;
	m_dBck	= dwBack;
	
	return SetTexture();
}


INT	CLnFont::SetColorFrnt(DWORD dwFrnt)
{
	bool bUdate =false;

	if(m_dFrn != dwFrnt)
		bUdate = true;

	if(false == bUdate)
		return 1;

	m_dFrn	= dwFrnt;
	
	return SetTexture();
}

INT	CLnFont::SetColorBack(DWORD dwBack)
{
	bool bUdate =false;

	if(m_dBck != dwBack)
		bUdate = true;

	if(false == bUdate)
		return 1;

	m_dBck	= dwBack;
	
	return SetTexture();
}


INT CLnFont::SetTexture()
{
	LPDIRECT3DTEXTURE9			pTxS	= NULL;
	LPDIRECT3DSURFACE9			pSfTxtS	= NULL;
	LPDIRECT3DSURFACE9			pSfTxtD	= NULL;
	D3DSURFACE_DESC	dsc;
	D3DLOCKED_RECT	rt;
	HRESULT			hr;
	INT				i, j;
	HDC				hDC=0;
	
	if(m_pTxD)
	{
		m_pTxD->Release();
		m_pTxD	= NULL;
	}
	
	
	hr = D3DXCreateTexture(m_pDev, m_iW, INT(m_iH + m_iTcY* 4), 1, 0
		, D3DFMT_X1R5G5B5, D3DPOOL_MANAGED, &pTxS);					// ������ Texture�� �����.
	
	if(FAILED(hr))
		return hr;
	
	hr  = pTxS->GetSurfaceLevel(0, &pSfTxtS);
	hr  = pSfTxtS->GetDesc(&dsc);
	
	pSfTxtS->LockRect(&rt, 0, 0);
	WORD*	pData = (WORD*) rt.pBits;
	memset(pData, 0x00, sizeof(WORD) * dsc.Width * dsc.Height);				// ����� ���������� ĥ�Ѵ�.
	pSfTxtS->UnlockRect();
	
	
	hDC = NULL;																	// ������ �ؽ��翡 DC�� ���� ����.
	pSfTxtS->GetDC(&hDC);
	
	if(!hDC)
	{
		pSfTxtS->ReleaseDC(hDC);
		
		if(	pTxS )
		{
			pTxS->Release();
			pTxS = NULL;
		}
		
		if(	pSfTxtS )
		{
			pSfTxtS->Release();
			pSfTxtS = NULL;
		}
		
		return -1;
	}
	
	SelectObject(hDC, m_hFnt);
	SetBkMode(hDC, TRANSPARENT);
	
	
	COLORREF dBck;
	COLORREF dFrn;
	BYTE*	pClr;
	
	pClr = GetColorFromARGB(m_dBck);
	dBck = RGB( pClr[1],  pClr[2],  pClr[3]);
	
	pClr = GetColorFromARGB(m_dFrn);
	dFrn = RGB( pClr[1],  pClr[2],  pClr[3]);
	
	for(i=-m_iTcX; i<=m_iTcX; ++i)
	{
		for(j=-m_iTcY; j<=m_iTcY ; ++j)
		{
			if(i==0 && i==j)
				continue;
			
			SetTextColor(hDC, dBck );
			TextOut(hDC, m_iTcX+ i, m_iTcY+j, m_sStr.c_str(), m_iLen);
		}
	}
	
	SetTextColor(hDC, dFrn);
	TextOut(hDC, m_iTcX, m_iTcY, m_sStr.c_str(), m_iLen);
	hr = pSfTxtS->ReleaseDC(hDC);
	
	if(FAILED(hr))
		return -1;
	
	
	
	
	
	hr = D3DXCreateTexture(m_pDev, m_iW, INT(m_iH + m_iTcY* 4), 1, 0
		, D3DFMT_A1R5G5B5, D3DPOOL_MANAGED, &m_pTxD);				// ������ �ؽ��縦 �����.
	
	m_pTxD->GetSurfaceLevel(0, &pSfTxtD);
	pSfTxtD->GetDesc(&dsc);
	
	m_rt.left = 0;																// ������ �ؽ����� �������� �巯���� ������ �����Ѵ�.
	m_rt.top = 0;
	m_rt.right = dsc.Width;
	m_rt.bottom = dsc.Height;
	
	hr = D3DXLoadSurfaceFromSurface( pSfTxtD, NULL, NULL,						// ������ �ؽ��縦 ���������� �ű�� �������� ������� ����� �������� �÷�Ű�� �����Ѵ�.
		pSfTxtS,  NULL, NULL,
		D3DX_DEFAULT, 0xFF000000);
	
	if(	pSfTxtS		)
	{
		pSfTxtS->Release();
		pSfTxtS = NULL;
	}
	
	if(	pSfTxtD		)
	{
		pSfTxtD->Release();
		pSfTxtD = NULL;
	}
	
	if(	pTxS )
	{
		pTxS->Release();
		pTxS = NULL;
	}
	
	return 1;
}



// ARGB <--> BGR
BYTE* CLnFont::GetColorFromARGB(DWORD& _argb)
{
	static BYTE argb[4];
	BYTE* pClr = (BYTE*)&_argb;
	
	argb[0] = pClr[3];
	argb[1] = pClr[2];
	argb[2] = pClr[1];
	argb[3] = pClr[0];
	
	return argb;
}



