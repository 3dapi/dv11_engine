// Implementation of the CLnLzo class.
//
////////////////////////////////////////////////////////////////////////////////

#define WANT_LZO_MALLOC 1
#define WANT_LZO_FREAD 1

#include <windows.h>
#include <lzo/lzoconf.h>
#include <lzo/lzo1x.h>

#include <lzo/portab_a.h>
#include <lzo/portab.h>
#include "LnLzo.h"


CLnLzo::CLnLzo()
{
	m_iLenIn	= 0;
	m_iLenOut	= 0;
	m_bDebug	= 0;
	
	m_iLevel	= 1;
	m_iBlock	= 512 * 1024L;
	
	m_pData		= NULL;
}


CLnLzo::~CLnLzo()
{
	Destroy();
}


int CLnLzo::Init()
{
	// Initialize the LZO library
	if (lzo_init() != LZO_E_OK)
	{
		printf("lzo_init() failed\n");
		return -1;
	}
	
	
	return 1;
}


void CLnLzo::Destroy()
{
}


void CLnLzo::Reset()
{
	m_iLenIn	= 0;
	m_iLenOut	= 0;
	m_bDebug	= 0;
	m_pData		= NULL;
}


BYTE* CLnLzo::Compress(INT* iSizeOut, char* sFile)
{
	FILE* pF = fopen(sFile, "rb");
	
	Compress(pF);
	fclose(pF);
	
	*iSizeOut = m_iLenOut;
	
	return m_pData;
}


BYTE* CLnLzo::DeCompress(INT* iSizeOut, char* sFile)
{
	FILE* pF = fopen(sFile, "rb");
	
	DeCompress(pF);
	fclose(pF);
	
	*iSizeOut = m_iLenOut;
	
	return m_pData;
}

void CLnLzo::SetLevel(int iLevel)
{
	m_iLevel = iLevel;
}

void CLnLzo::SetBlockSize(int iSize)
{
	m_iBlock = iSize;
}

INT CLnLzo::GetLevel()
{
	return m_iLevel;
}

INT CLnLzo::GetBlockSize()
{
	return m_iBlock;
}

lzo_uint CLnLzo::GetLenIn()
{
	return m_iLenIn;
}

lzo_uint CLnLzo::GetLenOut()
{
	return m_iLenOut;
}

lzo_bool CLnLzo::GetDebug()
{
	return m_bDebug;
}





// magic file header for lzopack-compressed files
const unsigned char magic[7] = { 0x00, 0xe9, 0x4c, 0x5a, 0x4f, 0xff, 0x1a };


LONG CLnLzo::xread(FILE *fp, lzo_voidp buf, lzo_uint len, lzo_bool allow_eof)
{
	lzo_uint l;
	
	l = (lzo_uint) lzo_fread(fp, buf, len);
	
	if (l > len)
	{
		return -1;
	}
	
	if (l != len && !allow_eof)
	{
		return -1;
	}
	
	m_iLenIn += (lzo_uint) l;
	
	return l;
}


LONG CLnLzo::mem_write(const lzo_voidp buf, lzo_uint len)
{
	INT	iOrg =m_iLenOut;
	
	
	m_iLenOut += (lzo_uint) len;
	
	if(len>0)
	{
		m_pData = (BYTE*)realloc(m_pData, m_iLenOut);
		memcpy(m_pData+iOrg, buf, len);
	}
	
	return len;
}


int CLnLzo::xgetc(FILE *fp)
{
	unsigned char c;
	xread(fp, (lzo_voidp) &c, 1, 0);
	return c;
}

void CLnLzo::mem_writec(int c)
{
	unsigned char cc = (unsigned char) (c & 0xff);
	mem_write((const lzo_voidp) &cc, 1);
}


// read and write portable 32-bit integers

lzo_uint32 CLnLzo::xread32(FILE *fp)
{
	unsigned char b[4];
	lzo_uint32 v;
	
	xread(fp, b, 4, 0);
	v  = (lzo_uint32) b[3] <<  0;
	v |= (lzo_uint32) b[2] <<  8;
	v |= (lzo_uint32) b[1] << 16;
	v |= (lzo_uint32) b[0] << 24;
	return v;
}

void CLnLzo::mem_write32(lzo_xint v)
{
	unsigned char b[4];
	
	b[3] = (unsigned char) ((v >>  0) & 0xff);
	b[2] = (unsigned char) ((v >>  8) & 0xff);
	b[1] = (unsigned char) ((v >> 16) & 0xff);
	b[0] = (unsigned char) ((v >> 24) & 0xff);
	
	mem_write(b, 4);
}




int CLnLzo::Compress(FILE *fi)
{
	int r = 0;
	lzo_bytep	in = NULL;
	lzo_bytep	wrkmem = NULL;
	lzo_uint	in_len;
	lzo_uint	iLenOut;
	lzo_uint32	wrk_len = 0;
	lzo_uint32	flags = 1;			// do compute a checksum
	int			method = 1;         // compression method: LZO1X
	lzo_uint32	checksum;
	
	lzo_bytep	pDataC= NULL;		// Compressed Data
	
	
	m_iLenIn = m_iLenOut = 0;
	
	// Step 1: write magic header, flags & block size, init checksum
	
	mem_write(magic, sizeof(magic));
	mem_write32(flags);
	mem_writec(method);          // compression method
	mem_writec(m_iLevel);           // compression level
	mem_write32(m_iBlock);
	checksum = lzo_adler32(0, NULL, 0);
	
	
	// Step 2: allocate compression buffers and work-memory
	
	in = (lzo_bytep) lzo_malloc(m_iBlock);
	pDataC = (lzo_bytep) lzo_malloc(m_iBlock + m_iBlock / 16 + 64 + 3);
	
	if (m_iLevel == 9)
		wrk_len = LZO1X_999_MEM_COMPRESS;
	else
		wrk_len = LZO1X_1_MEM_COMPRESS;
	
	wrkmem = (lzo_bytep) lzo_malloc(wrk_len);
	
	if (in == NULL || pDataC == NULL || wrkmem == NULL)
	{
		printf("Out of memory\n");
		r = 1;
		goto err;
	}
	
	
	// Step 3: process blocks
	while(1)
	{
		// read block
		in_len = xread(fi, in, m_iBlock, 1);
		
		if (in_len <= 0)
			break;
		
		// update checksum
		checksum = lzo_adler32(checksum, in, in_len);
		
		// clear wrkmem (not needed, only for debug/benchmark purposes)
		if (m_bDebug)
			lzo_memset(wrkmem, 0xff, wrk_len);
		
		// compress block
		if (m_iLevel == 9)
			r = lzo1x_999_compress(in, in_len, pDataC, &iLenOut, wrkmem);
		else
			r = lzo1x_1_compress(in, in_len, pDataC, &iLenOut, wrkmem);
		
		if (r != LZO_E_OK || iLenOut > in_len + in_len / 16 + 64 + 3)
		{
			// this should NEVER happen
			printf("internal error - compression failed: %d\n", r);
			r = 2;
			goto err;
		}
		
		// write uncompressed block size
		mem_write32(in_len);
		
		if (iLenOut< in_len)
		{
			// write compressed block
			mem_write32(iLenOut);
			mem_write(pDataC, iLenOut);
		}
		else
		{
			// not compressible - write uncompressed block
			mem_write32(in_len);
			mem_write(in, in_len);
		}
	}
	
	// write EOF marker
	mem_write32(0);
	
	// write checksum
	mem_write32(checksum);
	
	r = 0;
err:
	lzo_free(wrkmem);
	lzo_free(pDataC);
	lzo_free(in);
	return r;
}


int CLnLzo::DeCompress(FILE *fi)
{
	int				hr = 0;
	lzo_bytep		buf = NULL;
	lzo_uint		buf_len;
	unsigned char	m [ sizeof(magic) ];
	lzo_uint32		flags;
	int				method;
	int				level;
	lzo_uint		block_size;
	lzo_uint32		checksum;
	
	lzo_bytep		pDataD = NULL;				// Decompress Data
	
	
	
	m_iLenIn = m_iLenOut = 0;
	
	// Step 1: check magic header, read flags & block size, init checksum
	
	if (xread(fi, m, sizeof(magic),1) != sizeof(magic) || memcmp(m, magic, sizeof(magic)) != 0)
	{
		printf("header error - this file is not compressed by lzopack\n");
		hr = 1;
		goto err;
	}
	flags = xread32(fi);
	method = xgetc(fi);
	level = xgetc(fi);
	
	if (method != 1)
	{
		printf("header error - invalid method %d (level %d)\n", method, level);
		hr = 2;
		goto err;
	}
	
	block_size = xread32(fi);
	
	if (block_size < 1024 || block_size > 8*1024*1024L)
	{
		printf("error - invalid block size %ld\n", (long) block_size);
		hr= 3;
		goto err;
	}
	
	checksum = lzo_adler32(0,NULL,0);
	
	
	// Step 2: allocate buffer for in-place decompression
	
	buf_len = block_size + block_size / 16 + 64 + 3;
	buf = (lzo_bytep) lzo_malloc(buf_len);
	if (buf == NULL)
	{
		printf("Out of memory\n");
		hr = 4;
		goto err;
	}
	
	
	// Step 3: process blocks
	
	while(1)
	{
		lzo_bytep in;
		lzo_uint in_len;
		lzo_uint iSizeCompressed;
		
		// read uncompressed size
		iSizeCompressed = xread32(fi);
		
		// exit if last block (EOF marker)
		if (iSizeCompressed == 0)
			break;
		
		// read compressed size
		in_len = xread32(fi);
		
		// sanity check of the size values
		if (in_len > block_size || iSizeCompressed > block_size || in_len == 0 || in_len > iSizeCompressed)
		{
			printf("block size error - data corrupted\n");
			hr = 5;
			goto err;
		}
		
		// place compressed block at the top of the buffer
		in = buf + buf_len - in_len;
		pDataD = buf;
		
		// read compressed block data
		xread(fi, in, in_len, 0);
		
		if (in_len < iSizeCompressed)
		{
			// decompress - use safe decompressor as data might be corrupted during a file transfer
			lzo_uint new_len = iSizeCompressed;
			
			hr = lzo1x_decompress_safe(in, in_len, pDataD, &new_len, NULL);
			
			if (hr != LZO_E_OK || new_len != iSizeCompressed)
			{
				printf("compressed data violation\n");
				hr = 6;
				goto err;
			}
			
			// write decompressed block
			mem_write(pDataD, iSizeCompressed);
			
			// update checksum
			if (flags & 1)
				checksum = lzo_adler32(checksum, pDataD, iSizeCompressed);
		}
		else
		{
			// write original (incompressible) block
			mem_write(in, in_len);
			
			// update checksum
			if (flags & 1)
				checksum = lzo_adler32(checksum, in, in_len);
		}
	}
	
	// read and verify checksum
	if (flags & 1)
	{
		lzo_uint32 c = xread32(fi);
		if (c != checksum)
		{
			printf("checksum error - data corrupted\n");
			hr = 7;
			goto err;
		}
	}
	
	hr = 0;
err:
	lzo_free(buf);
	return hr;
}




int CLnLzo::CompressFile(char* sFileIn, char* sFileOut)
{
	int r = 0;
	lzo_bytep in = NULL;
	lzo_bytep g_pDataOut = NULL;
	lzo_bytep wrkmem = NULL;
	lzo_uint in_len;
	lzo_uint g_iLenOut;
	lzo_uint32 wrk_len = 0;
	lzo_uint32 flags = 1;       // do compute a checksum
	int method = 1;             // compression method: LZO1X
	lzo_uint32 checksum;
	
	m_iLenIn = m_iLenOut = 0;
	
	
	FILE *fi = fopen(sFileIn, "rb");
	FILE *fo = fopen(sFileOut, "wb");
	
	if(!fi || !fo)
		return -1;
	
	
	// Step 1: write magic header, flags & block size, init checksum
	
	xwrite(fo, magic, sizeof(magic));
	xwrite32(fo, flags);
	xputc(fo, method);          // compression method
	xputc(fo, m_iLevel);           // compression level
	xwrite32(fo, m_iBlock);
	checksum = lzo_adler32(0, NULL, 0);
	
	
	// Step 2: allocate compression buffers and work-memory
	
	in = (lzo_bytep) lzo_malloc(m_iBlock);
	g_pDataOut = (lzo_bytep) lzo_malloc(m_iBlock + m_iBlock / 16 + 64 + 3);
	
	if (m_iLevel == 9)
		wrk_len = LZO1X_999_MEM_COMPRESS;
	else
		wrk_len = LZO1X_1_MEM_COMPRESS;
	
	wrkmem = (lzo_bytep) lzo_malloc(wrk_len);
	
	if (in == NULL || g_pDataOut == NULL || wrkmem == NULL)
	{
		printf("Out of memory\n");
		r = 1;
		goto err;
	}
	
	
	//  Step 3: process blocks
	
	while(1)
	{
		// read block
		in_len = xread(fi, in, m_iBlock, 1);
		if (in_len <= 0)
			break;
		
		// update checksum
		checksum = lzo_adler32(checksum, in, in_len);
		
		// clear wrkmem (not needed, only for debug/benchmark purposes)
		if (m_bDebug)
			lzo_memset(wrkmem, 0xff, wrk_len);
		
		// compress block
		if (m_iLevel == 9)
			r = lzo1x_999_compress(in, in_len, g_pDataOut, &g_iLenOut, wrkmem);
		else
			r = lzo1x_1_compress(in, in_len, g_pDataOut, &g_iLenOut, wrkmem);
		if (r != LZO_E_OK || g_iLenOut > in_len + in_len / 16 + 64 + 3)
		{
			// this should NEVER happen
			printf("internal error - compression failed: %d\n", r);
			r = 2;
			goto err;
		}
		
		// write uncompressed block size
		xwrite32(fo, in_len);
		
		if (g_iLenOut < in_len)
		{
			// write compressed block
			xwrite32(fo, g_iLenOut);
			xwrite(fo, g_pDataOut, g_iLenOut);
		}
		else
		{
			// not compressible - write uncompressed block
			xwrite32(fo, in_len);
			xwrite(fo, in, in_len);
		}
	}
	
	// write EOF marker
	xwrite32(fo, 0);
	
	// write checksum
	xwrite32(fo, checksum);
	
	r = 0;
	
	fclose(fi);
	fclose(fo);
	
err:
	lzo_free(wrkmem);
	lzo_free(g_pDataOut);
	lzo_free(in);
	return r;
}


int CLnLzo::DeCompressFile(char* sFileIn, char* sFileOut)
{
	int r = 0;
	lzo_bytep buf = NULL;
	lzo_uint buf_len;
	unsigned char m [ sizeof(magic) ];
	lzo_uint32 flags;
	int method;
	int level;
	lzo_uint block_size;
	lzo_uint32 checksum;
	
	
	FILE *fi = fopen(sFileIn, "rb");
	FILE *fo = fopen(sFileOut, "wb");
	
	if(!fi || !fo)
		return -1;
	
	
	m_iLenIn = m_iLenOut = 0;
	
	// Step 1: check magic header, read flags & block size, init checksum
	if (xread(fi, m, sizeof(magic),1) != sizeof(magic) || memcmp(m, magic, sizeof(magic)) != 0)
	{
		printf("header error - this file is not compressed by lzopack\n");
		r = 1;
		goto err;
	}
	
	flags = xread32(fi);
	method = xgetc(fi);
	level = xgetc(fi);
	
	if (method != 1)
	{
		printf("header error - invalid method %d (level %d)\n", method, level);
		r = 2;
		goto err;
	}
	
	block_size = xread32(fi);
	
	if (block_size < 1024 || block_size > 8*1024*1024L)
	{
		printf("error - invalid block size %ld\n", (long) block_size);
		r = 3;
		goto err;
	}
	
	checksum = lzo_adler32(0,NULL,0);
	
	
	// Step 2: allocate buffer for in-place decompression
	
	buf_len = block_size + block_size / 16 + 64 + 3;
	buf = (lzo_bytep) lzo_malloc(buf_len);
	
	if (buf == NULL)
	{
		printf("Out of memory\n");
		r = 4;
		goto err;
	}
	
	
	// Step 3: process blocks
	
	while(1)
	{
		lzo_bytep in;
		lzo_bytep g_pDataOut;
		lzo_uint in_len;
		lzo_uint g_iLenOut;
		
		// read uncompressed size
		g_iLenOut = xread32(fi);
		
		// exit if last block (EOF marker)
		if (g_iLenOut == 0)
			break;
		
		// read compressed size
		in_len = xread32(fi);
		
		// sanity check of the size values
		if (in_len > block_size || g_iLenOut > block_size || in_len == 0 || in_len > g_iLenOut)
		{
			printf("block size error - data corrupted\n");
			r = 5;
			goto err;
		}
		
		// place compressed block at the top of the buffer
		in = buf + buf_len - in_len;
		g_pDataOut = buf;
		
		// read compressed block data
		xread(fi, in, in_len, 0);
		
		if (in_len < g_iLenOut)
		{
			
			// decompress - use safe decompressor as data might be corrupted during a file transfer
			lzo_uint new_len = g_iLenOut;
			
			r = lzo1x_decompress_safe(in, in_len, g_pDataOut, &new_len, NULL);
			
			if (r != LZO_E_OK || new_len != g_iLenOut)
			{
				printf("compressed data violation\n");
				r = 6;
				goto err;
			}
			
			// write decompressed block
			xwrite(fo, g_pDataOut, g_iLenOut);
			
			// update checksum
			if (flags & 1)
				checksum = lzo_adler32(checksum, g_pDataOut, g_iLenOut);
		}
		else
		{
			// write original (incompressible) block
			xwrite(fo, in, in_len);
			
			// update checksum
			if (flags & 1)
				checksum = lzo_adler32(checksum, in, in_len);
		}
	}
	
	// read and verify checksum
	if (flags & 1)
	{
		lzo_uint32 c = xread32(fi);
		if (c != checksum)
		{
			printf("checksum error - data corrupted\n");
			r = 7;
			goto err;
		}
	}
	
	r = 0;
	
	fclose(fi);
	fclose(fo);
	
err:
	lzo_free(buf);
	return r;
}





lzo_uint CLnLzo::xwrite(FILE *fp, const lzo_voidp buf, lzo_uint len)
{
	if (fp != NULL && lzo_fwrite(fp, buf, len) != len)
	{
		fprintf(stderr, "\nwrite error  (disk full ?)\n");
		exit(1);
	}
	m_iLenOut += (lzo_uint) len;
	return len;
}

void CLnLzo::xwrite32(FILE *fp, lzo_xint v)
{
	unsigned char b[4];
	
	b[3] = (unsigned char) ((v >>  0) & 0xff);
	b[2] = (unsigned char) ((v >>  8) & 0xff);
	b[1] = (unsigned char) ((v >> 16) & 0xff);
	b[0] = (unsigned char) ((v >> 24) & 0xff);
	xwrite(fp, b, 4);
}


void CLnLzo::xputc(FILE *fp, int c)
{
	unsigned char cc = (unsigned char) (c & 0xff);
	xwrite(fp, (const lzo_voidp) &cc, 1);
}