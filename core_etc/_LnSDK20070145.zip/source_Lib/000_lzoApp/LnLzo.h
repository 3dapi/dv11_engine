// Interface for the CLnLzo class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNLZO_H_
#define _LNLZO_H_


class CLnLzo
{
protected:
	lzo_uint	m_iLenIn;					// Orginal Size
	lzo_uint	m_iLenOut;					// Destination Size
	lzo_bool	m_bDebug;

	INT			m_iLevel;					// Level
	INT			m_iBlock;					// Block Size

	lzo_bytep	m_pData;					// Output Data


public:
	CLnLzo();
	virtual ~CLnLzo();

	INT			Init();
	void		Destroy();

	// File <--> Memory
	BYTE*		Compress(INT* iSizeOut, char* sFile);
	BYTE*		DeCompress(INT* iSizeOut, char* sFile);

	// File <--> File
	int			CompressFile(char* sFileIn, char* sFileOut);
	int			DeCompressFile(char* sFileIn, char* sFileOut);
	void		Reset();

public:
	void		SetLevel(int iLevel);
	void		SetBlockSize(int iSize);

	INT			GetLevel();
	INT			GetBlockSize();

	lzo_uint	GetLenIn();
	lzo_uint	GetLenOut();
	lzo_bool	GetDebug();

protected:
	int			Compress(FILE *fi);
	int			DeCompress(FILE *fi);

	lzo_uint32	xread32(FILE *fp);
	LONG		xread(FILE *fp, lzo_voidp buf, lzo_uint len, lzo_bool allow_eof);
	int			xgetc(FILE *fp);

	void		xwrite32(FILE *fp, lzo_xint v);
	lzo_uint	xwrite(FILE *fp, const lzo_voidp buf, lzo_uint len);
	void		xputc(FILE *fp, int c);

	void		mem_write32(lzo_xint v);
	LONG		mem_write(const lzo_voidp buf, lzo_uint len);
	void		mem_writec(int c);	
};

#endif