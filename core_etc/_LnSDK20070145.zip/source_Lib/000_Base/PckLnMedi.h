// Media Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNMEDI_H_
#define _PCK_LNMEDI_H_

#pragma comment(lib, "dsound.lib"		)										// Sound


#include <Ln/Medi/MiUtil.h>
#include <Ln/Medi/MiMp3.h>														// Mp3
#include <Ln/Medi/MiMusic.h>													// Music
#include <Ln/Medi/MiSnd.h>														// 2D sound
#include <Ln/Medi/MiSnd3D.h>													// 3D sound
#include <Ln/Medi/MiDShow.h>													// Direct Show

#ifndef _DEBUG
	#pragma comment(lib, "DShowStrmbase"		)								// Direct Show Base
	#pragma comment(lib, "MiDShow.lib"			)								// Direct Show
	#pragma comment(lib, "MiSnd.lib"			)								// Sound
#else
	#pragma comment(lib, "DShowStrmbase_"		)								// Direct Show Base
	#pragma comment(lib, "MiDShow_.lib"			)								// Direct Show
	#pragma comment(lib, "MiSnd_.lib"			)								// Sound
#endif


#endif