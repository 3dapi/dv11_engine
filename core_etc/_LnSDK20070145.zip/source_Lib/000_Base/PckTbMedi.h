// Table Media Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_TBMEDI_H_
#define _PCK_TBMEDI_H_

#include <Ln/Table/TbBase.h>													// Table Base class

#include <Ln/Table/TbMis.h>														// Sound

#ifndef _DEBUG
	#pragma comment(lib, "TbBase.lib"			)								// Table Base
	#pragma comment(lib, "TbMis.lib"			)								// Table Sound
#else
	#pragma comment(lib, "TbBase_.lib"			)								// Table Base
	#pragma comment(lib, "TbMis_.lib"			)								// Table Sound
#endif


#endif