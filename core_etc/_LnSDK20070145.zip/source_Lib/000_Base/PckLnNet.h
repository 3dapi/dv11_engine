// Small Network Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNNET_H_
#define _PCK_LNNET_H_

#pragma comment(lib, "ws2_32.lib"		)										// Winsock
#pragma comment(lib, "mswsock.lib"		)

// Network
#include <Ln/Net/NwUtil.h>
#include <Ln/Net/NwRingBuf.h>
#include <Ln/Net/NwPacket.h>
#include <Ln/Net/ScIocp.h>

#include <Ln/Net/NwIocpSvr.h>
#include <Ln/Net/NwSelectCln.h>
#include <Ln/Net/NwIocpCln.h>
#include <Ln/Net/NwEventCln.h>


#ifndef _DEBUG
	#pragma comment(lib, "LnNet.lib"			)								// Small Network
#else
	#pragma comment(lib, "LnNet_.lib"			)								// Small Network
#endif


#endif