// Util Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNWINDOW_H_
#define _PCK_LNWINDOW_H_


#include <Ln/Window/LnWindow.h>


#ifndef _DEBUG
	#pragma comment(lib, "LnWindow.lib"			)								// Ln Window
#else
	#pragma comment(lib, "LnWindow_.lib"		)
#endif


#endif