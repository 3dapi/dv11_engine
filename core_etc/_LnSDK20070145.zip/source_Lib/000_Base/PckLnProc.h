// Process Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_PROCESS_H_
#define _PCK_PROCESS_H_

#include <Ln/Process/LnProcess.h>												// Process Base


#ifndef _DEBUG
	#pragma comment(lib, "LnProcess.lib"		)								// Process
#else
	#pragma comment(lib, "LnProcess_.lib"		)								// Process	
#endif


#endif