// MODELS Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNMDLS_H_
#define _PCK_LNMDLS_H_

#include <Ln/Mdls/ILnMdl.h>
#include <Ln/Mdls/MtMdl.h>

#ifndef _DEBUG
	#pragma comment(lib, "LnMdls.lib"			)								// Model
#else
	#pragma comment(lib, "LnMdls_.lib"			)								// Model
#endif

#endif