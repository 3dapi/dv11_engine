// Ln Resource Define data.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNRES_H_
#define _LNRES_H_

// For Window Class Name
//
#define EXC_TITLE		"NZ_BLAME"
#define EXC_VER			"0.00.01"
#define EXC_MTX			EXC_TITLE"_"EXC_VER

// Resource String table
// 
#define IDI_MAIN_ICON			101
#define IDR_MAIN_ACCEL			113
#define IDR_MENU				141


#define IDM_CHANGEDEVICE		40010
#define IDM_TOGGLEFULLSCREEN	40011
#define IDM_EXIT				40012
#define IDM_BACK				40013
#define IDM_RETURN				40014
#define IDM_RETURN_CTRL			40015
#define IDM_TAB					40016
#define IDM_TAB_BACK			40017
#define IDM_RETURN_SHIFT		40018
#define IDM_ESC					40019

#endif