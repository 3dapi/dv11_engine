// MD3 Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNMD3_H_
#define _PCK_LNMD3_H_

#include <Ln/Model/AltMdStrt.h>													// Model
#include <Ln/Model/MdMsh.h>
#include <Ln/Model/MdB.h>

#include <Ln/Model/AltMonoRen.h>												// Model Mdl Mono
#include <Ln/Model/AltMono.h>													// Model Mdl Mono Render.
#include <Ln/Model/AltMultiRen.h>												// Model Mdl Multi
#include <Ln/Model/AltMulti.h>													// Model Mdl Multi Render.


#ifndef _DEBUG
	#pragma comment(lib, "LnMdl.lib"			)								// Model
#else
	#pragma comment(lib, "LnMdl_.lib"			)								// Model
#endif


#endif