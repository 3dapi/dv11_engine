// Common Header Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNCOMM_H_
#define _PCK_LNCOMM_H_

#define WIN32_LEAN_AND_MEAN
#define STRICT
#define _WIN32_WINNT			0x0400
#define DIRECTINPUT_VERSION		0x0800


#pragma warning( disable : 4018)
#pragma warning( disable : 4098)
#pragma warning( disable : 4100)
#pragma warning( disable : 4238)
#pragma warning( disable : 4245)
#pragma warning( disable : 4503)
#pragma warning( disable : 4663)
#pragma warning( disable : 4786)


// Static Library
#pragma comment(lib, "shell32.lib"		)
#pragma comment(lib, "comctl32.lib"		)


// STL
#include <vector>
#include <list>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <string>

using namespace std;


#include <winsock2.h>															//For net work...
#include <windows.h>
#include <windowsx.h>
#include <assert.h>
#include <comdef.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <atlbase.h>
#include <io.h>
#include <malloc.h>
#include <math.h>
#include <mmsystem.h>
#include <process.h>
#include <shellapi.h>
#include <shlobj.h>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <tchar.h>
#include <time.h>
#include <wchar.h>

#include <D3D9.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <dxfile.h>
#include <d3dx9mesh.h>
#include <dinput.h>
#include <rmxfguid.h>

#include <direct.h>
#include <d3dx9tex.h>


#include <Ln/_Cmm/LnType.h>														// Base type
#include <Ln/_Cmm/LnRes.h>														// Resource Define
#include <Ln/_Cmm/LnArch.h>														// Architecture
#include <Ln/_Cmm/LnTree.h>														// Three
#include <Ln/_Cmm/LnVtxFmt.h>													// vertex format


#endif