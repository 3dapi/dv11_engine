// ODE Header Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNODE_H_
#define _PCK_LNODE_H_

#include <ode/ode.h>
//#include <drawstuff/_drawstuff.h>


#ifdef _DEBUG
	#pragma comment(lib, "Ode_op_.lib"	)
	#pragma comment(lib, "OdeLib_.lib"	)
//	#pragma comment(lib, "OdeDraw_.lib"	)
#else
	#pragma comment(lib, "Ode_op.lib"	)
	#pragma comment(lib, "OdeLib.lib"	)
//	#pragma comment(lib, "OdeDraw.lib"	)
#endif


#endif