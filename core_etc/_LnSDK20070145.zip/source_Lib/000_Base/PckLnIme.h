// IME Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNIME_H_
#define _PCK_LNIME_H_

#pragma comment(lib, "imm32.lib"		)										// IME

#include <Ln/Font/LnIMEHan.h>

#ifndef _DEBUG
	#pragma comment(lib, "LnIme.lib"			)								// Hangul IME
#else
	#pragma comment(lib, "LnIme_.lib"			)								// Hangul IME
#endif


#endif