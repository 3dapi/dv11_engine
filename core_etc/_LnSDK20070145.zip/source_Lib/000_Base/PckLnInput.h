// Input Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNINPUT_H_
#define _PCK_LNINPUT_H_

#pragma comment(lib, "dinput8.lib"		)										// Direct Input

#include <Ln/Input/LnInput.h>
#include <Ln/Input/LnInputA1.h>
#include <Ln/Input/LnInputD1.h>

#ifndef _DEBUG
	#pragma comment(lib, "LnInput.lib"			)								// Ln Input
#else
	#pragma comment(lib, "LnInput_.lib"			)								// Ln Input
#endif


#endif