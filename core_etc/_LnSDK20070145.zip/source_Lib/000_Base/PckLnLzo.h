// Lzo Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LN_LZO_H_
#define _PCK_LN_LZO_H_

#define WANT_LZO_MALLOC 1
#define WANT_LZO_FREAD 1

#include <windows.h>

#include <lzo/lzoconf.h>
#include <lzo/lzo1x.h>

#include <lzo/portab_a.h>
#include <lzo/portab.h>

#include <lzo/LnLzo.h>


#ifndef _DEBUG
	#pragma comment(lib, "lzo.lib")
	#pragma comment(lib, "LzoApp.lib")
#else
	#pragma comment(lib, "lzo_.lib")
	#pragma comment(lib, "LzoApp_.lib")
#endif


#endif