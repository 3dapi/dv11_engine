// Effect Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNEFT_H_
#define _PCK_LNEFT_H_

#include <Ln/Effect/EfBase.h>
#include <Ln/Effect/EftLoader.h>
#include <Ln/Effect/EfPtcS.h>
#include <Ln/Effect/EfPtcG.h>


#ifndef _DEBUG
	#pragma comment(lib, "LnEft.lib"			)								// Effect
#else
	#pragma comment(lib, "LnEft_.lib"			)								// Effect
#endif


#endif