// Direct3D Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LND3D_H_
#define _PCK_LND3D_H_

#include <Ln/_D3D/D3DEnum.h>
#include <Ln/_D3D/D3DDriver.h>
#include <Ln/_D3D/D3DApp.h>


#ifndef _DEBUG
	#pragma comment(lib, "Ln_D3D9.lib"			)								// DirectX9
#else
	#pragma comment(lib, "Ln_D3D9_.lib"			)								// DirectX9
#endif


#endif