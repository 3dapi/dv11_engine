// Implementation of the Arch class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <d3dx9math.h>

#include "LnType.h"

#include "LnArch.h"


