// Util Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNUTIL_H_
#define _PCK_LNUTIL_H_

#pragma comment(lib, "Version.lib"		)										// DX version Check

#include <Ln/Util/LnString.h>
#include <Ln/Util/LnUtil.h>
#include <Ln/Util/LnUtilDx.h>
#include <Ln/Util/LnUtilDxDiag.h>
#include <Ln/Util/LnUtilFile.h>
#include <Ln/Util/McGrid.h>
#include <Ln/Util/McFloor.h>

#ifndef _DEBUG
	#pragma comment(lib, "LnUtil.lib"			)								// Ln Util
	#pragma comment(lib, "McGrid.lib"			)								// Grid
	#pragma comment(lib, "McFloor.lib"			)								// Floor
#else
	#pragma comment(lib, "LnUtil_.lib"			)								// Ln Util
	#pragma comment(lib, "McGrid_.lib"			)								// Grid
	#pragma comment(lib, "McFloor_.lib"			)								// Floor
#endif


#endif