// Math Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNEUCLID_H_
#define _PCK_LNEUCLID_H_

#include <Ln/Euclid/LnEuclid.h>													// For Geometry
#include <Ln/Euclid/LnMath.h>													// For Functions

#ifndef _DEBUG
	#pragma comment(lib, "LnEuclid.lib"		)									// Ln Math
#else
	#pragma comment(lib, "LnEuclid_.lib"	)									// Ln Math
#endif


#endif