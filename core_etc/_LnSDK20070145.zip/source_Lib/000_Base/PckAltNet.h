// Network Application Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_ALT_NET_H_
#define _PCK_ALT_NET_H_

#include <Nave/Nave.h>
#include <Nave/Token.h>
#include <ALTNetwork/LoginProtocol/Protocol.h>
#include <ALTNetwork/LoginProtocol/NetLogin.h>
#include <ALTNetwork/WorldProtocol/Protocol.h>
#include <ALTNetwork/WorldProtocol/NetWorld.h>

#pragma comment(lib, "Nave.lib"				)
#pragma comment(lib, "Net.lib"				)
#pragma comment(lib, "Debugging.lib"		)
#pragma comment(lib, "Database.lib"			)
#pragma comment(lib, "Crypto.lib"			)
#pragma comment(lib, "LoginProtocol.lib"	)
#pragma comment(lib, "WorldProtocol.lib"	)


#endif