//
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNMDB_H_
#define _PCK_LNMDB_H_

//Base Class
#include <Ln/Model/ILnMdl.h>

//Mesh Class
#include <Ln/Model/MshSolid.h>
#include <Ln/Model/MshQ2.h>
#include <Ln/Model/MshQ3.h>
#include <Ln/Model/MshAlt.h>

// Model Class
#include <Ln/Model/MdBill.h>
#include <Ln/Model/MdSolid.h>
#include <Ln/Model/MdRigid.h>
#include <Ln/Model/MdBone.h>
#include <Ln/Model/MdSkin.h>

// Q2,3 Class
#include <Ln/Model/MdQ2.h>
#include <Ln/Model/MdQ3S.h>
#include <Ln/Model/MdQ3M.h>

// ALT class
#include <Ln/Model/MdAlt.h>

#include <Ln/Model/MtMdl.h>

#ifndef _DEBUG
	#pragma comment(lib, "LnMdB.lib"			)								// Model
#else
	#pragma comment(lib, "LnMdB_.lib"			)								// Model
#endif

#endif