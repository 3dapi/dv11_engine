// Network Game Logic Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_GAMELOGIC_H_
#define _PCK_GAMELOGIC_H_

#include <Ln/Logic/GameLogic.h>													//GameLogic

#ifndef _DEBUG
	#pragma comment(lib, "GameLogic.lib"		)								// Logic
#else
	#pragma comment(lib, "GameLogic_.lib"		)								// Logic
#endif


#endif