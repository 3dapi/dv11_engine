// Camera Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNCAM_H_
#define _PCK_LNCAM_H_

#include <Ln/Camera/LnCam.h>
#include <Ln/Camera/LnCam1P.h>
#include <Ln/Camera/LnCam3P.h>

#ifndef _DEBUG
	#pragma comment(lib, "LnCam.lib"			)
#else
	#pragma comment(lib, "LnCam_.lib"			)								// Ln Camera
#endif


#endif