// Field Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_MAPFLD_H_
#define _PCK_MAPFLD_H_

// Field
#include <Ln/Map/MpBase.h>
#include <Ln/Map/MpTbTx.h>
#include <Ln/Map/MpTbMdB.h>

#include <Ln/Map/MpMsh.h>														// Model Mesh
#include <Ln/Map/MpMdB.h>														// Model Object
#include <Ln/Map/MpObj.h>														// Model Object
#include <Ln/Map/MpMdBLst.h>													// Model List

#include <Ln/Map/MpiLcl.h>
#include <Ln/Map/MpiFld.h>
#include <Ln/Map/McFld.h>

#ifndef _DEBUG
	#pragma comment(lib, "McFld.lib"			)								// Outdoor
#else
	#pragma comment(lib, "McFld_.lib"			)								// Outdoor
#endif


#endif