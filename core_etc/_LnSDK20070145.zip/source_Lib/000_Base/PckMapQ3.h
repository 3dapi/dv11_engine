// Quake3 Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_MAPQ3_H_
#define _PCK_MAPQ3_H_

// Indoor
#include <Ln/Map/Q3Tri.h>
#include <Ln/Map/Q3TxI.h>
#include <Ln/Map/Q3Tx.h>

#include <Ln/Map/Q3Base.h>
#include <Ln/Map/Q3Msh.h>
#include <Ln/Map/Q3Info.h>
#include <Ln/Map/Q3Map.h>
#include <Ln/Map/Q3Bsp.h>

#ifndef _DEBUG
	#pragma comment(lib, "LnQ3Lib.lib"			)								// Indoor
	#pragma comment(lib, "LnQ3Tri.lib"			)								// Indoor Height
#else
	#pragma comment(lib, "LnQ3Lib.lib"			)								// Indoor
	#pragma comment(lib, "LnQ3Tri.lib"			)								// Indoor Height
#endif


#endif