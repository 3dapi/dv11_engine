// Table Model Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_TBMDB_H_
#define _PCK_TBMDB_H_

#include <Ln/Table/TbMdB.h>														// Model Table

#ifndef _DEBUG
	#pragma comment(lib, "TbBase.lib"			)								// Table Base
	#pragma comment(lib, "TbMdl.lib"			)								// Model Table
#else
	#pragma comment(lib, "TbBase_.lib"			)								// Table Base
	#pragma comment(lib, "TbMdl_.lib"			)								// Model Table
#endif


#endif