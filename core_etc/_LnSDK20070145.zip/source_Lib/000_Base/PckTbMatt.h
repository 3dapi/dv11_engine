// Table Matter Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_TBMATT_H_
#define _PCK_TBMATT_H_

#include <Ln/Table/TbBase.h>													// Table Base class

#include <Ln/Table/TbData.h>													// Game Data Table(Excel)
#include <Ln/Table/TbTx.h>														// Texture
#include <Ln/Table/TbFnt.h>														// Font Table
#include <Ln/Table/TbLgt.h>														// Lighting
#include <Ln/Table/TbIt.h>														// Item

#ifndef _DEBUG
	#pragma comment(lib, "TbBase.lib"			)								// Table Base
	#pragma comment(lib, "TbMatt.lib"			)								// Table Matters. Texture, Font, Light, Item, Data, Sound
#else
	#pragma comment(lib, "TbBase_.lib"			)								// Table Base
	#pragma comment(lib, "TbMatt_.lib"			)								// Table Matters. Texture, Font, Light, Item, Data, Sound
#endif


#endif