// Font Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNFONT_H_
#define _PCK_LNFONT_H_

#include <Ln/Font/LnFont.h>

#ifndef _DEBUG
	#pragma comment(lib, "LnFont_.lib"			)								// Ln Font
#else
	#pragma comment(lib, "LnFont.lib"			)								// Ln Font
#endif


#endif