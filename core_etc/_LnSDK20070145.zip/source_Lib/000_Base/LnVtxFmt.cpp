// Implementation of the VtxFmt class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <d3dx9math.h>

#include "LnType.h"

#include "LnVtxFmt.h"

