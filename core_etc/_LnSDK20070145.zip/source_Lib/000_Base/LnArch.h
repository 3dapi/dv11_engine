// Interface for the Architecture classes.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNARCH_H_
#define _LNARCH_H_

#pragma warning(disable : 4786)

#include <vector>

typedef int					INT;
typedef unsigned long		DWORD;
typedef unsigned short		WORD;
typedef float				FLOAT;



// Base Class.
////////////////////////////////////////////////////////////////////////////////

class _CLn	{	public:	virtual ~_CLn(){};	};

class CLnBase : public _CLn														// Base class
{
public:

	union
	{
		struct
		{
			union	{	WORD m_nI1; WORD m_wM;	};
			union	{	WORD m_nI2; WORD m_wS;	};
			union	{	WORD m_nI3; WORD m_wT;	};
			union	{	WORD m_nI4; WORD m_wW;	};
		};

		ULONGLONG m_nId;
	};


	CLnBase(): m_nI1(0xFFFF),m_nI2(0xFFFF),m_nI3(0xFFFF),m_nI4(0xFFFF)	{}
	CLnBase(WORD I1,WORD I2=0xFFFF,WORD I3=0xFFFF,WORD I4=0xFFFF): m_nI1(I1),m_nI2(I2),m_nI3(I3),m_nI4(I4)	{}
	CLnBase(ULONGLONG nId){	m_nId = nId;	}

	void		SetId(WORD I1=0xFFFF,WORD I2=0xFFFF,WORD I3=0xFFFF,WORD I4=0xFFFF){m_nI1=I1;m_nI2=I2;m_nI3=I3;m_nI4=I4;}
	
	void		SetId(ULONGLONG nId=0xFFFF){	m_nId = nId;	}
	
	void		SetId1(WORD nI1=0xFFFF)	{	m_nI1 = nI1;	}
	void		SetId2(WORD nI2=0xFFFF)	{	m_nI2 = nI2;	}
	void		SetId3(WORD nI3=0xFFFF)	{	m_nI3 = nI3;	}
	void		SetId4(WORD nI4=0xFFFF)	{	m_nI4 = nI4;	}

	void		SetM(WORD wM=0xFFFF)	{	m_wM  = wM;		}
	void		SetS(WORD wS=0xFFFF)	{	m_wS  = wS;		}
	void		SetT(WORD wT=0xFFFF)	{	m_wT  = wT;		}
	void		SetW(WORD wW=0xFFFF)	{	m_wW  = wW;		}

	ULONGLONG	GetId()		{	return m_nId;	}

	WORD		GetM()		{	return m_wM;	}
	WORD		GetS()		{	return m_wS;	}
	WORD		GetT()		{	return m_wT;	}
	WORD		GetW()		{	return m_wW;	}

	WORD		GetId1()	{	return m_nI1;	}
	WORD		GetId2()	{	return m_nI2;	}
	WORD		GetId3()	{	return m_nI3;	}
	WORD		GetId4()	{	return m_nI4;	}
};

typedef std::vector<CLnBase>	lsBase;
typedef lsBase::iterator		itBase;



// Rendering Base Class.
////////////////////////////////////////////////////////////////////////////////

class CLnRen : public CLnBase
{
public:
	bool	bFm;																// FrameMove
	bool	bMv;																// FrameMove �ȿ��� Move?
	bool	bUa;																// FrameMove �ȿ��� Animation?

	bool	bRn;																// ������ �� ���ΰ�?
	
	CLnRen() : bFm(1), bMv(1), bUa(1), bRn(1){}
	
	void	SetFrmMov(bool _bFm=true)	{	bFm	= _bFm;						}
	bool	IsFrmMov()					{	return bFm;						}

	void	SetTransfer(bool _bMv=true)	{	bMv	= _bMv;	bFm=true;			}
	bool	IsFTransfer()				{	return bMv;						}

	void	SetUpdate(bool _bUa=true)	{	bUa	= _bUa; bFm=true; bMv=true;	}
	bool	GetUpate()					{	return bUa;						}

	void	SetRender(bool  _bRn=true)	{	bRn	= _bRn;						}
	bool	IsRender()					{	return bRn;						}
};


// Object Base Class.
////////////////////////////////////////////////////////////////////////////////

class CLnObj : public CLnRen
{
public:
	virtual INT	 Init()		{	return 1;	}
	virtual void Destroy()	{				}

	virtual INT	 Restore()	{	return 1;	}
	virtual void Invalidate(){				}

	virtual INT	 FrameMove(){	return 1;	}
	virtual void Render()	{				}
};



// Object Map Base Class.
////////////////////////////////////////////////////////////////////////////////

class CLnMap : public CLnObj
{
public:
	CLnMap(){}
	virtual ~CLnMap(){}

	//���� ���� �������� 1, �����ϸ� <0
	//vcDir =(0, 1, 0)�̸� ���� ���� ������ �� �ִ�.
	virtual INT	 GetPickPos(FLOAT* vcOut, FLOAT* vcPos, FLOAT* vcDir){return 1;}
};




////////////////////////////////////////////////////////////////////////////////
//	Game Phase
//
//	enum EGmPhase
//	{
//		GP_BGN=0,																// ���� ����
//		GP_END=128,																// ���� ��
//		GP_TOT=GP_END+1,														// ���� �� ����
//	};
//	�� ���� ���.
//
////////////////////////////////////////////////////////////////////////////////

class IGmPhase
{
public:
	IGmPhase(){}
	virtual ~IGmPhase(){}

	virtual INT		Init()=0;
	virtual void	Destroy()=0;

	virtual INT		FrameMove()=0;
	virtual void	Render()=0;

	virtual INT		Restore()	{	return 1;	}
	virtual void	Invalidate(){				}
	virtual void	RenderS()	{				}
};




////////////////////////////////////////////////////////////////////////////////
// Define Base Matter Interfase
// 3D ���α׷��� �⺻ ���
//
// 1. Texture
// 2. �̵��: ����, ������
// 3. ��Ʈ
//
////////////////////////////////////////////////////////////////////////////////


// Texture Interface
class IMtTexture
{
public:
	IMtTexture(){}
	virtual ~IMtTexture(){}
};


// Sound, Midi, Show Interface
class IMtMedia
{
public:
	enum EMediaType
	{
		MEDIA_SOUND_	=0x0008,	// 0000 0000 1000
		MEDIA_SOUND_S	=0x0009,	// 0000 0000 1001
		MEDIA_SOUND_3	=0x000A,	// 0000 0000 1010

		MEDIA_MUSIC_	=0x0080,	// 0000 1000 0000
		MEDIA_MUSIC_M	=0x0090,	// 0000 1001 0000
		MEDIA_MUSIC_3	=0x00A0,	// 0000 1010 0000

		MEDIA_SHW_		=0x0800,	// 1000 0000 0000
		MEDIA_SHW_MP3	=0x0900,	// 1001 0000 0000
		MEDIA_SHW_AVI	=0x0A00,	// 1010 0000 0000

		MEDIA_UNKNOWN	=0xFFFFFFFF,
	};

public:
	IMtMedia(){}
	virtual ~IMtMedia(){}

	virtual DWORD	GetType()=0;
	virtual void	Play()=0;
	virtual void	Stop()=0;
	virtual void	Reset()=0;
	virtual void	Pause()=0;
	virtual void	SetVolume(LONG dVol)=0;
	virtual LONG	GetVolume()=0;
	virtual void	SetRepeat(DWORD dRepeat= 0xFFFFFFFF/*INFINITE*/)=0;
	virtual DWORD	GetStatus()=0;
};


// Font Interface
class IMtFont
{
public:
	IMtFont(){}
	virtual ~IMtFont(){}
};

#endif


