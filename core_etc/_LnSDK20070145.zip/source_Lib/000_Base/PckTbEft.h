// Table Effect Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_TBEFT_H_
#define _PCK_TBEFT_H_

#include <Ln/Table/TbBase.h>													// Table Base class

#include <Ln/Table/TbEfFnt.h>													// Effect Font
#include <Ln/Table/TbEfLgt.h>													// Lighting
#include <Ln/Table/TbEfBld.h>													// Billboard
#include <Ln/Table/TbEfPtc.h>													// Particle
#include <Ln/Table/TbEfPrj.h>													// Projectile

#ifndef _DEBUG
	#pragma comment(lib, "TbBase.lib"			)								// Table Base
	#pragma comment(lib, "TbEft.lib"			)								// Table Effects
#else
	#pragma comment(lib, "TbBase_.lib"			)								// Table Base
	#pragma comment(lib, "TbEft_.lib"			)								// Table Effects
#endif


#endif