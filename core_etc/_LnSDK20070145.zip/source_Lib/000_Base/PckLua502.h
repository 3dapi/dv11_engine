// Lua Files.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _PCK_LNLUA502_H_
#define _PCK_LNLUA502_H_

#include <lua/lua.h>
#include <lua/lualib.h>
#include <lua/lauxlib.h>


#ifndef _DEBUG
	#pragma comment(lib, "Lua.lib"				)								// Lua..
	
#else
	#pragma comment(lib, "Lua_.lib"				)								// Lua..
	
#endif


#endif