// Implementation of the CImgTGA class.
//
////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>

#include "ImgTGA.H"


CImgTGA::CImgTGA()
{
	m_bByteSwap	= true;

	m_pF		= NULL;

	m_pColorMap	= NULL;
	m_pData		= NULL;

	memset(&m_Header, 0, sizeof m_Header);
}


CImgTGA::~CImgTGA()
{
//	if(m_pColorMap)
//	{
//		delete [] m_pColorMap;
//		m_pColorMap = NULL;
//	}
	
//	if(m_pData)
//	{
//		delete [] m_pData;
//		m_pData = NULL;
//	}
}



void CImgTGA::SetByteSwap(INT val)
{
	m_bByteSwap = val;
}


INT CImgTGA::GetByteSwap()
{
	return m_bByteSwap;
}


BYTE* CImgTGA::GetMap() const
{
	return m_pColorMap;
}



BYTE* CImgTGA::GetData() const
{
	return m_pData;
}

INT CImgTGA::ImageW()
{
	return m_Header.nImgW;
}

INT CImgTGA::ImageH()
{
	return m_Header.nImgH;
}


INT CImgTGA::ImageD()
{
	return m_Header.nImgD;
}


INT CImgTGA::ImageT()
{
	return m_Header.cImgType;
}




INT CImgTGA::FileRead(char* sFile)
{
	m_pF = fopen(sFile, "rb");

	if (!m_pF)
	{
		printf("TGA_read- Fatal error!\n");
		return -1;
	}

	HeaderRead();
	ColorMapRead();
	DataRead();

	fclose(m_pF);
	m_pF = NULL;

	return 1;
}



INT CImgTGA::FileWrite(char* sFile)
{
	m_pF = fopen(sFile, "wb");

	if (!m_pF)
	{
		printf("TGA_Write - Fatal error!\n");
		return -1;
	}

	HeaderWrite();
	ColorMapWrite();
	DataWrite();

	fclose(m_pF);
	m_pF = NULL;

	return 1;
}


//#define LN_RGBA(r,g,b,a)((DWORD)(((BYTE)(r)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(b))<<16)(((DWORD)(BYTE)(a))<<24)))

INT CImgTGA::FileWrite32(char* sFile, byte* pPixel, int ImgW, int ImgH, int ImgD)
{
	m_pF = fopen(sFile, "wb");

	if (!m_pF)
	{
		printf("TGA_Write - Fatal error!\n");
		return -1;
	}


	int nSize	=ImgW* ImgH;
	int nBit	= ImgD/8;

	m_pData = new BYTE[nSize * 4];

	if(4 == nBit)
	{
		memcpy(m_pData, pPixel, ImgW * ImgH * 4);
	}

	else
	{
		for(int i=0; i<nSize; ++i)
		{
			BYTE r = pPixel[i*nBit +0];
			BYTE g = pPixel[i*nBit +1];
			BYTE b = pPixel[i*nBit +2];
			BYTE a =  BYTE(r*0.3f + g+0.59f + b*0.11f);

			m_pData[i*4 +0]	= r;
			m_pData[i*4 +1]	= g;
			m_pData[i*4 +2]	= b;
			m_pData[i*4 +3]	= a;
		}

	}




	m_Header.cImgType = 2;
	m_Header.nImgW = ImgW;
	m_Header.nImgH = ImgH;
	m_Header.nImgD = 32;

	HeaderWrite();
	ColorMapWrite();
	DataWrite();

	fclose(m_pF);
	m_pF = NULL;

	delete [] m_pData;

	m_pData = NULL;

	return 1;
}



void CImgTGA::HeaderRead()
{
	m_Header.cIdLen		= ByteRead();
	m_Header.cMapType	= ByteRead();
	m_Header.cImgType	= ByteRead();
	
	m_Header.nMapOrg	= WordRead();
	m_Header.nMapLen	= WordRead();
	m_Header.cMapSize	= ByteRead();
	m_Header.nImgX		= WordRead();
	m_Header.nImgY		= WordRead();

	m_Header.nImgW		= WordRead();
	m_Header.nImgH		= WordRead();
	m_Header.nImgD		= ByteRead();

	m_Header.cImgDsc	= ByteRead();
	
	if ( 0 < m_Header.cIdLen )
	{
		m_Header.sImdId = new BYTE[(m_Header.cIdLen)+1];

		fread(m_Header.sImdId, sizeof(BYTE), m_Header.cIdLen, m_pF);
		
		m_Header.sImdId[(m_Header.cIdLen)] = '\0';
	}
	else
		m_Header.sImdId = NULL;

}


void CImgTGA::HeaderWrite()
{
	ByteWrite( m_Header.cIdLen	);
	ByteWrite( m_Header.cMapType);
	ByteWrite( m_Header.cImgType);
	WordWrite( m_Header.nMapOrg	);
	WordWrite( m_Header.nMapLen	);
	ByteWrite( m_Header.cMapSize);

	WordWrite( m_Header.nImgX	);
	WordWrite( m_Header.nImgY	);
	WordWrite( m_Header.nImgW	);
	WordWrite( m_Header.nImgH	);
	ByteWrite( m_Header.nImgD	);
	ByteWrite( m_Header.cImgDsc	);

	if ( 0 < m_Header.cIdLen )
		fwrite(m_Header.sImdId, sizeof(BYTE), m_Header.cIdLen, m_pF);
}



void CImgTGA::ColorMapRead()
{
	int size =0;

	size = m_Header.nMapLen * m_Header.cMapSize;

	if(size>0)
	{
		if ( 0 != m_Header.cMapType)
		{
			m_pColorMap = (BYTE*) malloc(size);

			fread(m_pColorMap, 1, size, m_pF);
		}
	}
}




void CImgTGA::ColorMapWrite()
{
	if ( 0 != m_Header.cMapType )
	{
		fwrite(m_pColorMap, 1, m_Header.nMapLen * m_Header.cMapSize, m_pF);
	}
}



void CImgTGA::DataRead()
{
	int		size = m_Header.nImgH * m_Header.nImgW * m_Header.nImgD;

	if(2 == m_Header.cImgType || 3 == m_Header.cImgType)
	{
		m_pData= (BYTE*) malloc(size);
		fread(m_pData, 1, size, m_pF);
	}
	else
	{
		printf("  Can't Read Image Type %d.\n", m_Header.cImgType);
	}

}



void CImgTGA::DataWrite()
{
	int size;

	if ( m_Header.cImgType == 2)
	{
		size = m_Header.nImgH * m_Header.nImgW * (m_Header.nImgD/8);
		fwrite(m_pData, 1, size, m_pF);
	}
	else
	{
		printf("  Can't Write Image Type %d.\n", m_Header.cImgType);
	}

	return;
}



BYTE CImgTGA::ByteRead()
{
	BYTE c;
	fread ( &c, 1, 1, m_pF);
	return c;
}

void CImgTGA::ByteWrite(BYTE val)
{
	fwrite(&val, 1, 1, m_pF);
}



DWORD CImgTGA::DwordRead()
{
	DWORD val;
	USHORT val_hi;
	USHORT val_lo;

	if ( m_bByteSwap )
	{
		val_lo = WordRead();
		val_hi = WordRead();
	}
	else
	{
		val_hi = WordRead();
		val_lo = WordRead();
	}

	val = ( val_hi << 16 ) | val_lo;

	return val;
}




void CImgTGA::DwordWrite(DWORD val)
{
	USHORT val_hi;
	USHORT val_lo;

	val_hi = ( USHORT ) ( val / 65536 );
	val_lo = ( USHORT ) ( val % 65536 );

	if ( m_bByteSwap )
	{
		WordWrite( val_lo);
		WordWrite( val_hi);
	}
	else
	{
		WordWrite( val_hi);
		WordWrite( val_lo);
	}
}



USHORT CImgTGA::WordRead()
{
	BYTE chi;
	BYTE clo;
	USHORT USHORT_val;

	if ( m_bByteSwap )
	{
		fread ( &clo, 1, 1, m_pF);
		fread ( &chi, 1, 1, m_pF);
	}
	else
	{
		fread ( &chi, 1, 1, m_pF);
		fread ( &clo, 1, 1, m_pF);		
	}

	USHORT_val = ( chi << 8 ) | clo;

	return USHORT_val;
}



void CImgTGA::WordWrite( WORD val)
{
	BYTE chi;
	BYTE clo;

	chi = ( BYTE ) ( val / 256 );
	clo = ( BYTE ) ( val % 256 );

	if ( m_bByteSwap )
	{
		fwrite(&clo, 1,1, m_pF);
		fwrite(&chi, 1,1, m_pF);
	}
	else
	{
		fwrite(&chi, 1,1, m_pF);
		fwrite(&clo, 1,1, m_pF);
	}

	return;
}



