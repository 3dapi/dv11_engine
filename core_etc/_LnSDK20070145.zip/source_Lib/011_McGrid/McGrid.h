// Interface for the CMcGrid class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCGRID_H_
#define _MCGRID_H_

class CMcGrid
{
protected:
	PDEV		m_pDev;
	VtxD*		m_pLine;
	
public:
	INT		Create(PDEV pDev);
	void	Destroy();
	INT		FrameMove();
	void	Render();
	
public:
	CMcGrid();
	~CMcGrid();
};

#endif