// Interface for the CLnCam1P class.
// FPS Camera
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNCAM_F_H_
#define _LNCAM_F_H_


class CLnCam1P : public CLnCam
{
public:
	CLnCam1P();
	virtual ~CLnCam1P();

public:
	virtual INT	Init();
	virtual INT	FrameMove();

public:
	void	MoveSideward(FLOAT	fSpeed);
	void	MoveForward	(FLOAT	fSpeed, FLOAT fY=0);

	void	RotateYaw	(FLOAT fDelta,FLOAT fSpeed);
	void	RotatePitch	(FLOAT fDelta,FLOAT fSpeed);
};

#endif