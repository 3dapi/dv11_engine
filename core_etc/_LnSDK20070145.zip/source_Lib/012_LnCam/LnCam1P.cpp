// Implementation of the CLnCam1P class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>

#include "LnCam.h"
#include "LnCam1P.h"



CLnCam1P::CLnCam1P()
{
	strcpy(m_sN, "LN_FPS_CAMERA");
	m_eType	= LN_CAM_1;
}

CLnCam1P::~CLnCam1P()
{

}


INT CLnCam1P::Init()
{
	SetParamView(VEC3(1000,500,-1000), VEC3( 1000, 300, 0), VEC3(0,1,0));

	return 1;
}


INT CLnCam1P::FrameMove()
{
	
	Update();

	return 1;
}

void CLnCam1P::MoveSideward(FLOAT fSpeed)
{
	VEC3 tmp(m_mtViw._11, 0, m_mtViw._31);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}


void CLnCam1P::MoveForward(FLOAT fSpeed, FLOAT fY)
{
	VEC3 tmp(m_mtViw._13, m_mtViw._23*fY, m_mtViw._33);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}



void CLnCam1P::RotateYaw(FLOAT fDelta,FLOAT fSpeed)
{
	D3DXMATRIX	rot;	
	VEC3		vcZ = m_vcLook-m_vcEye;
	m_fYaw		= D3DXToRadian(fDelta*fSpeed);
		
	D3DXMatrixRotationY(&rot, m_fYaw);
	D3DXVec3TransformCoord(&vcZ, &vcZ, &rot);
	D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);
	
	m_vcLook = vcZ + m_vcEye;
	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
}

void CLnCam1P::RotatePitch(FLOAT fDelta,FLOAT fSpeed)
{
	D3DXMATRIX rot;
	VEC3 vcZ = m_vcLook - m_vcEye;
	VEC3 vcX =VEC3(m_mtViw._11, m_mtViw._21, m_mtViw._31);

	m_fPitch   = D3DXToRadian(fDelta*fSpeed);
	
	D3DXMatrixRotationAxis(&rot, & vcX, m_fPitch);
	D3DXVec3TransformCoord(&vcZ, &vcZ, &rot);
	D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);

	m_vcLook = vcZ + m_vcEye;
}
