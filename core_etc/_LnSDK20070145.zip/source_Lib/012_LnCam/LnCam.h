// Interface for the CLnCam class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _LNCAM_H_
#define _LNCAM_H_


class CLnCam
{
public:
	enum ELnCam
	{
		LN_CAM_1,
		LN_CAM_3,
	};
	
protected:
	char		m_sN[128];														// Camera Name
	ELnCam		m_eType;														// Camera Type
	
	// For View Matrix
	D3DXVECTOR3	m_vcEye;														// Camera position
	D3DXVECTOR3	m_vcLook;														// Look vector
	D3DXVECTOR3	m_vcUp;															// up vector

	// For Projection Matrix
	FLOAT		m_fScnW;														// Screen Width
	FLOAT		m_fScnH;														// Screen Height
	FLOAT		m_fFv;															// Field of View
	FLOAT		m_fAs;															// Aspect
	FLOAT		m_fNr;															// Near
	FLOAT		m_fFr;															// Far
	
	FLOAT		m_fYaw;
	FLOAT		m_fPitch;

	D3DXMATRIX	m_mtViw;														// View Matrix
	D3DXMATRIX	m_mtViwI;														// View Inverse Matrix
	D3DXMATRIX	m_mtBill;
	D3DXMATRIX	m_mtPrj;														// Projection Matrix
	D3DXMATRIX	m_mtVP;															// m_mtViw * m_mtPrj;
	
	//
	D3DXVECTOR3	m_vcX;															// Camera Axis X
	D3DXVECTOR3	m_vcY;															// Camera Axis Y
	D3DXVECTOR3	m_vcZ;															// Camera Axis Z

	D3DXPLANE	m_Frsm[6];														// Near, Far, Left, Right, Up, Down
	FLOAT		m_fSpd;															// Camera Move Speed

public:
	CLnCam();
	virtual ~CLnCam();
	virtual INT		Init()=0;
	virtual INT		FrameMove()=0;
	virtual void	Update();

public:
	void	SetName(char* sN)	;
	char*	GetName()			;
	
	void	SetType(INT	eType)	;
	ELnCam	GetType()			;
	
	D3DXMATRIX	GetMatrixViw()	;
	D3DXMATRIX	GetMatrixPrj()	;
	D3DXMATRIX	GetMatrixViwI()	;
	D3DXMATRIX	GetMatrixBill()	;
	
	D3DXVECTOR3	GetEye()		;
	D3DXVECTOR3	GetLook()		;
	D3DXVECTOR3	GetUP()			;

	void	SetEye(D3DXVECTOR3);
	void	SetLook(D3DXVECTOR3);
	void	SetUP(D3DXVECTOR3)	;
	
	FLOAT	GetYaw()			;
	FLOAT	GetPitch()			;
	
	void	SetFov(FLOAT)		;
	void	SetScnW(FLOAT)		;
	void	SetScnH(FLOAT)		;
	void	SetNear(FLOAT)		;
	void	SetFar(FLOAT)		;

	FLOAT	GetFov()			;
	FLOAT	GetScnW()			;
	FLOAT	GetScnH()			;
	FLOAT	GetAspect()			;
	FLOAT	GetNear()			;
	FLOAT	GetFar()			;

	D3DXVECTOR3	GetAxisX()		;
	D3DXVECTOR3	GetAxisY()		;
	D3DXVECTOR3	GetAxisZ()		;
		
	void	SetParamView(D3DXVECTOR3 vcEye, D3DXVECTOR3 vcLook, D3DXVECTOR3 vcUp);
	void	SetParamProj(FLOAT fFov, FLOAT fScnW, FLOAT fScnH, FLOAT fNear, FLOAT fFar);
	
	void	SetTransformViw(LPDIRECT3DDEVICE9 pDev);
	void	SetTransformPrj(LPDIRECT3DDEVICE9 pDev);

	// Pick Ray direction
	D3DXVECTOR3	Get3DDir(FLOAT fMouseX, FLOAT fMouseY);

	// Individual Camera
	void	SetMatrixViw(D3DXMATRIX);
	void	SetMatrixPrj(D3DXMATRIX);
};

#endif