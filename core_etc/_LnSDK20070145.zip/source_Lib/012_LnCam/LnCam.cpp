// Implementation of the CLnCam class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3dx9.h>

#include "LnCam.h"


CLnCam::CLnCam()
{
	strcpy(m_sN, "MC_DEFAULT_CAMERA");
	m_eType	= LN_CAM_1;
	
	D3DXMatrixIdentity(&m_mtViw);
	D3DXMatrixIdentity(&m_mtPrj);

	m_fYaw		= 0.f;
	m_fPitch	= 0.f;
	m_vcEye		= D3DXVECTOR3(10,1000,-2000);
	m_vcLook	= D3DXVECTOR3(0,0,0);
	m_vcUp		= D3DXVECTOR3(0,1,0);
	
	m_fFv		= D3DX_PI/4.f;
	m_fScnW		= 1024;
	m_fScnH		= 768;
	m_fAs		= m_fScnW/m_fScnH;
	m_fNr		= 1.f;
	m_fFr		= 50000.f;
	
	m_fSpd		= 10.f;
}

CLnCam::~CLnCam()
{
}


void CLnCam::Update()
{
	D3DXMatrixPerspectiveFovLH(&m_mtPrj, m_fFv, m_fAs, m_fNr, m_fFr);
	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
	D3DXMatrixInverse(&m_mtViwI, 0, &m_mtViw);
	
	m_mtBill = m_mtViwI;
	m_mtBill._41 = m_mtBill._42 = m_mtBill._43 = 0;								// Bill board Matrix
	
	m_vcX.x = m_mtViw._11;
	m_vcX.y = m_mtViw._21;
	m_vcX.z = m_mtViw._31;
	
	m_vcY.x = m_mtViw._12;
	m_vcY.y = m_mtViw._22;
	m_vcY.z = m_mtViw._32;
	
	m_vcZ.x = m_mtViw._13;
	m_vcZ.y = m_mtViw._23;
	m_vcZ.z = m_mtViw._33;
	
	//	m_vcEye	= D3DXVECTOR3( m_mtViwI._41, m_mtViwI._42, m_mtViwI._43);				// Camera Position ReSetting
	
	m_mtVP	= m_mtViw * m_mtPrj;
	
	D3DXVECTOR3 vcLf = -D3DXVECTOR3(m_mtVP._14 + m_mtVP._11, m_mtVP._24 + m_mtVP._21, m_mtVP._34 + m_mtVP._31);		// Left
	D3DXVECTOR3 vcRg = -D3DXVECTOR3(m_mtVP._14 - m_mtVP._11, m_mtVP._24 - m_mtVP._21, m_mtVP._34 - m_mtVP._31);		// Right
	D3DXVECTOR3 vcTp = -D3DXVECTOR3(m_mtVP._14 - m_mtVP._12, m_mtVP._24 - m_mtVP._22, m_mtVP._34 - m_mtVP._32);		// Top
	D3DXVECTOR3 vcBt = -D3DXVECTOR3(m_mtVP._14 + m_mtVP._12, m_mtVP._24 + m_mtVP._22, m_mtVP._34 + m_mtVP._32);		// Bottom
	D3DXVECTOR3 vcNr = -D3DXVECTOR3(m_mtViwI._31, m_mtViwI._32, m_mtViwI._33);				// Near
	D3DXVECTOR3 vcFr = -vcNr;															// Far
	D3DXVECTOR3 vcZn = m_vcEye + vcNr * m_fNr;
	D3DXVECTOR3 vcZf = m_vcEye + vcNr * m_fFr;
	
	D3DXPlaneFromPointNormal((D3DXPLANE*)&m_Frsm[0], &vcZn, &vcNr);				// Near Plane
	D3DXPlaneFromPointNormal((D3DXPLANE*)&m_Frsm[1], &vcZf, &vcFr);				// Far Plane
	D3DXPlaneFromPointNormal((D3DXPLANE*)&m_Frsm[2], &m_vcEye, &vcLf);			// Left Plane
	D3DXPlaneFromPointNormal((D3DXPLANE*)&m_Frsm[3], &m_vcEye, &vcRg);			// Right Plane
	D3DXPlaneFromPointNormal((D3DXPLANE*)&m_Frsm[4], &m_vcEye, &vcTp);			// Top Plane
	D3DXPlaneFromPointNormal((D3DXPLANE*)&m_Frsm[5], &m_vcEye, &vcBt);			// Bottom Plane
}


D3DXVECTOR3 CLnCam::Get3DDir(FLOAT fMouseX, FLOAT fMouseY)
{
	// Get the pick ray from the mouse position
	FLOAT w = m_mtPrj._11;
	FLOAT h = m_mtPrj._22;
	
	D3DXVECTOR3	vcScnP;
	D3DXVECTOR3	vcRayDir;
	
	vcScnP.x =  ( 2.f * fMouseX/ m_fScnW - 1.f ) / w;
	vcScnP.y = -( 2.f * fMouseY/ m_fScnH - 1.f ) / h;
	vcScnP.z =  1.f;
	
	// Transform the screen space pick ray into 3D space
	// Ray Direction
	vcRayDir.x  = D3DXVec3Dot(&vcScnP, &D3DXVECTOR3(m_mtViwI._11, m_mtViwI._21, m_mtViwI._31));
	vcRayDir.y  = D3DXVec3Dot(&vcScnP, &D3DXVECTOR3(m_mtViwI._12, m_mtViwI._22, m_mtViwI._32));
	vcRayDir.z  = D3DXVec3Dot(&vcScnP, &D3DXVECTOR3(m_mtViwI._13, m_mtViwI._23, m_mtViwI._33));
	
	return vcRayDir;
}


void CLnCam::SetTransformViw(LPDIRECT3DDEVICE9 pDev)
{
	pDev->SetTransform(D3DTS_VIEW, &m_mtViw);
}

void CLnCam::SetTransformPrj(LPDIRECT3DDEVICE9 pDev)
{
	pDev->SetTransform(D3DTS_PROJECTION, &m_mtPrj);	
}


void CLnCam::SetParamView(D3DXVECTOR3 vcEye, D3DXVECTOR3 vcLook, D3DXVECTOR3 vcUp)
{
	m_vcEye		= vcEye;
	m_vcLook	= vcLook;
	m_vcUp		= vcUp;
}

void CLnCam::SetParamProj(FLOAT fFov, FLOAT fScnW, FLOAT fScnH, FLOAT fNear, FLOAT fFar)
{
	m_fFv	= fFov;
	m_fScnW	= fScnW;
	m_fScnH	= fScnH;
	m_fAs	= m_fScnW/m_fScnH;
	m_fNr	= fNear;
	m_fFr	= fFar;
}



void CLnCam::SetName(char* sN)
{
	strcpy(m_sN, sN);
}
char* CLnCam::GetName()
{
	return m_sN;
}

void	CLnCam::SetType(INT	eType)
{
	m_eType = ELnCam(eType);
}

CLnCam::ELnCam	CLnCam::GetType()
{
	return m_eType;
}

D3DXMATRIX CLnCam::GetMatrixViw()
{
	return m_mtViw;
}

D3DXMATRIX CLnCam::GetMatrixPrj()
{
	return m_mtPrj;
}

D3DXMATRIX CLnCam::GetMatrixViwI()
{
	return m_mtViwI;
}
D3DXMATRIX CLnCam::GetMatrixBill()
{
	return m_mtBill;
}

D3DXVECTOR3	CLnCam::GetEye()
{
	return m_vcEye;
}
D3DXVECTOR3	CLnCam::GetLook()
{
	return m_vcLook;
}
D3DXVECTOR3	CLnCam::GetUP()
{
	return m_vcUp;
}

void CLnCam::SetEye(D3DXVECTOR3 v)
{
	m_vcEye = v;
}

void CLnCam::SetLook(D3DXVECTOR3 v)
{
	m_vcLook = v;
}

void CLnCam::SetUP(D3DXVECTOR3 v)
{
	m_vcUp = v;
}

FLOAT CLnCam::GetYaw()
{
	return m_fYaw;
}

FLOAT CLnCam::GetPitch()
{
	return m_fPitch;
}

void CLnCam::SetFov(FLOAT fFov)
{
	m_fFv	= fFov;
}

void CLnCam::SetScnW(FLOAT fScnW)
{
	m_fScnW	= fScnW;
}

void CLnCam::SetScnH(FLOAT fScnH)
{
	m_fScnH	= fScnH;
}

void CLnCam::SetNear(FLOAT fNear)
{
	m_fNr	= fNear;
}

void CLnCam::SetFar(FLOAT fFar)
{
	m_fFr	= fFar;
}

FLOAT CLnCam::GetFov()
{
	return m_fFv;
}

FLOAT CLnCam::GetScnW()
{
	return m_fScnW;
}

FLOAT CLnCam::GetScnH()
{
	return m_fScnH;
}

FLOAT CLnCam::GetAspect()
{
	return m_fAs;
}

FLOAT CLnCam::GetNear()
{
	return m_fNr;
}

FLOAT CLnCam::GetFar()
{
	return m_fFr;
}

D3DXVECTOR3	CLnCam::GetAxisX()
{
	return m_vcX;
}

D3DXVECTOR3	CLnCam::GetAxisY()
{
	return m_vcY;
}
D3DXVECTOR3	CLnCam::GetAxisZ()
{
	return m_vcZ;
}


// Individual Camera
void CLnCam::SetMatrixViw(D3DXMATRIX mtViw)
{
	m_mtViw = mtViw;
}
void CLnCam::SetMatrixPrj(D3DXMATRIX mtPrj)
{
	m_mtPrj = mtPrj;
}