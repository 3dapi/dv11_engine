// Implementation of the CLnCam3P class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/PckLnEuclid.h>

#include "LnCam.h"
#include "LnCam3P.h"



CLnCam3P::CLnCam3P()
{
	strcpy(m_sN, "LN_3rd_CAMERA");
	m_eType		= LN_CAM_3;

	m_vcBasis	= D3DXVECTOR3( 0, 0, 0);
	m_fEpslnY	=  20.f;
	m_fGap		= 100.f;
}

CLnCam3P::~CLnCam3P()
{

}


INT CLnCam3P::Init()
{
	m_vcBasis	= D3DXVECTOR3( 60, 50, 60);
	m_fYaw		= D3DXToRadian(60.f);

	D3DXVECTOR3	vcR( cosf(m_fYaw), 0, sinf(m_fYaw));

	vcR			*=m_fGap;

	D3DXVECTOR3 vcLook	= m_vcBasis + D3DXVECTOR3(0, m_fEpslnY, 0);
	D3DXVECTOR3 vcEye	= m_vcBasis + vcR;

	SetParamView(vcEye, vcLook, D3DXVECTOR3(0,1,0));

	return 1;
}


INT CLnCam3P::FrameMove()
{
//	// Wheel mouse...
//	D3DXVECTOR3 vcD = g_pInput->GetMouseDelta();
//
//	if(vcD.z !=0.f)
//	{
//		MoveForward(-vcD.z* .5f, 1.f);
//	}
//
//	if(g_pInput->KeyState(DIK_W))					// W
//	{
//		MoveForward( 4.f, 1.f);
//	}
//
//	if(g_pInput->KeyState(DIK_S))					// S
//	{
//		MoveForward(-4.f, 1.f);
//	}
//
//
//	if(g_pInput->KeyState(DIK_A))					// A
//	{
//		MoveSideward(-4.f);
//	}
//
//	if(g_pInput->KeyState(DIK_D))					// D
//	{
//		MoveSideward(4.f);
//	}
//
//	if(g_pInput->GetMouseSt(1))
//	{
//		D3DXVECTOR3	vcDelta = g_pInput->GetMouseDelta();
//		m_fYaw	= D3DXToRadian(vcDelta.x * 0.1f);
//		m_fPitch= D3DXToRadian(vcDelta.y * 0.1f);
//		
//		D3DXMATRIX rot;
//		D3DXVECTOR3 vcR = m_vcEye - m_vcLook;
//		D3DXVECTOR3 vcX;
//
//		D3DXMatrixRotationY(&rot, m_fYaw);
//		D3DXVec3TransformCoord(&vcR, &vcR, &rot);
//		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);
//		
//		m_vcEye		= m_vcLook + vcR;
//
//		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
//
//		vcR = m_vcEye - m_vcLook;
//		vcX =D3DXVECTOR3(m_mtViw._11, m_mtViw._21, m_mtViw._31);
//		
//		D3DXMatrixRotationAxis(&rot, & vcX, m_fPitch);
//		D3DXVec3TransformCoord(&vcR, &vcR, &rot);
//		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);
//
//		m_vcEye		= m_vcLook + vcR;
//	}

	Update();

	return 1;
}

void CLnCam3P::MoveSideward(FLOAT fSpeed)
{
	D3DXVECTOR3 tmp(m_mtViw._11, 0, m_mtViw._31);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcBasis+= tmp * fSpeed;
	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}


void CLnCam3P::MoveForward(FLOAT fSpeed, FLOAT fY)
{
	D3DXVECTOR3 tmp(m_mtViw._13, m_mtViw._23*fY, m_mtViw._33);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcBasis+= tmp * fSpeed;
	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}
