// Interface for the CTbBase class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _TBBASE_H_
#define _TBBASE_H_


#define TBL_LAST_VERSION	"00.00.01"


typedef enum tagETbKey
{
	TBVER = 0,																	//	0
	LNTBL,																		//	1
	LNTBM,																		//	2
	LNTBS,																		//	3
	INDEX,																		//	4
	NAMEC,																		//	5
	PRPTY,																		//	6
	NUMCS,																		//	7
	LNREC,																		//	8
}ETbKey;


// Lighting
typedef enum tagETbKeyLgt
{
	AMBLC = LNREC+1,
	MTRLS,
	MTRLI,
}ETbKeyLgt;

// Texture
typedef enum tagETbKeyTx
{
	PATHS = LNREC+1,
}ETbKeyTx;


// Map Indoor
typedef enum tagETbKeyMpi
{
	MPIDX = LNREC+1,
}ETbKeyMpi;


// Ui Window
typedef enum tagETbKeyUiW
{
	VCPOS = LNREC+1,
	RCDR,
	RCFC,
	UIST,
}ETbKeyUiW;

typedef enum tagETbKeyEfPtc
{
	NUMPT = LNREC+1,
	BLBD,
	STTIME,
	IMGN,

	PTVCP,
	VCVEL,
	VCACL,
	VCROT,

	VCRTV,
	VCSCL,
	VCSCV,
	VCPRT,

	VCCLR,
	VCCLV,
	VCWHR,
	VCBRN,
}ETbKeyEfPtc;


// Table Base structure
struct TbBase
{
	INT		nI;																	// Index
	INT		iN;																	// Number of class
	TCHAR	sN[64];																// Name

	TbBase() : nI(-1), iN(0)
	{
		memset(sN, 0, sizeof(sN));
	}
};

struct TbBaseS : public TbBase{};
struct TbBaseM : public TbBase{};


template<class S=TbBaseS, class M=TbBaseM>
class CTbBase
{
public:
	struct TbM : public M
	{
		S*	pS;																	// Sub Pointer
		TbM() : pS(0){}
	};

public:
	INT			m_nI;
	INT			m_iN;
	TCHAR		m_sV[16];														// Version
	TCHAR		m_sN[64];														// Name
	TCHAR		m_sF[512];														// File

	TbM*		m_pM;

public:
	CTbBase() : m_nI(-1), m_pM(0), m_iN(0)
	{
		memset(m_sF, 0, sizeof(m_sF));
		memset(m_sV, 0, sizeof(m_sV));
	}


	INT Init()
	{
		return	OnInit();
	}

	void Destroy()
	{
		OnDestroy();
	}

	INT Restore()
	{
		return OnRestore();
	}

	void Invalidate()
	{
		OnInvalidate();
	}


protected:
	virtual INT		OnInit()		{	return 1;	}
	virtual void	OnDestroy()		{				}
	virtual INT		OnRestore()		{	return 1;	}							// ���� Ŭ�������� ���� ���� �ȸ��� ����..
	virtual void	OnInvalidate()	{				}

	virtual INT		OnLoad()=0;													// ���� Ŭ�������� �и��� ������ �ϱ� ����... Text
	virtual INT		OnLoadTxt()		{	return 1;	}							// Text
	virtual INT		OnLoadBin()		{	return 1;	}							// Binary..
	virtual void	OnConfTxt()		{				}							// Confirm Text
	virtual void	OnConfBin()		{				}							// Confirm Binary

public:	
	S*	Select(INT nM, INT nS) const
	{
		if(nM<0||nM>=m_iN)
			return NULL;
		
		if(nS<0 || nS>=m_pM[nM].iN)
			return NULL;

		return &m_pM[nM].pS[nS];
	}

	M*	Select(INT nM) const
	{
		if(nM<0||nM>=m_iN)
			return NULL;
		
		return &m_pM[nM];
	}



	M*	Select(TCHAR* sN) const
	{
		INT nIdx = -1;
		
		for(INT i=0 ; i< m_iN; ++i )
		{
			if ( !_stricmp( m_pM[i].sN, sN) )
			{
				nIdx =i;
				break;
			}
		}
		
		if(FAILED(nIdx))
			return NULL;
		
		return &m_pM[nIdx];
	}
	


	INT	GetNumM() const
	{
		return m_iN;
	}

	INT	GetNumS(INT nM) const
	{
		return m_pM[nM].iN;
	}

	TCHAR*	GetName(INT nM) const
	{
		return m_pM[nM].sN;
	}


	INT	SelectIdx(TCHAR* sN) const
	{
		for(INT i=0 ; i< m_iN; ++i )
		{
			if ( !_stricmp( m_pM[i].sN, sN) )
			{
				return i;
			}
		}

		return -1;
	}
};


extern TCHAR * sCmdTb[];
extern TCHAR * sCmdTbLgt[];
extern TCHAR * sCmdTbTx[];
extern TCHAR * sCmdTbUiW[];
extern TCHAR * sCmdTbMpi[];
extern TCHAR * sCmdTbPtc[];
#endif