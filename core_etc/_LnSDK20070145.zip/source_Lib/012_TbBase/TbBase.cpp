// Implementation of the CTbBase class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>

#include "TbBase.h"

// Base Table Paring Key Value
TCHAR * sCmdTb[] =
{
	"TbVer",																	//	TBVER
		"LnTbl",																//	LNTBL
		"LnTbM",																//	LNTBM
		"LnTbS",																//	LNTBS
		"Index",																//	INDEX
		"NameC",																//	NAMEC
		"Prpty",																//	PRPTY
		"NumCs",																//	NUMCS
		"LnRc*",																//	LNREC
};


// Lighting Key Value
TCHAR * sCmdTbLgt[] =
{
	"TbVer",																	//	TBVER
		"LnTbl",																//	LNTBL
		"LnTbM",																//	LNTBM
		"LnTbS",																//	LNTBS
		"Index",																//	INDEX
		"NameC",																//	NAMEC
		"Prpty",																//	PRPTY
		"NumCs",																//	NUMCS
		"LnRc*",																//	LNRC
		"AmbLC",																//	AMBLC
		"MtrlS",																//	MTRLS
		"MtrlI",																//	MTRLI
};


// Texture Key Value
TCHAR * sCmdTbTx[] =
{
	"TbVer",																	//	TBVER
		"LnTbl",																//	LNTBL
		"LnTbM",																//	LNTBM
		"LnTbS",																//	LNTBS
		"Index",																//	INDEX
		"NameC",																//	NAMEC
		"Prpty",																//	PRPTY
		"NumCs",																//	NUMCS
		"LnRc*",																//	PATHS
		"PathS",
};


// Ui Window Key Value
TCHAR * sCmdTbUiW[] =
{
	"TbVer",																	//	TBVER
		"LnTbl",																//	LNTBL
		"LnTbM",																//	LNTBM
		"LnTbS",																//	LNTBS
		"Index",																//	INDEX
		"NameC",																//	NAMEC
		"Prpty",																//	PRPTY
		"NumCs",																//	NUMCS
		
		"LnRc*",																//	LNREC
		"vcPos",
		"RcDr",
		"RcFc",
		"UiSt",
};


// Map Indoor Key Value
TCHAR * sCmdTbMpi[] =
{
	"TbVer",																	//	TBVER
		"LnTbl",																//	LNTBL
		"LnTbM",																//	LNTBM
		"LnTbS",																//	LNTBS
		"Index",																//	INDEX

		"NameC",																//	NAMEC
		"Prpty",																//	PRPTY
		"NumCs",																//	NUMCS

		"PathS",																//	PATHS
		"vcPos",																//	VCPOS
		"LnRc*",																//	LNREC

		"MpIdx",
};

TCHAR * sCmdTbPtc[] =
{
	"TbVer",																	//	TBVER
		"LnTbl",																//	LNTBL
		"LnTbM",																//	LNTBM
		"LnTbS",																//	LNTBS
		"Index",																//	INDEX
		"NameC",																//	NAMEC
		"Prpty",																//	PRPTY
		"NumCs",																//	NUMCS
		"LnRc*",																//	LNREC

		"NumPt",																//	NUMPT
		"Blbd",																	//	BLBD
		"StrT",																	//	STTIME
		"ImgN",																	//	IMGN

		"vcPos",																//	PTVCP
		"vcVel",																//	VCVEL
		"vcAcl",																//	VCACL
		"vcRot",																//	VCROT

		"vcRtV",																//	VCRTV
		"vcScl",																//	VCSCL
		"vcScV",																//	VCSCV
		"vcPrt",																//	VCPRT

		"vcClr",																//	VCCLR
		"vcClV",																//	VCCLV
		"vcWHR",																//	VCWHR
		"vcBrn",																//	VCBRN
};