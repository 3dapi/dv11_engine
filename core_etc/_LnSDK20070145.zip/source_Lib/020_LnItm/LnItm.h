// Interface for the CLnItem class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNITEM_H_
#define _LNITEM_H_


#pragma warning(disable : 4786)

#include <vector>


class CItBase : public CLnBase
{
public:																			// Type: nI1(LockOn, NonLockOn), Skil type: nI2, Skill Id: nI3 Current Id: nI4
	INT		m_iN;																// ź��, Ep(electric power, Mana), ���� ��
};


typedef std::vector<CItBase*>	lsItB;
typedef lsItB::iterator			itItB;





class CItPrt : public CItBase													// Parts
{
public:
};

typedef std::vector<CItPrt*>	lsItPrt;
typedef lsItPrt::iterator		itItPrt;







class CItPce : public CItBase													// Piece
{
public:
};

typedef std::vector<CItPce*>	lsItPce;
typedef lsItPce::iterator		itItPce;





class CItSkl : public CItBase													// ������ Animation�� ����.
{
public:
	INT		m_iNd;																// En ���ҷ� �׻� ����

	FLOAT	m_fRg;																// Range
	INT		m_iTargetType;														// Targeting Type
																				// ���� ����
	WORD	m_nPr;																// Id Parent
	WORD	m_nTr;																// Id Target
};

typedef std::vector<CItSkl*>	lsItSkl;
typedef lsItSkl::iterator		itItSkl;






class CItWpn : public CItBase
{
public:
	INT		m_iNd;																// En ���ҷ� �׻� ����

	FLOAT	m_fRg;																// Range
	INT		m_iTargetType;														// Targeting Type

																				// ���� ����
	WORD	m_nPr;																// Id Parent
	WORD	m_nTr;																// Id Target
};


typedef std::vector<CItWpn*>	lsItWpn;
typedef lsItWpn::iterator		itItWpn;



#endif