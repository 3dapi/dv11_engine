// Interface for the DxDiag functions and classes.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNUTIL_DXDIAG_H_
#define _LNUTIL_DXDIAG_H_

// Caution!!!
// See Source File. You may find #define INITGUID code.
// It will be guid error.
// So you must not include this header file with #define INITGUID code...

extern HRESULT LnUtil_GetDXVersion(DWORD* pDXVer, TCHAR* SDXVer, int chDVer);


DWORD LnD3D_DXVersion();

#endif






