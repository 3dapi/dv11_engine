// Interface for the Ln String functions.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNSTRING_H_
#define _LNSTRING_H_


#pragma warning( disable : 4786)

#include <string>
#include <vector>


char*	LnStr_Format(const char *format, ...);									// String Formating. Like a sprintf

void	LnStr_ReadLineQuot(char *strOut, char *strIn, INT iC='\"');
char*	LnStr_GetWord(char* s, int nIdx);										// Get Word from 1 or 2 Byte code
char*	LnStr_DWtoStr(DWORD dwA);

void	LnStr_StrList(															// Token Seperator
					  std::vector<std::string>& vStr
					  , char* sIn
					  , char* sSpes=" ,\t/\'\"\\\n");


char*	LnStr_EnumValueQuotation(char* sVal, char* s, int ch='\"');

void	LnStr_Replace(char* sInOut, int origin, int dest);						// To Replace origin to dest in string sInOut.
void	LnStr_Replaces(char* sInOut, const char* origin, int count, int dest);	// To Replace origin to dest in string sInOut.


INT		LnStr_Sgets(const char* sSrc, char* sLine, int iMax, BOOL bFillEndLineZero=TRUE);


int		vsscanf(const char* sBuf, const char* format, va_list ap);
int		LnStr_Scanf(char* sBuf, char* format, ...);								// if Failed then returned -1. succeeded then returned Argument count.


#endif

