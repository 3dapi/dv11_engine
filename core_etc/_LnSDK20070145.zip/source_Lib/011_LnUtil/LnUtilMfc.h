// Interface for the CLnFileSys class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNUTIL_MFC_H_
#define _LNUTIL_MFC_H_

#pragma warning( disable : 4786)

#include <string>
#include <vector>

#include <windows.h>
#include <io.h>
#include <atlbase.h>




void GetProjectFullName(char* sName, IBuildProject* pProject);
void GetProjectName(char* sName, IBuildProject* pProject);

#endif