// interface for the LnUtil Files.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNUTIL_FILE_H_
#define _LNUTIL_FILE_H_

#pragma warning( disable : 4786)

#include <string>
#include <vector>

#include <windows.h>
#include <io.h>



DWORD	LnFile_Err();
void	LnFile_Err(DWORD dError);
void	LnFile_GetAllFiles(std::vector<std::string>* pOut, char* sPath);
void	LnFile_GetAllFolders(std::vector<std::string>* pOut, char* sPath);

void	LnFile_GetAllFilesAndFoldersFromSubDir(std::vector<std::string>* pOut, char* sPath);
void	LnFile_GetAllFilesFromSubDir(std::vector<std::string>* pOut, char* sPath);
void	LnFile_GetAllFoldersFromSubDir(std::vector<std::string>* pOut, char* sPath);
void	LnFile_Finds(std::vector<std::string>* pOut, char* sPath, char* sFile);

INT		LnFile_FileFind(char* sFile);
INT		LnFile_FileSize(char* sFile);
long	LnFile_FileSize(FILE* &fp);												// Get File Size

DWORD	LnFile_GetAttrib(char* sFile);

void	LnFile_GetDrive( char const *pPath, char *pDrive);
void	LnFile_GetDir(char const *pPath, char *pDir);
void	LnFile_GetName(char const *pPath, char *pName);
void	LnFile_GetExt(char const *pPath, char *pExt);
void	LnFile_GetDriveAndDir(char const *pPath, char *pDriveDir);
void	LnFile_GetNameAndExt(char const *pPath, char *pNameExt);
void	LnFile_SetExt(char const *pSrcFile, char const *pExt, char *pDestFile);


INT		LnFile_XCopy(char *pSrc, char *pDst);
INT		LnFile_RemoveAll(char *pSrc, char *pDst=NULL);
char*	LnFile_SimpleStrDateTime(char* sYear, char* sMon, char* sDay, char* sTime, time_t lTime);

INT		LnFile_CmtlFileOpen(													// Common Control File Open
								HWND hWnd										// HWND Owner
							,	char* sFileFull									// File Full Path Name
							,	char* sFilePath									// File Path
							,	char* sFileName									// File Name
							,	char* sName										// Name
							,	char* sFileExtn									// File Extension
							,	CONST char* sFilter								// Filter
							,	CONST char* sDefExt								// Default Extension
							,	CONST char* sTitle								// Common Control Title
							,	CONST char* sInitPath = NULL					// Init Path
							);




// For WinAPI File Management From C Style Functions
HANDLE	LnFile_fopen(char* sFile, char* sT);									// Fail: return INVALID_HANDLE_VALUE, append Mode�� ��� ���� �����ʹ� �������� �ִ�.
INT		LnFile_fclose(HANDLE hFile);
DWORD	LnFile_fsize(HANDLE hFile);

INT		LnFile_fread(HANDLE hFile, void* p, INT bufSize, INT nCount=1);
INT		LnFile_fwrite(HANDLE hFile, void* p, INT bufSize, INT nCount=1);
INT		LnFile_fprintf(HANDLE hFile, char *format,...);
INT		LnFile_fgets(HANDLE hFile, char* sLine, int iMax, BOOL bFillEndLineZero=TRUE);
DWORD	LnFile_fseek(HANDLE hFile, LONG lOff, DWORD nFrom=FILE_BEGIN /*FILE_BEGIN, FILE_CURRENT, FILE_END*/);
DWORD	LnFile_fseekBegin(HANDLE hFile);
DWORD	LnFile_fseekEnd(HANDLE hFile);

void	LnFile_fsetLength(HANDLE hFile, DWORD dwNewLen);
DWORD	LnFile_fsetLength(HANDLE hFile);

DWORD	LnFile_ftell(HANDLE hFile);
BOOL	LnFile_feof(HANDLE hFile=INVALID_HANDLE_VALUE);							// return EOF is TRUE, others FALSE




struct TfileEntry
{
	DWORD	dAtt;
	
	INT		iYea;			// Year
	INT		iMon;			// Mon
	INT		iDay;			// Day

	INT		iHou;			// Hour
	INT		iMin;			// Minute
	INT		iSec;			// Second
	
	DWORD	dLen;			// Size
	char	name[MAX_PATH];	// Name
	char	path[MAX_PATH];	// Path

	BOOL	IsFolder()
	{
		return ( _A_SUBDIR & dAtt);
	}
};


INT		LnFile_GetEntry(TfileEntry* pData, char* sFullPathFile);

void	LnFile_ReadFileLine(HANDLE hFile, char* sLine);
void	LnFile_ReadFileLine(FILE *fp, char* sLine);


#endif


