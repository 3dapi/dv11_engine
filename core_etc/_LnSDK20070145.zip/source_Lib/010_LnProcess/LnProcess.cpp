// Implementation of Processes...
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <process.h>
#include <stdio.h>
#include <string.h>

#include "LnProcess.h"


INT CLnThread::m_iN = 0;


CLnThread::CLnThread()
{
	m_nId	= m_iN;
	m_hHnd	= NULL;
	++m_iN;

	m_bRun	= false;
};


CLnThread::~CLnThread()
{
	--m_iN;

	Release();
}


DWORD	WINAPI	CLnThread::ThrdPrc(void *pParam)
{
	((CLnThread*)pParam)->m_bRun = true;
	((CLnThread*)pParam)->OnThrdPrc(pParam);

	return 1;
}


void CLnThread::ThreadCreate()
{
	if(m_hHnd)
	{
		CloseHandle(m_hHnd);
		m_hHnd	= NULL;
	}

	m_hHnd = LnProc_ThreadCreate(ThrdPrc, this, 0, &m_dTh);
}

void CLnThread::Release()
{
	m_bRun = false;

	if(m_hHnd)
	{
		CloseHandle(m_hHnd);
		WaitForSingleObject(m_hHnd, INFINITE);
		m_hHnd = NULL;
	}
}

void CLnThread::Wait(DWORD dT)
{
	if(m_hHnd)
		WaitForSingleObject(m_hHnd, dT);
}


void CLnThread::SetRun(bool bRun)
{
	m_bRun = bRun;

	if(m_hHnd)
	{
		LnProc_ThreadRun(m_hHnd, bRun);
	}
}

bool CLnThread::GetRun()
{
	return m_bRun;
}




HANDLE LnProc_ThreadCreate(LPTHREAD_START_ROUTINE pFunc,PVOID pParam, ULONG dFlag, DWORD* dId)
{
	return (HANDLE)_beginthreadex(NULL, 0, (LPBEGIN_THREAD_EX)pFunc, pParam, dFlag, (unsigned*)dId);
}


void LnProc_ThreadClose(HANDLE* hThread)
{
	DWORD	dExit= 0;
	INT		hr	 = 0;
	
	if(0==hThread || 0 == *hThread)
		return;

	GetExitCodeThread(*hThread, &dExit);
	
	if(dExit)
	{
		SuspendThread(*hThread);

		if(0==TerminateThread(*hThread, dExit))
		{
			char	sMsg[512];
			LPVOID	pBuf;
			DWORD	hr= GetLastError();

			FormatMessage( 
				FORMAT_MESSAGE_ALLOCATE_BUFFER | 
				FORMAT_MESSAGE_FROM_SYSTEM | 
				FORMAT_MESSAGE_IGNORE_INSERTS,
				NULL,
				hr,
				0,
				(LPTSTR) &pBuf,
				0,
				NULL 
			);

			sprintf(sMsg, "%s", (char*)pBuf);
			LocalFree( pBuf );
			printf("%s\n", sMsg);
		}
	}

	//	WaitForSingleObject(m_hTh, INFINITE);
	CloseHandle(*hThread);
	*hThread = NULL;
}


void LnProc_ThreadRun(HANDLE hThread, BOOL bRun)
{
	if(bRun)
		ResumeThread(hThread);
	else
		SuspendThread(hThread);
}





INT CLnCriticalSection::m_iN = 0;							// Critical Section Counter


CLnCriticalSection::CLnCriticalSection()
{
	static CRITICAL_SECTION	Lock;

	if( !(m_iN++))
		InitializeCriticalSection(&Lock);

	m_Lock = &Lock;
}

CLnCriticalSection::~CLnCriticalSection()
{
	--m_iN;

	if(0 == m_iN)
		DeleteCriticalSection(m_Lock);
}

void CLnCriticalSection::Lock() const						// Enter Critical Section
{
	EnterCriticalSection(m_Lock);
}

void CLnCriticalSection::Unlock() const						// Enter Critical Section
{
	LeaveCriticalSection(m_Lock);
}



CLnCriticalSection		g_CriticalSection;					// Critical Section ����






HANDLE LnProc_MutexCreate(TCHAR* pName, BOOL bSignal)
{
	return CreateMutex(NULL, bSignal, pName);
}


void LnProc_MutexDestroy(HANDLE* hMutex)
{
	if(NULL == hMutex || NULL == *hMutex)
		return;

	CloseHandle(*hMutex);

	*hMutex = NULL;
}


HANDLE LnProc_MutexOpen(TCHAR *pName, DWORD dwDesiredAccess, BOOL bInheritHandle)
{
	return OpenMutex(dwDesiredAccess, bInheritHandle, pName);
}


DWORD LnProc_MutexLock(HANDLE hMutex, DWORD dTimeOut)
{
	return WaitForSingleObject(hMutex, dTimeOut);
}

BOOL LnProc_MutexUnlock(HANDLE hMutex)
{
	return ReleaseMutex(hMutex);
}


