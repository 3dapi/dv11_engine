// Interface for Processes...
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNPROCESS_H_
#define _LNPROCESS_H_

typedef unsigned (__stdcall* PBEGIN_THREAD_EX)(void*);
typedef PBEGIN_THREAD_EX LPBEGIN_THREAD_EX;


class CLnThread
{
protected:
	static INT	m_iN;															// Thread Counter
	INT			m_nId;															// Thread Id
	HANDLE		m_hHnd;															// Thread Handle
	DWORD		m_dTh;															// Thread Id
	bool		m_bRun;

public:
	CLnThread();
	virtual ~CLnThread();

	static	DWORD	WINAPI	ThrdPrc(void *pParam);
	
	virtual	DWORD	OnThrdPrc(void *pParam) = 0;
	void			ThreadCreate();
	void			Wait(DWORD dT=INFINITE);

	bool			GetRun();
	void			SetRun(bool bRun);

protected:
	virtual void	Release();
};



HANDLE	LnProc_ThreadCreate(LPTHREAD_START_ROUTINE pFunc,void* pParam, ULONG dFlag=0, DWORD* dId= NULL);	// Thread Create
void	LnProc_ThreadClose(HANDLE* hThread);																// Thread Close
void	LnProc_ThreadRun(HANDLE hThread, BOOL bRun);



class CLnCriticalSection
{
protected:
	static INT			m_iN;					// Critical Section Counter
	CRITICAL_SECTION*	m_Lock;					// Critical Section

public:
	CLnCriticalSection();
	virtual ~CLnCriticalSection();

	void	Lock() const;						// Enter Critical Section
	void	Unlock() const;						// Enter Critical Section
};



HANDLE	LnProc_MutexCreate(TCHAR* pName, BOOL bSignal=FALSE);
void	LnProc_MutexDestroy(HANDLE hMutex);

HANDLE	LnProc_MutexOpen(TCHAR *pName, DWORD dwDesiredAccess=SYNCHRONIZE, BOOL bInheritHandle=FALSE);

DWORD	LnProc_MutexLock(HANDLE hMutex, DWORD dTimeOut=INFINITE);
BOOL	LnProc_MutexUnlock(HANDLE hMutex);


#endif

