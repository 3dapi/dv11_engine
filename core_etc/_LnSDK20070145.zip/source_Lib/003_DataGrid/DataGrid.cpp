
#define _WIN32_WINNT 0x0400

#include <windows.h>

#include <Ln/PckLnWindow.h>


#include "DataGrid.h"


CDataGrid::CDataGrid()
{
	m_hEdit		= NULL;
	m_hFontRow	= NULL;
	m_hFontCol	= NULL;

	m_hBgBrush	= NULL;
	m_hCellPen	= NULL;

	m_hMemDC		= NULL;
	m_hOldMemBitmap	= NULL;
	m_hMemBitmap	= NULL;

	m_nSelectCol	= -1;
	m_nSelectRow	= -1;
	m_Resize		= FALSE;

	m_Column		= -1;
	m_Row			= -1;

	m_EnableEdit	= FALSE;
	m_bEdit			= FALSE;
	
	m_Click			= FALSE;
	m_EnableEdit	= TRUE;
	m_EnableSort	= TRUE;
	m_EnableResize	= TRUE;
	m_EnableGrid	= TRUE;
	m_Cursor		= FALSE;	

	m_pRowSelect	= NULL;
	m_TextColorCol	= DGTXT_COLOR;
	m_TextColorRow	= DGTXT_COLOR;

	m_CompareFunc	= NULL;
}


CDataGrid::~CDataGrid()
{
	Destroy();
}


void CDataGrid::Resize()
{
	// Recalculate DataGrid relative size
	RECT rectParent;
	GetWindowRect( m_hPrn, &rectParent );
	SetWindowPos( m_hWnd, HWND_NOTOPMOST, int((double(m_rcDG.left)/100.0)*(rectParent.right-rectParent.left)), int((double(m_rcDG.top)/100.0)*(rectParent.bottom-rectParent.top)), 
		int((double(m_rcDG.right)/100.0)*(rectParent.right-rectParent.left)), int((double(m_rcDG.bottom)/100.0)*(rectParent.bottom-rectParent.top)), SWP_NOZORDER | SWP_SHOWWINDOW );
	RECT clientRect;
	GetClientRect( m_hWnd, &clientRect );
	RecalcWindow(m_hWnd);
	InvalidateRect( m_hWnd, NULL, TRUE );
	UpdateWindow(m_hWnd);
}


BOOL CDataGrid::Create(RECT wndRect, HWND hParent, int numCols)
{
	RECT rectParent;
	BOOL result = FALSE;

	m_hPrn = hParent;
	HINSTANCE hInst = (HINSTANCE)GetModuleHandle(NULL);
	
	GetWindowRect( m_hPrn, &rectParent );
	m_rcDG.left = int(100*double(wndRect.left)/double(rectParent.right-rectParent.left));
	m_rcDG.top = int(100*double(wndRect.top)/double(rectParent.right-rectParent.left));
	m_rcDG.right = int(100*double(wndRect.right-wndRect.left)/double(rectParent.right-rectParent.left));
	m_rcDG.bottom = int(100*double(wndRect.bottom-wndRect.top)/double(rectParent.bottom-rectParent.top));
	
	WNDCLASSEX wincl;
	wincl.hInstance = hInst;
	wincl.lpszClassName = "DATAGRID";
	wincl.lpfnWndProc = (WNDPROC)CDataGrid::WndProc;
	wincl.style = CS_DBLCLKS;
	wincl.cbSize = sizeof (WNDCLASSEX);
	wincl.hIcon = LoadIcon( NULL, IDI_APPLICATION );
	wincl.hIconSm = LoadIcon( NULL, IDI_APPLICATION );
	wincl.hCursor = LoadCursor( NULL, IDC_ARROW );
	wincl.lpszMenuName = NULL;
	wincl.cbClsExtra = 0;
	wincl.cbWndExtra = 0;
	wincl.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	
	ATOM reg = RegisterClassEx(&wincl);
	DWORD error = GetLastError();
	
	// Register DataGrid window class
	if ( ( reg ) || ( error == ERROR_CLASS_ALREADY_EXISTS ) )
	{
		// Create DataGrid window
		m_hWnd = CreateWindowEx( WS_EX_CLIENTEDGE, "DATAGRID", "", WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_VSCROLL | WS_HSCROLL
								, wndRect.left, wndRect.top, wndRect.right-wndRect.left, wndRect.bottom-wndRect.top
								, m_hPrn, NULL
								, hInst
								, (LPVOID)this );

		if(0==m_hWnd)
			return -1;

		result = TRUE;

		// Hide DataGrid window scroll bars
		ShowScrollBar( m_hWnd, SB_BOTH, FALSE );
		
		
		// Init DataGrid GDI objects
		InitDGGlobals();
		

		for ( int i=0; i< numCols; i++ )
		{
			DG_COLUMN*	pColumn = new DG_COLUMN;
			
			pColumn->columnWidth = 50;
			pColumn->textAlign = DGTA_LEFT;
			pColumn->columnText = " ";

			m_vCols.push_back(pColumn);
		}
		
		// Create EDIT control
		m_hEdit = CreateWindow( "EDIT"
							, ""
							, WS_CHILD | WS_CLIPSIBLINGS | ES_AUTOHSCROLL
							, 0, 0, 100, 20, m_hWnd
							, NULL
							, hInst, NULL );

		SendMessage( m_hEdit, WM_SETFONT, (WPARAM)m_hFontRow, MAKELPARAM(TRUE,0) );
	}
	
	return result;
}


void CDataGrid::InitDGGlobals()
{
	// Create fonts
	HDC hParentDC = GetDC(m_hPrn);
	LOGFONT lf;
	lf.lfHeight = -MulDiv( 10, GetDeviceCaps(hParentDC,LOGPIXELSY), 72 );
	lf.lfWidth = 0;
	lf.lfEscapement = 0;
	lf.lfOrientation = 0;
	lf.lfWeight = FW_NORMAL;
	lf.lfItalic = FALSE;
	lf.lfUnderline = FALSE;
	lf.lfStrikeOut = FALSE;
	lf.lfCharSet = ANSI_CHARSET;
	lf.lfOutPrecision = OUT_DEFAULT_PRECIS;
	lf.lfClipPrecision = CLIP_DEFAULT_PRECIS;
	lf.lfQuality = DEFAULT_QUALITY;
	lf.lfPitchAndFamily = DEFAULT_PITCH | FF_DONTCARE;

	strcpy( lf.lfFaceName, "Arial" );
	m_hFontCol = CreateFontIndirect(&lf);
	
	memcpy( &m_lfCol, &lf, sizeof(LOGFONT) );
	
	lf.lfHeight = -MulDiv( 9, GetDeviceCaps(hParentDC,LOGPIXELSY), 72 );
	m_hFontRow = CreateFontIndirect(&lf);
	
	memcpy( &m_lfRow, &lf, sizeof(LOGFONT) );
	
	ReleaseDC( m_hPrn, hParentDC );
	
	// Create background brush
	LOGBRUSH lb;
	lb.lbColor = DGBGR_COLOR;
	lb.lbStyle = BS_SOLID;
	m_hBgBrush = CreateBrushIndirect(&lb);
	
	// Create cell pen
	LOGPEN lp;
	lp.lopnColor = RGB(210,210,210);
	lp.lopnStyle = PS_SOLID;
	lp.lopnWidth.x = 1;
	m_hCellPen = CreatePenIndirect(&lp);
}


BOOL CDataGrid::SetColumnInfo(int columnIndex, char* columnText, int columnWidth, int textAlign)
{
	BOOL result = FALSE;
	
	// Check column index
	if ( columnIndex < m_vCols.size() )
	{
		// Set new DataGrid column info
		m_vCols[columnIndex]->columnText	= columnText;
		m_vCols[columnIndex]->columnWidth	= columnWidth;
		m_vCols[columnIndex]->textAlign		= textAlign;
		m_vCols[columnIndex]->pressed		= false;
		
		result = TRUE;
	}
	
	return result;
}


BOOL CDataGrid::SetItemInfo(int rowIndex, int columnIndex, char* itemText, int textAlign, bool readOnly)
{
	BOOL result = FALSE;
	
	if ( SetDGItemText( m_hWnd, rowIndex, columnIndex, itemText ) )
	{
		m_vRows[rowIndex]->textAlign[columnIndex] = textAlign;

		if ( m_EnableEdit )
			m_vRows[rowIndex]->readOnly[columnIndex] = readOnly;
		
		result = TRUE;
	}
	
	return result;
}


BOOL CDataGrid::SetDGItemText(HWND hWnd, int rowIndex, int columnIndex, char* buffer)
{
	BOOL result = FALSE;
	
	// Check column and row index
	if ( ( columnIndex < m_vCols.size() ) && ( rowIndex < m_vRows.size() ) && ( buffer != NULL ) )
	{
		m_vRows[rowIndex]->rowText[columnIndex] = buffer;
		result = TRUE;
	}

	
	return result;
}


BOOL CDataGrid::SetItemInfo(DG_ITEMINFO* itemInfo)
{
	BOOL result = FALSE;
	
	if ( ( itemInfo != NULL ) && ( itemInfo->dgItem < m_vRows.size() ) && ( itemInfo->dgSubitem < m_vCols.size() ) )
	{
		switch ( itemInfo->dgMask )
		{
		case DG_TEXTEDIT:
			{
				// Set DataGrid item text
				SetDGItemText( m_hWnd, itemInfo->dgItem, itemInfo->dgSubitem, itemInfo->dgText );
			}
			break;
			
		case DG_TEXTALIGN:
			{
				// Set DataGrid item text align
				m_vRows[itemInfo->dgItem]->textAlign[itemInfo->dgSubitem] = itemInfo->dgTextAlign;
			}
			break;
			
		case DG_TEXTHIGHLIGHT:
			{
				// Select DataGrid item
				SelectItem( itemInfo->dgItem, itemInfo->dgSubitem );
			}
			break;
			
		case DG_TEXTRONLY:
			{
				// Set DataGrid item edit mode
				m_vRows[itemInfo->dgItem]->readOnly[itemInfo->dgSubitem] = itemInfo->dgReadOnly;
			}
			break;
			
		case DG_TEXTBGCOLOR:
			{
				// Set DataGrid row background color
				m_vRows[itemInfo->dgItem]->bgColor = itemInfo->dgBgColor;
			}
			break;
		}
	}
	
	return result;
}


BOOL CDataGrid::GetItemText(int rowIndex, int columnIndex, char* buffer, int buffer_size)
{
	BOOL result = GetDGItemText( m_hWnd, rowIndex, columnIndex, buffer, buffer_size );
	return result;
}


BOOL CDataGrid::GetDGItemText(HWND hWnd, int rowIndex, int columnIndex, char* buffer, int buffer_size)
{
	BOOL result = FALSE;
	
	// Clear return buffer
	strcpy( buffer, "" );
	

	if ( ( columnIndex < m_vCols.size() ) && ( rowIndex < m_vRows.size() ) )
	{
		// Get DataGrid item text
		strncpy( buffer, m_vRows[rowIndex]->rowText[columnIndex].c_str(), buffer_size );
		
		result = TRUE;
	}
	
	return result;
}


LRESULT CDataGrid::OnMsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
		case WM_SIZE:
		{
			// Delete memory device context
			if ( m_hMemDC )
			{
				SelectObject( m_hMemDC, m_hOldMemBitmap );
				DeleteDC(m_hMemDC);
				m_hMemDC = NULL;
			}
			// Delete memory bitmap
			if ( m_hMemBitmap )
			{
				DeleteObject(m_hMemBitmap);
				m_hMemBitmap = NULL;
			}
			
			HDC hDC = GetDC(m_hWnd);
			RECT rectClient;
			GetClientRect( m_hWnd, &rectClient );
			m_hMemBitmap = CreateCompatibleBitmap( hDC, (rectClient.right-rectClient.left), (rectClient.bottom-rectClient.top) );
			m_hMemDC = CreateCompatibleDC(hDC);
			m_hOldMemBitmap = (HBITMAP)SelectObject( m_hMemDC, m_hMemBitmap );
			ReleaseDC( m_hWnd, hDC );
			
			break;
		}
		
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			BeginPaint( hWnd, &ps );
			
			// Draw DataGrid rows
			DrawRows(m_hWnd);
			// Draw DataGrid columns
			DrawColumns(m_hWnd);
			
			RECT clientRect;
			GetClientRect( m_hWnd, &clientRect );
			BitBlt( ps.hdc, 0, 0, (clientRect.right-clientRect.left), (clientRect.bottom-clientRect.top), m_hMemDC, 0, 0, SRCCOPY );
			
			EndPaint( hWnd, &ps );

			break;
		}
		
		
		case WM_ERASEBKGND:
		{
			RECT clientRect;
			GetClientRect( m_hWnd, &clientRect );
			FillRect( m_hMemDC, &clientRect, m_hBgBrush );
		}
		break;
		
		case WM_HSCROLL:
		{
			switch ( LOWORD(wParam) )
			{
			case SB_LINERIGHT:
			case SB_PAGERIGHT:
				{
					int OldPos = GetScrollPos( hWnd, SB_HORZ );
					SetScrollPos( hWnd, SB_HORZ, OldPos+10, TRUE );
					int NewPos = GetScrollPos( hWnd, SB_HORZ );
					InvalidateRect( hWnd, NULL, TRUE );
					UpdateWindow(hWnd);
				}
				break;
				
			case SB_LINELEFT:
			case SB_PAGELEFT:
				{
					int OldPos = GetScrollPos( hWnd, SB_HORZ );
					SetScrollPos( hWnd, SB_HORZ, OldPos-10, TRUE );
					int NewPos = GetScrollPos( hWnd, SB_HORZ );
					InvalidateRect( hWnd, NULL, TRUE );
					UpdateWindow(hWnd);
				}
				break;
				
			case SB_THUMBTRACK:
				{
					SCROLLINFO si;
					si.cbSize = sizeof(SCROLLINFO);
					si.fMask = SIF_ALL;
					GetScrollInfo( hWnd, SB_HORZ, &si );
					int OldPos = si.nPos;
					si.nPos = si.nTrackPos;
					int NewPos = si.nPos;
					SetScrollPos( hWnd, SB_HORZ, si.nPos, TRUE );
					InvalidateRect( hWnd, NULL, TRUE );
					UpdateWindow(hWnd);
				}
				break;
			}
			
	
			if(m_bEdit)
			{
				int scrollX = GetScrollPos( hWnd, SB_HORZ );
				int scrollY = GetScrollPos( hWnd, SB_VERT );
				RECT columnRect, clientRect;
				GetClientRect( hWnd, &clientRect );
				GetColumnRect( hWnd, 0, &columnRect );
				int offsetLeft = scrollX + clientRect.left;
				int offsetRight = scrollX + (clientRect.right-clientRect.left);
				int offsetTop = scrollY + clientRect.top + (columnRect.bottom-columnRect.top);
				int offsetBottom = scrollY + (clientRect.bottom - clientRect.top);
				if ( ( m_rcEdit.top >= offsetTop ) && ( m_rcEdit.bottom <= offsetBottom ) &&
					( m_rcEdit.right >= offsetLeft ) && ( m_rcEdit.left <= offsetRight ) )
				{
					SetWindowPos( m_hEdit, HWND_NOTOPMOST, m_rcEdit.left-scrollX, m_rcEdit.top-scrollY, m_rcEdit.right-m_rcEdit.left, m_rcEdit.bottom-m_rcEdit.top, SWP_NOZORDER | SWP_SHOWWINDOW );
					SetFocus(m_hEdit);
				}
				else
					ShowWindow( m_hEdit, SW_HIDE );
			}
		}
		break;
		
		case WM_VSCROLL:
		{
			switch ( LOWORD(wParam) )
			{
			case SB_LINEUP:
				{
					RECT rowRect;
					GetRowRect( hWnd, 0, &rowRect );
					int OldPos = GetScrollPos( hWnd, SB_VERT );
					int diff = (rowRect.bottom-rowRect.top) - 1;
					SetScrollPos( hWnd, SB_VERT, OldPos-diff, TRUE );
					InvalidateRect( hWnd, NULL, TRUE );
					UpdateWindow(hWnd);
				}
				break;
				
			case SB_PAGEUP:
				{
					RECT rowRect, clientRect;
					GetRowRect( hWnd, 0, &rowRect );
					GetClientRect( hWnd, &clientRect );
					int OldPos = GetScrollPos( hWnd, SB_VERT );
					int diff = (clientRect.bottom-clientRect.top) / (rowRect.bottom-rowRect.top-1) - 2;
					diff *= (rowRect.bottom-rowRect.top-1);
					SetScrollPos( hWnd, SB_VERT, OldPos-diff, TRUE );
					InvalidateRect( hWnd, NULL, TRUE );
					UpdateWindow(hWnd);
				}
				break;
				
			case SB_LINEDOWN:
				{
					RECT rowRect;
					GetRowRect( hWnd, 0, &rowRect );
					int OldPos = GetScrollPos( hWnd, SB_VERT );
					int diff = (rowRect.bottom-rowRect.top) - 1;
					SetScrollPos( hWnd, SB_VERT, OldPos+diff, TRUE );
					InvalidateRect( hWnd, NULL, TRUE );
					UpdateWindow(hWnd);
				}
				break;
				
			case SB_PAGEDOWN:
				{
					RECT rowRect, clientRect;
					GetRowRect( hWnd, 0, &rowRect );
					GetClientRect( hWnd, &clientRect );
					int OldPos = GetScrollPos( hWnd, SB_VERT );
					int diff = (clientRect.bottom-clientRect.top) / (rowRect.bottom-rowRect.top-1) - 2;
					diff *= (rowRect.bottom-rowRect.top-1);
					SetScrollPos( hWnd, SB_VERT, OldPos+diff, TRUE );
					InvalidateRect( hWnd, NULL, TRUE );
					UpdateWindow(hWnd);
				}
				break;
				
			case SB_THUMBTRACK:
				{
					RECT rowRect, clientRect, columnRect;
					GetRowRect( hWnd, 0, &rowRect );
					GetColumnRect( hWnd, 0, &columnRect );
					GetClientRect( hWnd, &clientRect );
					clientRect.top = columnRect.bottom;
					SCROLLINFO si;
					si.cbSize = sizeof(SCROLLINFO);
					si.fMask = SIF_ALL;
					GetScrollInfo( hWnd, SB_VERT, &si );
					int OldPos = si.nPos;
					int NewPos = si.nTrackPos;
					int diff = NewPos % (rowRect.bottom-rowRect.top-1);
					NewPos -= diff;
					si.nPos = NewPos;
					si.nTrackPos = NewPos;
					SetScrollPos( hWnd, SB_VERT, NewPos, TRUE );
					InvalidateRect( hWnd, NULL, TRUE );
					UpdateWindow(hWnd);
				}
				break;
			}
			
	
			if ( m_bEdit )
			{
				int scrollX = GetScrollPos( hWnd, SB_HORZ );
				int scrollY = GetScrollPos( hWnd, SB_VERT );
				RECT columnRect, clientRect;
				GetClientRect( hWnd, &clientRect );
				GetColumnRect( hWnd, 0, &columnRect );
				int offsetLeft = scrollX + clientRect.left;
				int offsetRight = scrollX + (clientRect.right-clientRect.left);
				int offsetTop = scrollY + clientRect.top + (columnRect.bottom-columnRect.top);
				int offsetBottom = scrollY + (clientRect.bottom - clientRect.top);
				
				if ( ( m_rcEdit.top >= offsetTop ) && ( m_rcEdit.bottom <= offsetBottom ) &&
					( m_rcEdit.right >= offsetLeft ) && ( m_rcEdit.left <= offsetRight ) )
				{
					SetWindowPos( m_hEdit, HWND_NOTOPMOST, m_rcEdit.left-scrollX, m_rcEdit.top-scrollY, m_rcEdit.right-m_rcEdit.left, m_rcEdit.bottom-m_rcEdit.top, SWP_NOZORDER | SWP_SHOWWINDOW );
					SetFocus(m_hEdit);
				}
				else
					ShowWindow( m_hEdit, SW_HIDE );
			}
		}
		break;

		case WM_MOUSEWHEEL:
		{
			short int zDelta = (short)HIWORD(wParam);
			if ( zDelta > 0 )
			{
				// Scroll page up
				int scrollCode = SB_PAGEUP;
				short int pos = GetScrollPos( hWnd, SB_VERT );
				SendMessage( hWnd, WM_VSCROLL, MAKEWPARAM(scrollCode,pos), (LPARAM)NULL );
			}
			else
			{
				// Scroll page down
				int scrollCode = SB_PAGEDOWN;
				short int pos = GetScrollPos( hWnd, SB_VERT );
				SendMessage( hWnd, WM_VSCROLL, MAKEWPARAM(scrollCode,pos), (LPARAM)NULL );
			}
		}
		break;
		
		case WM_LBUTTONDOWN:
		{
			int scrollX = GetScrollPos( hWnd, SB_HORZ );
			int scrollY = GetScrollPos( hWnd, SB_VERT );
			int xPos = LOWORD(lParam) + scrollX;
			int yPos = HIWORD(lParam) + scrollY;
			
			if ( m_bEdit )
			{
				char text[1024];
				SendMessage( m_hEdit, WM_GETTEXT, (WPARAM)1024, (LPARAM)text );
				ShowWindow( m_hEdit, SW_HIDE );
				m_bEdit = FALSE;
				SetDGItemText( hWnd, m_nSelectRow, m_nSelectCol, text );
				
				// Send notification to the parent window
				SendMessage( m_hPrn, WM_COMMAND, MAKEWPARAM(0,DGM_ITEMTEXTCHANGED), (LPARAM)hWnd );
			}
			
			// Check for resized columns
			RECT rect;
			if ( m_Resize == FALSE )
				m_Resize = CheckColumnResize( hWnd, xPos, yPos, &m_Column, &rect );
			// Check for clicked columns
			if ( !m_Resize )
				m_Click = CheckColumnClick( hWnd, xPos, yPos, &m_Column );

			if ( m_Click )
				m_vCols[m_Column]->pressed = true;
			
			// Check for selected rows
			if ( !m_Click )
			{
				if ( CheckRows( hWnd, xPos, yPos, &m_Row ) )
				{
					// Send notification to the parent window
					SendMessage( m_hPrn, WM_COMMAND, MAKEWPARAM(0,DGM_ITEMCHANGED), (LPARAM)hWnd );
				}
			}
			InvalidateRect( hWnd, NULL, FALSE );
			UpdateWindow(hWnd);
			
			SetFocus(hWnd);
			
			// Capture mouse
			SetCapture(hWnd);

		}
		break;
		
		case WM_LBUTTONUP:
		{
			int scrollX = GetScrollPos( hWnd, SB_HORZ );
			int scrollY = GetScrollPos( hWnd, SB_VERT );
			int xPos = LOWORD(lParam) + scrollX;
			int yPos = HIWORD(lParam) + scrollY;
			
			for ( int i=0; i<m_vCols.size(); i++ )
				m_vCols[i]->pressed = false;
			
			if ( m_Resize )
			{
				// Send notification to the parent window
				SendMessage( m_hPrn, WM_COMMAND, MAKEWPARAM(0,DGM_COLUMNRESIZED), (LPARAM)hWnd );
			}
			
			RECT rect;
			m_Resize = FALSE;

			if ( ( m_Click ) && ( m_EnableSort ) )
			{
				SortDGItems( hWnd, m_Column );
				m_Click = FALSE;
				
				// Send notification to the parent window
				SendMessage( m_hPrn, WM_COMMAND, MAKEWPARAM(0,DGM_COLUMNCLICKED), (LPARAM)hWnd );
			}
			m_Cursor = CheckColumnResize( hWnd, xPos, yPos, &m_Column, &rect );
			InvalidateRect( hWnd, NULL, FALSE );
			UpdateWindow(hWnd);
			
			// Release mouse
			ReleaseCapture();
		}
		break;
		
		case WM_NCLBUTTONUP:
		{
			for ( int i=0; i<m_vCols.size(); i++ )
				m_vCols[i]->pressed = false;
			
			if ( m_Resize )
			{
				// Send notification to the parent window
				SendMessage( m_hPrn, WM_COMMAND, MAKEWPARAM(0,DGM_COLUMNRESIZED), (LPARAM)hWnd );
			}
			
			m_Resize = FALSE;
			if ( ( m_Click ) && ( m_EnableSort ) )
			{
				SortDGItems( hWnd, m_Column );
				m_Click = FALSE;
				
				// Send notification to the parent window
				SendMessage( m_hPrn, WM_COMMAND, MAKEWPARAM(0,DGM_COLUMNCLICKED), (LPARAM)hWnd );
			}
			InvalidateRect( hWnd, NULL, FALSE );
			UpdateWindow(hWnd);

		}
		break;
		
		case WM_LBUTTONDBLCLK:
		{
			int scrollX = GetScrollPos( hWnd, SB_HORZ );
			int scrollY = GetScrollPos( hWnd, SB_VERT );
			RECT columnRect, clientRect;
			GetClientRect( hWnd, &clientRect );
			GetColumnRect( hWnd, 0, &columnRect );
			int offsetLeft = scrollX + clientRect.left;
			int offsetRight = scrollX + (clientRect.right-clientRect.left);
			int offsetTop = scrollY + clientRect.top + (columnRect.bottom-columnRect.top);
			int offsetBottom = scrollY + (clientRect.bottom - clientRect.top);
			GetCellRect( hWnd, &m_rcEdit );
			if ( ( m_rcEdit.top >= offsetTop ) && ( m_rcEdit.bottom <= offsetBottom ) &&
				( m_rcEdit.right >= offsetLeft ) && ( m_rcEdit.left <= offsetRight ) )
			{
				if ( !m_vRows[m_nSelectRow]->readOnly[m_nSelectCol] )
				{
					if ( CheckRows( hWnd, LOWORD(lParam) + scrollX, HIWORD(lParam) + scrollY, &m_Row ) )
					{
						char text[1024];
						GetDGItemText( hWnd, m_nSelectRow, m_nSelectCol, text, 1024 );
						SetWindowPos( m_hEdit, HWND_NOTOPMOST, m_rcEdit.left-scrollX, m_rcEdit.top-scrollY, m_rcEdit.right-m_rcEdit.left, m_rcEdit.bottom-m_rcEdit.top, SWP_NOZORDER | SWP_SHOWWINDOW );
						SendMessage( m_hEdit, WM_SETTEXT, (WPARAM)0, (LPARAM)(LPCTSTR)text );
						SetFocus(m_hEdit);
						m_bEdit = TRUE;
					}
				}
			}

		}
		break;
		
		case WM_MOUSEMOVE:
		{
			int scrollX = GetScrollPos( hWnd, SB_HORZ );
			int scrollY = GetScrollPos( hWnd, SB_VERT );
			int xPos = LOWORD(lParam) + scrollX;
			int yPos = HIWORD(lParam) + scrollY;
			
			int oldSize, newSize;
			RECT rect;
			if ( wParam == MK_LBUTTON )
			{
				if ( ( m_Resize ) && ( m_EnableResize ) )
				{
					// Get column rectangle
					GetColumnRect( hWnd, m_Column, &rect );
					
					RECT wndRect;
					GetWindowRect( hWnd, &wndRect );
					POINT pt = {LOWORD(lParam), HIWORD(lParam)};
					
					if ( ( pt.x >= 0 ) && ( pt.x <= 2000 ) )
					{
						// Calculate new column size
						oldSize = rect.right - rect.left;
						newSize = xPos - rect.left;
						if ( newSize < 0 )
							newSize = 2;
						
						// Resize DataGrid column
						m_vCols[m_Column]->columnWidth = newSize;
						RecalcWindow(hWnd);
						RECT clientRect, columnRect;
						GetColumnRect( hWnd, 0, &columnRect );
						GetClientRect( hWnd, &clientRect );
						clientRect.top += (columnRect.bottom-columnRect.top);
						InvalidateRect( hWnd, NULL, TRUE );
						UpdateWindow(hWnd);
						
						m_Cursor = TRUE;
					}
				}
				else
					m_Cursor = FALSE;
			}
			else if ( m_EnableResize )
				m_Cursor = CheckColumnResize( hWnd, xPos, yPos, &m_Column, &rect );
		}
		break;
		
		case WM_SETCURSOR:
		{
			// Check cursor flag
			if ( ( m_Cursor ) && ( LOWORD(lParam) == HTCLIENT ) )
				SetCursor(LoadCursor(NULL, IDC_SIZEWE));
			else
				SetCursor(LoadCursor(NULL, IDC_ARROW));
		}
		break;
		
		case WM_KEYDOWN:
		{
			if ( m_pRowSelect != NULL )
			{
				/* KEY_DOWN pressed */
				if ( int(wParam) == 40 )
				{
					// Select next item
					SelectNextItem( hWnd, m_pRowSelect );
					EnsureVisible( hWnd, m_nSelectRow, m_nSelectCol );
				}
				/* KEY_UP pressed */
				else if ( int(wParam) == 38 )
				{
					// Select previous item
					SelectPreviousItem( hWnd, m_pRowSelect );
					EnsureVisible( hWnd, m_nSelectRow, m_nSelectCol );
				}
				/* KEY_LEFT pressed */
				else if ( int(wParam) == 37 )
				{
					// Select previous subitem
					SelectPreviousSubitem(hWnd);
					EnsureVisible( hWnd, m_nSelectRow, m_nSelectCol );
				}
				/* KEY_RIGHT pressed */
				else if ( int(wParam) == 39 )
				{
					// Select next subitem
					SelectNextSubitem(hWnd);
					EnsureVisible( hWnd, m_nSelectRow, m_nSelectCol );
				}
				/* KEY_PAGEUP pressed */
				else if ( int(wParam) == 33 )
				{
					// Scroll page up
					int scrollCode = SB_PAGEUP;
					short int pos = GetScrollPos( hWnd, SB_VERT );
					SendMessage( hWnd, WM_VSCROLL, MAKEWPARAM(scrollCode,pos), (LPARAM)NULL );
				}
				/* KEY_PAGEDOWN pressed */
				else if ( int(wParam) == 34 )
				{
					// Scroll page up
					int scrollCode = SB_PAGEDOWN;
					short int pos = GetScrollPos( hWnd, SB_VERT );
					SendMessage( hWnd, WM_VSCROLL, MAKEWPARAM(scrollCode,pos), (LPARAM)NULL );
				}
				
				// Send notification to the parent window
				SendMessage( m_hPrn, WM_COMMAND, MAKEWPARAM(0,DGM_ITEMCHANGED), (LPARAM)hWnd );
				
				InvalidateRect( hWnd, NULL, TRUE );
				UpdateWindow(hWnd);
			}
		}

		break;
		
	default:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
	}

	return 0;
}


void CDataGrid::DrawColumns(HWND hWnd)
{
	int offsetX=0, offsetY=0;
	RECT rect;
	SIZE size;
	TEXTMETRIC tm;
	DRAWTEXTPARAMS dtp;
	dtp.cbSize = sizeof(DRAWTEXTPARAMS);
	dtp.iLeftMargin = 5;
	dtp.iRightMargin = 5;
	dtp.iTabLength = 0;
	
	// Find DataGrid
	
	HDC hDC = m_hMemDC;
	
	int scrollX = GetScrollPos( hWnd, SB_HORZ );
	offsetX -= scrollX;
	
	HFONT hOldFont = (HFONT)SelectObject( hDC, m_hFontCol );
	COLORREF oldTxtColor = SetTextColor( hDC, m_TextColorCol );
	SetBkMode( hDC, TRANSPARENT );
	
	for ( int i=0; i<m_vCols.size(); i++ )
	{
		// Get column text dimensions
		GetTextExtentPoint( hDC, (char*)m_vCols[i]->columnText.c_str(), strlen(m_vCols[i]->columnText.c_str()), &size );
		GetTextMetrics( hDC, &tm );
		
		// Set column rectangle
		rect.left = offsetX;
		rect.top = offsetY;
		rect.right = rect.left + m_vCols[i]->columnWidth;
		rect.bottom = rect.top + size.cy + tm.tmInternalLeading;
		offsetX = rect.right;
		
		if ( m_EnableSort )
		{
			// Draw sorting column
			if ( !m_vCols[i]->pressed )
				DrawFrameControl( hDC, &rect, DFC_BUTTON, DFCS_BUTTONPUSH );
			else
				DrawFrameControl( hDC, &rect, DFC_BUTTON, DFCS_BUTTONPUSH | DFCS_FLAT );
		}
		else
		{
			// Draw non-sorting column
			rect.bottom += 2;
			DrawEdge( hDC, &rect, EDGE_ETCHED, BF_RECT | BF_MIDDLE | BF_ADJUST );
		}
		
		// Draw column text
		DrawTextEx( hDC
			, (char*)m_vCols[i]->columnText.c_str()
			, strlen(m_vCols[i]->columnText.c_str())
			, &rect, m_vCols[i]->textAlign | DT_VCENTER | DT_SINGLELINE | DT_WORD_ELLIPSIS
			, &dtp );
	}
	
	SetTextColor( hDC, oldTxtColor );
	SetBkMode( hDC, OPAQUE );
	SelectObject( hDC, hOldFont );
}


void CDataGrid::DrawRows(HWND hWnd)
{
	int offsetX=0, offsetY=0, offY=0;
	RECT rect, colRect, clientRect;
	SIZE size;
	TEXTMETRIC tm;
	DRAWTEXTPARAMS dtp;
	dtp.cbSize = sizeof(DRAWTEXTPARAMS);
	dtp.iLeftMargin = 5;
	dtp.iRightMargin = 5;
	dtp.iTabLength = 0;
	
	
	HDC hDC = m_hMemDC;
	
	GetClientRect( hWnd, &clientRect );
	
	int scrollX = GetScrollPos( hWnd, SB_HORZ );
	offsetX -= scrollX+1;
	int scrollY = GetScrollPos( hWnd, SB_VERT );
	offY -= scrollY;
	
	// Get column rectangle
	GetColumnRect( hWnd, 0, &colRect );
	offsetY += (colRect.bottom - colRect.top) - 1;
	
	HFONT hOldFont = (HFONT)SelectObject( hDC, m_hFontRow );
	HPEN hOldPen;
	HPEN hBgPen = CreatePen( PS_SOLID, 1, DGBGR_COLOR );
	if ( m_EnableGrid )
		hOldPen = (HPEN)SelectObject( hDC, m_hCellPen );
	else
		hOldPen = (HPEN)SelectObject( hDC, hBgPen );
	COLORREF oldTxtColor = SetTextColor( hDC, m_TextColorRow );
	SetBkMode( hDC, TRANSPARENT );
	
	// Get row clipping boundaries
	RECT rRect, cRect;
	GetRowRect( hWnd, 0, &rRect );
	GetClientRect( hWnd, &cRect );
	int rowOffsetT = scrollY / (rRect.bottom-rRect.top-1);
	if ( ( scrollY % (rRect.bottom-rRect.top-1) != 0 ) && ( rowOffsetT > 0 ) )
		rowOffsetT--;
	offY += rowOffsetT*(rRect.bottom-rRect.top-1);
	int rowOffsetB = (scrollY + cRect.bottom-cRect.top) / (rRect.bottom-rRect.top-1);
	if ( rowOffsetB > m_vRows.size() )
		rowOffsetB = m_vRows.size();
	
	for ( int i=rowOffsetT; i<rowOffsetB; i++ )
	{
		for ( int j=0; j<m_vCols.size(); j++ )
		{
			// Get column rectangle
			GetColumnRect( hWnd, j, &colRect );
			
			// Get row text dimensions
			GetTextExtentPoint( hDC, m_vRows[i]->rowText[j].c_str(), strlen(m_vRows[i]->rowText[j].c_str()), &size );
			GetTextMetrics( hDC, &tm );
			
			// Set row rectangle
			rect.left = offsetX;
			rect.top = offsetY + offY;
			rect.right = rect.left + (colRect.right-colRect.left+1);
			rect.bottom = rect.top + size.cy + tm.tmInternalLeading;
			offsetX = rect.right - 1;
			// If item is full or partially visible
			if ( ( ( rect.top >= offsetY ) && ( rect.bottom <= clientRect.bottom ) ) || 
				( ( rect.top < clientRect.bottom ) && ( rect.bottom > clientRect.bottom ) ) || 
				( ( rect.top < offsetY ) && ( rect.bottom > offsetY ) ) )
			{
				// Check if row is selected
				if ( m_vRows[i]->selected == false )
				{
					// Draw row
					HBRUSH hBgBrush;
					if ( !m_vRows[i]->readOnly[j] )
						hBgBrush = CreateSolidBrush(m_vRows[i]->bgColor);
					else
						hBgBrush = CreateSolidBrush(DGRONLY_COLOR);
					HBRUSH hOldBrush = (HBRUSH)SelectObject( hDC, hBgBrush );
					Rectangle( hDC, rect.left, rect.top, rect.right, rect.bottom );
					
					SelectObject( hDC, hOldBrush );
					DeleteObject(hBgBrush);
					// Draw row text
					DrawTextEx( hDC, (char*)m_vRows[i]->rowText[j].c_str()
						, strlen(m_vRows[i]->rowText[j].c_str())
						, &rect, m_vRows[i]->textAlign[j] | DT_VCENTER | DT_SINGLELINE | DT_WORD_ELLIPSIS, &dtp );
				}
				else
				{
					// Draw row
					HBRUSH hSelectionBrush = CreateSolidBrush(RGB(220,230,250));
					HBRUSH hOldBrush = (HBRUSH)SelectObject( hDC, hSelectionBrush );
					Rectangle( hDC, rect.left, rect.top, rect.right, rect.bottom );
					SelectObject( hDC, hOldBrush );
					DeleteObject(hSelectionBrush);
					// Draw row text
					COLORREF oldTextColor = SetTextColor( hDC, RGB(130,130,130) );

					DrawTextEx( hDC, (char*)m_vRows[i]->rowText[j].c_str()
						, strlen(m_vRows[i]->rowText[j].c_str())
						, &rect
						, m_vRows[i]->textAlign[j] | DT_VCENTER | DT_SINGLELINE | DT_WORD_ELLIPSIS, &dtp );

					SetTextColor( hDC, oldTextColor );
				}
				
				if ( ( j == m_nSelectCol ) && ( i == m_nSelectRow ) )
				{
					// Draw focus
					RECT focusRect = rect;
					focusRect.left += 1;
					focusRect.right -= 1;
					focusRect.top += 1;
					focusRect.bottom -= 1;
					DrawFocusRect( hDC, &focusRect );
				}
			}
		}
		
		offsetX = -scrollX-1;
		offY += (rect.bottom - rect.top) - 1;
	}
	
	DeleteObject(hBgPen);
	SetTextColor( hDC, oldTxtColor );
	SetBkMode( hDC, OPAQUE );
	SelectObject( hDC, hOldPen );
	SelectObject( hDC, hOldFont );
}


BOOL CDataGrid::CheckColumnResize(HWND hWnd, int x, int y, int* col, RECT* colRect)
{
	BOOL result = FALSE;
	
	RECT rect;
	SIZE size;
	int offsetX=0, offsetY=0;
	TEXTMETRIC tm;
	
	HDC hDC = GetDC(hWnd);
	
	int scrollY = GetScrollPos( hWnd, SB_VERT );
	offsetY += scrollY;
	
	HFONT hOldFont = (HFONT)SelectObject( hDC, m_hFontCol );
	m_Cursor = FALSE;

	for ( int i=0; i<m_vCols.size(); i++ )
	{
		GetTextExtentPoint( hDC, (char*)m_vCols[i]->columnText.c_str(), strlen(m_vCols[i]->columnText.c_str()), &size );
		GetTextMetrics( hDC, &tm );
		
		rect.left = offsetX;
		rect.top = offsetY;
		rect.right = rect.left + m_vCols[i]->columnWidth;
		rect.bottom = rect.top + size.cy + tm.tmInternalLeading;
		offsetX = rect.right;
		
		// Check mouse position
		if ( ( abs(rect.right-x) < 3 ) && ( rect.top <= y ) && ( rect.bottom >= y ) )
		{
			*col = i;
			*colRect = rect;
			result = TRUE;
			break;
		}
	}
	SelectObject( hDC, hOldFont );
	
	ReleaseDC( hWnd, hDC );
	
	return result;
}


BOOL CDataGrid::CheckColumnClick(HWND hWnd, int x, int y, int* col)
{
	BOOL result = FALSE;
	
	POINT pt = {x, y};
	RECT rect;
	SIZE size;
	int offsetX=0, offsetY=0;
	TEXTMETRIC tm;
	

	HDC hDC = GetDC(hWnd);
	*col = -1;
	
	int scrollY = GetScrollPos( hWnd, SB_VERT );
	offsetY += scrollY;
	
	HFONT hOldFont = (HFONT)SelectObject( hDC, m_hFontCol );
	m_Cursor = FALSE;
	for ( int i=0; i<m_vCols.size(); i++ )
	{
		GetTextExtentPoint( hDC, (char*)m_vCols[i]->columnText.c_str(), strlen(m_vCols[i]->columnText.c_str()), &size );
		GetTextMetrics( hDC, &tm );
		
		rect.left = offsetX;
		rect.top = offsetY;
		rect.right = rect.left + m_vCols[i]->columnWidth;
		rect.bottom = rect.top + size.cy + tm.tmInternalLeading;
		offsetX = rect.right;
		
		// Check mouse position
		if ( PtInRect( &rect, pt ) )
		{
			*col = i;
			result = TRUE;
			break;
		}
	}
	SelectObject( hDC, hOldFont );
	
	ReleaseDC( hWnd, hDC );
	
	return result;
}


void CDataGrid::GetColumnRect(HWND hWnd, int col, RECT* colRect)
{
	SIZE size;
	int offsetX=0, offsetY=0;
	TEXTMETRIC tm;
	
	
	HDC hDC = GetDC(hWnd);
	
	HFONT hOldFont = (HFONT)SelectObject( hDC, m_hFontCol );

	for ( int i=0; i<m_vCols.size(); i++ )
	{
		GetTextExtentPoint( hDC, (char*)m_vCols[i]->columnText.c_str(), strlen(m_vCols[i]->columnText.c_str()), &size );
		GetTextMetrics( hDC, &tm );
		
		if ( i == col )
		{
			colRect->left = offsetX;
			colRect->top = offsetY;
			colRect->right = colRect->left + m_vCols[i]->columnWidth;
			colRect->bottom = colRect->top + size.cy + tm.tmInternalLeading;

			if ( !m_EnableSort )
				colRect->bottom += 2;
			break;
		}
		
		offsetX += m_vCols[i]->columnWidth;
	}
	SelectObject( hDC, hOldFont );
	
	ReleaseDC( hWnd, hDC );
}


int CDataGrid::GetResizedColumn()
{
	int result;
	
	result = m_Column;

	return result;
}


void CDataGrid::GetRowRect(HWND hWnd, int row, RECT* rowRect)
{
	int offsetX=0, offsetY=0;
	RECT colRect;
	SIZE size;
	TEXTMETRIC tm;
	DRAWTEXTPARAMS dtp;
	dtp.cbSize = sizeof(DRAWTEXTPARAMS);
	dtp.iLeftMargin = 5;
	dtp.iRightMargin = 5;
	dtp.iTabLength = 0;
	

	HDC hDC = GetDC(hWnd);
	
	int scrollX = GetScrollPos( hWnd, SB_HORZ );
	offsetX -= scrollX;
	
	// Get column rectangle
	GetColumnRect( hWnd, 0, &colRect );
	offsetY += (colRect.bottom - colRect.top) - 1;
	
	HFONT hOldFont = (HFONT)SelectObject( hDC, m_hFontRow );
	HPEN hOldPen = (HPEN)SelectObject( hDC, m_hCellPen );
	SetBkMode( hDC, TRANSPARENT );
	
	for ( int i=0; i<m_vRows.size(); i++ )
	{
		// Get row text dimensions
		GetTextExtentPoint( hDC, (char*)m_vRows[i]->rowText[0].c_str(), strlen(m_vRows[i]->rowText[0].c_str()), &size );
		GetTextMetrics( hDC, &tm );
		
		if ( i == row )
		{
			// Get row rectangle
			rowRect->left = offsetX;
			rowRect->top = offsetY;
			rowRect->right = rowRect->left + m_vCols[0]->columnWidth;
			rowRect->bottom = rowRect->top + size.cy + tm.tmInternalLeading;
			break;
		}
		
		offsetY += (rowRect->bottom - rowRect->top) - 1;
	}
	SetBkMode( hDC, OPAQUE );
	SelectObject( hDC, hOldPen );
	SelectObject( hDC, hOldFont );
	
	ReleaseDC( hWnd, hDC );
}


BOOL CDataGrid::CheckRows(HWND hWnd, int x, int y, int* row)
{
	BOOL result = FALSE;
	
	HDC hDC = GetDC(hWnd);
	*row = -1;
	
	if ( m_Resize )
	{
		if(hDC)
			ReleaseDC(hWnd, hDC);
		
		return result;
	}
	
	if(hDC)
	{
		// Clear selection
		m_pRowSelect = NULL;
		m_nSelectRow = -1;
		m_nSelectCol = -1;
		
		int offsetX=0, offsetY=0, offY=0;
		RECT rect, colRect;
		SIZE size;
		TEXTMETRIC tm;
		DRAWTEXTPARAMS dtp;
		dtp.cbSize = sizeof(DRAWTEXTPARAMS);
		dtp.iLeftMargin = 5;
		dtp.iRightMargin = 5;
		dtp.iTabLength = 0;
		
		int scrollX = GetScrollPos( hWnd, SB_HORZ );
		offsetX -= scrollX;
		int scrollY = GetScrollPos( hWnd, SB_VERT );
		offY -= scrollY;
		
		POINT pt = {x-scrollX, y};
		
		// Get column rectangle
		GetColumnRect( hWnd, 0, &colRect );
		offsetY += (colRect.bottom - colRect.top) - 1;
		
		HFONT hOldFont = (HFONT)SelectObject( hDC, m_hFontRow );
		HPEN hOldPen = (HPEN)SelectObject( hDC, m_hCellPen );
		SetBkMode( hDC, TRANSPARENT );
		
		bool found = false;


		int rowInd = 0;
		for ( int j=0; j<m_vRows.size(); j++ )
		{
			// Reset row selection flag
			m_vRows[j]->selected = false;
			
			for ( int i=0; i<m_vCols.size(); i++ )
			{
				// Get row text dimensions
				GetTextExtentPoint( hDC, (char*)m_vRows[j]->rowText[i].c_str(), strlen(m_vRows[j]->rowText[i].c_str()), &size );
				GetTextMetrics( hDC, &tm );
				
				// Set row rectangle
				rect.left = offsetX;
				rect.top = offsetY;
				rect.right = rect.left + m_vCols[i]->columnWidth;
				rect.bottom = rect.top + size.cy + tm.tmInternalLeading;
				offsetX = rect.right - 1;
				
				// Check if row is selected
				if ( ( PtInRect( &rect, pt ) ) && ( found == false ) )
				{
					*row = rowInd;
					m_vRows[j]->selected = true;
					found = true;
					
					// Mark selection
					m_pRowSelect = m_vRows[j];
					m_nSelectRow = j;
					m_nSelectCol = i;
					
					result = TRUE;
				}
			}
			
			offsetX = -scrollX;
			offsetY += (rect.bottom - rect.top) - 1;
			rowInd++;
		}
		
		SetBkMode( hDC, OPAQUE );
		SelectObject( hDC, hOldPen );
		SelectObject( hDC, hOldFont );
		
		ReleaseDC( hWnd, hDC );
	}
	
	return result;
}


void CDataGrid::RecalcWindow(HWND hWnd)
{
	int sizeX = 0;
	int sizeY = 0;
	

	// Get DataGrid window rectangle
	RECT rect;
	GetClientRect( hWnd, &rect );
	
	for ( int i=0; i<m_vCols.size(); i++ )
	{
		// Calculate total columns width
		sizeX += m_vCols[i]->columnWidth;
	}
	
	// Check horizontal scroll bar visibility
	int scrollDiff = (rect.right - rect.left) - sizeX;
	if ( scrollDiff < 0 )
	{
		
		// Show horizontal scroll bar
		SCROLLINFO si;
		si.cbSize = sizeof(SCROLLINFO);
		si.fMask = SIF_ALL;
		si.nPos = GetScrollPos( hWnd, SB_HORZ );
		si.nMin = 0;
		si.nMax = sizeX;
		si.nPage = si.nMax - si.nMin + 1 - abs(scrollDiff);
		si.nTrackPos = 0;
		SetScrollInfo( hWnd, SB_HORZ, &si, TRUE );
		ShowScrollBar( hWnd, SB_HORZ, TRUE );
	}
	else
		ShowScrollBar( hWnd, SB_HORZ, FALSE );
	
	if ( m_vRows.size() > 0 )
	{
		RECT colRect, rowRect;
		DRAWTEXTPARAMS dtp;
		dtp.cbSize = sizeof(DRAWTEXTPARAMS);
		dtp.iLeftMargin = 5;
		dtp.iRightMargin = 5;
		dtp.iTabLength = 0;
		// Get column rectangle
		GetColumnRect( hWnd, 0, &colRect );
		sizeY += (colRect.bottom - colRect.top) - 1;
		// Get row rectangle
		GetRowRect( hWnd, 0, &rowRect );
		sizeY += m_vRows.size() * (rowRect.bottom-rowRect.top-1) + 1;
		
		// Check vertical scroll bar visibility
		scrollDiff = (rect.bottom - rect.top) - sizeY;
		if ( scrollDiff < 0 )
		{
			// Show vertical scroll bar
			SCROLLINFO si;
			si.cbSize = sizeof(SCROLLINFO);
			si.fMask = SIF_ALL;
			si.nPos = GetScrollPos( hWnd, SB_VERT );
			si.nMin = 0;
			si.nMax = sizeY;
			si.nPage = si.nMax - si.nMin + 1 - abs(scrollDiff);
			si.nTrackPos = 0;
			SetScrollInfo( hWnd, SB_VERT, &si, TRUE );
			ShowScrollBar( hWnd, SB_VERT, TRUE );
		}
		else
			ShowScrollBar( hWnd, SB_VERT, FALSE );
	}
	else
		ShowScrollBar( hWnd, SB_VERT, FALSE );
}


BOOL CDataGrid::InsertItem(char* itemText, int textAlign)
{
	int k=0;
	BOOL result = FALSE;
	
	DG_ROW*	pNew = new CDataGrid::DG_ROW;

	INT		nColumn = m_vCols.size();
	
	pNew->Create(nColumn);
	
	for ( int j=0; j<nColumn; j++ )
	{
		pNew->rowText[j] = " ";
		pNew->textAlign[j] = textAlign;
	}


	m_vRows.push_back(pNew);

	INT		nRow	= m_vRows.size();
	
	m_vRows[nRow-1]->rowText[0] = itemText;
	m_vRows[nRow-1]->selected = false;
	m_vRows[nRow-1]->bgColor = DGBGR_COLOR;

	
	
	result = TRUE;

	
	// Send notification to the parent window
	SendMessage( m_hPrn, WM_COMMAND, MAKEWPARAM(0,DGM_ITEMADDED), (LPARAM)m_hWnd );
	
	return result;
}


BOOL CDataGrid::RemoveItem(int row)
{
	BOOL result = FALSE;
	
	if ( ( row >= 0 ) && ( row < m_vRows.size() ) )
	{
		lsDG_ROW::iterator it = m_vRows.begin() + row;

		delete (*it);

		m_vRows.erase(it);
		
		// Mark selection
		m_pRowSelect = NULL;
		m_nSelectRow = -1;
		m_nSelectCol = -1;
		
		result = TRUE;
	}
	
	// Send notification to the parent window
	SendMessage( m_hPrn, WM_COMMAND, MAKEWPARAM(0,DGM_ITEMREMOVED), (LPARAM)m_hWnd );
	
	return result;
}


void CDataGrid::RemoveAllItems()
{
	int i;
	int iSize;

	iSize = m_vRows.size();

	for(i=0; i<iSize; ++i)
	{
		delete m_vRows[i];
	}

	m_vRows.clear();
	
	m_bEdit = FALSE;
	ShowWindow( m_hEdit, SW_HIDE );
	
	m_Row = -1;
	SetScrollPos( m_hWnd, SB_HORZ, 0, TRUE );
	SetScrollPos( m_hWnd, SB_VERT, 0, TRUE );
	RecalcWindow(m_hWnd);
	
	InvalidateRect( m_hWnd, NULL, TRUE );
	UpdateWindow(m_hWnd);
}


int CDataGrid::GetSelectedRow()
{
	return m_nSelectRow;
}


int CDataGrid::GetSelectedColumn()
{
	return m_nSelectCol;
}


void CDataGrid::Update()
{
	RecalcWindow(m_hWnd);
	InvalidateRect( m_hWnd, NULL, TRUE );
	UpdateWindow(m_hWnd);
}


void CDataGrid::SetCompareFunction(DGCOMPARE CompareFunction)
{
	m_CompareFunc = (DGCOMPARE)CompareFunction;
}


void CDataGrid::SortDGItems(HWND hWnd, int column)
{
	// Send notification to the parent window
	SendMessage( m_hPrn, WM_COMMAND, MAKEWPARAM(0,DGM_STARTSORTING), (LPARAM)hWnd );
	
	// Sort DataGrid items
	Sort( hWnd, column, m_vRows.size() );
	
	// Send notification to the parent window
	SendMessage( m_hPrn, WM_COMMAND, MAKEWPARAM(0,DGM_ENDSORTING), (LPARAM)hWnd );
	
	// Set selection focus
	SetDGSelection( hWnd, m_nSelectRow, m_nSelectCol );
	InvalidateRect( hWnd, NULL, TRUE );
	UpdateWindow(hWnd);
}


void CDataGrid::Sort(HWND hWnd, int col, int size)
{
	return;
	
	int i;
	CDataGrid::DG_ROW temp;
	
	for ( i=(size+1/2); i>=0; i-- )
		SiftDown( hWnd, i, size-1, col );
	
	for ( i=size-1; i>=1; i-- )
	{
		memcpy( &temp, &m_vRows[0], sizeof(CDataGrid::DG_ROW) );
		memcpy( &m_vRows[0], &m_vRows[i], sizeof(CDataGrid::DG_ROW) );
		memcpy( &m_vRows[i], &temp, sizeof(CDataGrid::DG_ROW) );
		SiftDown( hWnd, 0, i-1, col );
	}
}


void CDataGrid::SiftDown( HWND hWnd, int root, int bottom, int col )
{
	return;

	int done, maxChild;
	
	CDataGrid::DG_ROW temp;
	
	done = 0;
	
	while ( (root*2 < bottom) && (!done) )
	{
		if ( root*2 == bottom )
			maxChild = root * 2;
		else if ( root*2 < bottom )
		{
			if ( m_CompareFunc((char*)m_vRows[root*2]->rowText[col].c_str(), (char*)m_vRows[root*2+1]->rowText[col].c_str(), col) > 0 )
				maxChild = root * 2;
			else
				maxChild = root * 2 + 1;
			
			if ( m_CompareFunc((char*)m_vRows[root]->rowText[col].c_str(), (char*)m_vRows[maxChild]->rowText[col].c_str(), col) < 0 )
			{
				memcpy( &temp, &m_vRows[root], sizeof(CDataGrid::DG_ROW) );
				memcpy( &m_vRows[root], &m_vRows[maxChild], sizeof(CDataGrid::DG_ROW) );
				memcpy( &m_vRows[maxChild], &temp, sizeof(CDataGrid::DG_ROW) );
				root = maxChild;
			}
			else
				done = 1;
		}
		else
			done = 1;
	}
}


void CDataGrid::SetDGSelection(HWND hWnd, int rowIndex, int columnIndex)
{
	bool found = false;
	for ( int j=0; j<m_vRows.size(); j++ )
	{
		if ( ( m_vRows[j]->selected ) && ( !found ) )
		{
			// Mark selection
			m_pRowSelect = m_vRows[j];
			m_nSelectRow = j;
			m_nSelectCol = columnIndex;
			found = true;
			break;
		}
		
		if ( found )
			break;
	}
}


void CDataGrid::SelectNextItem(HWND hWnd, CDataGrid::DG_ROW* item)
{
	for ( int i=0; i<m_vRows.size(); i++ )
	{
		if ( ( (m_vRows[i]) == m_pRowSelect ) && ( i < m_vRows.size()-1 ) )
		{
			// Set selected item
			m_vRows[i  ]->selected = false;
			m_vRows[i+1]->selected = true;
			m_pRowSelect = m_vRows[i+1];
			m_nSelectRow = i+1;
			break;
		}
	}
}


void CDataGrid::SelectPreviousItem(HWND hWnd, CDataGrid::DG_ROW* item)
{
	for ( int i=0; i<m_vRows.size(); i++ )
	{
		if ( ( m_vRows[i] == m_pRowSelect ) && ( i > 0 ) )
		{
			// Set selected item
			m_vRows[i  ]->selected = false;
			m_vRows[i-1]->selected = true;
			m_pRowSelect = m_vRows[i-1];
			m_nSelectRow = i-1;
			break;
		}
	}
}


void CDataGrid::SelectNextSubitem(HWND hWnd)
{
	// Set selected subitem
	if ( m_nSelectCol < m_vCols.size()-1 )
		m_nSelectCol++;
	else
		m_nSelectCol = m_vCols.size()-1;   
}


void CDataGrid::SelectPreviousSubitem(HWND hWnd)
{
	// Set selected subitem
	if ( m_nSelectCol > 0 )
		m_nSelectCol--;
	else
		m_nSelectCol = 0;
}


void CDataGrid::EnsureVisible(HWND hWnd, int rowIndex, int colIndex)
{
	// Ensure DataGrid item is visible
	EnsureRowVisible( hWnd, rowIndex );
	EnsureColumnVisible( hWnd, colIndex );
}


void CDataGrid::EnsureRowVisible(HWND hWnd, int rowIndex)
{
	RECT rowRect, clientRect, columnRect;
	GetClientRect( hWnd, &clientRect );
	GetColumnRect( hWnd, 0, &columnRect );
	int clientHeight = clientRect.bottom - clientRect.top;
	GetRowRect( hWnd, 0, &rowRect );
	int rowOffsetT = m_nSelectRow*(rowRect.bottom-rowRect.top-1);
	int rowOffsetB = m_nSelectRow*(rowRect.bottom-rowRect.top-1) + (columnRect.bottom-columnRect.top-1);
	int scrollY = GetScrollPos( hWnd, SB_VERT );
	if ( scrollY > rowOffsetT )
		SetScrollPos( hWnd, SB_VERT, rowOffsetT, TRUE );
	else if ( scrollY+clientHeight < rowOffsetB+(rowRect.bottom - rowRect.top) )
	{
		int pos = rowOffsetB + (rowRect.bottom - rowRect.top) - (scrollY+clientHeight);
		SetScrollPos( hWnd, SB_VERT, scrollY+pos, TRUE );
	}
}


void CDataGrid::EnsureColumnVisible(HWND hWnd, int columnIndex)
{
	RECT columnRect, clientRect;
	GetClientRect( hWnd, &clientRect );
	int scrollX = GetScrollPos( hWnd, SB_HORZ );
	int columnOffsetL = 0;
	for ( int i=0; i<m_nSelectCol; i++ )
	{
		GetColumnRect( hWnd, i, &columnRect );
		columnOffsetL += (columnRect.right-columnRect.left);
	}
	GetColumnRect( hWnd, m_nSelectCol, &columnRect );
	int columnOffsetR = columnOffsetL + (columnRect.right-columnRect.left);
	if ( scrollX + clientRect.left > columnOffsetL )
	{
		int pos = scrollX + clientRect.left - columnOffsetL;
		SetScrollPos( hWnd, SB_HORZ, columnOffsetL, TRUE );
	}
	else if ( scrollX+clientRect.right < columnOffsetR )
	{
		int pos = columnOffsetR - (scrollX+clientRect.right);
		SetScrollPos( hWnd, SB_HORZ, scrollX+pos, TRUE );
	}
}


void CDataGrid::SetItemBgColor(int rowIndex, COLORREF bgColor)
{
	if ( ( rowIndex >= 0 ) && ( rowIndex < m_vRows.size() ) )
	{
		m_vRows[rowIndex]->bgColor = bgColor;
		InvalidateRect( m_hWnd, NULL, TRUE );
		UpdateWindow(m_hWnd);
	}
}



void CDataGrid::GetCellRect(HWND hWnd, RECT* cellRect)
{
	RECT rowRect, columnRect;
	GetColumnRect( hWnd, m_nSelectCol, &columnRect );
	GetRowRect( hWnd, 0, &rowRect );
	int rowOffset = m_nSelectRow * (rowRect.bottom-rowRect.top-1) + (columnRect.bottom-columnRect.top-1);
	cellRect->left = columnRect.left;
	cellRect->right = cellRect->left + (columnRect.right-columnRect.left) - 1;
	cellRect->top = rowOffset + 1;
	cellRect->bottom = cellRect->top + (rowRect.bottom-rowRect.top-1) - 1;
}


void CDataGrid::EnableSort(BOOL enable)
{
	m_EnableSort = enable;
}


void CDataGrid::EnableEdit(BOOL enable)
{
	m_EnableEdit = enable;
}


void CDataGrid::EnableResize(BOOL enable)
{
	m_EnableResize = enable;
}


void CDataGrid::EnableGrid(BOOL enable)
{
	m_EnableGrid = enable;
}


void CDataGrid::SetRowTxtColor(COLORREF txtColor)
{
	// Set DataGrid Text color
	m_TextColorRow = txtColor;
	InvalidateRect( m_hWnd, NULL, TRUE );
	UpdateWindow(m_hWnd);
}


void CDataGrid::SetColumnTxtColor(COLORREF txtColor)
{
	// Set DataGrid Text color
	m_TextColorCol = txtColor;
	InvalidateRect( m_hWnd, NULL, TRUE );
	UpdateWindow(m_hWnd);
}


int CDataGrid::GetRowNumber()
{
	int result;
	result = m_vRows.size();
	return result;
}


void CDataGrid::GetColumnFont(LOGFONT* lf)
{
	memcpy( lf, &m_lfCol, sizeof(LOGFONT) );
}


void CDataGrid::SetColumnFont(LOGFONT* lf)
{
	memcpy( &m_lfCol, lf, sizeof(LOGFONT) );
		
	if ( m_hFontCol )
		DeleteObject(m_hFontCol);

	m_hFontCol = CreateFontIndirect(lf);
}


void CDataGrid::GetRowFont(LOGFONT* lf)
{
	memcpy( lf, &m_lfRow, sizeof(LOGFONT) );
}


void CDataGrid::SetRowFont(LOGFONT* lf)
{
	// Set DataGrid row font
	memcpy( &m_lfRow, lf, sizeof(LOGFONT) );
	
	if ( m_hFontRow )
		DeleteObject(m_hFontRow);
	m_hFontRow = CreateFontIndirect(lf);
}


COLORREF CDataGrid::GetColumnTxtColor()
{
	return m_TextColorCol;
}


void CDataGrid::GetItemInfo(DG_ITEMINFO* itemInfo)
{
	// Get DataGrid item info
	if ( ( itemInfo != NULL ) && ( itemInfo->dgItem < m_vRows.size() ) && ( itemInfo->dgSubitem < m_vCols.size() ) )
	{
		switch ( itemInfo->dgMask )
		{
		case DG_TEXTEDIT:
			{
				// Get DataGrid item text
				GetDGItemText( m_hWnd, itemInfo->dgItem, itemInfo->dgSubitem, itemInfo->dgText, itemInfo->dgTextLen );
			}
			break;
			
		case DG_TEXTALIGN:
			{
				// Get DataGrid item text alignment
				itemInfo->dgTextAlign = m_vRows[itemInfo->dgItem]->textAlign[itemInfo->dgSubitem];
			}
			break;
			
		case DG_TEXTHIGHLIGHT:
			{
				// Get DataGrid row selection state
				itemInfo->dgSelected = m_vRows[itemInfo->dgItem]->selected;
			}
			break;
			
		case DG_TEXTRONLY:
			{
				// Get DataGrid item edit mode
				itemInfo->dgReadOnly = m_vRows[itemInfo->dgItem]->readOnly[itemInfo->dgSubitem];
			}
			break;
			
		case DG_TEXTBGCOLOR:
			{
				// Get DataGrid row background color
				itemInfo->dgBgColor = m_vRows[itemInfo->dgItem]->bgColor;
			}
			break;
		}
	}
}


COLORREF CDataGrid::GetRowTxtColor()
{
	return m_TextColorRow;
}


void CDataGrid::EnsureVisible(int row, int column)
{
	EnsureVisible( m_hWnd, row, column );
}


void CDataGrid::SelectItem(int row, int column)
{
	// Set DataGrid selection
	for ( int j=0; j<m_vRows.size(); j++ )
	{
		if ( j == row )
		{
			// Mark selection
			m_vRows[j]->selected = true;
			m_pRowSelect = m_vRows[j];
			m_nSelectRow = row;
			m_nSelectCol = column;
		}
		else
			m_vRows[j]->selected = false;
	}
}




// Delete DataGrid grid
void CDataGrid::Destroy()
{
	int i;
	int iSize;

	iSize = m_vRows.size();

	for(i=0; i<iSize; ++i)
	{
		delete m_vRows[i];
	}

	m_vRows.clear();


	iSize = m_vCols.size();

	for(i=0; i<iSize; ++i)
	{
		delete m_vCols[i];
	}

	m_vCols.clear();

	SAFE_DELETE_OBJECT(	m_hFontCol	);
	SAFE_DELETE_OBJECT(	m_hFontRow		);
	SAFE_DELETE_OBJECT(	m_hBgBrush		);
	SAFE_DELETE_OBJECT(	m_hCellPen		);
	SAFE_DELETE_OBJECT(	m_hMemBitmap	);
	SAFE_DELETE_OBJECT(	m_hMemDC		);
	SAFE_DELETE_OBJECT(	m_hOldMemBitmap	);
}