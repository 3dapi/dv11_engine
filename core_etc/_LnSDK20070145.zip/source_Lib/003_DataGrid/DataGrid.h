// DataGrid
// Author: darkoman (http://www.codeguru.com/cpp/controls/controls/gridcontrol/article.php/c10319/)
// Create: August 17, 2005 
// Update1: 03/01/2006 by Heesung Oh
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _DATA_GRID_H_
#define _DATA_GRID_H_


#pragma warning(disable : 4786)

#include <vector>
#include <string>
#include <windows.h>


// DataGrid definitions


#define DGTA_LEFT           DT_LEFT
#define DGTA_CENTER         DT_CENTER
#define DGTA_RIGHT          DT_RIGHT
#define DGBGR_COLOR         RGB(255,255,255)
#define DGTXT_COLOR         RGB(0,0,0)
#define DGRONLY_COLOR       RGB(220,220,220)


// DataGrid messages
#define DGM_MESSAGE				(WM_USER+1024)

#define DGM_ITEMCHANGED			(DGM_MESSAGE + 0x0001)
#define DGM_ITEMTEXTCHANGED		(DGM_MESSAGE + 0x0002)
#define DGM_ITEMADDED			(DGM_MESSAGE + 0x0003)
#define DGM_ITEMREMOVED			(DGM_MESSAGE + 0x0004)
#define DGM_COLUMNRESIZED		(DGM_MESSAGE + 0x0005)
#define DGM_COLUMNCLICKED		(DGM_MESSAGE + 0x0006)
#define DGM_STARTSORTING		(DGM_MESSAGE + 0x0007)
#define DGM_ENDSORTING			(DGM_MESSAGE + 0x0008)


#ifndef SAFE_DELETE_ARRAY
#define SAFE_DELETE_ARRAY(p){	if(p){delete [] (p);p = NULL;	}}
#endif


#ifndef SAFE_DELETE_OBJECT
#define SAFE_DELETE_OBJECT(p){	if(p){DeleteObject(p);p = NULL;	}}
#endif



class CDataGrid : public ILnWindow
{
public:
	// Custom callback procedure
	typedef int(CALLBACK *DGCOMPARE)(char* item1, char* item2, int column);


	// DataGrid column definition structure
	struct  DG_COLUMN
	{
		std::string columnText;
		int columnWidth;
		int textAlign;
		bool pressed;
	};

	typedef std::vector<DG_COLUMN*>	lsDG_COL;


	// DataGrid row definition structure
	struct DG_ROW
	{
		INT				nColumn;
		std::string*	rowText;
		int*			textAlign;
		bool			selected;
		bool*			readOnly;
		COLORREF		bgColor;

		DG_ROW()
		{
			nColumn		= NULL;
			rowText		= NULL;
			textAlign	= NULL;
			readOnly	= NULL;
		}
		
		~DG_ROW()
		{
			SAFE_DELETE_ARRAY(	textAlign	);
			SAFE_DELETE_ARRAY(	readOnly	);
			SAFE_DELETE_ARRAY(	rowText		);
		}

		int Create(int nCount)
		{
			nColumn	= nCount;
			
			textAlign	= new int[nColumn];
			readOnly	= new bool[nColumn];
			rowText		= new std::string[nColumn];
			
			return 1;
		}

	};


	typedef std::vector<DG_ROW*>	lsDG_ROW;


	// DataGrid enumerations
	enum DG_MASK {DG_TEXTEDIT, DG_TEXTALIGN, DG_TEXTHIGHLIGHT, DG_TEXTRONLY, DG_TEXTBGCOLOR};


	// DataGrid item information structure
	struct DG_ITEMINFO
	{
		DG_MASK		dgMask;
		int			dgItem;
		int			dgSubitem;
		char*		dgText;
		int			dgTextLen;
		int			dgTextAlign;
		bool		dgSelected;
		bool		dgReadOnly;
		COLORREF	dgBgColor;
	};

public:
	// Basic DataGrid methods
	CDataGrid();
	virtual ~CDataGrid();

	BOOL	Create(RECT wndRect, HWND hParent, int numCols);
	void	Resize();
	void	Update();
	
	// General DataGrid methods
	BOOL	InsertItem(char* itemText, int textAlign);
	BOOL	RemoveItem(int row);
	void	RemoveAllItems();
	void	EnableSort(BOOL enable);
	void	EnableEdit(BOOL enable);
	void	EnableResize(BOOL enable);
	void	EnableGrid(BOOL enable);
	void	EnsureVisible(int row, int column);

	void	SelectItem(int row, int column);
	int		GetResizedColumn();
	int		GetRowNumber();
	int		GetSelectedRow();
	int		GetSelectedColumn();
	void	SetCompareFunction(DGCOMPARE CompareFunction);
	
	// DataGrid SET attribute methods
	BOOL	SetColumnInfo(int columnIndex, char* columnText, int columnWidth, int textAlign);
	void	SetColumnTxtColor(COLORREF txtColor);
	void	SetColumnFont(LOGFONT* lf);
	BOOL	SetItemInfo(int rowIndex, int columnIndex, char* itemText, int textAlign, bool readOnly);
	BOOL	SetItemInfo(DG_ITEMINFO* itemInfo);
	void	SetItemBgColor(int rowIndex, COLORREF bgColor);
	void	SetRowFont(LOGFONT* lf);
	void	SetRowTxtColor(COLORREF txtColor);
	
	// DataGrid GET attribute methods
	COLORREF	GetColumnTxtColor();
	COLORREF	GetRowTxtColor();

	void	GetColumnFont(LOGFONT* lf);
	void	GetItemInfo(DG_ITEMINFO* itemInfo);
	BOOL	GetItemText(int rowIndex, int columnIndex, char* buffer, int buffer_size);
	void	GetRowFont(LOGFONT* lf);


protected:
	void	DrawColumns(HWND hWnd);
	void	DrawRows(HWND hWnd);
	BOOL	CheckColumnResize(HWND hWnd, int x, int y, int* col, RECT* colRect);
	BOOL	CheckColumnClick(HWND hWnd, int x, int y, int* col);
	BOOL	CheckRows(HWND hWnd, int x, int y, int* row);

	void	GetColumnRect(HWND hWnd, int col, RECT* colRect);
	void	GetRowRect(HWND hWnd, int row, RECT* rowRect);

	void	RecalcWindow(HWND hWnd);
	void	SortDGItems(HWND hWnd, int column);
	void	Sort(HWND hWnd, int col, int size);

	void	SetDGSelection(HWND hWnd, int rowIndex, int columnIndex);
	void	SelectNextItem(HWND hWnd, CDataGrid::DG_ROW* item);
	void	SelectPreviousItem(HWND hWnd, CDataGrid::DG_ROW* item);
	void	SelectNextSubitem(HWND hWnd);
	void	SelectPreviousSubitem(HWND hWnd);
	void	EnsureRowVisible(HWND hWnd, int rowIndex);
	void	EnsureColumnVisible(HWND hWnd, int columnIndex);
	void	EnsureVisible(HWND hWnd, int rowIndex, int colIndex);
	void	GetCellRect(HWND hWnd, RECT* cellRect);
	BOOL	GetDGItemText(HWND hWnd, int rowIndex, int columnIndex, char* buffer, int buffer_size);
	BOOL	SetDGItemText(HWND hWnd, int rowIndex, int columnIndex, char* buffer);
	void	InitDGGlobals();

	void	SiftDown( HWND hWnd, int root, int bottom, int col );

	void	Destroy();
	
	virtual LRESULT	OnMsgPrc(HWND, UINT, WPARAM, LPARAM);

protected:
	lsDG_COL	m_vCols;
	lsDG_ROW	m_vRows;

	RECT		m_rcDG;

	HWND		m_hEdit;
	HFONT		m_hFontRow;
	HFONT		m_hFontCol;

	LOGFONT		m_lfCol;
	LOGFONT		m_lfRow;

	HBRUSH		m_hBgBrush;
	HPEN		m_hCellPen;

	HDC			m_hMemDC;

	HBITMAP		m_hOldMemBitmap;
	HBITMAP		m_hMemBitmap;

	RECT		m_rcEdit;

	int			m_nSelectCol;
	int			m_nSelectRow;
	BOOL		m_Resize;

	int			m_Column;
	int			m_Row;

	BOOL		m_EnableEdit;
	BOOL		m_bEdit;

	BOOL		m_Click;
	BOOL		m_EnableSort;
	BOOL		m_EnableResize;
	BOOL		m_EnableGrid;

	BOOL		m_Cursor;
	DG_ROW*		m_pRowSelect;	

	COLORREF	m_TextColorCol;
	COLORREF	m_TextColorRow;

	DGCOMPARE	m_CompareFunc;
};



#endif

