// Interface for the CMiDShow class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MIDSHOW_H_
#define _MIDSHOW_H_


class CMiDShow
{
public:
	class IMiDShowClip
	{
	public:
		IMiDShowClip(){};
		virtual ~IMiDShowClip(){};

		virtual INT		Create(LPDIRECT3DDEVICE9 pDev, TCHAR* sFile)=0;
		virtual INT		FrameMove()=0;
		virtual void	Destroy()=0;

	public:
		virtual LPDIRECT3DTEXTURE9	GetTexture()=0;
		virtual INT					GetVideoW()=0;
		virtual INT					GetVideoH()=0;

		virtual HRESULT	Run()=0;
		virtual HRESULT	Stop()=0;
		virtual HRESULT	Reset()=0;
	};



protected:
	LPDIRECT3DDEVICE9	m_pDev;
	IMiDShowClip*		m_pVid;

public:
	CMiDShow();
	virtual ~CMiDShow();

	INT		Create(LPDIRECT3DDEVICE9 pDev, TCHAR* sFile);
	void	Destroy();

	INT		FrameMove();
	
public:
	LPDIRECT3DTEXTURE9	GetTexture();
	INT					GetVideoW();
	INT					GetVideoH();

	virtual void	Play();
	virtual void	Stop();
	virtual void	Reset();
	virtual void	Pause();
	virtual void	SetVolume(LONG dVol);
	virtual LONG	GetVolume();
	virtual void	SetRepeat(DWORD dRepeat= 0xFFFFFFFF/*INFINITE*/);
};


#endif