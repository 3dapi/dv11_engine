// Implementation of the CMiDShow class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <mmsystem.h>
#include <atlbase.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>




#include "MiDShow.h"
#include "C:/DXSDK/Samples/C++/DirectShow/BaseClasses/streams.h"

// Define GUID for Texture Renderer
// {71771540-2017-11cf-AE26-0020AFD79767}
struct __declspec(uuid("{71771540-2017-11cf-ae26-0020afd79767}")) CLSID_TextureRenderer;



// CDShowRender Class Declarations
class CDShowRender : public CBaseVideoRenderer
{
public:
	LPDIRECT3DDEVICE9	m_pDev;
	LPDIRECT3DTEXTURE9	m_pTx;
	
	LONG				m_lVidW;												// Video width
	LONG				m_lVidH;												// Video Height
	LONG				m_lVidP;												// Video Pitch
	
public:
	CDShowRender(LPUNKNOWN pUnk,HRESULT *phr, LPDIRECT3DDEVICE9 pDev);
	virtual ~CDShowRender();
	
	HRESULT		CheckMediaType(const CMediaType *pmt );							// Format acceptable?
	HRESULT		SetMediaType(const CMediaType *pmt );							// Video format notification
	HRESULT		DoRenderSample(IMediaSample *pMediaSample);						// New video sample
	LPDIRECT3DTEXTURE9	GetTexture();
};


class CDShowClip : public CMiDShow::IMiDShowClip
{
protected:
	TCHAR					m_sFile[MAX_PATH];
	LPDIRECT3DDEVICE9		m_pDev;
	
public:
	CComPtr<IGraphBuilder>  m_pGB;												// GraphBuilder
	CComPtr<IMediaControl>  m_pMC;												// Media Control
	CComPtr<IMediaPosition> m_pMP;												// Media Position
	CComPtr<IMediaEvent>    m_pME;												// Media Event
	CComPtr<IBaseFilter>    m_pBF;												// our custom renderer
	CDShowRender*			m_pSR;												// DirectShow Texture renderer
	
public:
	CDShowClip();
	virtual ~CDShowClip();
	
	virtual INT		Create(LPDIRECT3DDEVICE9 pDev, TCHAR* sFile);
	virtual void	Destroy();
	virtual INT		FrameMove();

public:	
	virtual LPDIRECT3DTEXTURE9	GetTexture();
	virtual INT					GetVideoW();
	virtual INT					GetVideoH();

	virtual HRESULT	Run();
	virtual HRESULT	Stop();
	virtual HRESULT	Reset();
};


















CDShowClip::CDShowClip()
{
	m_pDev	= NULL;
}



CDShowClip::~CDShowClip()
{
	Destroy();
}



INT	 CDShowClip::Create(LPDIRECT3DDEVICE9 pDev, TCHAR* sFile)
{
	HWND	hWnd = NULL;
	D3DDEVICE_CREATION_PARAMETERS d3dParam;

	m_pDev = pDev;
	strcpy(m_sFile, sFile);

	if(SUCCEEDED(pDev->GetCreationParameters(&d3dParam)))
		hWnd = d3dParam.hFocusWindow;
	
	
	HRESULT hr = S_OK;
	CComPtr<IBaseFilter>    pFSrc;          // Source Filter
	CComPtr<IPin>           pFSrcPinOut;    // Source Filter Output Pin   
	
	// Create the filter graph
	if (FAILED(m_pGB.CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC)))
	{
		MessageBox(hWnd, "CoCreateInstance Failed.\nWe need CoInitialize.", "Err", MB_ICONEXCLAMATION);
		return -1;
	}
	
	// Create the Texture Renderer object
	m_pSR = new CDShowRender(NULL, &hr, m_pDev);
	
	
	if (FAILED(hr) || !m_pSR)
	{
		MessageBox(hWnd, "Could not create texture renderer object", "Err", MB_ICONEXCLAMATION);
		return -1;
	}
	
	// Get a pointer to the IBaseFilter on the TextureRenderer, add it to graph
	m_pBF = m_pSR;
	if (FAILED(hr = m_pGB->AddFilter(m_pBF, L"TEXTURERENDERER")))
	{
		MessageBox(hWnd, "Could not add renderer filter to graph", "Err", MB_ICONEXCLAMATION);
		return -1;
	}
	
	
	WCHAR wFileName[MAX_PATH];
	m_sFile[MAX_PATH-1] = 0;  // NULL-terminate
	wFileName[MAX_PATH-1] = 0;    // NULL-terminate
	
	USES_CONVERSION;
	wcsncpy(wFileName, T2W(m_sFile), NUMELMS(wFileName));
	
	// Add the source filter to the graph.
	hr = m_pGB->AddSourceFilter (wFileName, L"SOURCE", &pFSrc);
	
	// If the media file was not found, inform the user.
	if (hr == VFW_E_NOT_FOUND || FAILED(hr))
	{
		MessageBox(hWnd, "Could not add source filter to graph", "Err", MB_ICONEXCLAMATION);
		return -1;
	}
	
	if (FAILED(pFSrc->FindPin(L"Output", &pFSrcPinOut)))
	{
		MessageBox(hWnd, "Could not output pin", "Err", MB_ICONEXCLAMATION);
		return -1;
	}
	
	
	// Render the source filter's output pin.  The Filter Graph Manager
	// will connect the video stream to the loaded CDShowRender
	// and will load and connect an audio renderer (if needed).
	
	if (FAILED(m_pGB->Render(pFSrcPinOut)))
	{
		MessageBox(hWnd, "Could not render source output pin", "Err", MB_ICONEXCLAMATION);
		return -1;
	}
	
	
	// Get the graph's media control, event & position interfaces
	m_pGB.QueryInterface(&m_pMC);
	m_pGB.QueryInterface(&m_pMP);
	m_pGB.QueryInterface(&m_pME);
	
	// Start the graph running;
	if (FAILED(hr = m_pMC->Run()))
	{
		MessageBox(hWnd, "Could not run the DirectShow graph", "Err", MB_ICONEXCLAMATION);
		return -1;
	}
	
	return 1;
}

void CDShowClip::Destroy()
{
	Stop();
	
	if(m_pSR && m_pSR->m_pTx)
	{
		m_pSR->m_pTx->Release();
		m_pSR->m_pTx = NULL;
	}
}



INT CDShowClip::FrameMove()
{
	long lEventCode;
	long lParam1;
	long lParam2;
	HRESULT hr;
	
	if (!m_pME)
		return 1;
	
	// Check for completion events
	hr = m_pME->GetEvent(&lEventCode, (LONG_PTR *) &lParam1, (LONG_PTR *) &lParam2, 0);

	if (SUCCEEDED(hr))
	{
		// If we have reached the end of the media file, reset to beginning
		if (EC_COMPLETE == lEventCode) 
		{
			//hr = m_pMP->put_CurrentPosition(0);
			hr = m_pME->FreeEventParams(lEventCode, lParam1, lParam2);
			
			if(m_pSR->m_pTx)
			{
				m_pSR->m_pTx->Release();
				m_pSR->m_pTx = NULL;
			}
			
			return -1;
		}
		
		// Free any memory associated with this event
		hr = m_pME->FreeEventParams(lEventCode, lParam1, lParam2);
	}
	
	return 1;
}


LPDIRECT3DTEXTURE9 CDShowClip::GetTexture()
{
	if(m_pSR)
		return m_pSR->GetTexture();
	
	return NULL;
}


INT CDShowClip::GetVideoW()
{
	return m_pSR->m_lVidW;
}

INT CDShowClip::GetVideoH()
{
	return m_pSR->m_lVidH;
}


HRESULT CDShowClip::Run()
{
	if(m_pMC)
		return m_pMC->Run();

	return S_OK;
}


HRESULT CDShowClip::Stop()
{
	if(m_pMC)
		return m_pMC->Stop();

	return S_OK;
}


HRESULT CDShowClip::Reset()
{
	// ���߰�
	if (!(!m_pMC))
		m_pMC->Stop();
	
	// Ŭ���� ó������ �̵�
	if (!(!m_pMP))
		m_pMP->put_CurrentPosition(0);
	
	// �ٽ� ��
	if (!(!m_pMC))
		m_pMC->Run();

	return S_OK;
}






// CDShowRender constructor
CDShowRender::CDShowRender( LPUNKNOWN pUnk, HRESULT *phr, LPDIRECT3DDEVICE9 pDev)
: CBaseVideoRenderer(__uuidof(CLSID_TextureRenderer), 
					 NAME("Texture Renderer"), pUnk, phr)
{
	ASSERT(phr);
	if (phr)
		*phr = S_OK;
	
	m_pDev	= pDev;
	m_pTx	= NULL;
}



// CDShowRender destructor

CDShowRender::~CDShowRender()
{
	// Do nothing
}


HRESULT CDShowRender::CheckMediaType(const CMediaType *pmt)
{
	HRESULT   hr = -1;
	VIDEOINFO *pvi=0;
	
	CheckPointer(pmt,E_POINTER);
	
	// Reject the connection if this is not a video type
	if( *pmt->FormatType() != FORMAT_VideoInfo )
	{
		return E_INVALIDARG;
	}
	
	// Only accept RGB24 video
	pvi = (VIDEOINFO *)pmt->Format();
	
	if(IsEqualGUID( *pmt->Type(),    MEDIATYPE_Video)  &&
		IsEqualGUID( *pmt->Subtype(), MEDIASUBTYPE_RGB24))
	{
		hr = S_OK;
	}
	
	return hr;
}


HRESULT CDShowRender::SetMediaType(const CMediaType *pmt)
{
	HRESULT hr;
	
	UINT uintWidth = 2;
	UINT uintHeight = 2;
	
	// Retrive the size of this media type
	
	VIDEOINFO *pviBmp;                      // Bitmap info header
	pviBmp = (VIDEOINFO *)pmt->Format();
	
	m_lVidW  = pviBmp->bmiHeader.biWidth;
	m_lVidH = abs(pviBmp->bmiHeader.biHeight);
	m_lVidP  = (m_lVidW * 3 + 3) & ~(3); // We are forcing RGB24
	
	hr = m_pDev->CreateTexture(m_lVidW, m_lVidH, 1, 0, D3DFMT_X8R8G8B8,D3DPOOL_MANAGED,	&m_pTx, NULL);
	
	if( FAILED(hr))
	{
		HWND hWnd = NULL;
		D3DDEVICE_CREATION_PARAMETERS d3dParam;	

		if(m_pDev && SUCCEEDED(m_pDev->GetCreationParameters(&d3dParam)))
		{
			hWnd = d3dParam.hFocusWindow;
		}

		MessageBox(hWnd, "Could not create the DShow texture", "Err", MB_ICONEXCLAMATION);
		return -1;
	}
	
	return S_OK;
}


// DoRenderSample: A sample has been delivered. Copy it to the texture.

HRESULT CDShowRender::DoRenderSample( IMediaSample * pSample )
{
	BYTE  *pBmpBuffer, *pTxtBuffer; // Bitmap buffer, texture buffer
	LONG  lTxtPitch;                // Pitch of bitmap, texture
	
	BYTE  * pbS = NULL;
	DWORD * pdwS = NULL;
	DWORD * pdwD = NULL;
	UINT row, col, dwordWidth;
	
	CheckPointer(pSample,E_POINTER);
	CheckPointer(m_pTx,E_UNEXPECTED);
	
	// Get the video bitmap buffer
	pSample->GetPointer( &pBmpBuffer );
	
	// Lock the Texture
	D3DLOCKED_RECT d3dlr;
	
	if( FAILED(m_pTx->LockRect(0, &d3dlr, 0, 0)))
		return -1;
	
	
	// Get the texture buffer & pitch
	pTxtBuffer = static_cast<byte *>(d3dlr.pBits);
	lTxtPitch = d3dlr.Pitch;
	
	
	// Copy the bits    
	dwordWidth = m_lVidW / 4; // aligned width of the row, in DWORDS
	// (pixel by 3 bytes over sizeof(DWORD))
	
	for( row = 0; row< (UINT)m_lVidH; row++)
	{
		pdwS = ( DWORD*)pBmpBuffer;
		pdwD = ( DWORD*)pTxtBuffer;
		
		for( col = 0; col < dwordWidth; col ++ )
		{
			pdwD[0] =  pdwS[0] | 0xFF000000;
			pdwD[1] = ((pdwS[1]<<8)  | 0xFF000000) | (pdwS[0]>>24);
			pdwD[2] = ((pdwS[2]<<16) | 0xFF000000) | (pdwS[1]>>16);
			pdwD[3] = 0xFF000000 | (pdwS[2]>>8);
			pdwD +=4;
			pdwS +=3;
		}
		
		// we might have remaining (misaligned) bytes here
		pbS = (BYTE*) pdwS;
		for( col = 0; col < (UINT)m_lVidW % 4; col++)
		{
			*pdwD = 0xFF000000 |
				(pbS[2] << 16) |
				(pbS[1] <<  8) |
				(pbS[0]);
			pdwD++;
			pbS += 3;           
		}
		
		pBmpBuffer  += m_lVidP;
		pTxtBuffer += lTxtPitch;
	}// for rows
	
	
	// Unlock the Texture
	if (FAILED(m_pTx->UnlockRect(0)))
		return -1;
	
	return S_OK;
}


LPDIRECT3DTEXTURE9 CDShowRender::GetTexture()
{
	return m_pTx;
}




















CMiDShow::CMiDShow()
{
	m_pDev		= NULL;
	m_pVid		= NULL;
}

CMiDShow::~CMiDShow()
{
	Destroy();	
}


INT CMiDShow::Create(LPDIRECT3DDEVICE9 pDev, TCHAR* sFile)
{
	m_pDev = pDev;
	
	if(!m_pVid)
	{
		m_pVid = new CDShowClip;
		
		if(FAILED(m_pVid->Create(pDev, sFile)))
			return -1;
	}
	
	return 1;
}

void CMiDShow::Destroy()
{
	if(m_pVid)
	{
		delete m_pVid;
		m_pVid = NULL;
	}
}


INT CMiDShow::FrameMove()
{
	if(m_pVid)
		return m_pVid->FrameMove();
	
	return 1;
}


LPDIRECT3DTEXTURE9 CMiDShow::GetTexture()
{
	if(m_pVid)
		return m_pVid->GetTexture();
	
	return NULL;
}



INT CMiDShow::GetVideoW()
{
	return m_pVid->GetVideoW();
}

INT CMiDShow::GetVideoH()
{
	return m_pVid->GetVideoH();
}





void CMiDShow::Play()
{
	if(m_pVid)
	{
		m_pVid->Run();
	}
}

void CMiDShow::Stop()
{
	if(m_pVid)
	{
		m_pVid->Stop();
	}
}

void CMiDShow::Reset()
{
	if(m_pVid)
	{
		m_pVid->Reset();
	}
}

void CMiDShow::Pause()
{
}

void CMiDShow::SetVolume(LONG dVol)
{
}

LONG CMiDShow::GetVolume()
{
	return 0;
}

void CMiDShow::SetRepeat(DWORD dRepeat)
{
}


