// Implementation of the ILnInput class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>

#include "LnInput.h"



ILnInput*	g_pInput;


ILnInput::ILnInput()
{
	g_pInput	= this;
	m_eType		= LN_INPUT_0;
	m_hWnd		= NULL;

	memset(  m_KeyCur, 0, sizeof  m_KeyCur);
	memset(  m_KeyOld, 0, sizeof  m_KeyOld);

	memset(  m_KeyMap, 0, sizeof  m_KeyMap);
	memset(  m_BtnMap, 0, sizeof  m_BtnMap);

	memset(&m_vcMsCur, 0, sizeof m_vcMsCur);
	memset(&m_vcMsOld, 0, sizeof m_vcMsOld);
	memset(&m_vcDelta, 0, sizeof m_vcDelta);
}

ILnInput::~ILnInput()
{
}


void ILnInput::Reset()
{
	memset(  m_KeyCur, 0, sizeof  m_KeyCur);
	memset(  m_KeyOld, 0, sizeof  m_KeyOld);

	memset(  m_KeyMap, 0, sizeof  m_KeyMap);
	memset(  m_BtnMap, 0, sizeof  m_BtnMap);

	memset(&m_vcMsCur, 0, sizeof m_vcMsCur);
	memset(&m_vcMsOld, 0, sizeof m_vcMsOld);
	memset(&m_vcDelta, 0, sizeof m_vcDelta);

	OnReset();
}


void ILnInput::OnReset()
{
}



INT ILnInput::Create(void* p)
{
	return 1;
}

INT ILnInput::FrameMove()
{
	return 1;
}


INT ILnInput::GetType()
{
	return m_eType;
}


BOOL ILnInput::IsInRect(INT left, INT top, INT right, INT bottom)
{
	return (	m_vcMsCur.x>=left
			&&	m_vcMsCur.y>=top
			&&	m_vcMsCur.x<=right
			&&	m_vcMsCur.y<=bottom);
}



BYTE* ILnInput::GetKeyMap() const
{
	return (BYTE*)m_KeyMap;
}



BOOL ILnInput::KeyDown(INT nKey)
{
	return (1 == m_KeyMap[nKey])? 1: 0;
}

BOOL ILnInput::KeyUp(INT nKey)
{
	return (2 == m_KeyMap[nKey])? 1: 0;
}

BOOL ILnInput::KeyPress(INT nKey)
{
	return (3 == m_KeyMap[nKey])? 1: 0;
}

INT ILnInput::KeyState(int nKey)
{
	return m_KeyMap[nKey];
}






BOOL ILnInput::ButtonDown(INT nBtn)
{
	return (1 == m_BtnMap[nBtn])? 1: 0;
}

BOOL ILnInput::ButtonUp(INT nBtn)
{
	return (2 == m_BtnMap[nBtn])? 1: 0;
}

BOOL ILnInput::ButtonPress(INT nBtn)
{
	return (3 == m_BtnMap[nBtn])? 1: 0;
}



VEC3 ILnInput::GetMousePos()
{
	return m_vcMsCur;
}

VEC3 ILnInput::GetMouseDelta()
{
	return m_vcDelta;
}


BOOL ILnInput::GetMouseMove()
{
	return (m_vcMsCur != m_vcMsOld) ? 1: 0;
}


void ILnInput::SetMousePos(FLOAT* vcPos)
{
	m_vcMsCur.x = vcPos[0];
	m_vcMsCur.y = vcPos[1];
	m_vcMsCur.z = vcPos[2];
}


void ILnInput::SetMousePosCenter()
{
	RECT	rc;
	VEC3 vcMouse = this->GetMousePos();										// Update Input

	::GetClientRect(m_hWnd, &rc);
	vcMouse.x  = (rc.right - rc.left)/2.f;
	vcMouse.y  = (rc.bottom - rc.top)/2.f;

	this->SetMousePos(vcMouse);
}




void ILnInput::ClientRect(HWND hWnd, RECT* rc)
{
	RECT rc1;
	RECT rc2;
	INT FrmW;
	INT FrmH;

	::GetWindowRect(hWnd, &rc1);
	::GetClientRect(hWnd, &rc2);

	FrmW = (rc1.right - rc1.left - rc2.right)/2;
	FrmH = rc1.bottom - rc1.top - rc2.bottom - FrmW;

	// Window Client Rect ���� ��ġ
	rc->left = rc1.left + FrmW;
	rc->top  = rc1.top  + FrmH;

	// Window Client Rect Width and Height
	rc->right	= rc2.right+ rc2.left;
	rc->bottom	= rc2.bottom+ rc2.top;
}



