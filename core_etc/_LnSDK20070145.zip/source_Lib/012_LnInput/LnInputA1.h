// Interface for the CLnInputA1 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNINPUTA1_H_
#define _LNINPUTA1_H_






class CLnInputA1 : public ILnInput
{
protected:
	FLOAT			m_fWheel		;											// Wheel Position

public:
	CLnInputA1();
	virtual ~CLnInputA1();

	virtual INT		Create(void* p);
	virtual INT		FrameMove();
	virtual void	SetMousePos(FLOAT* vcPos);

public:
	void			AddWheelPos(INT d);
	LRESULT			MsgProc(HWND,UINT,WPARAM,LPARAM);

protected:
	virtual void	OnReset();
};


#endif