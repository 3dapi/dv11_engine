// Interface for the ILnInput class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNINPUT_H_
#define _LNINPUT_H_


// Not defined Virtual Keys. So U'll make it.

// - on main keyboard
#define VK_MINUS		0xBD
#define VK_EQUALS		0xBB
#define VK_BACKSLASH	0xDC

#define VK_LBRACKET		0xDB
#define VK_RBRACKET		0xDD

#define VK_SEMICOLON	0xBA
#define VK_APOSTROPHE	0xDE

#define VK_COMMA		0xBC

// . on main keyboard
#define VK_PERIOD		0xBE
#define VK_SLASH		0xBF

#define VK_0			0x30
#define VK_1			0x31
#define VK_2			0x32
#define VK_3			0x33
#define VK_4			0x34
#define VK_5			0x35
#define VK_6			0x36
#define VK_7			0x37
#define VK_8			0x38
#define VK_9			0x39

#define VK_A			0x41
#define VK_B			0x42
#define VK_C			0x43
#define VK_D			0x44
#define VK_E			0x45
#define VK_F			0x46
#define VK_G			0x47

#define VK_H			0x48
#define VK_I			0x49
#define VK_J			0x4A
#define VK_K			0x4B
#define VK_L			0x4C
#define VK_M			0x4D
#define VK_N			0x4E

#define VK_O			0x4F
#define VK_P			0x50
#define VK_Q			0x51
#define VK_R			0x52
#define VK_S			0x53
#define VK_T			0x54
#define VK_U			0x55
#define VK_V			0x56
#define VK_W			0x57
#define VK_X			0x58
#define VK_Y			0x59
#define VK_Z			0x5A






#ifdef USE_DIRECT_INPUT8

#define LNK_ESCAPE			DIK_ESCAPE
#define LNK_1				DIK_1
#define LNK_2				DIK_2
#define LNK_3				DIK_3
#define LNK_4				DIK_4
#define LNK_5				DIK_5
#define LNK_6				DIK_6
#define LNK_7				DIK_7
#define LNK_8				DIK_8
#define LNK_9				DIK_9
#define LNK_0				DIK_0
#define LNK_MINUS			DIK_MINUS
#define LNK_EQUALS			DIK_EQUALS
#define LNK_BACK			DIK_BACK
#define LNK_TAB				DIK_TAB
#define LNK_Q				DIK_Q
#define LNK_W				DIK_W
#define LNK_E				DIK_E
#define LNK_R				DIK_R
#define LNK_T				DIK_T
#define LNK_Y				DIK_Y
#define LNK_U				DIK_U
#define LNK_I				DIK_I
#define LNK_O				DIK_O
#define LNK_P				DIK_P
#define LNK_LBRACKET		DIK_LBRACKET
#define LNK_RBRACKET		DIK_RBRACKET
#define LNK_RETURN			DIK_RETURN
#define LNK_LCONTROL		DIK_LCONTROL
#define LNK_A				DIK_A
#define LNK_S				DIK_S
#define LNK_D				DIK_D
#define LNK_F				DIK_F
#define LNK_G				DIK_G
#define LNK_H				DIK_H
#define LNK_J				DIK_J
#define LNK_K				DIK_K
#define LNK_L				DIK_L
#define LNK_SEMICOLON		DIK_SEMICOLON
#define LNK_APOSTROPHE		DIK_APOSTROPHE
#define LNK_GRAVE			DIK_GRAVE
#define LNK_LSHIFT			DIK_LSHIFT
#define LNK_BACKSLASH		DIK_BACKSLASH
#define LNK_Z				DIK_Z
#define LNK_X				DIK_X
#define LNK_C				DIK_C
#define LNK_V				DIK_V
#define LNK_B				DIK_B
#define LNK_N				DIK_N
#define LNK_M				DIK_M
#define LNK_COMMA			DIK_COMMA
#define LNK_PERIOD			DIK_PERIOD
#define LNK_SLASH			DIK_SLASH
#define LNK_RSHIFT			DIK_RSHIFT
#define LNK_MULTIPLY		DIK_MULTIPLY
#define LNK_LMENU			DIK_LMENU
#define LNK_SPACE			DIK_SPACE
#define LNK_CAPITAL			DIK_CAPITAL
#define LNK_F1				DIK_F1
#define LNK_F2				DIK_F2
#define LNK_F3				DIK_F3
#define LNK_F4				DIK_F4
#define LNK_F5				DIK_F5
#define LNK_F6				DIK_F6
#define LNK_F7				DIK_F7
#define LNK_F8				DIK_F8
#define LNK_F9				DIK_F9
#define LNK_F10				DIK_F10
#define LNK_NUMLOCK			DIK_NUMLOCK
#define LNK_SCROLL			DIK_SCROLL
#define LNK_NUMPAD7			DIK_NUMPAD7
#define LNK_NUMPAD8			DIK_NUMPAD8
#define LNK_NUMPAD9			DIK_NUMPAD9
#define LNK_SUBTRACT		DIK_SUBTRACT
#define LNK_NUMPAD4			DIK_NUMPAD4
#define LNK_NUMPAD5			DIK_NUMPAD5
#define LNK_NUMPAD6			DIK_NUMPAD6
#define LNK_ADD				DIK_ADD
#define LNK_NUMPAD1			DIK_NUMPAD1
#define LNK_NUMPAD2			DIK_NUMPAD2
#define LNK_NUMPAD3			DIK_NUMPAD3
#define LNK_NUMPAD0			DIK_NUMPAD0
#define LNK_DECIMAL			DIK_DECIMAL
#define LNK_OEM_102			DIK_OEM_102
#define LNK_F11				DIK_F11
#define LNK_F12				DIK_F12
#define LNK_F13				DIK_F13
#define LNK_F14				DIK_F14
#define LNK_F15				DIK_F15
#define LNK_KANA			DIK_KANA
#define LNK_ABNT_C1			DIK_ABNT_C1
#define LNK_CONVERT			DIK_CONVERT
#define LNK_NOCONVERT		DIK_NOCONVERT
#define LNK_YEN				DIK_YEN
#define LNK_ABNT_C2			DIK_ABNT_C2
#define LNK_NUMPADEQUALS    DIK_NUMPADEQUALS
#define LNK_PREVTRACK		DIK_PREVTRACK
#define LNK_AT				DIK_AT
#define LNK_COLON			DIK_COLON
#define LNK_UNDERLINE		DIK_UNDERLINE
#define LNK_KANJI			DIK_KANJI
#define LNK_STOP			DIK_STOP
#define LNK_AX				DIK_AX
#define LNK_UNLABELED		DIK_UNLABELED
#define LNK_NEXTTRACK		DIK_NEXTTRACK
#define LNK_NUMPADENTER		DIK_NUMPADENTER
#define LNK_RCONTROL		DIK_RCONTROL
#define LNK_MUTE			DIK_MUTE
#define LNK_CALCULATOR		DIK_CALCULATOR
#define LNK_PLAYPAUSE		DIK_PLAYPAUSE
#define LNK_MEDIASTOP		DIK_MEDIASTOP
#define LNK_VOLUMEDOWN		DIK_VOLUMEDOWN
#define LNK_VOLUMEUP		DIK_VOLUMEUP
#define LNK_WEBHOME			DIK_WEBHOME
#define LNK_NUMPADCOMMA		DIK_NUMPADCOMMA
#define LNK_DIVIDE			DIK_DIVIDE
#define LNK_SYSRQ			DIK_SYSRQ
#define LNK_RMENU			DIK_RMENU
#define LNK_PAUSE			DIK_PAUSE
#define LNK_HOME			DIK_HOME
#define LNK_UP				DIK_UP
#define LNK_PRIOR			DIK_PRIOR
#define LNK_LEFT			DIK_LEFT
#define LNK_RIGHT			DIK_RIGHT
#define LNK_END				DIK_END
#define LNK_DOWN			DIK_DOWN
#define LNK_NEXT			DIK_NEXT
#define LNK_INSERT			DIK_INSERT
#define LNK_DELETE			DIK_DELETE
#define LNK_LWIN			DIK_LWIN
#define LNK_RWIN			DIK_RWIN
#define LNK_APPS			DIK_APPS
#define LNK_POWER			DIK_POWER
#define LNK_SLEEP			DIK_SLEEP
#define LNK_WAKE			DIK_WAKE
#define LNK_WEBSEARCH		DIK_WEBSEARCH
#define LNK_WEBFAVORITES	DIK_WEBFAVORITES
#define LNK_WEBREFRESH		DIK_WEBREFRESH
#define LNK_WEBSTOP			DIK_WEBSTOP
#define LNK_WEBFORWARD		DIK_WEBFORWARD
#define LNK_WEBBACK			DIK_WEBBACK
#define LNK_MYCOMPUTER		DIK_MYCOMPUTER
#define LNK_MAIL			DIK_MAIL
#define LNK_MEDIASELECT		DIK_MEDIASELECT

#define LNK_BACKSPACE		DIK_BACKSPACE
#define LNK_NUMPADSTAR		DIK_NUMPADSTAR
#define LNK_LALT			DIK_LALT
#define LNK_CAPSLOCK		DIK_CAPSLOCK
#define LNK_NUMPADMINUS		DIK_NUMPADMINUS
#define LNK_NUMPADPLUS		DIK_NUMPADPLUS
#define LNK_NUMPADPERIOD    DIK_NUMPADPERIOD
#define LNK_NUMPADSLASH		DIK_NUMPADSLASH
#define LNK_RALT			DIK_RALT
#define LNK_UPARROW			DIK_UPARROW
#define LNK_PGUP			DIK_PGUP
#define LNK_LEFTARROW		DIK_LEFTARROW
#define LNK_RIGHTARROW		DIK_RIGHTARROW
#define LNK_DOWNARROW		DIK_DOWNARROW
#define LNK_PGDN			DIK_PGDN
#define LNK_CIRCUMFLEX		DIK_CIRCUMFLEX

#else

#define LNK_LBUTTON			VK_LBUTTON
#define LNK_RBUTTON			VK_RBUTTON
#define LNK_CANCEL			VK_CANCEL
#define LNK_MBUTTON			VK_MBUTTON

#define LNK_BACK			VK_BACK
#define LNK_TAB				VK_TAB

#define LNK_CLEAR			VK_CLEAR
#define LNK_RETURN			VK_RETURN

#define LNK_SHIFT			VK_SHIFT
#define LNK_CONTROL			VK_CONTROL
#define LNK_MENU			VK_MENU
#define LNK_PAUSE			VK_PAUSE
#define LNK_CAPITAL			VK_CAPITAL

#define LNK_KANA			VK_KANA
#define LNK_HANGEUL			VK_HANGEUL
#define LNK_HANGUL			VK_HANGUL
#define LNK_JUNJA			VK_JUNJA
#define LNK_FINAL			VK_FINAL
#define LNK_HANJA			VK_HANJA
#define LNK_KANJI			VK_KANJI

#define LNK_ESCAPE			VK_ESCAPE

#define LNK_CONVERT			VK_CONVERT
#define LNK_NONCONVERT		VK_NONCONVERT
#define LNK_ACCEPT			VK_ACCEPT
#define LNK_MODECHANGE		VK_MODECHANGE

#define LNK_SPACE			VK_SPACE
#define LNK_PRIOR			VK_PRIOR
#define LNK_NEXT			VK_NEXT
#define LNK_END				VK_END
#define LNK_HOME			VK_HOME
#define LNK_LEFT			VK_LEFT
#define LNK_UP				VK_UP
#define LNK_RIGHT			VK_RIGHT
#define LNK_DOWN			VK_DOWN
#define LNK_SELECT			VK_SELECT
#define LNK_PRINT			VK_PRINT
#define LNK_EXECUTE			VK_EXECUTE
#define LNK_SNAPSHOT		VK_SNAPSHOT
#define LNK_INSERT			VK_INSERT
#define LNK_DELETE			VK_DELETE
#define LNK_HELP			VK_HELP

#define LNK_LWIN			VK_LWIN
#define LNK_RWIN			VK_RWIN
#define LNK_APPS			VK_APPS

#define LNK_NUMPAD0			VK_NUMPAD0
#define LNK_NUMPAD1			VK_NUMPAD1
#define LNK_NUMPAD2			VK_NUMPAD2
#define LNK_NUMPAD3			VK_NUMPAD3
#define LNK_NUMPAD4			VK_NUMPAD4
#define LNK_NUMPAD5			VK_NUMPAD5
#define LNK_NUMPAD6			VK_NUMPAD6
#define LNK_NUMPAD7			VK_NUMPAD7
#define LNK_NUMPAD8			VK_NUMPAD8
#define LNK_NUMPAD9			VK_NUMPAD9
#define LNK_MULTIPLY		VK_MULTIPLY
#define LNK_ADD				VK_ADD
#define LNK_SEPARATOR		VK_SEPARATOR
#define LNK_SUBTRACT		VK_SUBTRACT
#define LNK_DECIMAL			VK_DECIMAL
#define LNK_DIVIDE			VK_DIVIDE
#define LNK_F1				VK_F1
#define LNK_F2				VK_F2
#define LNK_F3				VK_F3
#define LNK_F4				VK_F4
#define LNK_F5				VK_F5
#define LNK_F6				VK_F6
#define LNK_F7				VK_F7
#define LNK_F8				VK_F8
#define LNK_F9				VK_F9
#define LNK_F10				VK_F10
#define LNK_F11				VK_F11
#define LNK_F12				VK_F12
#define LNK_F13				VK_F13
#define LNK_F14				VK_F14
#define LNK_F15				VK_F15
#define LNK_F16				VK_F16
#define LNK_F17				VK_F17
#define LNK_F18				VK_F18
#define LNK_F19				VK_F19
#define LNK_F20				VK_F20
#define LNK_F21				VK_F21
#define LNK_F22				VK_F22
#define LNK_F23				VK_F23
#define LNK_F24				VK_F24

#define LNK_NUMLOCK			VK_NUMLOCK
#define LNK_SCROLL			VK_SCROLL

#define LNK_LSHIFT			VK_LSHIFT
#define LNK_RSHIFT			VK_RSHIFT
#define LNK_LCONTROL		VK_LCONTROL
#define LNK_RCONTROL		VK_RCONTROL
#define LNK_LMENU			VK_LMENU
#define LNK_RMENU			VK_RMENU
#define LNK_LALT			VK_LMENU
#define LNK_RALT			VK_RMENU

#define LNK_PROCESSKEY		VK_PROCESSKEY

#define LNK_ATTN			VK_ATTN
#define LNK_CRSEL			VK_CRSEL
#define LNK_EXSEL			VK_EXSEL
#define LNK_EREOF			VK_EREOF
#define LNK_PLAY			VK_PLAY
#define LNK_ZOOM			VK_ZOOM
#define LNK_NONAME			VK_NONAME
#define LNK_PA1				VK_PA1
#define LNK_OEM_CLEAR		VK_OEM_CLEAR



#define LNK_MINUS			VK_MINUS
#define LNK_EQUALS			VK_EQUALS
#define LNK_BACKSLASH		VK_BACKSLASH
#define LNK_LBRACKET		VK_LBRACKET
#define LNK_RBRACKET		VK_RBRACKET
#define LNK_SEMICOLON		VK_SEMICOLON
#define LNK_APOSTROPHE		VK_APOSTROPHE
#define LNK_COMMA			VK_COMMA
#define LNK_PERIOD			VK_PERIOD
#define LNK_SLASH			VK_SLASH
#define LNK_SYSRQ			VK_SNAPSHOT
#define LNK_GRAVE			VK_SELECT


#define LNK_0				VK_0
#define LNK_1				VK_1
#define LNK_2				VK_2
#define LNK_3				VK_3
#define LNK_4				VK_4
#define LNK_5				VK_5
#define LNK_6				VK_6
#define LNK_7				VK_7
#define LNK_8				VK_8
#define LNK_9				VK_9

#define LNK_A				VK_A
#define LNK_B				VK_B
#define LNK_C				VK_C
#define LNK_D				VK_D
#define LNK_E				VK_E
#define LNK_F				VK_F
#define LNK_G				VK_G
#define LNK_H				VK_H
#define LNK_I				VK_I
#define LNK_J				VK_J
#define LNK_K				VK_K
#define LNK_L				VK_L
#define LNK_M				VK_M
#define LNK_N				VK_N
#define LNK_O				VK_O
#define LNK_P				VK_P
#define LNK_Q				VK_Q
#define LNK_R				VK_R
#define LNK_S				VK_S
#define LNK_T				VK_T
#define LNK_U				VK_U
#define LNK_V				VK_V
#define LNK_W				VK_W
#define LNK_X				VK_X
#define LNK_Y				VK_Y
#define LNK_Z				VK_Z

#endif


#define LNK_BUTTONL			0
#define LNK_BUTTONR			1
#define LNK_BUTTONM			2

#define LNK_KEYNONE			0
#define LNK_KEYDOWN			1
#define LNK_KEYUP			2
#define LNK_KEYPRESS		3




class ILnInput
{
public:
	public:
	enum ELnInput
	{
		LN_INPUT_0,
		LN_INPUT_A1,
		LN_INPUT_D1,
		LN_INPUT_D2,
		
	};
	
protected:
	ELnInput		m_eType			;											// Input Type
	HWND			m_hWnd			;											// Window Handle

	BYTE			m_KeyCur[256]	;											// Current Keyboard
	BYTE			m_KeyOld[256]	;											// Old Keyboard
	
	BYTE			m_KeyMap[256]	;											// Key Map down: 1, up: 2, Press 3
	BYTE			m_BtnMap[8]		;											// Button Map

	VEC3			m_vcMsCur		;											// Mouse Current Position
	VEC3			m_vcMsOld		;											// Mouse Old Position
	VEC3			m_vcDelta		;											// Delta Mouse Position

public:
	ILnInput();
	virtual ~ILnInput();

	virtual INT		Create(void* p);
	virtual INT		FrameMove();
	virtual void	SetMousePos(FLOAT* vcPos);

public:
	void	Reset();
	INT		GetType();
	
	BYTE*	GetKeyMap()	const;
	BOOL	KeyDown(INT nKey);
	BOOL	KeyUp(INT nKey);
	BOOL	KeyPress(INT nKey);
	INT		KeyState(int nKey);

	BOOL	ButtonDown(INT nBtn);
	BOOL	ButtonUp(INT nBtn);
	BOOL	ButtonPress(INT nBtn);

	VEC3	GetMousePos();
	VEC3	GetMouseDelta();
	BOOL	GetMouseMove();

	BOOL	IsInRect(INT left, INT top, INT right, INT bottom);
	void	SetMousePosCenter();

protected:
	void	ClientRect(HWND hWnd, RECT* rc);
	virtual void	OnReset();
};


#ifndef GINPUT
	#define GINPUT g_pInput
#endif

#define GET_MOUSEPOS()		GINPUT->GetMousePos()
#define GET_MOUSEDELTA()	GINPUT->GetMouseDelta()

#define KEY_DOWN(key)		if(GINPUT->KeyDown(key))
#define KEY_UP(key)			if(GINPUT->KeyUp(key))
#define KEY_PRESS(key)		if(GINPUT->KeyPress(key))
#define BUTTON_DOWN(key)	if(GINPUT->ButtonDown(key))
#define BUTTON_UP(key)		if(GINPUT->ButtonUp(key))
#define BUTTON_PRESS(key)	if(GINPUT->ButtonPress(key))


extern ILnInput*	g_pInput;

#endif

