// Interface for the CMiSnd3D class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MISND3D_H_
#define _MISND3D_H_


class CMiSnd3D : public IMtMedia
{
protected:
	LPDIRECTSOUND3DBUFFER	m_pDsrc;											// 3D sound buffer
	LPDIRECTSOUND3DLISTENER	m_pDlsn;											// 3D listener object

	DS3DBUFFER				m_DsSrc;											// 3D buffer properties (Source)
	DS3DLISTENER			m_DsLsn;											// Listener properties (Dest)

	CMiSnd*					m_pSnd;												// sound
	
public:
	CMiSnd3D();
	virtual ~CMiSnd3D();
	
	INT		Create(LPDIRECTSOUND8 pDS, TCHAR* sFile);
	void	Destroy();

public:
	D3DXVECTOR3	GetPosSrc();
	D3DXVECTOR3	GetPosLsn();
	void		SetPosSrc(const D3DXVECTOR3* vcP);								// Sound Source Position
	void		SetPosLsn(const D3DXVECTOR3* vcP);								// Sound Listener Position

public:
	virtual DWORD	GetType();
	virtual void	Play();
	virtual void	Stop();
	virtual void	Reset();
	virtual void	Pause();
	virtual void	SetVolume(LONG dVol);
	virtual LONG	GetVolume();
	virtual void	SetRepeat(DWORD dRepeat= 0xFFFFFFFF/*INFINITE. DSBPLAY_LOOPING */);
	virtual DWORD	GetStatus();
};


INT		LnDms_Create3DSoundFromFile(
							void*		pL
						,	CMiSnd3D**	ppSound
						,	char*		sFile
					   );


#endif