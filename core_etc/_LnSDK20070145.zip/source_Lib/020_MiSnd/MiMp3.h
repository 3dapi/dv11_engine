// Interface for the CMiMp3 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MIMP3_PLAYER_H_
#define _MIMP3_PLAYER_H_

// Need DShowStrmBase.lib....
// You must be copy below codes..
//
// Begin------------------------------------------------------------------------
//	#ifdef _DEBUG
//	#pragma comment(lib, "DShowStrmbase_.lib")
//	#else
//	#pragma comment(lib, "DShowStrmbase.lib")
//	#endif
// End--------------------------------------------------------------------------


class CMiMp3 : public IMtMedia
{
protected:
	char	m_sFile[256];
	
	void*	m_pGB		;														// IGraphBuilder*
	void*	m_pMC		;														// IMediaControl*
	void*	m_pMS		;														// IMediaSeeking*
	void*	m_pSC		;														// IBaseFilter*		Source Current
	void*	m_pBA		;														// IBasicAudio*
	void*	m_pME		;														// IMediaEventEx*

	LONGLONG m_Duration	;
	DWORD	m_dRepeat	;
	DWORD	m_dStatus	;

	HWND	m_hWnd		;
	INT		m_nEventId	;

public:
	CMiMp3();
	virtual ~CMiMp3();
	virtual INT		Create(HWND hWnd, DWORD nEventId, char* sFile);
	virtual INT		ProcessEvent();

protected:
	INT		InitialGraph();

public:
	virtual DWORD	GetType();
	virtual void	Play();
	virtual void	Stop();
	virtual void	Reset();
	virtual void	Pause();
	virtual void	SetVolume(LONG dVol);
	virtual LONG	GetVolume();
	virtual void	SetRepeat(DWORD dRepeat= 0xFFFFFFFF/*INFINITE*/);
	virtual DWORD	GetStatus();
};


INT		LnDms_CreateMp3FromFile(HWND hWnd, INT nEvntId, CMiMp3** ppMp3,	char* sFile);


#endif