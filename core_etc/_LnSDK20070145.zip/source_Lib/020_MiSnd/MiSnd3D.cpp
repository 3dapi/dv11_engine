// Implementation of the CMiSnd3D class.
//
////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <d3dx9.h>
#include <dsound.h>
#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>

#include "MiWaveFile.h"
#include "MiSnd.h"
#include "MiSnd3D.h"



CMiSnd3D::CMiSnd3D()
{
	m_pDsrc	= 0;
	m_pDlsn	= 0;
	m_pSnd	= 0;
}

CMiSnd3D::~CMiSnd3D()
{
	Destroy();
}



DWORD CMiSnd3D::GetType()
{
	return MEDIA_SOUND_3;
}



void CMiSnd3D::Play()
{
	if(m_pSnd->GetStatus())
		m_pSnd->Stop();
	
	m_pSnd->Play();
}


void CMiSnd3D::Stop()
{
	m_pSnd->Stop();
}


void CMiSnd3D::Reset()
{
	m_pSnd->Reset();
}

void CMiSnd3D::Pause()
{
	m_pSnd->Pause();
}

void CMiSnd3D::SetVolume(LONG dVol)
{
	m_pSnd->SetVolume(dVol);
}

LONG CMiSnd3D::GetVolume()
{
	return m_pSnd->GetVolume();
}


void CMiSnd3D::SetRepeat(DWORD dRepeat)
{
	m_pSnd->SetRepeat(dRepeat);
}


DWORD CMiSnd3D::GetStatus()
{
	return m_pSnd->GetStatus();
}




void CMiSnd3D::SetPosSrc(const D3DXVECTOR3* vcP)
{
	m_pDsrc->SetPosition( vcP->x, vcP->y, vcP->z, DS3D_IMMEDIATE);
}

void CMiSnd3D::SetPosLsn(const D3DXVECTOR3* vcP)
{
	m_pDlsn->SetPosition( vcP->x, vcP->y, vcP->z, DS3D_IMMEDIATE);
}

D3DXVECTOR3 CMiSnd3D::GetPosSrc()
{
	D3DXVECTOR3	vcP;
	m_pDsrc->GetPosition( &vcP);
	return vcP;
}


D3DXVECTOR3 CMiSnd3D::GetPosLsn()
{
	D3DXVECTOR3	vcP;
	m_pDlsn->GetPosition( &vcP);

	return vcP;
}



INT CMiSnd3D::Create(LPDIRECTSOUND8 pDS, TCHAR* sFile)
{
	HRESULT hr;

	//1. Create 3D Sound
//	if(FAILED(hr = SNDMN->CreateSound( &m_pSnd, sFile, DSBCAPS_CTRL3D, DS3DALG_HRTF_LIGHT )))
	
	if(FAILED(hr = LnDms_CreateSoundFromFile(pDS, &m_pSnd, sFile, DSBCAPS_CTRL3D, DS3DALG_NO_VIRTUALIZATION, 1 )))
	{
		MessageBox(NULL, "Create 3D Sound BufferInterface Failed.", "Err", MB_ICONERROR);
		return hr;
	}
	
	//2. Create 3D Buffer
	if( FAILED(hr = m_pSnd->Get3DBufferInterface( 0, &m_pDsrc )))
	{
		MessageBox(NULL, "Get3DBufferInterface Failed", "Err", MB_ICONERROR);
		return hr;
	}

	
	//3. Create 3D Listener
	if( FAILED( hr = LnDms_Get3DListener(pDS, &m_pDlsn)))
	{
		MessageBox(NULL, "Initializing DirectSound Faild.", "Err", MB_ICONERROR);
		return hr;
	}
	
	
	memset(&m_DsSrc, 0, sizeof m_DsSrc);
	memset(&m_DsLsn, 0, sizeof m_DsLsn);

	m_DsSrc.dwSize			= sizeof m_DsSrc;
	m_DsSrc.dwMode			= DS3DMODE_NORMAL;
	m_DsSrc.flMinDistance	= 0.f;
	m_DsSrc.flMaxDistance	= 0.1f;

	m_pDsrc->SetAllParameters( &m_DsSrc, DS3D_IMMEDIATE );

	
	m_DsLsn.dwSize			= sizeof m_DsLsn;
	m_pDlsn->GetAllParameters(&m_DsLsn);

	m_DsLsn.vPosition.x		= 0.f;
	m_DsLsn.vPosition.y		= 0.f;
	m_DsLsn.vPosition.z		= 0.f;
	m_DsLsn.flDopplerFactor	= 0.F;
	m_DsLsn.flRolloffFactor	= 0.1F;
	m_DsLsn.flDistanceFactor= 0.F;						// �̰͵� �߿�
	
	m_pDlsn->SetAllParameters(&m_DsLsn, DS3D_IMMEDIATE);
	
	return 1;
}



void CMiSnd3D::Destroy()
{
	if(m_pSnd && m_pSnd->IsSoundPlaying())
		m_pSnd->Stop();
	
	if( m_pSnd )
	{
		delete m_pSnd;
		m_pSnd = NULL;
	}
	
	if( m_pDlsn )
	{
		m_pDlsn->Release();
		m_pDlsn = NULL;
	}
	
	if( m_pDsrc )
	{
		m_pDsrc->Release();
		m_pDsrc = NULL;
	}
}






INT	LnDms_Create3DSoundFromFile(void* pL, CMiSnd3D** ppSound, char* sFile)
{
	LPDIRECTSOUND8 pDS = (LPDIRECTSOUND8) pL;
	(*ppSound) = new CMiSnd3D;
		
	if(FAILED( (*ppSound)->Create(pDS, sFile) ))
	{
		delete (*ppSound);
		(*ppSound) = NULL;
		return -1;
	}
	
	return 1;
}
