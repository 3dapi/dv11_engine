// Implementation of the MiUtilities.
//
////////////////////////////////////////////////////////////////////////////////


#include <dmusicc.h>				// DirectMusic includes
#include <dmusici.h>
#include <cguid.h>					// for GUID_NULL

#include "MiUtil.h"


