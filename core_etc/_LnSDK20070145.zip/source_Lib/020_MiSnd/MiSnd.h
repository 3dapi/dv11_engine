// Interface for the CMiSnd class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MISND_H_
#define _MISND_H_


#pragma warning( disable : 4786)
#include <vector>


typedef LPDIRECTSOUNDBUFFER				LPDSB;
typedef LPDIRECTSOUND3DBUFFER			LPDS3D;


class CMiSnd : public IMtMedia
{
protected:
    LPDSB*	m_pBuffer	;
    DWORD	m_dBufSize	;
    void*	m_pWaveFile	;
    DWORD	m_dNbuff	;
    DWORD	m_dInitFlag	;

	DWORD	m_dwFlags	;
	DWORD	m_dwPrior	;
	LONG	m_lVolume	;
	LONG	m_lHz		;
	LONG	m_lPan		;

    HRESULT		RestoreBuffer( LPDSB pDSB, BOOL* pbWasRestored );

public:
    CMiSnd(LPDSB* apDSBuffer, DWORD dwDSBufferSize, DWORD dwNumBuffers, void* pWaveFile, DWORD dwCreationFlags);
    virtual ~CMiSnd();

    HRESULT		Get3DBufferInterface( DWORD dwIndex, LPDS3D* ppDS3DBuffer );
    HRESULT		FillBufferWithSound( LPDSB pDSB, BOOL bRepeatWavIfBufferLarger );
    LPDSB		GetFreeBuffer();
    LPDSB		GetBuffer( DWORD dwIndex );
	BOOL		IsSoundPlaying();

public:
	virtual DWORD	GetType();
	virtual void	Play();
	virtual void	Stop();
	virtual void	Reset();
	virtual void	Pause();
	virtual void	SetVolume(LONG dVol);
	virtual LONG	GetVolume();
	virtual void	SetRepeat(DWORD dRepeat= 0xFFFFFFFF/*INFINITE. DSBPLAY_LOOPING */);
	virtual DWORD	GetStatus();
};



INT	LnDms_DSoundCreate(															// Direct Sound Create
					LPDIRECTSOUND8&	pDS											// DirectSound8
					,	HWND hWnd
					,	DWORD dwCoopLevel=DSSCL_PRIORITY						// Sets the priority level
					,	DWORD dwPrimaryChannels	=2								// Stereo. Mono:1
					,	DWORD dwPrimaryFreq		= 22050							// 22KHz
					,	DWORD dwPrimaryBitRate	= 16							// 16bit
					);

INT		LnDms_DSoundPrimaryBufferFMT(LPDIRECTSOUND8 pDS, DWORD dChannels, DWORD dHz, DWORD dBitRate );
DWORD	LnDms_DSoundSpeakerConfig(LPDIRECTSOUND8 pDS);
INT		LnDms_DSound3DTest(LPDIRECTSOUND8 pDS, char* sFile);






HRESULT LnDms_CreateSoundFromFile(
							void* pL
						,	CMiSnd** ppSound
						,	LPTSTR sWaveFile
						,	DWORD dwCreationFlags = 0
						,	GUID guid3DAlgorithm = GUID_NULL
						,	DWORD dwNumBuffers = 1
					   );



HRESULT LnDms_CreateSoundFromMemory(
							void* pL
						,	CMiSnd** ppSound
						,	BYTE* pbData
						,	ULONG ulDataSize
						,	LPWAVEFORMATEX pwfx
						,	DWORD dwCreationFlags = 0
						,	GUID guid3DAlgorithm = GUID_NULL
						,	DWORD dwNumBuffers = 1
						);


HRESULT LnDms_Create3DSoundFromMemoryForTst(
									void* pL
								,	CMiSnd** ppSound
								,	DWORD dwCreationFlags = 0
								,	GUID guid3DAlgorithm = GUID_NULL
								,	DWORD dwNumBuffers = 1
								);


HRESULT LnDms_Get3DListener(void* pL, LPDIRECTSOUND3DLISTENER* ppDSListener);




#endif



