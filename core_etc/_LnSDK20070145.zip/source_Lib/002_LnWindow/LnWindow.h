// Wnd.h: interface for the ILnWindow class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _ILNWINDOW_H_
#define _ILNWINDOW_H_


#pragma once


#include <windows.h>

#ifndef _T_LINKED_LIST_OBJECT_
#define _T_LINKED_LIST_OBJECT_

class TlinkD																	// D Linked List
{
public:
	TlinkD*	pB;																	// �ڸų�� ����
	TlinkD*	pN;																	// �ڸų�� ����
	
public:
	TlinkD() : pB(0), pN(0){}
	TlinkD(TlinkD *pNod) : pB(0), pN(0)
	{
		InsertTo(pNod);
	}


	virtual ~TlinkD()
	{
		Detach();																// �θ��� �ο��� ����
		
		while(pN)																// �� �ؿ� �ڽ��� �ֳ�?
		{
			pN->Detach();
		}
	}

	TlinkD* FindFirst()	{	return (pB)? pB->FindFirst():	this;	}			// �ֻ���
	TlinkD* FindLast()	{	return (pN)? pN->FindLast():	this;	}			// ������

	void InsertTo(TlinkD *pNew)													// �θ�  �Ծ�Ǳ�^^
	{
		if (pB)																	// ���࿡ ���� �ٸ� ���� Insert�Ǿ� �ִٸ�
			Detach();															// ���� ������.
		
		TlinkD* pTmp = pNew->pN;

		this->pB = pNew;														// ���� �θ� ����
		pNew->pN = this;

		if(pTmp)
		{
			pTmp->pB = this;
			this->pN  = pTmp;
		}
	}
	
	void Insert(TlinkD *pNew)													// �Ծ��ϱ�
	{
		TlinkD* pTmp = this->pN;

		this->pN = pNew;
		pNew->pB = this;

		if(pTmp)
		{
			pTmp->pB = pNew;
			pNew->pN  = pTmp;
		}
	}


	void PushBack(TlinkD *pNew)													// �Ծ��ϱ�
	{
		TlinkD* pL = FindLast();

		pL->pN	 = pNew;
		pNew->pB = pL;
	}
	
	void Detach()
	{
		if(pB)
			pB->pN = pN;														// get rid of links
		
		if(pN)
			pN->pB = pB;
		
		pB = 0;
		pN = 0;
	}

	void DetachTo(TlinkD* pNew)
	{
		TlinkD* pLnk = FindFirst();

		while (pLnk)
		{
			if( pLnk == pNew)
				break;

			pLnk = pLnk->pN;
		}

		if(pLnk)
		{
			if(pLnk->pB)
				pLnk->pB->pN = pLnk->pN;											// get rid of links
			
			if(pLnk->pN)
				pLnk->pN->pB = pLnk->pB;
			
			pLnk->pB = 0;
			pLnk->pN = 0;
		}
	}
	
	int CountNodes()
	{
		if (pN)
			return pN->CountNodes() + 1;
		else
			return 1;
	}

	int CountNodesAll()
	{
		int nNode=0;
		TlinkD* pHead = FindFirst();

		if (pHead)
			nNode = pHead->CountNodes();

		return nNode;
	}
	
};


#endif




class ILnWindow : public TlinkD
{
protected:
	HWND	m_hWnd;
	HWND	m_hPrn;

public:
	ILnWindow();
	virtual ~ILnWindow();

	HWND	CreateDlg(HINSTANCE hInst, HWND hParent, LPCTSTR pTemplate);		// Modaless Dialog

	HWND	CreateWin( HWND hParent
						, WNDCLASSEX* pWC
						, const char* sWinName	// Window Name
						, DWORD dStyle			// Window Style
						, RECT* prcClient		// left: xPos, top: yPos, right: Width, bottom: Height
						, HMENU hMenu=0			// Menu
						, DWORD dStyleEx=0		// Extended Window Style
						);

	virtual LRESULT	OnMsgPrc(HWND, UINT, WPARAM, LPARAM)=0;

public:
	static INT_PTR	DlgProc(HWND, UINT, WPARAM, LPARAM);
	static LRESULT  WndProc(HWND, UINT, WPARAM, LPARAM);

public:
	void	SetHwnd(HWND);
	HWND	GetHwnd();
	HWND	GetHPrn();



public:
	static TlinkD*	m_pWnd;

	static void* FindWindow(HWND hWnd);
	static void* FindObject(ILnWindow* pWin);

	static void* FindObjectFirst();
	static void* FindObjectLast();
};

#endif