// Wnd.cpp: implementation of the ILnWindow class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>

#include "LnWindow.h"

TlinkD* ILnWindow::m_pWnd = NULL;

ILnWindow::ILnWindow()
{
	m_hWnd = NULL;
	m_hPrn = NULL;

	if(NULL == ILnWindow::m_pWnd)
	{
		ILnWindow::m_pWnd = new TlinkD;
	}
	
	m_pWnd->PushBack( (TlinkD*)this);
}

ILnWindow::~ILnWindow()
{
	int iSize = 0;

	if(m_pWnd)
	{
		m_pWnd->DetachTo( (TlinkD*)this);
	
		if( 1 == ILnWindow::m_pWnd->CountNodesAll())
		{
			delete m_pWnd;
			m_pWnd = NULL;
		}
	}
}



void* ILnWindow::FindWindow(HWND hWnd)
{
	TlinkD* p = NULL;
	
	if(m_pWnd)
		p = m_pWnd->FindFirst();

	if(!p || !p->pN)
		return NULL;

	p = p->pN;

	while(p)
	{
		if( ((ILnWindow*)p)->m_hWnd == hWnd)
			break;

		p = p->pN;
	}

	return (void*)p;
}


void* ILnWindow::FindObject(ILnWindow* pWin)
{
	TlinkD* p = m_pWnd->FindFirst();

	while(p)
	{
		if( (ILnWindow*)p == pWin)
			break;

		p = p->pN;
	}

	return (void*)p;
}


void* ILnWindow::FindObjectFirst()
{
	TlinkD* p = m_pWnd->FindFirst();
	return p;
}

void* ILnWindow::FindObjectLast()
{
	TlinkD* p = m_pWnd->FindLast();
	return p;
}




HWND ILnWindow::CreateDlg(HINSTANCE hInst, HWND hParent, LPCTSTR pTemplate)
{
	return ::CreateDialogParam(hInst, pTemplate, hParent, (DLGPROC)DlgProc, (LPARAM)this);
}

HWND ILnWindow::CreateWin(  HWND hParent
							, WNDCLASSEX* pWC
							, const char* sWinName
							, DWORD dStyle
							, RECT* prcClient
							, HMENU hMenu
							, DWORD dStyleEx)
{
	DWORD	hr	= -1;
	HWND	hWnd= NULL;

	WNDCLASSEX wc;
	wc.cbSize			= sizeof wc;
	wc.style			= pWC->style;
	wc.lpfnWndProc		= (WNDPROC)ILnWindow::WndProc;
	wc.cbClsExtra		= pWC->cbClsExtra;
	wc.cbWndExtra		= pWC->cbWndExtra;
	wc.hInstance		= pWC->hInstance;
	wc.hIcon			= pWC->hIcon;
	wc.hCursor			= pWC->hCursor;
	wc.hbrBackground	= pWC->hbrBackground;
	wc.lpszMenuName		= pWC->lpszMenuName;
	wc.lpszClassName	= pWC->lpszClassName;
	wc.hIconSm			= pWC->hIconSm;

//	return CreateWindowEx( WS_EX_CLIENTEDGE
//			, wc.lpszClassName
//			, sWinName
//			, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_VSCROLL | WS_HSCROLL
//			, x, y, width, height
//			, hParent
//			, NULL
//			, hInst
//			, (LPVOID)this );


	pWC->lpfnWndProc	= (WNDPROC)ILnWindow::WndProc;


	hr = RegisterClassEx(pWC);

	if(0== hr)
	{
		hr = GetLastError();

		if( ERROR_CLASS_ALREADY_EXISTS != hr )
		{
			LPVOID lpMsgBuf;

			FormatMessage( 
							FORMAT_MESSAGE_ALLOCATE_BUFFER | 
							FORMAT_MESSAGE_FROM_SYSTEM | 
							FORMAT_MESSAGE_IGNORE_INSERTS
							, NULL
							, hr
							, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT) // Default language
							, (LPTSTR) &lpMsgBuf
							, 0
							, NULL 
							);
			
			MessageBox( NULL, (LPCTSTR)lpMsgBuf, "Error", MB_OK | MB_ICONINFORMATION );
			LocalFree( lpMsgBuf );
			return NULL;
		}
	}

	
	hWnd = CreateWindowEx( dStyleEx
			, pWC->lpszClassName
			, sWinName
			, dStyle
			, prcClient->left, prcClient->top
			, prcClient->right, prcClient->bottom
			, hParent
			, hMenu
			, pWC->hInstance
			, (LPVOID)this );

	return hWnd;
}



INT_PTR ILnWindow::DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	ILnWindow* pWnd = (ILnWindow*)ILnWindow::FindWindow(hWnd);

	if(WM_INITDIALOG == uMsg)
	{
		pWnd = (ILnWindow*)lParam;
		pWnd->SetHwnd(hWnd);
	}

	if(pWnd)
		return (pWnd)->OnMsgPrc(hWnd, uMsg, wParam, lParam);

	return FALSE;
}


LRESULT ILnWindow::WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	ILnWindow* p = (ILnWindow*)ILnWindow::FindWindow(hWnd);

	if(WM_NCCREATE == uMsg)
	{
		LPCREATESTRUCT lpcs = (LPCREATESTRUCT)lParam;
		p = (ILnWindow*)(lpcs->lpCreateParams);

		p = (ILnWindow*)ILnWindow::FindObject(p);

		if(p)
			p->SetHwnd( hWnd);
	}
		
	
	if(p)
		return p->OnMsgPrc(hWnd, uMsg, wParam, lParam);
	
	return DefWindowProc( hWnd, uMsg, wParam, lParam );
}




void ILnWindow::SetHwnd(HWND hWnd)
{
	m_hWnd = hWnd;
}

HWND ILnWindow::GetHwnd()
{
	return m_hWnd;
}

HWND ILnWindow::GetHPrn()
{
	return m_hPrn;
}