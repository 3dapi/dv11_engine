// Interface for the CEfAccptEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EFACCPTEX_H_
#define _EFACCPTEX_H_


class CEfAccptEx : public IEfBase
{
public:
	char		m_sCls[64];
	PDEV		m_pDev;

	PDTX		m_pTx;
	INT			m_nImgX;
	INT			m_nImgY;
	INT			m_iImgN;
	
	INT			m_iN;
	INT			m_iC;
	EfPtc*		m_pPtc;															// Particle
	VtxDUV1*	m_pVtx;															// Vertices

	D3DXCOLOR	m_xWght;														// Color Weight

	char		m_pMdFile[MAX_PATH];											// Media File
	void*		m_pMdData;														// Media Data
	
public:
	CEfAccptEx();
	virtual ~CEfAccptEx();

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		LoadEnvFromFile(void* pLoader, char* sFile, char* sApp);	// Load Environment From File
	virtual INT		LoadEnvFromString(void* pLoader, char* sStr);				// Load Environment From String

	virtual void	OnReset();
	virtual void	OnPlay();

	virtual INT		SetVal(void* pIn, char* =NULL/*command*/);
	virtual INT		GetVal(void* pOut, char* =NULL/*command*/) const;

	// Set and Get Val Command
	// 1. Command: "Stage", Type: INT

protected:
	void	Set(INT i);
};

#endif

