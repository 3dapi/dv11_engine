// Interface for the CEftLoader class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _EFTLOADER_H_
#define _EFTLOADER_H_


#pragma warning(disable : 4786)
#include <vector>
#include <map>

class CEftLoader  
{
protected:
	std::map<std::string, PDTX >		m_mpTxF;								// <File Name, Texture > List
	std::map<std::string, IEfBase* >	m_mpEfSgl;								// Single Effect File
	
	PDEV								m_pDev;									// Device
	PDSP								m_pSpr;									// Sprite
	char								m_sFileS[MAX_PATH];
	char								m_sFileM[MAX_PATH];

public:
	struct EfLnkData
	{
		struct EfLnkDataS
		{
			int							nLnkPrn;
			std::string					sEfName;
			std::string					sEfData;
		};

		
		std::string						m_sCls;
		std::vector<EfLnkDataS >		m_vSubCls;
	};

	std::map<std::string, EfLnkData >	m_mpEfLnk;								// Multi Effect
	
public:
	CEftLoader();
	virtual ~CEftLoader();

	virtual INT		Create(PDSP pSpr /*Must be DxSprite*/, char* sFile);
	virtual void	Destroy();
	
	IEfBase*		SelectSgl(char* sFile, int nCreateOpt=1);					// Single Effect, Create Option
	IEfBase*		SelectLnk(char* sFile);										// Multi Effect

	PDTX			LoadTexture(char* sFile);

	PDEV			GetDevice() const;
	PDSP			GetSprite() const;

protected:
	IEfBase*		CreateNew(char* sName);
};


INT		LnEft_CreateEffectFromRsc(			// If it succeed then return value is 1 faied is -1
							void* pL		// Effect Loader It may be CEftLoader Instance
						,	IEfBase** pOut	// In, Out Model Instance
						,	char*	sName	// Effect Name
						);


INT		LnEft_GetMediaEntryFromEffect(lsEfMdaEnt* pEntry, IEfBase* pEft);


// sNames...
// "ScreenBlur",
// "ScreenLight",
// "ScreenMono",
// "ScreenSpread",

INT		LnEft_CreateScreenEffect(void* pL			// Effect Loader It may be CEftLoader Instance
							,	IEfScnBase** pOut	// In, Out Model Instance
							,	char*	sName		// Effect Name
							,	void*	pFunc		// Render Function Pointer
							);


#endif