// Interface for the CEfScnSprd class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EFSCNSPRD_H_
#define _EFSCNSPRD_H_


class CEfScnSprd : public IEfScnBase
{
public:
	struct TrndSf
	{
		PDTX	m_pT;			// Texture
		PDSF	m_pC;			// color buffer  
		PDSF	m_pD;			// Depth and Stencil

		TrndSf();
		void	Invalidate();
		INT		Create(PDEV pDev, INT scnW, INT scnH, DWORD dFmtColor, DWORD dFmtDepth);
		PDTX	GetTexture() const;
	};

	struct VtxwUV1
	{
		VEC4	p;
		FLOAT	u0,v0;

		VtxwUV1()	{}
		VtxwUV1(FLOAT X,FLOAT Y,FLOAT Z,FLOAT W,FLOAT U0,FLOAT V0):p(X,Y,Z,W),u0(U0),v0(V0){}
		enum	{FVF = (D3DFVF_XYZRHW|D3DFVF_TEX1),};
	};

	struct HdrRc
	{
		float u0, v0;
		float u1, v1;
	};


protected:
	PDEV				m_pDev	;
	FLOAT				m_fScnW	;
	FLOAT				m_fScnH	;

	LPD3DXEFFECT		m_pDxEft	;
	D3DXHANDLE			m_hDxTch	;
	D3DXHANDLE			m_hHafWgt	;	// ����ġ�迭
	D3DXHANDLE			m_hTxSrc	;	// �ؽ�ó

	CEfScnSprd::TrndSf	m_RndOld	;
	CEfScnSprd::TrndSf	m_RndOrg	;
	CEfScnSprd::TrndSf	m_RndDst	;

	FLOAT				m_fRgbWg	;


public:
	CEfScnSprd();
	virtual ~CEfScnSprd();
	
	virtual	INT		Create(void* p1=NULL, void* pFunc=NULL, void* p3=NULL);
	virtual	void	Destroy();

	virtual	INT		FrameMove();
	virtual	void	Render();

	virtual INT		Restore();
	virtual void	Invalidate();

	virtual INT		SetVal(void* pIn, char* =NULL/*command*/);
	virtual INT		GetVal(void* pOut, char* =NULL/*command*/) const;


protected:
	
};


#endif


