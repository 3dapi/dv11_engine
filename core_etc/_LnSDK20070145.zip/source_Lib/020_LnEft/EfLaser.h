// Interface for the CEfLaser class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EFLASER_H_
#define _EFLASER_H_


class CEfLaser : public IEfBase
{
protected:
	char		m_sCls[64];
	PDEV		m_pDev;

	PDTX		m_pTx;
	INT			m_nImgX;
	INT			m_nImgY;
	INT			m_iImgN;
	
	VtxDUV1		m_pVtx[6][10];
	D3DXCOLOR	m_pRGB[6][10];

	INT			m_nSt;		// State -1, 0, 1, 2
	FLOAT		m_fAh;		// Header
	FLOAT		m_fAt;		// tail
	
	INT			m_nColor;	// 1: Red 0: Blue
	INT			m_nRnd;		// Render Type
	FLOAT		m_fWdth;	// Width
	FLOAT		m_fInc;		// Increase Value

	char		m_pMdFile[MAX_PATH];											// Media File
	void*		m_pMdData;														// Media Data
	
	
public:
	CEfLaser();
	virtual ~CEfLaser();

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		LoadEnvFromFile(void* pLoader, char* sFile, char* sApp);	// Load Environment
	virtual INT		LoadEnvFromString(void* pLoader, char* sStr);				// Load Environment From String

	virtual void	OnReset();
	virtual void	OnPlay();
	
	virtual INT		SetVal(void* pIn, char* =NULL/*command*/);
	virtual INT		GetVal(void* pOut, char* =NULL/*command*/) const;

protected:
	void	(CEfLaser::*RenderLaser[2])();
	void	RenderLaser1();
	void	RenderLaser2();
};

#endif

