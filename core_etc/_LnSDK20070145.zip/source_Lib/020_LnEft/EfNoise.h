// Interface for the CEfNoise class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EFNOISE_H_
#define _EFNOISE_H_


class CEfNoise : public IEfBase
{
public:
	struct VtxwPnt
	{
		D3DXVECTOR4	p;
		DWORD	d;

		VtxwPnt()	{}
		VtxwPnt(FLOAT X,FLOAT Y,FLOAT Z,DWORD D=0XFFFFFFFF) : p(X,Y,Z, 1.f),d(D){}

		enum { FVF = (D3DFVF_XYZRHW|D3DFVF_DIFFUSE) };
	};

protected:
	PDEV	m_pDev	;
	
	INT		m_iN;
	PDVB	m_pVB;
	PDTX	m_pTx;

	FLOAT	m_fScnW;
	FLOAT	m_fScnH;

	FLOAT	m_fPnt;

public:
	CEfNoise();
	virtual ~CEfNoise();

	virtual INT		Create(void* p1=NULL/*Device */, void* p2=NULL/*Texture*/, void* p3=NULL);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();
};

#endif