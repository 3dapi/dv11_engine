// Interface for the CEfScnNoise class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EFSCNNOISE_H_
#define _EFSCNNOISE_H_


class CEfScnNoise : public IEfScnBase
{
public:
	struct VtxwPnt
	{
		D3DXVECTOR4	p;
		DWORD	d;

		VtxwPnt()	{}
		VtxwPnt(FLOAT X,FLOAT Y,FLOAT Z,DWORD D=0XFFFFFFFF) : p(X,Y,Z, 1.f),d(D){}

		enum { FVF = (D3DFVF_XYZRHW|D3DFVF_DIFFUSE) };
	};

protected:
	PDEV	m_pDev	;
	
	INT		m_iN;
	PDVB	m_pVB;
	PDTX	m_pTx;

	FLOAT	m_fScnW;
	FLOAT	m_fScnH;

	FLOAT	m_fPnt;

public:
	CEfScnNoise();
	virtual ~CEfScnNoise();

	virtual INT		Create(void* p1=NULL/*Device */, void* p2=NULL/*Texture*/, void* p3=NULL);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();
};

#endif