// Interface for the CEfCloud class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EFCLOUD_H_
#define _EFCLOUD_H_


class CEfCloud : public IEfBase
{
protected:
	char		m_sCls[64];
	PDEV		m_pDev;

	PDTX		m_pTx;
	INT			m_nImgX;
	INT			m_nImgY;
	INT			m_iImgN;
	
	VtxIdx		m_pIdx[12];
	VtxDUV1		m_pVtx[24];

	FLOAT		m_fWdth;														// Width
	D3DXCOLOR	m_xWght;														// Color Weight
	
	FLOAT		m_fVal;
	MATA		m_mtWld[4];


public:
	CEfCloud();
	virtual ~CEfCloud();

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		LoadEnvFromFile(void* pLoader, char* sFile, char* sApp);	// Load Environment
	virtual INT		LoadEnvFromString(void* pLoader, char* sStr);				// Load Environment From String

	virtual void	OnReset();
};

#endif

