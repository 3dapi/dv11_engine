// Interface for the CEfScnMono class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EFSCNMONO_H_
#define _EFSCNMONO_H_


class CEfScnMono : public IEfScnBase
{
public:
	struct VtxwDUV
	{
		VEC4	p;
		DWORD	d;
		FLOAT	u,v;

		VtxwDUV()	{}
		VtxwDUV(FLOAT X,FLOAT Y,FLOAT Z,FLOAT U,FLOAT V,DWORD D=0xFFFFFFFF) : p(X,Y,Z,1.F),u(U),v(V),d(D){}

		enum { FVF = (D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1)};
	};

protected:
	PDEV	m_pDev	;
	
	PDRS	m_pRS	;
	PDTX	m_pTx	;
	PDSF	m_pTxS	;
	
	FLOAT	m_fScnW	;
	FLOAT	m_fScnH	;

	PDPS	m_pPS	;

	DCLR	m_dMonoWgt;
	DCLR	m_dMonoColor;

public:
	CEfScnMono();
	virtual ~CEfScnMono();
	
	virtual INT		Create(void* p1=NULL/*IDirect3DDevice9* */, void* pFunc=NULL, void* p3=NULL);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		Restore();
	virtual void	Invalidate();


public:
	virtual INT		SetVal(void* pIn, char* =NULL/*command*/);
	virtual INT		GetVal(void* pOut, char* =NULL/*command*/) const;

	// Set and Get Val Command
	// 1. Command: "MonoColor", Type: D3DXCOLOR
};



#endif
