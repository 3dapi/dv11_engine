// Interface for the CEfDryIce class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EFDRYICE_H_
#define _EFDRYICE_H_


class CEfDryIce : public IEfBase
{
protected:
	char		m_sCls[64];
	PDEV		m_pDev;

	PDTX		m_pTx;
	INT			m_nImgX;
	INT			m_nImgY;
	INT			m_iImgN;
	
	INT			m_iN;
	INT			m_iC;
	EfPtc*		m_pPtc;															// Particle
	VtxDUV1*	m_pVtx;															// Vertices
	
	D3DXCOLOR	m_xWght;

	VEC3		m_vcRgnMin;
	VEC3		m_vcRgnMax;	
	
public:
	CEfDryIce();
	virtual ~CEfDryIce();

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		LoadEnvFromFile(void* pLoader, char* sFile, char* sApp);	// Load Environment
	virtual INT		LoadEnvFromString(void* pLoader, char* sStr);				// Load Environment From String

	virtual void	OnReset();

protected:
	void	Set(INT i);
};

#endif

