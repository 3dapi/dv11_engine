// Implementation for the CEfScnBlur class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/Euclid/LnEuclid.h>
#include <ln/Util/LnUtil.h>
#include <ln/Util/LnUtilDx.h>

#include "EfBase.h"

#include "EfScnBlur.h"


#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }
#endif

CEfScnBlur::CEfScnBlur()
{
	m_pSpt		= NULL;

	m_pRndT		= NULL;
	m_pRndA		= NULL;
	
	m_fScnW		= 0.f;
	m_fScnH		= 0.f;

	m_nStart	= 0;

	m_dColor = D3DXCOLOR(1.F, 1.F, 1.F, .92F);
	m_vcPos = VEC4(-0.125f, -0.25f, 0.f, 1.f);
}


CEfScnBlur::~CEfScnBlur()
{
	Destroy();
}


INT CEfScnBlur::Create(void* p1, void* pFunc, void* p3)
{
	m_pSpt	= (PDSP)p1;
	
	if(pFunc)
	{
		RenderPtr = (void (*)())(pFunc);
	}
	
	if(FAILED(this->Restore()))
		return -1;
	
	return 1;
}


INT CEfScnBlur::Restore()
{
	if(m_pRndT)
		return 1;

	PDEV	pDev = NULL;
	PDSF	pSf1 = NULL;
	PDSF	pSf2 = NULL;

	
	D3DSURFACE_DESC dsc1;
	D3DSURFACE_DESC dsc2;

	m_pSpt->GetDevice(&pDev);
	
	pDev->GetRenderTarget(0, &pSf1);
	pDev->GetDepthStencilSurface(&pSf2);
	
	pSf1->GetDesc(&dsc1);
	pSf2->GetDesc(&dsc2);

	m_fScnW	= FLOAT(dsc1.Width);
	m_fScnH	= FLOAT(dsc1.Height);

	SAFE_NEWCREATE3(m_pRndT, TrndSf, pDev, m_fScnW, m_fScnH);
	SAFE_NEWCREATE3(m_pRndA, TrndSf, pDev, m_fScnW, m_fScnH);

	m_pRndT->OnResetDevice();
	m_pRndA->OnResetDevice();

	SAFE_RELEASE(	pDev	);
	SAFE_RELEASE(	pSf1	);
	SAFE_RELEASE(	pSf2	);
	
	return 1;
}

void CEfScnBlur::Invalidate()
{
	Destroy();
}

void CEfScnBlur::Destroy()
{
	SAFE_DELETE(	m_pRndT	);
	SAFE_DELETE(	m_pRndA	);
}

INT CEfScnBlur::FrameMove()
{
	if(!IsFrmMov() || !RenderPtr)
	{
		m_nFrmR = EFT_STATE_UPDATE_NONE;
		return m_nFrmR;
	}


	RECT	rc={0,0,m_fScnW, m_fScnH};
	PDTX	pTx = NULL;

	m_pRndT->BeginScene();

	if(RenderPtr)
		RenderPtr();


	if(m_nStart)
	{
		pTx		= m_pRndA->GetTexture();
		m_pSpt->Draw(pTx, &rc, NULL, NULL, 0, (VEC2*)&m_vcPos, m_dColor);
	}
	else
		m_nStart = 1;


	m_pRndT->EndScene();

	
	m_pRndA->BeginScene();

	pTx		= m_pRndT->GetTexture();
	m_pSpt->Draw(pTx, &rc, NULL, NULL, 0, 0, 0xFFFFFFFF);

	m_pRndA->EndScene();
	

	m_nFrmR = EFT_STATE_UPDATE_PLAY;

	return m_nFrmR;
}

void CEfScnBlur::Render()
{
	if(!IsRender() || !RenderPtr)
		return;

	RECT	rc={0,0,m_fScnW, m_fScnH};
	PDTX pTx = NULL;
	pTx = m_pRndT->GetTexture();

	m_pSpt->Draw(pTx, &rc, NULL, NULL, 0, 0, D3DXCOLOR(1,1,1,1));

}






int CEfScnBlur::SetVal(void* pIn, char* sCmd)
{
	if(0==stricmp(sCmd, "Color"))
	{
		memcpy(&m_dColor, pIn, sizeof m_dColor);
		return 1;
	}
	else if(0==stricmp(sCmd, "Position"))
	{
		memcpy(&m_vcPos, pIn, sizeof m_vcPos);
		return 1;
	}


	return -1;
}

int CEfScnBlur::GetVal(void* pOut, char* sCmd) const
{
	if(0==stricmp(sCmd, "Color"))
	{
		memcpy(pOut, &m_dColor, sizeof m_dColor);
		return 1;
	}
	else if(0==stricmp(sCmd, "Position"))
	{
		memcpy(pOut, &m_vcPos , sizeof m_vcPos);
		return 1;
	}

	return -1;
}

