// Interface for the CEfPtcS class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EFPTCS_H_
#define _EFPTCS_H_


class CEfPtcS : public IEfBase
{
public:
	DWORD		m_dwSt;
	EfPtcB* 	m_pPtB;						// Particle Boundary
	EfPtc*		m_pPrt;
	VtxDUV1*	m_pVtx;
	
	PDEV		m_pDev;
	PDTX		m_pTx;
	MATA*		m_mtVwI;					// Inverse View Matrix

public:
	CEfPtcS();
	virtual ~CEfPtcS();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();

	void	SetTx(PDTX);
	void	SetMatrixViwI(MATA* mtView);
	void	SetDevice(PDEV);

	INT		PtcUpdate();
	void	PtcSet(EfPtcB* pPtB);
	void	PtcSet(INT _nM, INT _nS, EfPtcB* pPtB);

	INT		VtxUpdate();
	void	VtxSet();

	void	Set(INT i);

	FLOAT	GetABC(VEC3 abc);
	FLOAT	GetShk(VEC3 abc);								// Shaking
	INT		GetNum();

public:
	void	OnReset();
};


typedef std::vector<CEfPtcS*>	lsEfPtcS;
typedef lsEfPtcS::iterator		itEfPtcS;

#endif