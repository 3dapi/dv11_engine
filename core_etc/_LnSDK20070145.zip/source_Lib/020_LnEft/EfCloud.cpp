// Implementation of CEfCloud class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/_Cmm/LnVtxFmt.h>

#include <Ln/Euclid/LnEuclid.h>
#include <ln/Util/LnUtil.h>
#include <ln/Util/LnUtilDx.h>

#include "EfBase.h"

#include "EfCloud.h"
#include "EftLoader.h"


CEfCloud::CEfCloud()
{
	m_pDev		= NULL;
	
	m_pTx		= NULL;
	m_nImgX		= 1;
	m_nImgY		= 1;
	m_iImgN		= 1;
	
	m_fVal		= 0.F;

	m_fWdth		= 10000.f;
	m_xWght		= D3DXCOLOR(0.1f, .1f, .1f, .1f);
}

CEfCloud::~CEfCloud()
{
	Destroy();
}


void CEfCloud::Destroy()
{
}


INT CEfCloud::Create(void* p1, void* p2, void* p3)
{
	if(p2)
		memcpy(this, (CEfCloud*)p2, sizeof(CEfCloud) );

	m_pDev = (PDEV)p1;

	Stop();

	return 1;
}


INT CEfCloud::LoadEnvFromFile(void* pLoader, char* sFile, char* sApp)
{
	char	sTemp[MAX_PATH];

	LnUtil_INIReadString(sFile, sApp, "ClassName", m_sCls, sizeof m_sCls, 0);

	m_fWdth = LnUtil_INIReadFloat(sFile, sApp, "Width");

	LnUtil_INIReadSscanf(sFile, sApp, "Color",		"%f %f %f %f", &m_xWght.r, &m_xWght.g, &m_xWght.b, &m_xWght.a);
	LnUtil_INIReadSscanf(sFile, sApp, "Position",	"%f %f %f", &m_vcI.x, &m_vcI.y, &m_vcI.z);


	LnUtil_INIReadString(sFile, sApp, "Texture", sTemp, sizeof sTemp, 0);
	m_pTx = ((CEftLoader*)pLoader)->LoadTexture(sTemp);
	
	return 1;
}


INT CEfCloud::LoadEnvFromString(void* pLoader, char* sStr)
{
	sscanf(sStr,
		
		" %f"
		" %f %f %f %f"
		" %f %f %f"
		, &m_fWdth
		, &m_xWght.r, &m_xWght.g, &m_xWght.b, &m_xWght.a
		, &m_vcI.x, &m_vcI.y, &m_vcI.z
		);


	return 1;
}



INT CEfCloud::FrameMove()
{
	if(!m_bFm)
	{
		m_nFrmR = EFT_STATE_UPDATE_NONE;

		return m_nFrmR;
	}


	m_vcC = m_vcI;

	m_fVal+=.1F/85.F;


	m_mtWld[0]._31 = m_fVal* sinf(D3DXToRadian(45)) +0.2f;
	m_mtWld[0]._32 = m_fVal* sinf(D3DXToRadian(45)) +0.2f;

	m_mtWld[1]._31 = m_fVal*0.7f * sinf(D3DXToRadian(30)) +0.4f;
	m_mtWld[1]._32 = m_fVal*0.7f * sinf(D3DXToRadian(30)) +0.4f;

	m_mtWld[2]._31 = m_fVal*1.3f * sinf(D3DXToRadian(60)) +0.6f;
	m_mtWld[2]._32 = m_fVal*1.3f * sinf(D3DXToRadian(60)) +0.6f;

	m_mtWld[3]._11 = 1.5f;
	m_mtWld[3]._22 = 1.5f;
	m_mtWld[3]._31 = m_fVal*0.3f * sinf(D3DXToRadian(75)) +0.8f;
	m_mtWld[3]._32 = m_fVal*0.3f * sinf(D3DXToRadian(75)) +0.8f;


	m_nFrmR = EFT_STATE_UPDATE_PLAY;

	return m_nFrmR;
}


void CEfCloud::Render()
{
	if(!m_bRn)
		return;

	INT i=0;

	LnD3D_SetWorldIdentity(m_pDev);

	for(i=0; i<4; ++i)
	{
		m_pDev->SetTextureStageState( i, D3DTSS_TEXCOORDINDEX, 0);
		m_pDev->SetTextureStageState( i, D3DTSS_TEXTURETRANSFORMFLAGS, D3DTTFF_COUNT2);
	}

	m_pDev->SetTransform(D3DTS_TEXTURE0, &m_mtWld[0]);
	m_pDev->SetTransform(D3DTS_TEXTURE1, &m_mtWld[1]);
	m_pDev->SetTransform(D3DTS_TEXTURE2, &m_mtWld[2]);
	m_pDev->SetTransform(D3DTS_TEXTURE3, &m_mtWld[3]);


	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);


	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );


	for(i=1; i<4; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP);

		m_pDev->SetTextureStageState(i, D3DTSS_COLOROP,   D3DTOP_LERP);
		m_pDev->SetTextureStageState(i, D3DTSS_COLORARG1, D3DTA_TEXTURE);
		m_pDev->SetTextureStageState(i, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
		m_pDev->SetTextureStageState(i, D3DTSS_COLORARG0, D3DTA_CURRENT);
		
		m_pDev->SetTextureStageState(i, D3DTSS_ALPHAOP,   D3DTOP_LERP);
		m_pDev->SetTextureStageState(i, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
		m_pDev->SetTextureStageState(i, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
		m_pDev->SetTextureStageState(i, D3DTSS_ALPHAARG0, D3DTA_CURRENT);
	}
	
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_ONE);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	

	for(i=0; i<4; ++i)
		m_pDev->SetTexture(i, m_pTx);

	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, 12*3, 12, m_pIdx, D3DFMT_INDEX16, m_pVtx, sizeof(VtxDUV1));

	
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);


	for(i=0; i<4; ++i)
	{
		LnD3D_SetWorldIdentity(m_pDev, D3DTS_TEXTURE0 + i);
		m_pDev->SetTextureStageState( i, D3DTSS_TEXCOORDINDEX, i);
		m_pDev->SetTextureStageState( i, D3DTSS_TEXTURETRANSFORMFLAGS, 0);

		m_pDev->SetTextureStageState(i, D3DTSS_COLOROP,   D3DTOP_MODULATE);
		m_pDev->SetTextureStageState(i, D3DTSS_ALPHAOP,   D3DTOP_MODULATE);
		m_pDev->SetTextureStageState(i, D3DTSS_COLORARG1, D3DTA_TEXTURE);
		m_pDev->SetTextureStageState(i, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	}

	for(i=0; i<4; ++i)
		m_pDev->SetTexture(i, 0);


	for(i=1; i<4; ++i)
	{
		m_pDev->SetTextureStageState(i, D3DTSS_COLOROP,   D3DTOP_MODULATE);
		m_pDev->SetTextureStageState(i, D3DTSS_COLORARG1, D3DTA_TEXTURE);
		m_pDev->SetTextureStageState(i, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
		
		m_pDev->SetTextureStageState(i, D3DTSS_ALPHAOP,   D3DTOP_MODULATE);
		m_pDev->SetTextureStageState(i, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
		m_pDev->SetTextureStageState(i, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	}
}


void CEfCloud::OnReset()
{
	int i=0;

	// front
	m_pVtx[ 0] = VtxDUV1(-1.f, -1.f, -1.f, 0.f, 0.f);
	m_pVtx[ 1] = VtxDUV1(-1.f,  1.f, -1.f, 0.f, 1.f);
	m_pVtx[ 2] = VtxDUV1( 1.f,  1.f, -1.f, 1.f, 1.f);
	m_pVtx[ 3] = VtxDUV1( 1.f, -1.f, -1.f, 1.f, 0.f);
	
	// back
	m_pVtx[ 4] = VtxDUV1(-1.f, -1.f,  1.f, 0.f, 0.f);
	m_pVtx[ 5] = VtxDUV1( 1.f, -1.f,  1.f, 0.f, 1.f);
	m_pVtx[ 6] = VtxDUV1( 1.f,  1.f,  1.f, 1.f, 1.f);
	m_pVtx[ 7] = VtxDUV1(-1.f,  1.f,  1.f, 1.f, 0.f);
	
	// top
	m_pVtx[ 8] = VtxDUV1(-1.f,  1.f, -1.f, 0.f, 0.f);
	m_pVtx[ 9] = VtxDUV1(-1.f,  1.f,  1.f, 0.f, 1.f);
	m_pVtx[10] = VtxDUV1( 1.f,  1.f,  1.f, 1.f, 1.f);
	m_pVtx[11] = VtxDUV1( 1.f,  1.f, -1.f, 1.f, 0.f);
	
	// bottom
	m_pVtx[12] = VtxDUV1(-1.f, -1.f, -1.f, 0.f, 0.f);
	m_pVtx[13] = VtxDUV1( 1.f, -1.f, -1.f, 0.f, 1.f);
	m_pVtx[14] = VtxDUV1( 1.f, -1.f,  1.f, 1.f, 1.f);
	m_pVtx[15] = VtxDUV1(-1.f, -1.f,  1.f, 1.f, 0.f);
	
	// left
	m_pVtx[16] = VtxDUV1(-1.f, -1.f,  1.f, 0.f, 0.f);
	m_pVtx[17] = VtxDUV1(-1.f,  1.f,  1.f, 0.f, 1.f);
	m_pVtx[18] = VtxDUV1(-1.f,  1.f, -1.f, 1.f, 1.f);
	m_pVtx[19] = VtxDUV1(-1.f, -1.f, -1.f, 1.f, 0.f);
	
	// right
	m_pVtx[20] = VtxDUV1( 1.f, -1.f, -1.f, 0.f, 0.f);
	m_pVtx[21] = VtxDUV1( 1.f,  1.f, -1.f, 0.f, 1.f);
	m_pVtx[22] = VtxDUV1( 1.f,  1.f,  1.f, 1.f, 1.f);
	m_pVtx[23] = VtxDUV1( 1.f, -1.f,  1.f, 1.f, 0.f);
	
	// front
	m_pIdx[0] = VtxIdx(0, 1, 2);
	m_pIdx[1] = VtxIdx(0, 2, 3);
		
	// back
	m_pIdx[2] = VtxIdx(4, 5, 6);
	m_pIdx[3] = VtxIdx(4, 6, 7);
	
	// top
	m_pIdx[4] = VtxIdx( 8,  9, 10);
	m_pIdx[5] = VtxIdx( 8, 10, 11);
	
	// bottom
	m_pIdx[6] = VtxIdx(12, 13, 14);
	m_pIdx[7] = VtxIdx(12, 14, 15);
	
	// left
	m_pIdx[8] = VtxIdx(16, 17, 18);
	m_pIdx[9] = VtxIdx(16, 18, 19);

	// right
	m_pIdx[10] = VtxIdx(20, 21, 22);
	m_pIdx[11] = VtxIdx(20, 22, 23);


	for(i=0; i<24; ++i)
	{
		m_pVtx[i].p *=  m_fWdth;
		m_pVtx[i].p +=  m_vcI;
		m_pVtx[i].d  =  m_xWght;
	}


	for(i=0; i<4; ++i)
	{
		D3DXMatrixIdentity(&m_mtWld[i]);
	}
}