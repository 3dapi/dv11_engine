// Implementation of the CEfRocket class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/_Cmm/LnVtxFmt.h>

#include <Ln/Euclid/LnEuclid.h>
#include <ln/Util/LnUtil.h>
#include <ln/Util/LnUtilDx.h>

#include "EfBase.h"

#include "EfRocket.h"
#include "EftLoader.h"


CEfRocket::CEfRocket()
{
	m_pDev		= NULL;
	
	m_pTx		= NULL;
	m_nImgX		= 1;
	m_nImgY		= 1;
	m_iImgN		= 1;
	
	m_iN		= 0;
	m_iC		= 0;
	m_pPtc		= NULL;
	m_pVtx		= NULL;

	m_xWght		= D3DXCOLOR(1,1,1,1);
	m_fSpd		= 10.f;

	m_pMdData	= NULL;
}


CEfRocket::	~CEfRocket()
{
	Destroy();
}


void CEfRocket::Destroy()
{
	SAFE_FREE(m_pPtc);
	SAFE_FREE(m_pVtx);

	if(m_pMdData)
	{
		IMtMedia*	pMdData = (IMtMedia*)m_pMdData;
		delete pMdData;
		m_pMdData	= NULL;
	}
}


INT CEfRocket::Create(void* p1, void* p2, void* p3)
{
	if(p2)
		memcpy(this, (CEfRocket*)p2, sizeof(CEfRocket) );

	m_pDev = (PDEV)p1;

	int	nCreateOpt =(int)p3;

	if(1 == nCreateOpt && m_iN>0)
	{
		m_pPtc =(EfPtc*) malloc(m_iN*1 * sizeof(EfPtc  ));
		m_pVtx=(VtxDUV1*)malloc(m_iN*6 * sizeof(VtxDUV1));

		memset(m_pPtc, 0, m_iN*1 * sizeof(EfPtc  ));
		memset(m_pVtx, 0, m_iN*6 * sizeof(VtxDUV1));
	}

	Stop();
	
	return 1;
}


INT CEfRocket::LoadEnvFromFile(void* pLoader, char* sFile, char* sApp)
{
	char	sTemp[MAX_PATH];

	LnUtil_INIReadString(sFile, sApp, "ClassName", m_sCls, sizeof m_sCls, 0);

	m_iN	= LnUtil_INIReadINT(sFile, sApp, "PartileNum");

	m_nImgX	= LnUtil_INIReadINT(sFile, sApp, "ImageX");
	m_nImgY	= LnUtil_INIReadINT(sFile, sApp, "ImageY");
	m_iImgN	= LnUtil_INIReadINT(sFile, sApp, "ImageNum");

	LnUtil_INIReadSscanf(sFile, sApp, "ColorWeight",	"%f %f %f", &m_xWght.r, &m_xWght.g, &m_xWght.b);
	m_fSpd	= LnUtil_INIReadFloat(sFile, sApp, "MoveSpeed");

	LnUtil_INIReadString(sFile, sApp, "Texture", sTemp, sizeof sTemp, 0);
	m_pTx = ((CEftLoader*)pLoader)->LoadTexture(sTemp);


	LnUtil_INIReadString(sFile, sApp, "Sound", m_pMdFile, sizeof m_pMdFile, 0);

	return 1;
}


INT CEfRocket::LoadEnvFromString(void* pLoader, char* sStr)
{
	sscanf(sStr,
		
		" %d"
		" %f %f %f"
		" %f"

		, &m_iN
		, &m_xWght.r, &m_xWght.g, &m_xWght.b
		, &m_fSpd
		);

	return 1;
}



INT	CEfRocket::FrameMove()
{
	if(!m_bRn)
		return 1;

	INT i=0;
	
	if(EFT_STATE_UPDATE_PLAY==m_nFrmR)
		m_vcC += m_vcD*m_fSpd;
	
	
	for (i=0;i<m_iN;++i)
	{
		if(FALSE == m_pPtc[i].bAct && EFT_STATE_UPDATE_PLAY==m_nFrmR)
		{
			Set(i);
			break;
		}
	}

	for (i=0;i<m_iN;++i)
	{
		if(FALSE == m_pPtc[i].bAct)
			continue;
	
		m_pPtc[i].vcV += m_pPtc[i].vcA;
		m_pPtc[i].vcP += m_pPtc[i].vcV;
		m_pPtc[i].vcR += m_pPtc[i].vcRv;
		m_pPtc[i].vcS += m_pPtc[i].vcSv;

		m_pPtc[i].fLf+= m_pPtc[i].fFd;
		m_pPtc[i].xcC.r+= m_pPtc[i].fFd;
		m_pPtc[i].xcC.g = m_pPtc[i].xcC.r*0.2f;
		m_pPtc[i].xcC.b = m_pPtc[i].xcC.r*0.4f;
		m_pPtc[i].xcC.a+= m_pPtc[i].fFd*.5f;
		
		if(m_pPtc[i].xcC.r <0)	m_pPtc[i].xcC.r = 0;
		if(m_pPtc[i].xcC.g <0)	m_pPtc[i].xcC.g = 0;
		if(m_pPtc[i].xcC.b <0)	m_pPtc[i].xcC.b = 0;
		if(m_pPtc[i].xcC.a <0)	m_pPtc[i].xcC.a = 0;
		
		if(m_pPtc[i].fLf<=0 || m_pPtc[i].xcC.a<=0)
			m_pPtc[i].bAct = FALSE;
		
		m_pPtc[i].fFp += 1.f;

		if(1.f< m_pPtc[i].fFp)
			m_pPtc[i].fFp =10.f;
	}

	

	MATA	mtZ;
	MATA	mtR;
	
	MATA	mtB;
	MATA	mtView;

	m_pDev->GetTransform(D3DTS_VIEW, &mtView);
	D3DXMatrixInverse(&mtB, NULL, &mtView);

	mtB._41 = 0.f;
	mtB._42 = 0.f;
	mtB._43 = 0.f;
	
	VEC2	uv0;
	VEC2	uv1;
	DWORD	d;
	FLOAT	w;
	FLOAT	h;

	m_iC = 0;

	for (i=0;i<m_iN;++i)
	{
		if(FALSE == m_pPtc[i].bAct)
			continue;

		uv0	= m_pPtc[i].uv0;
		uv1	= m_pPtc[i].uv1;
		d	= m_pPtc[i].xcC;
		w	= m_pPtc[i].fW*m_pPtc[i].vcS.x;
		h	= m_pPtc[i].fH*m_pPtc[i].vcS.y;
		
		VEC3 p0 = VEC3(-w,  h, 0);
		VEC3 p1 = VEC3( w,  h, 0);
		VEC3 p2 = VEC3(-w, -h, 0);
		VEC3 p3 = VEC3( w, -h, 0);
		
		D3DXMatrixRotationZ(&mtZ, DEGtoRAD(m_pPtc[i].vcR.z));
		mtR = mtZ * mtB;
		
		D3DXVec3TransformCoord(&p0, &p0, &mtR);
		D3DXVec3TransformCoord(&p1, &p1, &mtR);
		D3DXVec3TransformCoord(&p2, &p2, &mtR);
		D3DXVec3TransformCoord(&p3, &p3, &mtR);
		
		m_pVtx[m_iC*6 + 0].p = m_pPtc[i].vcP + p0;
		m_pVtx[m_iC*6 + 1].p = m_pPtc[i].vcP + p1;
		m_pVtx[m_iC*6 + 2].p = m_pPtc[i].vcP + p2;
		m_pVtx[m_iC*6 + 3].p = m_pPtc[i].vcP + p3;

		m_pVtx[m_iC*6 + 0].d =
		m_pVtx[m_iC*6 + 1].d =
		m_pVtx[m_iC*6 + 2].d =
		m_pVtx[m_iC*6 + 3].d = m_pPtc[i].xcC;

		m_pVtx[m_iC*6 + 0].u =  uv0.x;
		m_pVtx[m_iC*6 + 1].u =  uv1.x;
		m_pVtx[m_iC*6 + 2].u =  uv0.x;
		m_pVtx[m_iC*6 + 3].u =  uv1.x;

		m_pVtx[m_iC*6 + 0].v =  uv0.y;
		m_pVtx[m_iC*6 + 1].v =  uv0.y;
		m_pVtx[m_iC*6 + 2].v =  uv1.y;
		m_pVtx[m_iC*6 + 3].v =  uv1.y;

		m_pVtx[m_iC*6 + 4] = m_pVtx[m_iC*6 + 2];
		m_pVtx[m_iC*6 + 5] = m_pVtx[m_iC*6 + 1];

		++m_iC;
	}


	VEC3 vcCur = m_vcT - m_vcC;

	FLOAT L	= D3DXVec3Dot(&vcCur, &m_vcD);

	if(L<=0001.f)
	{
		if(EFT_STATE_UPDATE_PLAY == m_nFrmR)
			m_nFrmR = EFT_STATE_UPDATE_END;
		else
			m_nFrmR = EFT_STATE_UPDATE_NONE;


		if(m_iC<1)
		{
			Stop();
			m_nFrmR = EFT_STATE_UPDATE_NONE;
			return m_nFrmR;
		}
	}

	else
	{
		m_nFrmR = EFT_STATE_UPDATE_PLAY;
	}
	
	return m_nFrmR;
}


void CEfRocket::Render()
{
	if(!m_bRn || m_iC<1)
		return;
	
	LnD3D_SetWorldIdentity(m_pDev);

	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

	
	
	
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);
	
	m_pDev->SetTexture(0, m_pTx);
	m_pDev->SetTexture(1, 0);

	m_pDev->SetFVF(VtxDUV1::FVF);
	
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, m_iC*2, m_pVtx, sizeof(VtxDUV1));
	
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
}



void	CEfRocket::Set(INT i)
{
	m_pPtc[i].bAct	= TRUE;
	m_pPtc[i].vcP	= m_vcC;
	m_pPtc[i].vcV	= VEC3(( 5- rand()%10) *0.6f, rand()%10 *0.3f, ( 5- rand()%10) *0.6f) - m_vcD*0.25f;
	m_pPtc[i].vcA	= VEC3(0, 0, 0);									// Set Accelation
	m_pPtc[i].vcR	= VEC3(0, 0, 0);
	m_pPtc[i].vcRv	= VEC3(0, 0, (-10 + rand()%20) *1.f);

	m_pPtc[i].vcS	= VEC3(1, 1, 1) * (10.f + rand()%11) * 0.1f;
	m_pPtc[i].vcSv	= VEC3(1, 1, 0) * (10.f + rand()%11) * 0.02f;

	m_pPtc[i].xcC.r	= 1.f;
	m_pPtc[i].xcC.a	= 1.f;
	
	m_pPtc[i].fFd	= -(50 + rand()%25)/4000.f;
	m_pPtc[i].fLf	= 1.f;												// Life
	m_pPtc[i].fW	= ( 10 + rand()%40)/4.f;							// width to height
	m_pPtc[i].fH	= m_pPtc[i].fW;								// width to height
	m_pPtc[i].fFp	= -1.f;												// First?
	m_pPtc[i].fDr	= ((rand()%100)/1 >0 )? 1.f: -1.f;					// Render Tail?

	INT nIdx = rand()%m_iImgN;

	INT	x = nIdx%m_nImgX;
	INT	y = nIdx/m_nImgX;

	m_pPtc[i].uv0.x = (x+0)/FLOAT(m_nImgX);
	m_pPtc[i].uv0.y = (y+0)/FLOAT(m_nImgY);
	m_pPtc[i].uv1.x = (x+1)/FLOAT(m_nImgX);
	m_pPtc[i].uv1.y = (y+1)/FLOAT(m_nImgY);
}



void CEfRocket::OnReset()
{
//	m_iN	= 1000;

	m_nFrmR = EFT_STATE_UPDATE_PLAY;
	m_vcC	= m_vcI;
	m_vcD	= m_vcT - m_vcI;

	D3DXVec3Normalize(&m_vcD, &m_vcD);
	
	if(NULL == m_pPtc && m_iN>0)
	{
		m_pPtc =(EfPtc*) malloc(m_iN*1 * sizeof(EfPtc  ));
		m_pVtx=(VtxDUV1*)malloc(m_iN*6 * sizeof(VtxDUV1));
	}

	memset(m_pPtc, 0, m_iN*1 * sizeof(EfPtc  ));
	memset(m_pVtx, 0, m_iN*6 * sizeof(VtxDUV1));

	for(INT i=0; i<m_iN; ++i)
	{
		Set(i);
		m_pPtc[i].bAct	= FALSE;
	}


	if(m_pMdData)
	{
		IMtMedia*	pMedia = (IMtMedia*)m_pMdData;
		pMedia->Reset();
		pMedia->Play();
	}
}


void CEfRocket::OnPlay()
{
	if(m_pMdData)
	{
		IMtMedia*	pMdData = (IMtMedia*)m_pMdData;
		pMdData->Play();
	}
}





int CEfRocket::SetVal(void* pIn, char* sCmd)
{
	if(0==stricmp(sCmd, "AddSound"))
	{
		m_pMdData = pIn;
		return 1;
	}

	return -1;
}

int CEfRocket::GetVal(void* pOut, char* sCmd) const
{
	if(0==stricmp(sCmd, "Media"))
	{
		lsEfMdaEnt* pvEnt = (lsEfMdaEnt*)pOut;

		EfMdaEntry	ent( (IEfBase*)this, (char*)m_pMdFile, m_pMdData);
		(*pvEnt).push_back(ent);

		return 1;
	}

	return -1;
}