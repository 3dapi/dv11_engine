// Interface for the CEfScnBlur class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _EFSCNBLUR_H_
#define _EFSCNBLUR_H_


class CEfScnBlur : public IEfScnBase
{
public:
	struct VtxwDUV
	{
		D3DXVECTOR4	p;
		DWORD		d;
		FLOAT		u,v;

		VtxwDUV()	{}
		VtxwDUV(FLOAT X,FLOAT Y,FLOAT Z,FLOAT U,FLOAT V,DWORD D=0xFFFFFFFF) : p(X,Y,Z,1.F),u(U),v(V),d(D){}

		enum { FVF = (D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1)};
	};

protected:
	PDSP	m_pSpt	;												// Sprite
	PDSF	m_pDevT	;												// Back buffer target
	PDSF	m_pDevD	;												// Back buffer Depth and stencil

	TrndSf*	m_pRndT	;
	TrndSf*	m_pRndA	;

	FLOAT	m_fScnW	;
	FLOAT	m_fScnH	;
	INT		m_nStart;

	DCLR	m_dColor;
	VEC4	m_vcPos ;

public:
	CEfScnBlur();
	virtual ~CEfScnBlur();

	virtual INT		Create(void* p1=NULL/*ID3DXSprite* */, void* pFunc=NULL/*Function Pointer*/, void* p3=NULL);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		Restore();
	virtual void	Invalidate();

	
public:
	virtual INT		SetVal(void* pIn, char* =NULL/*command*/);
	virtual INT		GetVal(void* pOut, char* =NULL/*command*/) const;

	// Set and Get Val Command
	// 1. Command: "Color", Type: D3DXCOLOR
	// 2. Command: "Position", Type: D3DXVECTOR3
	
};

#endif