// Interface for the CEfScnLght class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EfScnLght_H_
#define _EfScnLght_H_


class CEfScnLght : public IEfScnBase
{
public:
	struct TrndSf
	{
		PDTX	m_pT;			// Texture
		PDSF	m_pC;			// color buffer  
		PDSF	m_pD;			// Depth and Stencil

		TrndSf();
		void	Invalidate();
		INT		Create(PDEV pDev, INT scnW, INT scnH, DWORD dFmtColor, DWORD dFmtDepth);
		PDTX	GetTexture() const;
	};

	struct VtxwUV1
	{
		VEC4	p;
		FLOAT	u0,v0;

		VtxwUV1()	{}
		VtxwUV1(FLOAT X,FLOAT Y,FLOAT Z,FLOAT W,FLOAT U0,FLOAT V0):p(X,Y,Z,W),u0(U0),v0(V0){}
		enum	{FVF = (D3DFVF_XYZRHW|D3DFVF_TEX1),};
	};

	struct HdrRc
	{
		float u0, v0;
		float u1, v1;
	};


protected:
	PDEV				m_pDev	;
	FLOAT				m_fScnW	;
	FLOAT				m_fScnH	;

	LPD3DXEFFECT		m_pDxEft	;
	CEfScnLght::TrndSf	m_RndOld	;


	enum
	{
		NUM_STAR_TEXTURES =  8, // �����ؽ�ó ����
		MAX_SAMPLES       = 16, // ���÷��� �ִ��
	};
	
	DWORD		m_dwCropWidth;
	DWORD		m_dwCropHeight;
	
	PDTX		m_pSceneTx;
	PDSF		m_pSceneSf;
	
	PDTX		m_pSceneScaledTx;
	PDSF		m_pSceneScaledSf;

	PDTX		m_pBrightPassTx;
	PDSF		m_pBrightPassSf;
	
	PDTX		m_pStarTx;
	PDSF		m_pStarSf;
	
	PDTX		m_pHdrStarTx[NUM_STAR_TEXTURES];
	PDSF		m_pHdrStarSf[NUM_STAR_TEXTURES];
	
		
	FLOAT		m_fWorldRotY;		//
	FLOAT		m_fRgbOffset;		// Offset
	INT			m_nRptCount;		// Repeat Rendering
	FLOAT		m_fRptWidth	;		// Repeat Width


public:
	CEfScnLght();
	virtual ~CEfScnLght();
	
	virtual	INT		Create(void* p1=NULL, void* pFunc=NULL, void* p3=NULL);
	virtual	void	Destroy();

	virtual	INT		FrameMove();
	virtual	void	Render();

	virtual INT		Restore();
	virtual void	Invalidate();

	virtual INT		SetVal(void* pIn, char* =NULL/*command*/);
	virtual INT		GetVal(void* pOut, char* =NULL/*command*/) const;


protected:
	INT		Scene_To_SceneScaled();
	INT		SceneScaled_To_BrightPass();
	INT		BrightPass_To_StarSource();
	INT		RenderStar();
	
	void	DrawFullScreenQuad(float fLeftU, float fTopV, float fRightU, float fBottomV);
	INT		GetGaussBlur5x5(DWORD dwD3DTexWidth, DWORD dwD3DTexHeight,VEC2* avTexCoordOffset, VEC4* avSampleWeight );
	INT		GetTextureCoords( PDTX pTexSrc, RECT* pRectSrc, PDTX pTexDest, RECT* pRectDest, CEfScnLght::HdrRc* pCoords );
};


#endif
