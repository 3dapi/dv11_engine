// Implementation of the CEfShell class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/_Cmm/LnVtxFmt.h>

#include <Ln/Euclid/LnEuclid.h>
#include <ln/Util/LnUtil.h>
#include <ln/Util/LnUtilDx.h>

#include "EfBase.h"

#include "EfShell.h"
#include "EftLoader.h"


CEfShell::CEfShell()
{
	m_pDev		= NULL;
	
	m_pTx		= NULL;
	m_nImgX		= 1;
	m_nImgY		= 1;
	m_iImgN		= 1;
	
	m_iN		= 0;
	m_iC		= 0;
	m_pPtc		= NULL;
	m_pVtx		= NULL;

	m_xWght		= D3DXCOLOR(1,1,1,1);
	m_fSpd		= 5.f;

	m_pMdData	= NULL;
}

CEfShell::~CEfShell()
{
	Destroy();
}



void CEfShell::Destroy()
{
	SAFE_FREE(m_pPtc);
	SAFE_FREE(m_pVtx);

	if(m_pMdData)
	{
		IMtMedia*	pMdData = (IMtMedia*)m_pMdData;
		delete pMdData;
		m_pMdData	= NULL;
	}
}



INT CEfShell::Create(void* p1, void* p2, void* p3)
{
	if(p2)
		memcpy(this, (CEfShell*)p2, sizeof(CEfShell) );

	m_pDev = (PDEV)p1;

	int	nCreateOpt =(int)p3;

	if(1 == nCreateOpt && m_iN>0)
	{
		m_pPtc =(EfPtc*) malloc(m_iN*1 * sizeof(EfPtc  ));
		m_pVtx=(VtxDUV1*)malloc(m_iN*6 * sizeof(VtxDUV1));

		memset(m_pPtc, 0, m_iN*1 * sizeof(EfPtc  ));
		memset(m_pVtx, 0, m_iN*6 * sizeof(VtxDUV1));
	}

	Stop();
	
	return 1;
}


INT CEfShell::LoadEnvFromFile(void* pLoader, char* sFile, char* sApp)
{
	char	sTemp[MAX_PATH];

	LnUtil_INIReadString(sFile, sApp, "ClassName", m_sCls, sizeof m_sCls, 0);

	m_iN	= LnUtil_INIReadINT(sFile, sApp, "PartileNum");

	m_nImgX	= LnUtil_INIReadINT(sFile, sApp, "ImageX");
	m_nImgY	= LnUtil_INIReadINT(sFile, sApp, "ImageY");
	m_iImgN	= LnUtil_INIReadINT(sFile, sApp, "ImageNum");


	LnUtil_INIReadSscanf(sFile, sApp, "ColorWeight",	"%f %f %f", &m_xWght.r, &m_xWght.g, &m_xWght.b);
	m_fSpd	= LnUtil_INIReadFloat(sFile, sApp, "MoveSpeed");


	LnUtil_INIReadString(sFile, sApp, "Texture", sTemp, sizeof sTemp, 0);
	m_pTx = ((CEftLoader*)pLoader)->LoadTexture(sTemp);


	LnUtil_INIReadString(sFile, sApp, "Sound", m_pMdFile, sizeof m_pMdFile, 0);

	return 1;
}


INT CEfShell::LoadEnvFromString(void* pLoader, char* sStr)
{
	sscanf(sStr,
		
		" %d"
		" %f %f %f"
		" %f"

		, &m_iN
		, &m_xWght.r, &m_xWght.g, &m_xWght.b
		, &m_fSpd
		);

	return 1;
}



INT CEfShell::FrameMove()
{
	if(!m_bRn)
		return 1;

	INT i=0;
	
	if(EFT_STATE_UPDATE_PLAY==m_nFrmR)
		m_vcC += m_vcD*m_fSpd;

	
	for (i=0;i<m_iN;++i)
	{
		if(FALSE == m_pPtc[i].bAct && EFT_STATE_UPDATE_PLAY==m_nFrmR)
		{
			Set(i);
			break;
		}
	}

	for(i=0; i<m_iN; ++i)
	{
		m_pPtc[i].vcV += m_pPtc[i].vcA;
		m_pPtc[i].vcP += m_pPtc[i].vcV;
		m_pPtc[i].vcR += m_pPtc[i].vcRv;
		m_pPtc[i].vcS += m_pPtc[i].vcSv;
		
		m_pPtc[i].xcC += m_pPtc[i].xcV;

		m_pPtc[i].fW	-= m_pPtc[i].fFd*5.f;
		m_pPtc[i].fH	 = m_pPtc[i].fW;

		if( m_pPtc[i].xcC.r<0.f)	m_pPtc[i].xcC.r =0.f;
		if( m_pPtc[i].xcC.g<0.f)	m_pPtc[i].xcC.g =0.f;
		if( m_pPtc[i].xcC.b<0.f)	m_pPtc[i].xcC.b =0.f;
		if( m_pPtc[i].xcC.a<0.f)	m_pPtc[i].xcC.a =0.f;

		if( m_pPtc[i].xcC.r>1.f)	m_pPtc[i].xcC.r =1.f;
		if( m_pPtc[i].xcC.g>1.f)	m_pPtc[i].xcC.g =1.f;
		if( m_pPtc[i].xcC.b>1.f)	m_pPtc[i].xcC.b =1.f;
		if( m_pPtc[i].xcC.a>1.f)	m_pPtc[i].xcC.a =1.f;

		if (m_pPtc[i].xcC.a <=0.001f ||m_pPtc[i].xcC.a >=0.999f)
		{
			if( EFT_STATE_UPDATE_PLAY==m_nFrmR)
				Set(i);
		}
	}

	
	MATA	RotZ;
	MATA	mat;
	
	MATA	mtBill;
	MATA	mtView;
	
	m_pDev->GetTransform(D3DTS_VIEW, &mtView);
	D3DXMatrixInverse(&mtBill, NULL, &mtView);
	mtBill._41 = 0.f;
	mtBill._42 = 0.f;
	mtBill._43 = 0.f;

	VEC3 fX = VEC3(mtView._11, mtView._21, mtView._31);
	VEC3 fY = VEC3(mtView._12, mtView._22, mtView._32);
	VEC3 fZ = VEC3(mtView._13, mtView._23, mtView._33);	
	
	MATA	mR;
	VEC2	uv0;
	VEC2	uv1;
	DWORD	d;
	FLOAT	w;
	FLOAT	h;

	m_iC = 0;

	for (i=0;i<m_iN; ++i)					// Loop Through All The Particles
	{
		if(FALSE == m_pPtc[i].bAct)
			continue;

		D3DXMatrixRotationAxis(&mR, &fZ, m_pPtc[i].vcR.x);

		VEC3 p0 = -(fX-fY);
		VEC3 p1 = +(fX+fY);
		VEC3 p2 = -(fX+fY);
		VEC3 p3 = +(fX-fY);

		uv0	= m_pPtc[i].uv0;
		uv1	= m_pPtc[i].uv1;
		d	= m_pPtc[i].xcC;
		w	= m_pPtc[i].fW*m_pPtc[i].vcS.x;
		h	= m_pPtc[i].fH*m_pPtc[i].vcS.y;


		D3DXVec3TransformCoord(&p0, &p0, &mR);
		D3DXVec3TransformCoord(&p1, &p1, &mR);
		D3DXVec3TransformCoord(&p2, &p2, &mR);
		D3DXVec3TransformCoord(&p3, &p3, &mR);

		m_pVtx[m_iC*6 + 0].p = m_pPtc[i].vcP + VEC3(p0.x * w, p0.y * h, p0.z * w);
		m_pVtx[m_iC*6 + 1].p = m_pPtc[i].vcP + VEC3(p1.x * w, p1.y * h, p1.z * w);
		m_pVtx[m_iC*6 + 2].p = m_pPtc[i].vcP + VEC3(p2.x * w, p2.y * h, p2.z * w);
		m_pVtx[m_iC*6 + 3].p = m_pPtc[i].vcP + VEC3(p3.x * w, p3.y * h, p3.z * w);

		m_pVtx[m_iC*6 + 0].u =  uv0.x;
		m_pVtx[m_iC*6 + 1].u =  uv1.x;
		m_pVtx[m_iC*6 + 2].u =  uv0.x;
		m_pVtx[m_iC*6 + 3].u =  uv1.x;

		m_pVtx[m_iC*6 + 0].v =  uv0.y;
		m_pVtx[m_iC*6 + 1].v =  uv0.y;
		m_pVtx[m_iC*6 + 2].v =  uv1.y;
		m_pVtx[m_iC*6 + 3].v =  uv1.y;

		m_pVtx[m_iC*6 + 0].d = d;
		m_pVtx[m_iC*6 + 1].d = d;
		m_pVtx[m_iC*6 + 2].d = d;
		m_pVtx[m_iC*6 + 3].d = d;
		
		m_pVtx[m_iC*6 + 4] = m_pVtx[m_iC*6 + 2];
		m_pVtx[m_iC*6 + 5] = m_pVtx[m_iC*6 + 1];

		++m_iC;
	}


	VEC3 vcCur = m_vcT - m_vcC;

	FLOAT L	= D3DXVec3Dot(&vcCur, &m_vcD);

	if(L<=0001.f)
	{
		if(EFT_STATE_UPDATE_END != m_nFrmR)
			m_nFrmR = EFT_STATE_UPDATE_END;
		else
			m_nFrmR = EFT_STATE_UPDATE_NONE;

		if(m_iC<1)
		{
			Stop();
			m_nFrmR = EFT_STATE_UPDATE_NONE;
			return m_nFrmR;
		}
	}

	else
	{
		m_nFrmR = EFT_STATE_UPDATE_PLAY;
	}
	
	return m_nFrmR;
}



void CEfShell::Set(int i)
{
	FLOAT fPi = DEGtoRAD( rand()%360 );
	FLOAT fTh = DEGtoRAD( rand()%180 );
	
	VEC3 AxisZ = m_vcD;
	VEC3 AxisY = VEC3(0,1,0);
	VEC3 AxisX;
	
	D3DXVec3Cross(&AxisX, &AxisY, &AxisZ);
	D3DXVec3Normalize(&AxisX, &AxisX);
	
	m_pPtc[i].vcA.x= 0.f;
	m_pPtc[i].vcA.y= 0.f;
	m_pPtc[i].vcA.z= 0.f;

	m_pPtc[i].vcV =  (AxisY * sinf(fPi) + AxisX * cosf(fPi) ) * .7f;

	m_pPtc[i].vcP = m_vcC;

	m_pPtc[i].vcS	= VEC3(1, 1, 1) * (10.f + rand()%11) * 0.1f;
	m_pPtc[i].vcSv	= VEC3(1, 1, 0) * (10.f + rand()%11) * 0.02f;
	
	m_pPtc[i].xcC.r = 0.3f;
	m_pPtc[i].xcC.g = (10+rand()%256)/255.f;
	m_pPtc[i].xcC.b = (10+rand()%256)/255.f;

	m_pPtc[i].xcC.a	=  (50+rand()%51) * 0.01f;
	m_pPtc[i].xcC.r = m_pPtc[i].xcC.a*m_xWght.r;
	m_pPtc[i].xcC.g = m_pPtc[i].xcC.a*m_xWght.g;
	m_pPtc[i].xcC.b = m_pPtc[i].xcC.a*m_xWght.b;

	m_pPtc[i].xcV.a = -(50+rand()%51) * 0.001f;
	m_pPtc[i].xcV.r = -(50+rand()%51) * 0.001f * m_pPtc[i].xcV.a*m_xWght.r;
	m_pPtc[i].xcV.g = -(50+rand()%51) * 0.001f * m_pPtc[i].xcV.a*m_xWght.r;
	m_pPtc[i].xcV.b = -(50+rand()%51) * 0.001f * m_pPtc[i].xcV.a*m_xWght.r;

	

	m_pPtc[i].fFd	= -(15 + rand()%31) *0.001f;
	m_pPtc[i].fW	= (5+rand()%6) * 10.f/20.F;
	m_pPtc[i].fH	= m_pPtc[i].fW;

	INT nIdx = rand()%m_iImgN;

	INT	x = nIdx%m_nImgX;
	INT	y = nIdx/m_nImgX;

	m_pPtc[i].uv0.x = (x+0)/FLOAT(m_nImgX);
	m_pPtc[i].uv0.y = (y+0)/FLOAT(m_nImgY);
	m_pPtc[i].uv1.x = (x+1)/FLOAT(m_nImgX);
	m_pPtc[i].uv1.y = (y+1)/FLOAT(m_nImgY);

	m_pPtc[i].bAct	= TRUE;
}



void CEfShell::Render()
{
	if(!m_bRn || m_iC<1)
		return;
	
	LnD3D_SetWorldIdentity(m_pDev);

	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

	
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);
	
	m_pDev->SetTexture(0, m_pTx);
	m_pDev->SetTexture(1, 0);

	m_pDev->SetFVF(VtxDUV1::FVF);
	
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, m_iC*2, m_pVtx, sizeof(VtxDUV1));
	
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
}



void CEfShell::OnReset()
{
//	m_vcI	=VEC3(0,0,0);
//	m_vcT	=VEC3(1000, 0, 0);

	m_nFrmR = EFT_STATE_UPDATE_PLAY;
	m_vcC	= m_vcI;
	m_vcD	= m_vcT - m_vcI;

	D3DXVec3Normalize(&m_vcD, &m_vcD);
	
	if(NULL == m_pPtc && m_iN>0)
	{
		m_pPtc =(EfPtc*) malloc(m_iN*1 * sizeof(EfPtc  ));
		m_pVtx=(VtxDUV1*)malloc(m_iN*6 * sizeof(VtxDUV1));

		memset(m_pPtc, 0, m_iN*1 * sizeof(EfPtc  ));
		memset(m_pVtx, 0, m_iN*6 * sizeof(VtxDUV1));
	}

	for(INT i=0; i<m_iN; ++i)
	{
		Set(i);
		m_pPtc[i].bAct = FALSE;
	}



	if(m_pMdData)
	{
		IMtMedia*	pMedia = (IMtMedia*)m_pMdData;
		pMedia->Reset();
		pMedia->Play();
	}
}


void CEfShell::OnPlay()
{
	if(m_pMdData)
	{
		IMtMedia*	pMdData = (IMtMedia*)m_pMdData;
		pMdData->Play();
	}
}






int CEfShell::SetVal(void* pIn, char* sCmd)
{
	if(0==stricmp(sCmd, "AddSound"))
	{
		m_pMdData = pIn;
		return 1;
	}

	return -1;
}

int CEfShell::GetVal(void* pOut, char* sCmd) const
{
	if(0==stricmp(sCmd, "Media"))
	{
		lsEfMdaEnt* pvEnt = (lsEfMdaEnt*)pOut;

		EfMdaEntry	ent( (IEfBase*)this, (char*)m_pMdFile, m_pMdData);
		(*pvEnt).push_back(ent);

		return 1;
	}

	return -1;
}



