// Interface for the CEfSprnkl class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EFSPRNKL_H_
#define _EFSPRNKL_H_


class CEfSprnkl : public IEfBase
{
protected:
	char		m_sCls[64];
	PDEV		m_pDev;

	PDTX		m_pTx;
	INT			m_nImgX;
	INT			m_nImgY;
	INT			m_iImgN;
	
	INT			m_iN;
	INT			m_iC;
	EfPtc*		m_pPtc;															// Particle
	VtxDUV1*	m_pVtx;															// Vertices

	
public:
	CEfSprnkl();
	virtual ~CEfSprnkl();

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		LoadEnvFromFile(void* pLoader, char* sFile, char* sKey);	// Load Environment
	virtual INT		LoadEnvFromString(void* pLoader, char* sStr);				// Load Environment From String

	virtual	void	OnReset();

protected:
	void	Set(INT i);	
};

#endif

