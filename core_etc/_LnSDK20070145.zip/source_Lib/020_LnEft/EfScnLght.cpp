// Implementation of the CEfScnLght class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/Euclid/LnEuclid.h>
#include <ln/Util/LnUtilDx.h>

#include "EfBase.h"
#include "EfScnLght.h"

#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }
#endif


#define RS   m_pDev->SetRenderState
#define TSS  m_pDev->SetTextureStageState
#define SAMP m_pDev->SetSamplerState



CEfScnLght::TrndSf::TrndSf()
{
	m_pT	= NULL;
	m_pC	= NULL;
	m_pD	= NULL;
}


void CEfScnLght::TrndSf::Invalidate()
{
	SAFE_RELEASE(	m_pT	);
	SAFE_RELEASE(	m_pC	);
	SAFE_RELEASE(	m_pD	);
}



INT CEfScnLght::TrndSf::Create(PDEV pDev, INT scnW, INT scnH, DWORD dFmtColor, DWORD dFmtDepth)
{
	// �Ϲݷ������� �� ��
	if(FAILED(pDev->CreateTexture(scnW, scnH, 1, D3DUSAGE_RENDERTARGET, (D3DFORMAT)dFmtColor,D3DPOOL_DEFAULT, &m_pT, NULL)))
		return -1;

	if(FAILED(m_pT->GetSurfaceLevel(0, &m_pC)))
		return -1;


	// ���̹��� ����
	if(FAILED(pDev->CreateDepthStencilSurface(scnW, scnH, (D3DFORMAT)dFmtDepth, D3DMULTISAMPLE_NONE, 0, TRUE, &m_pD, NULL)))
		return -1;

	return 1;
}


PDTX CEfScnLght::TrndSf::GetTexture() const
{
	return m_pT;
}




char	g_HlslCross[] =
"// Original Source: IMAGIRE Takashi						\n"

"static const int    MAX_SAMPLES = 16;						\n"

"float2 g_avSampleOffsets[MAX_SAMPLES];						\n"

"float4 g_avSampleWeights[MAX_SAMPLES];						\n"

"// Offset value											\n"
"float g_fRgbOffset;										\n"


"// ���÷��� SetTexture ����								\n"
"sampler s0 : register(s0);									\n"
"sampler s1 : register(s1);									\n"
"sampler s2 : register(s2);									\n"
"sampler s3 : register(s3);									\n"
"sampler s4 : register(s4);									\n"
"sampler s5 : register(s5);									\n"
"sampler s6 : register(s6);									\n"
"sampler s7 : register(s7);									\n"


"//1/4��ҹ��ۿ� ��� ����									\n"
"float4 DownScale4x4 ( in float2 uv : TEXCOORD0 ) : COLOR	\n"
"{															\n"
"    float4 samp = 0.0f;									\n"
"															\n"
"	for( int i=0; i < 16; i++ )								\n"
"	{														\n"
"		samp += tex2D( s0, uv + g_avSampleOffsets[i] );		\n"
"	}														\n"
"															\n"
"	return samp / 16;										\n"
"}															\n"


"//�����κи� ����											\n"
"float4 BrightPassFilter(in float2 uv : TEXCOORD0) : COLOR	\n"
"{															\n"
"	float4 vSample = tex2D( s0, uv );						\n"
"															\n"
"	// ��ο� �κ� ����										\n"
"//	vSample.b -= 2.f;										\n"
"//	vSample.g -= 2.f;										\n"
"	vSample.rgb -= g_fRgbOffset;							\n"
"															\n"
"	// ���Ѱ��� 0����										\n"
"	vSample = 50.0f*max(vSample, 0.0f);						\n"
"															\n"
"	return vSample;											\n"
"}															\n"


"//�߽� ��ó�� 13�� �ؼ��� ���ø�							\n"
"float4 GaussBlur5x5 (in float2 uv : TEXCOORD0) : COLOR		\n"
"{															\n"
"   float4 samp = 0.0f;										\n"
"	for( int i=0; i < 13; i++ )								\n"
"	{														\n"
"		samp += g_avSampleWeights[i]						\n"
"				 * tex2D( s0, uv + g_avSampleOffsets[i] );	\n"
"	}														\n"
"															\n"
"	return samp;											\n"
"}															\n"



"//8���� ���ø��ؼ� ������ �����							\n"
"float4 Star ( in float2 uv : TEXCOORD0 ) : COLOR			\n"
"{															\n"
"    float4 vColor = 0.0f;									\n"
"															\n"
"    // ������ 8���� ���� ���ø�							\n"
"    for(int i = 0; i < 8; i++)								\n"
"	{														\n"
"        vColor += g_avSampleWeights[i]						\n"
"				 * tex2D(s0, uv + g_avSampleOffsets[i]);	\n"
"    }														\n"
"															\n"
"    return vColor;											\n"
"}															\n"



"//6���� ������ �ߺ��ռ�									\n"
"float4 MergeTextures_6(in float2 uv : TEXCOORD0 ) : COLOR	\n"
"{															\n"
"	float4 vColor = 0.0f;									\n"
"															\n"
"	vColor = ( tex2D(s0, uv)								\n"
"	         + tex2D(s1, uv)								\n"
"	         + tex2D(s2, uv)								\n"
"	         + tex2D(s3, uv)								\n"
"	         + tex2D(s4, uv)								\n"
"	         + tex2D(s5, uv) )/6.0f;						\n"
"															\n"
"	return vColor;											\n"
"}															\n"


"//1/4��ҹ��ۿ� ����� ����								\n"
"technique TechDownScale4x4									\n"
"{															\n"
"    pass P0												\n"
"    {														\n"
"        PixelShader  = compile ps_2_0 DownScale4x4();		\n"
"        MinFilter[0] = Point;								\n"
"        AddressU[0] = Clamp;								\n"
"        AddressV[0] = Clamp;								\n"
"    }														\n"
"}															\n"



"//�����κи� ����											\n"
"technique BrightPassFilter									\n"
"{															\n"
"    pass P0												\n"
"    {														\n"
"        PixelShader  = compile ps_2_0 BrightPassFilter();	\n"
"        MinFilter[0] = Point;								\n"
"        MagFilter[0] = Point;								\n"
"    }														\n"
"}															\n"


"//13�ؼ� ���ø����� ���콺 ������ ����						\n"
"technique GaussBlur5x5										\n"
"{															\n"
"    pass P0												\n"
"    {														\n"
"        PixelShader  = compile ps_2_0 GaussBlur5x5();		\n"
"        MinFilter[0] = Point;								\n"
"        AddressU[0] = Clamp;								\n"
"        AddressV[0] = Clamp;								\n"
"    }														\n"
"}															\n"


"//8���ø����� ���������									\n"
"technique Star												\n"
"{															\n"
"    pass P0												\n"
"    {														\n"
"        PixelShader  = compile ps_2_0 Star();				\n"
"        MagFilter[0] = Linear;								\n"
"        MinFilter[0] = Linear;								\n"
"    }														\n"
"															\n"
"}															\n"


"//6���� ���� �ߺ��ռ�										\n"
"technique MergeTextures									\n"
"{															\n"
"    pass P0												\n"
"    {														\n"
"        PixelShader  = compile ps_2_0 MergeTextures_6();	\n"
"        MagFilter[0] = Linear;								\n"
"        MinFilter[0] = Linear;								\n"
"        MagFilter[1] = Linear;								\n"
"        MinFilter[1] = Linear;								\n"
"        MagFilter[2] = Linear;								\n"
"        MinFilter[2] = Linear;								\n"
"        MagFilter[3] = Linear;								\n"
"        MinFilter[3] = Linear;								\n"
"        MagFilter[4] = Linear;								\n"
"        MinFilter[4] = Linear;								\n"
"        MagFilter[5] = Linear;								\n"
"        MinFilter[5] = Linear;								\n"
"    }														\n"
"}															\n"

;




CEfScnLght::CEfScnLght()
{
	m_fScnW			= 0;
	m_fScnH			= 0;

	m_pDxEft		= NULL;

	m_pSceneTx		= NULL;
	m_pSceneSf		= NULL;
	m_pSceneScaledTx= NULL;
	m_pSceneScaledSf= NULL;
	m_pBrightPassTx	= NULL;
	m_pBrightPassSf	= NULL;

	m_pStarTx		= NULL;
	m_pStarSf		= NULL;

	for(int i=0; i < NUM_STAR_TEXTURES; i++ )
	{
		m_pHdrStarTx[i]	= NULL;
		m_pHdrStarSf[i] = NULL;
	}

	m_fWorldRotY	= 45.F;
	m_fRgbOffset	= 0.85f;
	m_nRptCount		= 2;
	m_fRptWidth		= 20.f;
}



CEfScnLght::~CEfScnLght()
{
	Destroy();
}



INT CEfScnLght::Create(void* p1, void* pFunc, void* p3)
{
	m_pDev = (PDEV)p1;

	if(pFunc)
		RenderPtr = (void (*)())(pFunc);

	m_pDxEft = (LPD3DXEFFECT)LnD3D_EffectBuildFromString(m_pDev, g_HlslCross, strlen(g_HlslCross) );

	if( NULL == m_pDxEft)
		return -1;


	m_pDxEft->SetFloat("g_fRgbOffset", m_fRgbOffset);

	UINT	nScnW;
	UINT	nScnH;

	LnD3D_DeviceFormat(m_pDev, NULL, NULL, &nScnW, &nScnH);

	m_fScnW = nScnW;
	m_fScnH = nScnH;


	if(NULL == m_pSceneTx)
	{
		if(FAILED(this->Restore()))
			return -1;
	}

	return 1;
}

void CEfScnLght::Destroy()
{
	SAFE_RELEASE(	m_pDxEft	);
}


INT CEfScnLght::Restore()
{
	if(m_pSceneTx)
		return 1;

	HRESULT	hr;
	DWORD	dFmtColor;
	DWORD	dFmtDepth;
	UINT	nScnW;
	UINT	nScnH;

	LnD3D_DeviceFormat(m_pDev, &dFmtColor, &dFmtDepth, &nScnW, &nScnH);

	m_fScnW = nScnW;
	m_fScnH = nScnH;

	m_pDev->GetRenderTarget(0, &m_RndOld.m_pC);
	m_pDev->GetDepthStencilSurface(&m_RndOld.m_pD);





	// ����� ������ HDR ���� ������Ÿ��
	hr = m_pDev->CreateTexture(nScnW, nScnH, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A16B16G16R16F, D3DPOOL_DEFAULT, &m_pSceneTx, NULL);
	if( FAILED(hr) )
		return hr;

	hr = m_pSceneTx->GetSurfaceLevel( 0, &m_pSceneSf );
	if( FAILED(hr) ) return hr;

	// ��ҹ���

	// ��ҹ����� �⺻ũ��(4�� ���)
	m_dwCropWidth  = nScnW - nScnW  % 4;
	m_dwCropHeight = nScnH - nScnH % 4;

	hr = m_pDev->CreateTexture(m_dwCropWidth / 4, m_dwCropHeight / 4, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A16B16G16R16F, D3DPOOL_DEFAULT, &m_pSceneScaledTx, NULL);

	if( FAILED(hr) )
		return hr;

	hr = m_pSceneScaledTx->GetSurfaceLevel( 0, &m_pSceneScaledSf );

	if( FAILED(hr) )
		return hr;


	// �ֵ�����
	hr = m_pDev->CreateTexture(m_dwCropWidth / 4 + 2, m_dwCropHeight / 4 + 2, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8,D3DPOOL_DEFAULT, &m_pBrightPassTx, NULL);

	if( FAILED(hr) )
		return hr;

	hr = m_pBrightPassTx->GetSurfaceLevel( 0, &m_pBrightPassSf );

	if( FAILED(hr) )
		return hr;


	// �ֺ��θ� �˰�ĥ�Ѵ�
	LnD3D_TextureFill(m_pDev, m_pBrightPassTx);

	// ������ �ʵ��� �帴�ϰ� ������ �ؽ�ó
	hr = m_pDev->CreateTexture(m_dwCropWidth / 4 + 2, m_dwCropHeight / 4 + 2, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8,D3DPOOL_DEFAULT, &m_pStarTx, NULL);

	if( FAILED(hr) )
		return hr;

	hr = m_pStarTx->GetSurfaceLevel( 0, &m_pStarSf );

	if( FAILED(hr) )
		return hr;

	// �ֺ��θ� �˰�ĥ�Ѵ�
	LnD3D_TextureFill(m_pDev, m_pStarTx);

	// �����ؽ�ó
	for(int i=0; i < NUM_STAR_TEXTURES; i++ )
	{
		hr = m_pDev->CreateTexture(m_dwCropWidth /8, m_dwCropHeight /8,1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8,D3DPOOL_DEFAULT, &m_pHdrStarTx[i], NULL );

		if( FAILED(hr) )
			return hr;


		hr = m_pHdrStarTx[i]->GetSurfaceLevel( 0, &m_pHdrStarSf[i] );

		if( FAILED(hr) )
			return hr;
	}

	// ����Ʈ
	if(m_pDxEft)
		m_pDxEft->OnResetDevice();

	return 1;
}

void CEfScnLght::Invalidate()
{
	HRESULT hr;

	m_RndOld.Invalidate();

	SAFE_RELEASE(m_pSceneTx);
	SAFE_RELEASE(m_pSceneSf);

	SAFE_RELEASE(m_pSceneScaledTx);
	SAFE_RELEASE(m_pSceneScaledSf);

	SAFE_RELEASE(m_pBrightPassTx);
	SAFE_RELEASE(m_pBrightPassSf);

	SAFE_RELEASE(m_pStarTx);
	SAFE_RELEASE(m_pStarSf);

	for(int i=0; i < NUM_STAR_TEXTURES; i++ )
	{
		SAFE_RELEASE(m_pHdrStarSf[i]);
		SAFE_RELEASE(m_pHdrStarTx[i]);
	}


	if(m_pDxEft)
		hr = 	m_pDxEft->OnLostDevice();
}


INT CEfScnLght::FrameMove()
{
	if(!IsFrmMov() || !RenderPtr)
	{
		m_nFrmR = EFT_STATE_UPDATE_NONE;
		return m_nFrmR;
	}


	MATA	mtView;
	m_pDev->GetTransform(D3DTS_VIEW, &mtView);

	VEC3	vcZ( mtView._11, mtView._21, mtView._31);
	float	fCos	= D3DXVec3Dot(&vcZ, &VEC3(0,0,1));

	if(fCos>0.9999)
		m_fWorldRotY = 0.f;

	else if(fCos<-0.9999)
		m_fWorldRotY = 3.141592f;
	else
		m_fWorldRotY = acosf(fCos);




	// HDR������ Ÿ�� ����
	m_pDev->SetRenderTarget(0, m_pSceneSf);

	m_pDev->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER| D3DCLEAR_STENCIL, 0x00006699, 1.0f, 0L );

	if(RenderPtr)
		RenderPtr();


	for(int i=0; i<8; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	}

	this->Scene_To_SceneScaled();			    // ��ҹ��ۿ� ����� ����
	this->SceneScaled_To_BrightPass();			// �����κ� ����
	this->BrightPass_To_StarSource();			// ������ ���� ������
	this->RenderStar();							// ���� ����

	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);


	m_pDev->SetRenderTarget(0, m_RndOld.m_pC);
	m_pDev->SetDepthStencilSurface(m_RndOld.m_pD);

	return 1;
}

void CEfScnLght::Render()
{
	if(!IsRender() || !RenderPtr || NULL == m_pDxEft)
		return ;

	int	  i =0;
	float w = m_fScnW;
	float h = m_fScnH;


	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );

	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE);
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);


	for(i=0; i<8; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
		m_pDev->SetTexture(i, 0);
	}



	CEfScnLght::VtxwUV1 VertexFinal[4];

	VertexFinal[0] = CEfScnLght::VtxwUV1( 0, 0, 0, 1, 0, 0);
	VertexFinal[1] = CEfScnLght::VtxwUV1( w, 0, 0, 1, 1, 0);
	VertexFinal[2] = CEfScnLght::VtxwUV1( w, h, 0, 1, 1, 1);
	VertexFinal[3] = CEfScnLght::VtxwUV1( 0, h, 0, 1, 0, 1);


	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE) ;	

	m_pDev->SetTexture( 0, m_pSceneTx );
	m_pDev->SetFVF(D3DFVF_XYZRHW| D3DFVF_TEX1);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, VertexFinal, sizeof( CEfScnLght::VtxwUV1 ) );

	

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE) ;
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_ONE) ;
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE) ;

	
	m_pDev->SetTexture( 0, m_pHdrStarTx[0] );
	m_pDev->SetFVF(D3DFVF_XYZRHW| D3DFVF_TEX1);


	INT		nBgn = -m_nRptCount/2;
	INT		nEnd = m_nRptCount + nBgn;


	for(int j=nBgn; j<nEnd; ++j)
	{
		VertexFinal[0].p.x = 0 + (j+0.5f)* m_fRptWidth;
		VertexFinal[1].p.x = w + (j+0.5f)* m_fRptWidth;
		VertexFinal[2].p.x = w + (j+0.5f)* m_fRptWidth;
		VertexFinal[3].p.x = 0 + (j+0.5f)* m_fRptWidth;

		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, VertexFinal, sizeof( CEfScnLght::VtxwUV1 ) );
	}

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE) ;
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);


#if 0	// ����� �ؽ�ó ���
	for(i=0;i<5;i++)
	{
		CEfScnLght::VtxwUV1 VertexFinal2[4];

		VertexFinal2[0] = CEfScnLght::VtxwUV1(   0,   0+h*(FLOAT)i/8, 0, 1, 0+0.5f/w, 0+0.5f/h);
		VertexFinal2[1] = CEfScnLght::VtxwUV1( w/8,   0+h*(FLOAT)i/8, 0, 1, 1+0.5f/w, 0+0.5f/h);
		VertexFinal2[2] = CEfScnLght::VtxwUV1( w/8, h/8+h*(FLOAT)i/8, 0, 1, 1+0.5f/w, 1+0.5f/h);
		VertexFinal2[3] = CEfScnLght::VtxwUV1(   0, h/8+h*(FLOAT)i/8, 0, 1, 0+0.5f/w, 1+0.5f/h);

		m_pDev->SetFVF(D3DFVF_XYZRHW| D3DFVF_TEX1);
		switch(i)
		{
		case 0:m_pDev->SetTexture( 0, m_pSceneTx );break;
		case 1:m_pDev->SetTexture( 0, m_pSceneScaledTx );break;
		case 2:m_pDev->SetTexture( 0, m_pBrightPassTx );break;
		case 3:m_pDev->SetTexture( 0, m_pStarTx );break;
		case 4:m_pDev->SetTexture( 0, m_pHdrStarTx[0] );break;
		}
		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, VertexFinal2, sizeof( CEfScnLght::VtxwUV1 ) );
	}
#endif
}


// �簢���� ��üȭ�鿡 �����Ѵ�
void CEfScnLght::DrawFullScreenQuad(float fLeftU, float fTopV, float fRightU, float fBottomV)
{
	D3DSURFACE_DESC desc;
	PDSF pSurf;

	m_pDev->GetRenderTarget(0, &pSurf);
	pSurf->GetDesc(&desc);
	pSurf->Release();
	FLOAT w = (FLOAT)desc.Width;
	FLOAT h = (FLOAT)desc.Height;


	CEfScnLght::VtxwUV1 svQuad[4];

	svQuad[0] = CEfScnLght::VtxwUV1(0-0.5f, 0-0.5f, 0.5f, 1.0f, fLeftU,  fTopV   );
	svQuad[1] = CEfScnLght::VtxwUV1(w-0.5f, 0-0.5f, 0.5f, 1.0f, fRightU, fTopV   );
	svQuad[2] = CEfScnLght::VtxwUV1(0-0.5f, h-0.5f, 0.5f, 1.0f, fLeftU,  fBottomV);
	svQuad[3] = CEfScnLght::VtxwUV1(w-0.5f, h-0.5f, 0.5f, 1.0f, fRightU, fBottomV);

	m_pDev->SetRenderState(D3DRS_ZENABLE, FALSE);
	m_pDev->SetFVF(D3DFVF_XYZRHW | D3DFVF_TEX1);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, svQuad, sizeof(CEfScnLght::VtxwUV1));
	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
}





// �Է��ؽ�ó�� ����ؽ�ó���� �ؽ�ó��ǥ ���
INT CEfScnLght::GetTextureCoords( PDTX pTexSrc, RECT* pRectSrc, PDTX pTexDest, RECT* pRectDest, CEfScnLght::HdrRc* pCoords )
{
	D3DSURFACE_DESC desc;

	if( pTexSrc == NULL || pTexDest == NULL || pCoords == NULL )
		return -1;

	// �⺻������ �ؽ�ó��ǥ�� �״�� ���
	pCoords->u0 = 0.0f;
	pCoords->v0 = 0.0f;
	pCoords->u1 = 1.0f;
	pCoords->v1 = 1.0f;

	// �Է¿��� ǥ�鿡 ���� ����
	if( pRectSrc != NULL )
	{
		pTexSrc->GetLevelDesc( 0, &desc );// �ؽ�ó������ ��´�
		// ���ۿ���
		pCoords->u0 += pRectSrc->left                   / desc.Width;
		pCoords->v0 += pRectSrc->top                    / desc.Height;
		pCoords->u1 -= (desc.Width  - pRectSrc->right)  / desc.Width;
		pCoords->v1 -= (desc.Height - pRectSrc->bottom) / desc.Height;
	}

	// ����� ǥ�鿡 ���� ����
	if( pRectDest != NULL ) {
		pTexDest->GetLevelDesc( 0, &desc );// �ؽ�ó������ ��´�
		// ����� ���¿� ���� �ؽ�ó��ǥ�� �����
		pCoords->u0 -= pRectDest->left                   / desc.Width;
		pCoords->v0 -= pRectDest->top                    / desc.Height;
		pCoords->u1 += (desc.Width  - pRectDest->right)  / desc.Width;
		pCoords->v1 += (desc.Height - pRectDest->bottom) / desc.Height;
	}

	return 1;
}


//m_pSceneTx�� 1/4�� �ؼ� m_pTexSceneScale�� �ִ´�
INT CEfScnLght::Scene_To_SceneScaled()
{
	// �ʰ��� �κп� �߽ɺκ��� �����Ѵ�
	CEfScnLght::HdrRc coords;
	RECT rectSrc;
	rectSrc.left   = (m_fScnW - m_dwCropWidth ) / 2;
	rectSrc.top    = (m_fScnH - m_dwCropHeight) / 2;
	rectSrc.right  = rectSrc.left + m_dwCropWidth;
	rectSrc.bottom = rectSrc.top  + m_dwCropHeight;
	// ������Ÿ�ٿ� ���߿� �ؽ�ó��ǥ ���
	GetTextureCoords( m_pSceneTx, &rectSrc, m_pSceneScaledTx, NULL, &coords );

	// �ֺ� 16�ؼ��� ���ø������� �ؼ� 0.5�� �߽ɿ� ���߱����� ����
	int index=0;
	VEC2 offsets[MAX_SAMPLES];

	for( int y=0; y < 4; y++ )
	{
		for( int x=0; x < 4; x++ )
		{
			offsets[ index ].x = (x - 1.5f) / m_fScnW;
			offsets[ index ].y = (y - 1.5f) / m_fScnH;
			index++;
		}
	}
	m_pDxEft->SetValue("g_avSampleOffsets", offsets, sizeof(offsets));

	// 16�ؼ��� ���ø��ؼ� �� ��հ��� ��ҹ��ۿ� ���
	m_pDev->SetRenderTarget( 0, m_pSceneScaledSf );
	m_pDxEft->SetTechnique("TechDownScale4x4");
	m_pDxEft->Begin(NULL, 0);
	m_pDxEft->Pass(0);
	m_pDev->SetTexture( 0, m_pSceneTx );
	DrawFullScreenQuad( coords.u0, coords.v0, coords.u1, coords.v1 );
	m_pDxEft->End();

	return 1;
}




//��ҹ��ۿ� �����Ҷ� ���� �κи� �����Ѵ�
INT CEfScnLght::SceneScaled_To_BrightPass()
{
	// ����� ���� �����κ��� �������� ũ�� ����
	D3DSURFACE_DESC desc;
	m_pBrightPassTx->GetLevelDesc( 0, &desc );
	RECT rectDest = {0,0,desc.Width,desc.Height};
	InflateRect( &rectDest, -1, -1 );

	m_pDev->SetRenderState( D3DRS_SCISSORTESTENABLE, TRUE );
	m_pDev->SetScissorRect( &rectDest );

	// ��üȭ�� ����
	m_pDev->SetRenderTarget( 0, m_pBrightPassSf );
	m_pDxEft->SetTechnique("BrightPassFilter");
	m_pDxEft->Begin(NULL, 0);
	m_pDxEft->Pass(0);
	m_pDev->SetTexture( 0, m_pSceneScaledTx );
	DrawFullScreenQuad( 0.0f, 0.0f, 1.0f, 1.0f );
	m_pDxEft->End();

	m_pDev->SetRenderState( D3DRS_SCISSORTESTENABLE, FALSE );

	return 1;
}



//������ ���϶� ���콺�� �����Ⱑ �ǵ��� ��� ���
INT CEfScnLght::GetGaussBlur5x5(DWORD dwD3DTexWidth, DWORD dwD3DTexHeight,
							   VEC2* avTexCoordOffset, VEC4* avSampleWeight)
{
	float tu = 1.0f / (float)dwD3DTexWidth ;
	float tv = 1.0f / (float)dwD3DTexHeight ;

	float totalWeight = 0.0f;
	int index=0;

	for( int x = -2; x <= 2; x++ )
	{
		for( int y = -2; y <= 2; y++ )
		{
			// ����� ���� �κ��� �Ұ�
			if( 2 < abs(x) + abs(y) )
				continue;

			avTexCoordOffset[index] = VEC2( x * tu, y * tv );
			float fx = (FLOAT)x;
			float fy = (FLOAT)y;

			avSampleWeight[index].x = avSampleWeight[index].y =
				avSampleWeight[index].z = avSampleWeight[index].w
				= expf( -(fx*fx + fy*fy)/(2*1.0f) );

			totalWeight += avSampleWeight[index].x;

			index++;
		}
	}

	// ����ġ �հ�� 1.0
	for( int i=0; i < index; i++ )
		avSampleWeight[i] *= 1.0f/totalWeight;

	return 1;
}



//��ҹ��ۿ� �����Ҷ� ��������� �����ϱ� ���ؼ� ���콺�� �����⸦ �Ѵ�
INT CEfScnLght::BrightPass_To_StarSource()
{
	// ����� ���� ������ ���� �������� ũ�� ����
	D3DSURFACE_DESC desc;
	m_pStarTx->GetLevelDesc( 0, &desc );
	RECT rectDest = {0,0,desc.Width,desc.Height};
	InflateRect( &rectDest, -1, -1 );// ����Ұ��� ũ�⸦ 1��ŭ ���δ�
	m_pDev->SetRenderState( D3DRS_SCISSORTESTENABLE, TRUE );
	m_pDev->SetScissorRect( &rectDest );

	// �ؽ�ó��ǥ ����
	CEfScnLght::HdrRc coords;
	GetTextureCoords( m_pBrightPassTx, NULL, m_pStarTx,&rectDest, &coords );

	// ���� �̹����� ũ��κ��� ���콺��������� ���
	VEC2 offsets[MAX_SAMPLES];
	VEC4 weights[MAX_SAMPLES];
	m_pBrightPassTx->GetLevelDesc( 0, &desc );
	GetGaussBlur5x5( desc.Width, desc.Height, offsets, weights );
	m_pDxEft->SetValue("g_avSampleOffsets", offsets, sizeof(offsets));
	m_pDxEft->SetValue("g_avSampleWeights", weights, sizeof(weights));

	// ���콺 ������
	m_pDxEft->SetTechnique("GaussBlur5x5");
	m_pDev->SetRenderTarget( 0, m_pStarSf );
	m_pDxEft->Begin(NULL, 0);
	m_pDxEft->Pass(0);
	m_pDev->SetTexture( 0, m_pBrightPassTx );
	DrawFullScreenQuad( coords.u0, coords.v0, coords.u1, coords.v1 );
	m_pDxEft->End();

	m_pDev->SetRenderState( D3DRS_SCISSORTESTENABLE, FALSE );

	return 1;
}



//���������
INT CEfScnLght::RenderStar()
{
	// ����Ʈ���� ����ϴ� ��� ����
	const int s_maxPasses = 3;
	const int nSamples = 8;
	// ������
	const D3DXCOLOR s_colorWhite(0.63f, 0.63f, 0.63f, 0.0f) ;
	const D3DXCOLOR s_ChromaticAberrationColor[8] =
	{
		D3DXCOLOR(0.5f, 0.5f, 0.5f,  0.0f),	//
		D3DXCOLOR(0.8f, 0.3f, 0.3f,  0.0f), //
		D3DXCOLOR(1.0f, 0.2f, 0.2f,  0.0f),	//
		D3DXCOLOR(0.5f, 0.2f, 0.6f,  0.0f), //
		D3DXCOLOR(0.2f, 0.2f, 1.0f,  0.0f),	//
		D3DXCOLOR(0.2f, 0.3f, 0.7f,  0.0f), //
		D3DXCOLOR(0.2f, 0.6f, 0.2f,  0.0f),	//
		D3DXCOLOR(0.3f, 0.5f, 0.3f,  0.0f), //
	} ;

	VEC4 s_aaColor[s_maxPasses][nSamples];

	for (int p = 0 ; p < s_maxPasses ; p ++)
	{
		// �߽ɿ����� �Ÿ������� �������� �����
		float ratio = (float)(p + 1) / (float)s_maxPasses ;

		// ���� ���ø��ؼ� ������ ���� �����
		for (int s = 0 ; s < nSamples ; s ++)
		{
			D3DXCOLOR chromaticAberrColor ;
			D3DXColorLerp(&chromaticAberrColor,	&( s_ChromaticAberrationColor[s] ),	&s_colorWhite, ratio) ;
			// ��ü���� �� ��ȭ�� ����
			D3DXColorLerp( (D3DXCOLOR*)&( s_aaColor[p][s] ),	&s_colorWhite, &chromaticAberrColor, 0.7f ) ;
		}
	}

	float radOffset = m_fWorldRotY;// ������ ���� ȸ��

	// ����ȭ���� ���� ���� ����
	D3DSURFACE_DESC desc;
	m_pStarSf->GetDesc( &desc );
	float srcW = (FLOAT) desc.Width;
	float srcH = (FLOAT) desc.Height;

	int nStarLines = NUM_STAR_TEXTURES-2;// ������ �ٱ� ����

	// ���⿡ ���� ����
	for (int d = 0 ; d < nStarLines ; d ++)
	{
		PDTX pTexSource = m_pStarTx;
		float rad = radOffset + 2*d*D3DX_PI/(FLOAT)nStarLines;// ����
		float sn = sinf(rad);
		float cs = cosf(rad);

		VEC2 vtStepUV = VEC2(0.3f * sn / srcW, 0.3f * cs / srcH);

		float attnPowScale = (atanf(D3DX_PI/4) + 0.1f) * (160.0f + 120.0f) / (srcW + srcH);

		int iWorkTexture = 0;

		for (int p = 0 ; p < s_maxPasses; p++)
		{
			// �������� �� ����
			PDSF pSurfDest = NULL;

			if (p == s_maxPasses - 1)
			{
				// ���� �н��� ������ ���ۿ� Ȯ���Ѵ�
				pSurfDest = m_pHdrStarSf[d+2];
			}
			else
			{
				pSurfDest = m_pHdrStarSf[iWorkTexture];
			}

			m_pDev->SetRenderTarget( 0, pSurfDest );

			//�ؽ�ó��ǥ�� �ռ��Ҷ��� ����ġ�� ���
			VEC4 avSampleWeights[MAX_SAMPLES];
			VEC2 avSampleOffsets[MAX_SAMPLES];

			for (int i = 0 ; i < nSamples ; i++)
			{
				// ������ ����ġ
				float lum = powf( 0.95f, attnPowScale * i );
				avSampleWeights[i] = s_aaColor[s_maxPasses-1-p][i]* lum * (p+1.0f) * 0.5f ;

				// �ؽ�ó��ǥ�� �ø� ��
				avSampleOffsets[i].x = vtStepUV.x * i ;
				avSampleOffsets[i].y = vtStepUV.y * i ;

				if ( 0.9f <= fabs(avSampleOffsets[i].x) || 0.9f <= fabs(avSampleOffsets[i].y) )
				{
					avSampleOffsets[i].x = 0.0f ;
					avSampleOffsets[i].y = 0.0f ;
					avSampleWeights[i] *= 0.0f ;
				}
			}

			m_pDxEft->SetValue("g_avSampleOffsets", avSampleOffsets, sizeof(avSampleOffsets));
			m_pDxEft->SetVectorArray("g_avSampleWeights", avSampleWeights, nSamples);

			// ��üȭ�� ����
			m_pDxEft->SetTechnique("Star");
			m_pDxEft->Begin(NULL, 0);
			m_pDxEft->Pass(0);
			m_pDev->SetTexture( 0, pTexSource );
			DrawFullScreenQuad(0.0f, 0.0f, 1.0f, 1.0f);
			m_pDxEft->End();

			// ���� �н��� ���� �Ķ���� ����
			vtStepUV *= nSamples;
			attnPowScale *= nSamples;

			// �������� ����� ���� �ؽ�ó�� �Ѵ�
			pTexSource = m_pHdrStarTx[iWorkTexture];

			iWorkTexture ^= 1;
		}
	}


	// ��� ������ �ռ�
	m_pDev->SetRenderTarget( 0, m_pHdrStarSf[0] );

	m_pDxEft->SetTechnique("MergeTextures");
	m_pDxEft->Begin(NULL, 0);
	m_pDxEft->Pass(0);
	m_pDev->SetTexture( 0, m_pHdrStarTx[0+2] );
	m_pDev->SetTexture( 1, m_pHdrStarTx[1+2] );
	m_pDev->SetTexture( 2, m_pHdrStarTx[2+2] );
	m_pDev->SetTexture( 3, m_pHdrStarTx[3+2] );
	m_pDev->SetTexture( 4, m_pHdrStarTx[4+2] );
	m_pDev->SetTexture( 5, m_pHdrStarTx[5+2] );

	DrawFullScreenQuad(0.0f, 0.0f, 1.0f, 1.0f);

	m_pDxEft->End();

	return 1;
}






int CEfScnLght::SetVal(void* pIn, char* sCmd)
{
	if(0==stricmp(sCmd, "RgbOffset"))
	{
		m_fRgbOffset	= *((FLOAT*)pIn);
		return 1;
	}

	else if(0==stricmp(sCmd, "RepeatCount"))
	{
		m_nRptCount	= *((INT*)pIn);
		return 1;
	}

	else if(0==stricmp(sCmd, "LightWidth"))
	{
		m_fRptWidth		= *((FLOAT*)pIn);
		return 1;
	}

	return -1;
}

int CEfScnLght::GetVal(void* pOut, char* sCmd) const
{
	if(0==stricmp(sCmd, "Media"))
	{

		return 1;
	}

	return -1;
}

