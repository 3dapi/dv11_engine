// Implementation of the CEfPtcS class.
//
////////////////////////////////////////////////////////////////////////////////

// STL
#pragma warning( disable : 4786)
#include <vector>
#include <algorithm>
#include <functional>


#include <windows.h>
#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnVtxFmt.h>

#include <Ln/Util/LnUtil.h>

#include "EfBase.h"
#include "EfPtcS.h"


CEfPtcS::CEfPtcS()
{
	m_dwSt	= NULL;
	m_pPtB	= NULL;
	m_pPrt	= NULL;
	m_pVtx	= NULL;

	m_pDev	= NULL;
	m_mtVwI	= NULL;
	m_pTx	= NULL;
}

CEfPtcS::~CEfPtcS()
{
	Destroy();
}

INT	CEfPtcS::Init()
{
	return 1;
}


void CEfPtcS::Destroy()
{
	SAFE_FREE(m_pPrt);
	SAFE_FREE(m_pVtx);
}


INT CEfPtcS::FrameMove()
{
	if(!IsFrmMov())
	{
		m_nFrmR = EFT_STATE_UPDATE_NONE;
		return m_nFrmR;
	}

	PtcUpdate();
	VtxUpdate();
	
	m_nFrmR = EFT_STATE_UPDATE_PLAY;
	
	return m_nFrmR;
}



void CEfPtcS::Render()
{
	if(!IsRender())
		return;

	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);

	m_pDev->SetRenderState(D3DRS_ZENABLE, D3DZB_TRUE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_DESTALPHA);

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetFVF(VtxDUV1::FVF);

	m_pDev->SetTexture(0, m_pTx);
	
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, m_pPtB->iN * 2, m_pVtx, sizeof(VtxDUV1) );

	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
}

void CEfPtcS::SetTx(PDTX pTx)
{
	m_pTx = pTx;
}

void CEfPtcS::SetMatrixViwI(MATA* mtViwI)
{
	m_mtVwI = mtViwI;
}


void CEfPtcS::SetDevice(PDEV pDev)
{
	m_pDev = pDev;
}


INT	CEfPtcS::PtcUpdate()
{
	MATA	mtX;
	MATA	mtY;
	MATA	mtZ;
	MATA	mtS;

	VEC3	vcZ;
	VEC3	vcC;

	VEC3	vcRf;
	INT		i=0;

	if(!IsFrmMov())
		return 1;

	vcZ = VEC3(m_mtVwI->_31, m_mtVwI->_32, m_mtVwI->_33) ;
	vcC = VEC3(m_mtVwI->_41, m_mtVwI->_42, m_mtVwI->_43) ;

	// 1. Update particle
	for(i=0; i<m_pPtB->iN; ++i)
	{
		// �̵�
		m_pPrt[i].vcV += m_pPrt[i].vcA;

		// ȸ��
		m_pPrt[i].vcR += m_pPrt[i].vcRv;

		// Scaling
		m_pPrt[i].vcS += m_pPrt[i].vcSv;

		// color
		m_pPrt[i].xcC += m_pPrt[i].xcV;

		if(m_pPrt[i].xcC.r<0)	m_pPrt[i].xcC.r	= 0;
		if(m_pPrt[i].xcC.g<0)	m_pPrt[i].xcC.g	= 0;
		if(m_pPrt[i].xcC.b<0)	m_pPrt[i].xcC.b	= 0;
		if(m_pPrt[i].xcC.a<0)	m_pPrt[i].xcC.a	= 0;

		// Purtubation
		m_pPrt[i].vcG.x	= GetABC(m_pPrt[i].vcGx) * sinf(	DEGtoRAD(m_pPrt[i].vcR.x)	) * .1f;
		m_pPrt[i].vcG.y	= GetABC(m_pPrt[i].vcGy) * sinf(	DEGtoRAD(m_pPrt[i].vcR.y)	) * .1f;
		m_pPrt[i].vcG.z	= GetABC(m_pPrt[i].vcGz) * sinf(	DEGtoRAD(m_pPrt[i].vcR.z)	) * .1f;

		m_pPrt[i].vcP += m_pPrt[i].vcV;
		m_pPrt[i].vcP += m_pPrt[i].vcG;


		if(	m_pPrt[i].vcS.x<=0 || m_pPrt[i].vcS.y<=0 || m_pPrt[i].vcS.z<=0	||
			m_pPrt[i].vcP.x< m_pPtB->vcB0.x || m_pPrt[i].vcP.x> m_pPtB->vcB1.x	||
			m_pPrt[i].vcP.y< m_pPtB->vcB0.y || m_pPrt[i].vcP.y> m_pPtB->vcB1.y	||
			m_pPrt[i].vcP.z< m_pPtB->vcB0.z || m_pPrt[i].vcP.z> m_pPtB->vcB1.z	||
			m_pPrt[i].xcC.a<=0)
		{
			Set(i);
		}
		
		// Rotation Matrix
		D3DXMatrixIdentity(&mtX);
		D3DXMatrixIdentity(&mtY);
		D3DXMatrixIdentity(&mtZ);

		D3DXMatrixRotationX(&mtX, DEGtoRAD(m_pPrt[i].vcR.x) );
		D3DXMatrixRotationY(&mtY, DEGtoRAD(m_pPrt[i].vcR.y) );
		D3DXMatrixRotationZ(&mtZ, DEGtoRAD(m_pPrt[i].vcR.z) );

		//Scaling Matrix
		D3DXMatrixIdentity(&mtS);
		D3DXMatrixScaling(&mtS, m_pPrt[i].vcS.x, m_pPrt[i].vcS.y, m_pPrt[i].vcS.z);

		// world Matrix
		m_pPrt[i].mtW = mtS * mtX * mtY * mtZ;
		m_pPrt[i].mtW._41 =m_pPrt[i].vcP.x;
		m_pPrt[i].mtW._42 =m_pPrt[i].vcP.y;
		m_pPrt[i].mtW._43 =m_pPrt[i].vcP.z;

		vcRf = m_pPrt[i].vcP - vcC;
		m_pPrt[i].fStlSrtR= D3DXVec3Dot(&vcRf, &vcZ);
	}

	return 1;
}


INT	CEfPtcS::VtxUpdate()
{
	VEC2	uv0;
	VEC2	uv1;

	DWORD	d;
	FLOAT	w;
	FLOAT	h;
	FLOAT	x;
	FLOAT	y;
	FLOAT	z;
	
	MATA	mtB;
	VEC3	vcX;
	VEC3	vcY;
	VEC3	vcZ;
	VEC3	vcC;

	VEC3	p00;
	VEC3	p10;
	VEC3	p20;
	VEC3	p30;

	VEC3	p0;
	VEC3	p1;
	VEC3	p2;
	VEC3	p3;

	FLOAT	fCos;
	FLOAT	fSin;

	MATA	mR;
	INT		i=0;

	if(!IsFrmMov())
		return 1;

	// 2. Update Vertex
	mtB = *m_mtVwI;
	mtB._41 = mtB._42 = mtB._43 =0.f;

	vcX = VEC3(m_mtVwI->_11, m_mtVwI->_12, m_mtVwI->_13) ;
	vcY = VEC3(m_mtVwI->_21, m_mtVwI->_22, m_mtVwI->_23) ;
	vcZ = VEC3(m_mtVwI->_31, m_mtVwI->_32, m_mtVwI->_33) ;
	vcC = VEC3(m_mtVwI->_41, m_mtVwI->_42, m_mtVwI->_43) ;

	// 1. sorting
	std::sort(&m_pPrt[0], &m_pPrt[m_pPtB->iN], TsrtG<EfPtc>());

	for(i=0; i<m_pPtB->iN; ++i)
	{
		uv0	= m_pPrt[i].uv0;
		uv1	= m_pPrt[i].uv1;
		d	= m_pPrt[i].xcC;
		w	= m_pPrt[i].fW;
		h	= m_pPrt[i].fH;

		if(0 == m_pPrt[i].nBt)
		{
			m_pVtx[i*6 + 0] = VtxDUV1( -w, +h, 0, uv0.x, uv0.y, d);
			m_pVtx[i*6 + 1] = VtxDUV1( +w, +h, 0, uv1.x, uv0.y, d);
			m_pVtx[i*6 + 2] = VtxDUV1( -w, -h, 0, uv0.x, uv1.y, d);
			m_pVtx[i*6 + 3] = VtxDUV1( +w, -h, 0, uv1.x, uv1.y, d);

			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 0].p), &(m_pVtx[i*6 + 0].p), &m_pPrt[i].mtW);
			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 1].p), &(m_pVtx[i*6 + 1].p), &m_pPrt[i].mtW);
			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 2].p), &(m_pVtx[i*6 + 2].p), &m_pPrt[i].mtW);
			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 3].p), &(m_pVtx[i*6 + 3].p), &m_pPrt[i].mtW);
		}

		else if(1 == m_pPrt[i].nBt)														// Y �࿡ ���� ������
		{
			p00 = -(vcX * m_pPrt[i].vcS.x - vcY * m_pPrt[i].vcS.y);
			p10 = +(vcX * m_pPrt[i].vcS.x + vcY * m_pPrt[i].vcS.y);
			p20 = -(vcX * m_pPrt[i].vcS.x + vcY * m_pPrt[i].vcS.y);
			p30 = +(vcX * m_pPrt[i].vcS.x - vcY * m_pPrt[i].vcS.y);

			fCos = cosf(DEGtoRAD(m_pPrt[i].vcR.x));
			fSin = sinf(DEGtoRAD(m_pPrt[i].vcR.x));
			
			D3DXMatrixRotationAxis(&mR, &vcZ, m_pPrt[i].vcR.x);

			D3DXVec3TransformCoord(&p0, &p00, &mR);
			D3DXVec3TransformCoord(&p1, &p10, &mR);
			D3DXVec3TransformCoord(&p2, &p20, &mR);
			D3DXVec3TransformCoord(&p3, &p30, &mR);

			m_pVtx[i*6+0].p = m_pPrt[i].vcP + VEC3(p0.x * w, p0.y * h, p0.z * w);
			m_pVtx[i*6+1].p = m_pPrt[i].vcP + VEC3(p1.x * w, p1.y * h, p1.z * w);
			m_pVtx[i*6+2].p = m_pPrt[i].vcP + VEC3(p2.x * w, p2.y * h, p2.z * w);
			m_pVtx[i*6+3].p = m_pPrt[i].vcP + VEC3(p3.x * w, p3.y * h, p3.z * w);

			m_pVtx[i*6+0].u = uv0.x;
			m_pVtx[i*6+1].u = uv1.x;
			m_pVtx[i*6+2].u = uv0.x;
			m_pVtx[i*6+3].u = uv1.x;

			m_pVtx[i*6+0].v = uv0.y;
			m_pVtx[i*6+1].v = uv0.y;
			m_pVtx[i*6+2].v = uv1.y;
			m_pVtx[i*6+3].v = uv1.y;

			m_pVtx[i*6+0].d = d;
			m_pVtx[i*6+1].d = d;
			m_pVtx[i*6+2].d = d;
			m_pVtx[i*6+3].d = d;
		}


		else if(2 == m_pPrt[i].nBt)
		{
			m_pVtx[i*6 + 0] = VtxDUV1( -w, +h, 0, uv0.x, uv0.y, d);
			m_pVtx[i*6 + 1] = VtxDUV1( +w, +h, 0, uv1.x, uv0.y, d);
			m_pVtx[i*6 + 2] = VtxDUV1( -w, -h, 0, uv0.x, uv1.y, d);
			m_pVtx[i*6 + 3] = VtxDUV1( +w, -h, 0, uv1.x, uv1.y, d);

			x = m_pPrt[i].mtW._41;
			y = m_pPrt[i].mtW._42;
			z = m_pPrt[i].mtW._43;

			m_pPrt[i].mtW._41 = 0;
			m_pPrt[i].mtW._42 = 0;
			m_pPrt[i].mtW._43 = 0;

			m_pPrt[i].mtW *= mtB;

			m_pPrt[i].mtW._41 = x;
			m_pPrt[i].mtW._42 = y;
			m_pPrt[i].mtW._43 = z;

			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 0].p), &(m_pVtx[i*6 + 0].p), &m_pPrt[i].mtW);
			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 1].p), &(m_pVtx[i*6 + 1].p), &m_pPrt[i].mtW);
			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 2].p), &(m_pVtx[i*6 + 2].p), &m_pPrt[i].mtW);
			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 3].p), &(m_pVtx[i*6 + 3].p), &m_pPrt[i].mtW);
		}

		m_pVtx[i*6 + 4] = m_pVtx[i*6 + 2];
		m_pVtx[i*6 + 5] = m_pVtx[i*6 + 1];
	}


	return 1;
}


void	CEfPtcS::OnReset()
{
	for(int i=0;i<m_pPtB->iN; ++i)
	{
		Set(i);
	}
}


void CEfPtcS::PtcSet(EfPtcB* pPtB)
{
	if(NULL == pPtB)
		return;

	m_pPtB = pPtB;

	SAFE_FREE(	m_pPrt	);
	m_pPrt = (EfPtc*) malloc(m_pPtB->iN * sizeof(EfPtc));
	memset(m_pPrt, 0, m_pPtB->iN * sizeof(EfPtc));
}



void	CEfPtcS::VtxSet()
{
	SAFE_FREE(	m_pVtx	);
	m_pVtx = (VtxDUV1*) malloc(m_pPtB->iN * 6 * sizeof(VtxDUV1));
	memset(m_pVtx, 0, m_pPtB->iN* 6 * sizeof(VtxDUV1));
}



void	CEfPtcS::Set(INT i)
{
	VEC3	vcP;
	VEC3	vcV;
	VEC3	vcA;
	FLOAT	r;
	FLOAT	theta;
	FLOAT	phi;
	FLOAT	h;

	vcP.x		= GetABC(m_pPtB->vcPx);
	vcP.y		= GetABC(m_pPtB->vcPy);
	vcP.z		= GetABC(m_pPtB->vcPz);

	vcV.x		= GetABC(m_pPtB->vcVx);
	vcV.y		= GetABC(m_pPtB->vcVy);
	vcV.z		= GetABC(m_pPtB->vcVz);

	vcA.x		= GetABC(m_pPtB->vcAx);
	vcA.y		= GetABC(m_pPtB->vcAy);
	vcA.z		= GetABC(m_pPtB->vcAz);

	m_pPrt[i].vcP	= vcP;															// Default Cartesian coordinate
	m_pPrt[i].vcV	= vcV;
	m_pPrt[i].vcA	= vcA;

	if(1 == m_pPtB->nCp)															// Spherical coordinate
	{
		r		= vcP.x;
		theta	= vcP.y;
		phi		= vcP.z;

		m_pPrt[i].vcP.y	= r * cosf(DEGtoRAD(theta));
		m_pPrt[i].vcP.x	= r * sinf(DEGtoRAD(theta)) * cosf(DEGtoRAD(phi));
		m_pPrt[i].vcP.z	= r * sinf(DEGtoRAD(theta)) * sinf(DEGtoRAD(phi));
	}
	else if(2 == m_pPtB->nCp)														// Cylinder coordinate
	{
		r		= vcP.x;
		h		= vcP.y;
		theta	= vcP.z;		

		m_pPrt[i].vcP.y	= h;
		m_pPrt[i].vcP.x	= r * cosf(DEGtoRAD(theta));
		m_pPrt[i].vcP.z	= r * sinf(DEGtoRAD(theta));
	}


	if(1 == m_pPtB->nCv)															// Spherical coordinate
	{
		r		= vcV.x;
		theta	= vcV.y;
		phi		= vcV.z;

		m_pPrt[i].vcV.y	= r * cosf(DEGtoRAD(theta));
		m_pPrt[i].vcV.x	= r * sinf(DEGtoRAD(theta)) * cosf(DEGtoRAD(phi));
		m_pPrt[i].vcV.z	= r * sinf(DEGtoRAD(theta)) * sinf(DEGtoRAD(phi));
	}
	else if(2 == m_pPtB->nCv)														// Cylinder coordinate
	{
		r		= vcV.x;
		h		= vcV.y;
		theta	= vcV.z;

		m_pPrt[i].vcV.y	= h;
		m_pPrt[i].vcV.x	= r * cosf(DEGtoRAD(theta));
		m_pPrt[i].vcV.z	= r * sinf(DEGtoRAD(theta));
	}


	if(1 == m_pPtB->nCa)															// Spherical coordinate
	{
		r		= vcA.x;
		theta	= vcA.y;
		phi		= vcA.z;

		m_pPrt[i].vcA.y	= r * cosf(DEGtoRAD(theta));
		m_pPrt[i].vcA.x	= r * sinf(DEGtoRAD(theta)) * cosf(DEGtoRAD(phi));
		m_pPrt[i].vcA.z	= r * sinf(DEGtoRAD(theta)) * sinf(DEGtoRAD(phi));

	}
	else if(2 == m_pPtB->nCa)														// Cylinder coordinate
	{
		r		= vcA.x;
		h		= vcA.y;
		theta	= vcA.z;
		
		m_pPrt[i].vcA.y	= h;
		m_pPrt[i].vcA.x	= r * cosf(DEGtoRAD(theta));
		m_pPrt[i].vcA.z	= r * sinf(DEGtoRAD(theta));
	}


	m_pPrt[i].vcP		+= m_pPtB->vcP;

	m_pPrt[i].vcR.x	= GetABC(m_pPtB->vcRx);
	m_pPrt[i].vcR.y	= GetABC(m_pPtB->vcRy);
	m_pPrt[i].vcR.z	= GetABC(m_pPtB->vcRz);

	m_pPrt[i].vcRv.x	= GetABC(m_pPtB->vcRvx);
	m_pPrt[i].vcRv.y	= GetABC(m_pPtB->vcRvy);
	m_pPrt[i].vcRv.z	= GetABC(m_pPtB->vcRvz);

	m_pPrt[i].vcS.x	= GetABC(m_pPtB->vcSx);
	m_pPrt[i].vcS.y	= GetABC(m_pPtB->vcSy);
	m_pPrt[i].vcS.z	= GetABC(m_pPtB->vcSz);

	m_pPrt[i].vcSv.x	= GetABC(m_pPtB->vcSvx);
	m_pPrt[i].vcSv.y	= GetABC(m_pPtB->vcSvy);
	m_pPrt[i].vcSv.z	= GetABC(m_pPtB->vcSvz);

	m_pPrt[i].vcGx	= m_pPtB->vcGx;
	m_pPrt[i].vcGy	= m_pPtB->vcGy;
	m_pPrt[i].vcGz	= m_pPtB->vcGz;

	m_pPrt[i].xcC.r	= GetABC(m_pPtB->vcCr);
	m_pPrt[i].xcC.g	= GetABC(m_pPtB->vcCg);
	m_pPrt[i].xcC.b	= GetABC(m_pPtB->vcCb);
	m_pPrt[i].xcC.a	= GetABC(m_pPtB->vcCa);

	m_pPrt[i].xcV.r	= GetABC(m_pPtB->vcCvr);
	m_pPrt[i].xcV.g	= GetABC(m_pPtB->vcCvg);
	m_pPrt[i].xcV.b	= GetABC(m_pPtB->vcCvb);
	m_pPrt[i].xcV.a	= GetABC(m_pPtB->vcCva);

	m_pPrt[i].fW		=  GetABC(m_pPtB->vcWx);
	m_pPrt[i].fH		=  GetABC(m_pPtB->vcWy);

	m_pPtB->iNIm = m_pPtB->vIm.size();
	
	INT idx	= rand()%m_pPtB->iNIm;

	idx = m_pPtB->vIm[idx];

	INT iX = idx%16;
	INT iY = idx/16;

	m_pPrt[i].nBt	= m_pPtB->nBt;

	m_pPrt[i].uv0	= VEC2( (iX+0) / 16.f, (iY+0) / 16.f);
	m_pPrt[i].uv1	= VEC2( (iX+1) / 16.f, (iY+1) / 16.f);
}

FLOAT	CEfPtcS::GetABC(VEC3 abc)
{
	if(abc.z<1)
		return abc.x + abc.y * ( rand()%(INT(abc.z) + 1) );

	return abc.x + abc.y * ( rand()%(INT(abc.z)) );
}

FLOAT	CEfPtcS::GetShk(VEC3 abc)
{
	return abc.x + abc.y * sinf(DEGtoRAD( abc.z) );
}



INT CEfPtcS::GetNum()
{
	return m_pPtB->iN;
}