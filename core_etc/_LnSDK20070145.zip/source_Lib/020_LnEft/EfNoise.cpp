// Implementation of the CEfNoise class.
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable : 4786)
#include <vector>
#include <map>

#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/Euclid/LnEuclid.h>
#include <ln/Util/LnUtilDx.h>

#include "EfBase.h"																// Base Effect
#include "EfNoise.h"															// White Noise


#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }
#endif


CEfNoise::CEfNoise()
{
	m_iN	= 20000;
	m_pVB	= 0;
	m_pTx	= 0;

	m_fScnW	= 0.f;
	m_fScnH	= 0.f;
	m_fPnt	= 3.f;
}

CEfNoise::~CEfNoise()
{
	Destroy();
}


INT CEfNoise::Create(void* p1, void* p2, void* p3)
{
	m_pDev	= (PDEV)p1;

	D3DSURFACE_DESC   desc;
	PDSF pBSF = NULL;
    m_pDev->GetBackBuffer( 0, 0, D3DBACKBUFFER_TYPE_MONO, &pBSF );
    pBSF->GetDesc( &desc );
    pBSF->Release();

	m_fScnW	= FLOAT(desc.Width);
	m_fScnH	= FLOAT(desc.Height);


	if(FAILED( m_pDev->CreateVertexBuffer( m_iN * sizeof(CEfNoise::VtxwPnt), D3DUSAGE_POINTS, CEfNoise::VtxwPnt::FVF, D3DPOOL_MANAGED, &m_pVB, 0)))
		return -1;

    CEfNoise::VtxwPnt* pVtx;

	if(FAILED(m_pVB->Lock( 0, 0, (void **) &pVtx, 0)))
		return -1;

	for(INT i=0; i<m_iN; ++i)
	{
		pVtx[i].d	= D3DXCOLOR( 1,1,1,1);
		pVtx[i].p.z	= 1.f;
	}

	m_pVB->Unlock();


	if(p2)
		m_pTx = (PDTX)p2;


	Reset();
	

	return 1;
}


void CEfNoise::Destroy()
{
	SAFE_RELEASE(	m_pVB	);
	SAFE_RELEASE(	m_pTx	);
}



INT CEfNoise::FrameMove()
{
	if(false==m_bFm)
	{
		m_nFrmR = EFT_STATE_UPDATE_NONE;
		return m_nFrmR;
	}

	CEfNoise::VtxwPnt* pVtx;

	if(FAILED(m_pVB->Lock( 0, 0, (void **) &pVtx, 0)))
		return -1;

	for(int i=0; i<m_iN; ++i)
	{
		DWORD d = 200;
		FLOAT x = FLOAT(rand()%(INT(m_fScnW)));
		FLOAT y = FLOAT(rand()%(INT(m_fScnW)));

		pVtx[i].d = D3DCOLOR_XRGB(d, d, d);
		pVtx[i].p.x = x;
		pVtx[i].p.y = y;
	}

	m_pVB->Unlock();

	m_nFrmR = EFT_STATE_UPDATE_PLAY;
	
	return m_nFrmR;
}


void CEfNoise::Render()
{
	if(!m_bRn)
		return;


#define		FtoDW(v)	(*((DWORD*)&(v)))

	m_pDev->SetRenderState(D3DRS_ZENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE );

	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
	m_pDev->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_ONE );
	m_pDev->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCCOLOR );

	m_pDev->SetRenderState( D3DRS_POINTSPRITEENABLE, TRUE );
	m_pDev->SetRenderState( D3DRS_POINTSCALEENABLE,  TRUE );
	m_pDev->SetRenderState( D3DRS_POINTSIZE,     FtoDW(m_fPnt) );
	m_pDev->SetRenderState( D3DRS_POINTSIZE_MIN, FtoDW(m_fPnt) );
	m_pDev->SetRenderState( D3DRS_POINTSCALE_A,  FtoDW(m_fPnt) );
	m_pDev->SetRenderState( D3DRS_POINTSCALE_B,  FtoDW(m_fPnt) );
	m_pDev->SetRenderState( D3DRS_POINTSCALE_C,  FtoDW(m_fPnt) );

#undef  FtoDW

	m_pDev->SetTexture(0, m_pTx);
	m_pDev->SetStreamSource( 0, m_pVB, 0, sizeof(CEfNoise::VtxwPnt) );
    m_pDev->SetFVF( CEfNoise::VtxwPnt::FVF );
	m_pDev->DrawPrimitive(D3DPT_POINTLIST, 0, m_iN);

	m_pDev->SetRenderState( D3DRS_POINTSPRITEENABLE, FALSE );
	m_pDev->SetRenderState( D3DRS_POINTSCALEENABLE,  FALSE );

	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE, TRUE);
}