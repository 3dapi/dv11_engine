// Implementation of the CEfSpark class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/_Cmm/LnVtxFmt.h>

#include <Ln/Euclid/LnEuclid.h>
#include <ln/Util/LnUtil.h>
#include <ln/Util/LnUtilDx.h>

#include "EfBase.h"

#include "EfSpark.h"
#include "EftLoader.h"


CEfSpark::CEfSpark()
{
	m_pDev		= NULL;
	
	m_pTx		= NULL;
	m_nImgX		= 1;
	m_nImgY		= 1;
	m_iImgN		= 1;
	
	m_iN		= 0;
	m_iC		= 0;
	m_pPtc		= NULL;
	m_pVtx		= NULL;

	m_fWdth		= 5.f;
	
	m_fTimeTck	= 33.33f;
}


CEfSpark::~CEfSpark()
{
	Destroy();
}


void CEfSpark::Destroy()
{
	SAFE_FREE(	m_pPtc	);
	SAFE_FREE(	m_pVtx	);
}


INT CEfSpark::Create(void* p1, void* p2, void* p3)
{
	if(p2)
		memcpy(this, (CEfSpark*)p2, sizeof(CEfSpark) );

	m_pDev = (PDEV)p1;

	int	nCreateOpt =(int)p3;

	if(1 == nCreateOpt && m_iN>0)
	{
		m_pPtc =(EfPtc*) malloc(m_iN*1 * sizeof(EfPtc  ));
		m_pVtx=(VtxDUV1*)malloc(m_iN*6 * sizeof(VtxDUV1));

		memset(m_pPtc, 0, m_iN*1 * sizeof(EfPtc  ));
		memset(m_pVtx, 0, m_iN*6 * sizeof(VtxDUV1));
	}

	Stop();


	return 1;
}



INT CEfSpark::LoadEnvFromFile(void* pLoader, char* sFile, char* sApp)
{
	char	sTemp[MAX_PATH];

	LnUtil_INIReadString(sFile, sApp, "ClassName", m_sCls, sizeof m_sCls, 0);

	m_iN		= LnUtil_INIReadINT(sFile, sApp, "PartileNum");

	m_nImgX		= LnUtil_INIReadINT(sFile, sApp, "ImageX");
	m_nImgY		= LnUtil_INIReadINT(sFile, sApp, "ImageY");
	m_iImgN		= LnUtil_INIReadINT(sFile, sApp, "ImageNum");

	m_fWdth		= LnUtil_INIReadFloat(sFile, sApp, "Width");

	m_fTimeTck	= LnUtil_INIReadFloat(sFile, sApp, "TimeTick");

	
	LnUtil_INIReadString(sFile, sApp, "Texture", sTemp, sizeof sTemp, 0);
	m_pTx = ((CEftLoader*)pLoader)->LoadTexture(sTemp);
	
	return 1;
}


INT CEfSpark::LoadEnvFromString(void* pLoader, char* sStr)
{
	sscanf(sStr,
		
		" %d"
		" %f"
		
		, &m_iN
		, &m_fWdth
		);

	return 1;
}




INT CEfSpark::FrameMove()
{
	if(!m_bFm)
	{
		m_nFrmR = EFT_STATE_UPDATE_NONE;
		return m_nFrmR;
	}

	m_vcC = m_vcI;

	INT i;
	MATA mtView;
	
	m_pDev->GetTransform(D3DTS_VIEW, &mtView);

	VEC3 fX = VEC3(mtView._11, mtView._21, mtView._31);
	VEC3 fY = VEC3(mtView._12, mtView._22, mtView._32);
	VEC3 fZ = VEC3(mtView._13, mtView._23, mtView._33);

	for (i=0;i<m_iN;++i)					// Loop Through All The Particles
	{
		if(!m_pPtc[i].bAct)
			continue;
		
		m_pPtc[i].vcV	+= m_pPtc[i].vcA;
		m_pPtc[i].vcP	+= m_pPtc[i].vcV;
		m_pPtc[i].xcC.a += m_pPtc[i].fFd;


		if(m_pPtc[i].xcC.a <0.f)
			m_pPtc[i].bAct = FALSE;
	}


	VEC2	uv0;
	VEC2	uv1;
	DWORD	d;
	FLOAT	w;
	FLOAT	h;

	m_iC = 0;
	
	for (i=0;i<m_iN; ++i)					// Loop Through All The Particles
	{
		if(!m_pPtc[i].bAct)
			continue;
		
		MATA mR;

		D3DXMatrixRotationAxis(&mR, &fZ, m_pPtc[i].vcR.x);

		VEC3 p0 = -(fX-fY);
		VEC3 p1 = +(fX+fY);
		VEC3 p2 = -(fX+fY);
		VEC3 p3 = +(fX-fY);

		uv0	= m_pPtc[i].uv0;
		uv1	= m_pPtc[i].uv1;
		d	= m_pPtc[i].xcC;
		w	= m_pPtc[i].fW;
		h	= m_pPtc[i].fH;


		D3DXVec3TransformCoord(&p0, &p0, &mR);
		D3DXVec3TransformCoord(&p1, &p1, &mR);
		D3DXVec3TransformCoord(&p2, &p2, &mR);
		D3DXVec3TransformCoord(&p3, &p3, &mR);

		m_pVtx[m_iC*6 + 0].p = m_pPtc[i].vcP + VEC3(p0.x * w, p0.y * h, p0.z * w);
		m_pVtx[m_iC*6 + 1].p = m_pPtc[i].vcP + VEC3(p1.x * w, p1.y * h, p1.z * w);
		m_pVtx[m_iC*6 + 2].p = m_pPtc[i].vcP + VEC3(p2.x * w, p2.y * h, p2.z * w);
		m_pVtx[m_iC*6 + 3].p = m_pPtc[i].vcP + VEC3(p3.x * w, p3.y * h, p3.z * w);

		m_pVtx[m_iC*6 + 0].u =  uv0.x;
		m_pVtx[m_iC*6 + 1].u =  uv1.x;
		m_pVtx[m_iC*6 + 2].u =  uv0.x;
		m_pVtx[m_iC*6 + 3].u =  uv1.x;

		m_pVtx[m_iC*6 + 0].v =  uv0.y;
		m_pVtx[m_iC*6 + 1].v =  uv0.y;
		m_pVtx[m_iC*6 + 2].v =  uv1.y;
		m_pVtx[m_iC*6 + 3].v =  uv1.y;

		m_pVtx[m_iC*6 + 0].d = d;
		m_pVtx[m_iC*6 + 1].d = d;
		m_pVtx[m_iC*6 + 2].d = d;
		m_pVtx[m_iC*6 + 3].d = d;
		
		m_pVtx[m_iC*6 + 4] = m_pVtx[m_iC*6 + 2];
		m_pVtx[m_iC*6 + 5] = m_pVtx[m_iC*6 + 1];

		++m_iC;
	}


	if(m_iC<1)
	{
		if(0xFFFFFFFF==m_dRpt)
		{
			m_fTimeCrn = LnUtil_TimeGetTime();

			if(m_fTimeCrn> (m_fTimeBgn+ m_fTimeTck))
			{
				Reset();
				m_fTimeBgn = m_fTimeCrn;
			}
		}
		else
		{
			Stop();
			m_nFrmR = EFT_STATE_UPDATE_NONE;
			return m_nFrmR;
		}
	}

	else
	{
		m_fTimeBgn = LnUtil_TimeGetTime();
	}


	m_nFrmR = EFT_STATE_UPDATE_PLAY;
	
	return m_nFrmR;
}


void CEfSpark::Render()
{
	if(!m_bRn || m_iC<1)
		return;

	LnD3D_SetWorldIdentity(m_pDev);

	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

	
	
	
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);
	
	m_pDev->SetTexture(0, m_pTx);
	m_pDev->SetTexture(1, 0);
	m_pDev->SetFVF(VtxDUV1::FVF);
	
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, m_iC*2, m_pVtx, sizeof(VtxDUV1));
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, m_iC*2, m_pVtx, sizeof(VtxDUV1));
	
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
}



void CEfSpark::Set(INT i)
{
	FLOAT fT = DEGtoRAD(rand()%90);
	FLOAT fP = DEGtoRAD(rand()%360);
	FLOAT fR = 1.f;
	FLOAT fV = 10.f + rand()%10;

	m_pPtc[i].vcP	= VEC3(cosf(fP), 0, sinf(fP)) * fR;
	m_pPtc[i].vcA	= VEC3(0,0,0);

	m_pPtc[i].vcV.x	= fV * sinf(fT) * cosf(fP);
	m_pPtc[i].vcV.y	= fV * cosf(fT);
	m_pPtc[i].vcV.z	= fV * sinf(fT) * sinf(fP);

	m_pPtc[i].vcA	= -m_pPtc[i].vcV * 0.05f;
	m_pPtc[i].vcA.y	= -1.f;

	m_pPtc[i].xcC.a = (25+ rand()%26) * 0.02f;

	m_pPtc[i].xcC.r = m_pPtc[i].xcC.a;
	m_pPtc[i].xcC.g = m_pPtc[i].xcC.a*0.2f;
	m_pPtc[i].xcC.b = 0;
	
	m_pPtc[i].fFd = -(100+rand()%100) * 0.0003f;

	m_pPtc[i].fW = m_fWdth;
	m_pPtc[i].fH = m_pPtc[i].fW*2;
	m_pPtc[i].bAct=TRUE;

	m_pPtc[i].uv0.x = 0.f;
	m_pPtc[i].uv0.y = 0.f;
	m_pPtc[i].uv1.x = 1.f;
	m_pPtc[i].uv1.y = 1.f;

	m_pPtc[i].vcP  +=m_vcI;
}



void CEfSpark::OnReset()
{
	m_fTimeBgn	= LnUtil_TimeGetTime();
	m_fTimeCrn	= m_fTimeBgn;
	
	if(NULL == m_pPtc && m_iN>0)
	{
		m_pPtc =(EfPtc*) malloc(m_iN*1 * sizeof(EfPtc  ));
		m_pVtx=(VtxDUV1*)malloc(m_iN*6 * sizeof(VtxDUV1));

		memset(m_pPtc, 0, m_iN*1 * sizeof(EfPtc  ));
		memset(m_pVtx, 0, m_iN*6 * sizeof(VtxDUV1));
	}

	for(INT i=0; i<m_iN; ++i)
	{
		Set(i);
	}
}

