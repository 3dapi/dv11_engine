// Implementation of the CEfScnSprd class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/Euclid/LnEuclid.h>
#include <ln/Util/LnUtilDx.h>

#include "EfBase.h"
#include "EfScnSprd.h"

#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }
#endif


#define RS   m_pDev->SetRenderState
#define TSS  m_pDev->SetTextureStageState
#define SAMP m_pDev->SetSamplerState



CEfScnSprd::TrndSf::TrndSf()
{
	m_pT	= NULL;
	m_pC	= NULL;
	m_pD	= NULL;
}


void CEfScnSprd::TrndSf::Invalidate()
{
	SAFE_RELEASE(	m_pT	);
	SAFE_RELEASE(	m_pC	);
	SAFE_RELEASE(	m_pD	);
}



INT CEfScnSprd::TrndSf::Create(PDEV pDev, INT scnW, INT scnH, DWORD dFmtColor, DWORD dFmtDepth)
{
	// �Ϲݷ������� �� ��
	if(FAILED(pDev->CreateTexture(scnW, scnH, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8,D3DPOOL_DEFAULT, &m_pT, NULL)))
		return -1;

	if(FAILED(m_pT->GetSurfaceLevel(0, &m_pC)))
		return -1;

	return 1;
}


PDTX CEfScnSprd::TrndSf::GetTexture() const
{
	return m_pT;
}




char	g_HlslScnSpread[] =
"// 64 Box Filter													\n"
"// Copyright (c) 2003 IMAGIRE Takashi. All rights reserved.		\n"

"float g_fMapW;		// Map Width									\n"
"float g_fMapH;		// Map Height									\n"
"float g_fMapWg;	// Rgb Weight									\n"
"texture TxSrcMap;	// Texture										\n"

"sampler SrcSamp = sampler_state									\n"
"{																	\n"
"    Texture = <TxSrcMap>;											\n"
"    MinFilter = LINEAR;											\n"
"    MagFilter = LINEAR;											\n"
"    MipFilter = NONE;												\n"
"    AddressU = Clamp;												\n"
"    AddressV = Clamp;												\n"
"};																	\n"

"// �������̴����� �ȼ����̴��� �ѱ�� ������						\n"

"struct VS_OUTPUT													\n"
"{																	\n"
"    float4 Pos	: POSITION;											\n"
"	float2 Tex0	: TEXCOORD0;										\n"
"	float2 Tex1	: TEXCOORD1;										\n"
"	float2 Tex2	: TEXCOORD2;										\n"
"	float2 Tex3	: TEXCOORD3;										\n"
"	float2 Tex4	: TEXCOORD4;										\n"
"	float2 Tex5	: TEXCOORD5;										\n"
"	float2 Tex6	: TEXCOORD6;										\n"
"	float2 Tex7	: TEXCOORD7;										\n"
"};																	\n"


"// �������̴�														\n"

"VS_OUTPUT VS (														\n"
"				float4 Pos : POSITION,		// ������				\n"
"				float4 Tex : TEXCOORD0		// �ؽ�ó��ǥ			\n"
"			)														\n"
"{																	\n"
"    VS_OUTPUT Out = (VS_OUTPUT)0;	// ��µ�����					\n"
"    																\n"
"    Out.Pos = Pos;					// ��ġ��ǥ						\n"
"    																\n"
"    Out.Tex0 = Tex + float2(3.0f/g_fMapW, -3.0f/g_fMapH);			\n"
"    Out.Tex1 = Tex + float2(3.0f/g_fMapW, -1.0f/g_fMapH);			\n"
"    Out.Tex2 = Tex + float2(3.0f/g_fMapW, +1.0f/g_fMapH);			\n"
"    Out.Tex3 = Tex + float2(3.0f/g_fMapW, +3.0f/g_fMapH);			\n"
"    Out.Tex4 = Tex + float2(1.0f/g_fMapW, -3.0f/g_fMapH);			\n"
"    Out.Tex5 = Tex + float2(1.0f/g_fMapW, -1.0f/g_fMapH);			\n"
"    Out.Tex6 = Tex + float2(1.0f/g_fMapW, +1.0f/g_fMapH);			\n"
"    Out.Tex7 = Tex + float2(1.0f/g_fMapW, +3.0f/g_fMapH);			\n"
"    																\n"
"    return Out;													\n"
"}																	\n"


"// Pixel Shader													\n"
"																	\n"
"float4 PS ( VS_OUTPUT In ) : COLOR0								\n"
"{																	\n"
"	float4 Color;													\n"
"																	\n"
"	Color  = tex2D(SrcSamp, In.Tex0);								\n"
"	Color += tex2D(SrcSamp, In.Tex1);								\n"
"	Color += tex2D(SrcSamp, In.Tex2);								\n"
"	Color += tex2D(SrcSamp, In.Tex3);								\n"
"																	\n"
"	Color += tex2D(SrcSamp, In.Tex4);								\n"
"	Color += tex2D(SrcSamp, In.Tex5);								\n"
"	Color += tex2D(SrcSamp, In.Tex6);								\n"
"	Color += tex2D(SrcSamp, In.Tex7);								\n"
"																	\n"
"	Color += tex2D(SrcSamp, In.Tex0 + float2(-4.0f/g_fMapW, 0));	\n"
"	Color += tex2D(SrcSamp, In.Tex1 + float2(-4.0f/g_fMapW, 0));	\n"
"	Color += tex2D(SrcSamp, In.Tex2 + float2(-4.0f/g_fMapW, 0));	\n"
"	Color += tex2D(SrcSamp, In.Tex3 + float2(-4.0f/g_fMapW, 0));	\n"
"																	\n"
"	Color += tex2D(SrcSamp, In.Tex4 + float2(-4.0f/g_fMapW, 0));	\n"
"	Color += tex2D(SrcSamp, In.Tex5 + float2(-4.0f/g_fMapW, 0));	\n"
"	Color += tex2D(SrcSamp, In.Tex6 + float2(-4.0f/g_fMapW, 0));	\n"
"	Color += tex2D(SrcSamp, In.Tex7 + float2(-4.0f/g_fMapW, 0));	\n"
"																	\n"
"	Color /= 16;													\n"
"	Color.rgb *= g_fMapWg;											\n"
"																	\n"
"	return Color;													\n"
"}																	\n"


"//Technique														\n"

"technique TechShader												\n"
"{																	\n"
"    pass P0														\n"
"    {																\n"
"        VertexShader = compile vs_1_1 VS();						\n"
"        PixelShader  = compile ps_2_0 PS();						\n"
"    }																\n"
"}																	\n"


;




CEfScnSprd::CEfScnSprd()
{
	m_fScnW			= 0;
	m_fScnH			= 0;

	m_pDxEft		= NULL;

	m_fRgbWg	= 1.f;
	
	m_pDxEft	= NULL;
	m_hDxTch	= NULL;
	m_hHafWgt	= NULL;
	m_hTxSrc	= NULL;
}



CEfScnSprd::~CEfScnSprd()
{
	Destroy();
}



INT CEfScnSprd::Create(void* p1, void* pFunc, void* p3)
{
	m_pDev = (PDEV)p1;

	if(pFunc)
		RenderPtr = (void (*)())(pFunc);

	m_pDxEft = (LPD3DXEFFECT)LnD3D_EffectBuildFromString(m_pDev, g_HlslScnSpread, strlen(g_HlslScnSpread) );

	if( NULL == m_pDxEft)
		return -1;


	UINT	nScnW;
	UINT	nScnH;

	LnD3D_DeviceFormat(m_pDev, NULL, NULL, &nScnW, &nScnH);

	m_fScnW = nScnW;
	m_fScnH = nScnH;


	m_hDxTch = m_pDxEft->GetTechniqueByName( "TechShader" );
	m_hTxSrc = m_pDxEft->GetParameterByName( NULL, "TxSrcMap" );
	
	m_pDxEft->SetFloat("g_fMapW",  m_fScnW);
	m_pDxEft->SetFloat("g_fMapH",	m_fScnH);
	m_pDxEft->SetFloat("g_fMapWg",	m_fRgbWg);


	if(NULL == m_RndDst.m_pT)
	{
		if(FAILED(this->Restore()))
			return -1;
	}

	return 1;
}

void CEfScnSprd::Destroy()
{
	SAFE_RELEASE(	m_pDxEft	);
}


INT CEfScnSprd::Restore()
{
	if(m_RndDst.m_pT)
		return 1;

	DWORD	dFmtColor;
	DWORD	dFmtDepth;
	UINT	nScnW;
	UINT	nScnH;

	LnD3D_DeviceFormat(m_pDev, &dFmtColor, &dFmtDepth, &nScnW, &nScnH);

	m_fScnW = nScnW;
	m_fScnH = nScnH;

	m_pDev->GetRenderTarget(0, &m_RndOld.m_pC);
	m_pDev->GetDepthStencilSurface(&m_RndOld.m_pD);





	// �Ϲݷ������� �� ��
	if(FAILED(m_pDev->CreateTexture(m_fScnW, m_fScnH, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_RndOrg.m_pT, NULL)))
		return E_FAIL;

	if(FAILED(m_RndOrg.m_pT->GetSurfaceLevel(0, &m_RndOrg.m_pC)))
		return E_FAIL;


	// ����
	if(FAILED(m_pDev->CreateTexture(m_fScnW, m_fScnH, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_RndDst.m_pT, NULL)))
		return E_FAIL;

	if(FAILED(m_RndDst.m_pT->GetSurfaceLevel(0, &m_RndDst.m_pC)))
		return E_FAIL;


	
	// ����Ʈ
	if(m_pDxEft)
		m_pDxEft->OnResetDevice();

	return 1;
}

void CEfScnSprd::Invalidate()
{
	HRESULT hr;

	m_RndOld.Invalidate();
	m_RndDst.Invalidate();

	// ������ Ÿ��
	SAFE_RELEASE(m_RndOrg.m_pC);
	SAFE_RELEASE(m_RndOrg.m_pT);
	SAFE_RELEASE(m_RndDst.m_pC);
	SAFE_RELEASE(m_RndDst.m_pT);
	

	if(m_pDxEft)
		hr = 	m_pDxEft->OnLostDevice();
}


INT CEfScnSprd::FrameMove()
{
	if(!IsFrmMov() || !RenderPtr)
	{
		m_nFrmR = EFT_STATE_UPDATE_NONE;
		return m_nFrmR;
	}


	HRESULT hr;
	D3DXMATRIX m, mT, mR, mView, mProj;
	
	// ������Ÿ�� ����
	LPDIRECT3DSURFACE9	pOldBackBuffer;
	LPDIRECT3DSURFACE9	pOldZBuffer;

	hr = m_pDev->GetRenderTarget(0, &pOldBackBuffer);
	hr = m_pDev->GetDepthStencilSurface(&pOldZBuffer);
	

	// ���� �̹����� ����� ������ �Ѵ�.
	hr = m_pDev->SetRenderTarget(0, m_RndOrg.m_pC);


	// ������Ÿ�� Ŭ����
	hr = m_pDev->Clear(0L, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER| D3DCLEAR_STENCIL, 0xffffffff, 1.0f, 0L);

	if(RenderPtr)
		RenderPtr();
	



	// Dest�� ������ ŸŶ�� �ٲٰ�..
	hr = m_pDev->SetRenderTarget(0, m_RndDst.m_pC);

	if( m_pDxEft != NULL ) 
	{
		m_pDev->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER | D3DCLEAR_STENCIL, 0x00006699, 1.0f, 0L );
		m_pDxEft->SetTechnique(m_hDxTch);
		m_pDxEft->Begin( NULL, 0 );
		m_pDxEft->Pass( 0 );
		
		RS( D3DRS_ZENABLE, FALSE );
		RS( D3DRS_LIGHTING, FALSE );
		TSS(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		TSS(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		TSS(1,D3DTSS_COLOROP,   D3DTOP_DISABLE);
		
		typedef struct {FLOAT p[4]; FLOAT t[2];} TVERTEX;

		TVERTEX pVtx[4] =
		{
			//   x    y     z    tu tv
			{-1.0f, +1.0f, 0.1f,  0, 0},
			{+1.0f, +1.0f, 0.1f,  1, 0},
			{+1.0f, -1.0f, 0.1f,  1, 1},
			{-1.0f, -1.0f, 0.1f,  0, 1},
		};

		m_pDev->SetFVF( D3DFVF_XYZ | D3DFVF_TEX1 );
		m_pDxEft->SetTexture(m_hTxSrc, m_RndOrg.m_pT);
		m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, pVtx, sizeof( TVERTEX ) );
		
		m_pDxEft->End();
	}


	


	// ������ۿ� ���̹��۸� ������� ���� ���´�.	
	hr = m_pDev->SetRenderTarget(0, pOldBackBuffer);
	hr = m_pDev->SetDepthStencilSurface(pOldZBuffer);

	pOldBackBuffer->Release();
	pOldZBuffer->Release();

	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
	m_pDev->SetVertexDeclaration(NULL);
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);


	m_pDev->SetRenderTarget(0, m_RndOld.m_pC);
	m_pDev->SetDepthStencilSurface(m_RndOld.m_pD);

	return 1;
}

void CEfScnSprd::Render()
{
	if(!IsRender() || !RenderPtr || NULL == m_pDxEft)
		return ;

	int	  i =0;
	float w = m_fScnW;
	float h = m_fScnH;


	RS( D3DRS_ZENABLE, TRUE );
	RS( D3DRS_LIGHTING, TRUE );

	SAMP( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	SAMP( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );


	CEfScnSprd::VtxwUV1 pVtx[4];

	pVtx[0] = CEfScnSprd::VtxwUV1( 0, 0, 0, 1, 0, 0);
	pVtx[1] = CEfScnSprd::VtxwUV1( w, 0, 0, 1, 1, 0);
	pVtx[2] = CEfScnSprd::VtxwUV1( w, h, 0, 1, 1, 1);
	pVtx[3] = CEfScnSprd::VtxwUV1( 0, h, 0, 1, 0, 1);


	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);

	m_pDev->SetTexture( 0, m_RndOrg.m_pT );
	m_pDev->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, pVtx, sizeof( CEfScnSprd::VtxwUV1 ) );


	m_pDev->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_MAX);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_ONE);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);

	m_pDev->SetTexture(0, m_RndDst.m_pT);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, pVtx, sizeof( CEfScnSprd::VtxwUV1 ) );

	
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);
	
	
	
	
	
#if 0	// ����׿� �ؽ�ó ���
	{
		m_pDev->SetTextureStageState(0,D3DTSS_COLOROP,	D3DTOP_SELECTARG1);
		m_pDev->SetTextureStageState(0,D3DTSS_COLORARG1,	D3DTA_TEXTURE);
		m_pDev->SetTextureStageState(1,D3DTSS_COLOROP,    D3DTOP_DISABLE);
		m_pDev->SetVertexShader(NULL);
		m_pDev->SetFVF( D3DFVF_XYZRHW | D3DFVF_TEX1 );
		m_pDev->SetPixelShader(0);
		float scale = 256.0f;

		CEfScnSprd::VtxwUV1 pVtx2[4];

		for(int i=0; i<2; ++i)
		{
			pVtx2[0] = CEfScnSprd::VtxwUV1(     0, (i+0)*scale,0, 1, 0, 0);
			pVtx2[1] = CEfScnSprd::VtxwUV1( scale, (i+0)*scale,0, 1, 1, 0);
			pVtx2[2] = CEfScnSprd::VtxwUV1( scale, (i+1)*scale,0, 1, 1, 1);
			pVtx2[3] = CEfScnSprd::VtxwUV1(     0, (i+1)*scale,0, 1, 0, 1);
			
			if(0==i)	m_pDev->SetTexture( 0, m_RndOrg.m_pT );
			if(1==i)	m_pDev->SetTexture( 0, m_RndDst.m_pT );

			m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, pVtx2, sizeof( CEfScnSprd::VtxwUV1 ) );
		}
	}
#endif
}





int CEfScnSprd::SetVal(void* pIn, char* sCmd)
{
	if(0==stricmp(sCmd, "RgbWeight"))
	{
		m_fRgbWg = *((FLOAT*)pIn);
		m_pDxEft->SetFloat("g_fMapWg", m_fRgbWg);
		return 1;
	}


	return -1;
}

int CEfScnSprd::GetVal(void* pOut, char* sCmd) const
{
	if(0==stricmp(sCmd, "RgbWeight"))
	{
		*((FLOAT*)pOut) = m_fRgbWg;

		return 1;
	}

	return -1;
}

