// Implementation of the CEfScnMono class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/Euclid/LnEuclid.h>
#include <ln/Util/LnUtilDx.h>

#include "EfBase.h"
#include "EfScnMono.h"

#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }
#endif


CEfScnMono::CEfScnMono()
{
	m_pDev		= NULL;

	m_pRS		= NULL;
	m_pTx		= NULL;
	m_pTxS		= NULL;
	
	m_fScnW		= 0;
	m_fScnH		= 0;

	m_dMonoWgt	= D3DXCOLOR(0.299F, 0.5987F, 0.114F, 1.F);
	m_dMonoColor= D3DXCOLOR(0.0F, 0.2f, .5F, 1.F);
}

CEfScnMono::~CEfScnMono()
{
	Destroy();	
}


INT CEfScnMono::Create(void* p1, void* pFunc, void* p3)
{
	m_pDev	= (PDEV)p1;
	
	if(pFunc)
		RenderPtr = (void (*)())(pFunc);



	char* sPxlSh = 
	"ps_1_1								\n"

//	"def c0, 0.299, 0.5987, 0.114, 0	\n"

	"tex t0								\n" 
	"mov r0, t0							\n"
	"mov r1, t0							\n"
	"dp3 r0.rgb, r0, c0					\n"
	"add r0, r0, c1						\n"
	"mov t0, r0							\n";
	;

	
	if( !(m_pPS= (PDPS)LnD3D_BuildShader(m_pDev, sPxlSh, strlen(sPxlSh), "ps")))
		return -1;

	if(FAILED(this->Restore()))
		return -1;

	return 1;
}


void CEfScnMono::Destroy()
{
	SAFE_RELEASE(	m_pPS	);
}



INT CEfScnMono::Restore()
{
	HRESULT hr;

	if(m_pRS)
		return 1;

	D3DSURFACE_DESC dsc1;
	PDSF	pBSF = NULL;
	
    m_pDev->GetBackBuffer( 0, 0, D3DBACKBUFFER_TYPE_MONO, &pBSF );
    pBSF->GetDesc( &dsc1 );
    pBSF->Release();
	pBSF = NULL;

	m_fScnW	= FLOAT(dsc1.Width);
	m_fScnH	= FLOAT(dsc1.Height);

	m_pDev->GetDepthStencilSurface(&pBSF);


	D3DSURFACE_DESC dsc2;
    pBSF->GetDesc(&dsc2);
	pBSF->Release();

    if(FAILED(D3DXCreateRenderToSurface(m_pDev, m_fScnW, m_fScnH, dsc1.Format, TRUE, dsc2.Format, &m_pRS)))
        return -1;


	
	hr = D3DXCreateTexture(m_pDev, (UINT)m_fScnW, (UINT)m_fScnH, 1
						, D3DUSAGE_RENDERTARGET
						, D3DFMT_X8R8G8B8
						, D3DPOOL_DEFAULT
						, &m_pTx);

	m_pTx->GetSurfaceLevel(0, &m_pTxS);

	return 1;
}

void CEfScnMono::Invalidate()
{
	SAFE_RELEASE(	m_pRS	);
	SAFE_RELEASE(	m_pTx	);
	SAFE_RELEASE(	m_pTxS	);
}


INT CEfScnMono::FrameMove()
{
	if(!IsFrmMov() || !RenderPtr)
	{
		m_nFrmR = EFT_STATE_UPDATE_NONE;
		return m_nFrmR;
	}


	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);

	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0,  D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);

	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,   FALSE );
	
	
	
	m_pRS->BeginScene(m_pTxS, NULL);

	m_pDev->Clear( 0L, NULL, D3DCLEAR_TARGET| D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0xFF006699, 1.0f, 0L );

	if(RenderPtr)
		RenderPtr();

	m_pRS->EndScene( 0 );


	m_nFrmR = EFT_STATE_UPDATE_PLAY;
	
	return m_nFrmR;
}

void CEfScnMono::Render()
{
	if(!IsRender() || !RenderPtr)
		return;
	
	m_pDev->SetPixelShader(m_pPS);
	
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(1, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(1, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );
	m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

	LnD3D_SetPixelShaderConstant(m_pDev, 0, (float*)&m_dMonoWgt);
	LnD3D_SetPixelShaderConstant(m_pDev, 1, (float*)&m_dMonoColor);


	FLOAT fX0 = 0.F;
	FLOAT fY0 = 0.F;

	FLOAT fX1 = m_fScnW-fX0;
	FLOAT fY1 = m_fScnH-fY0;

	FLOAT fU0 = fX0/m_fScnW;
	FLOAT fV0 = fY0/m_fScnH;

	FLOAT fU1 = fX1/m_fScnW;
	FLOAT fV1 = fY1/m_fScnH;

	CEfScnMono::VtxwDUV	pVtx[4] =
	{
		CEfScnMono::VtxwDUV( fX0, fY0, 0.f, fU0, fV0) ,
		CEfScnMono::VtxwDUV( fX1, fY0, 0.f, fU1, fV0) ,
		CEfScnMono::VtxwDUV( fX0, fY1, 0.f, fU0, fV1) ,
		CEfScnMono::VtxwDUV( fX1, fY1, 0.f, fU1, fV1) ,
	};
		
	m_pDev->SetTexture( 0, m_pTx);
	m_pDev->SetFVF(CEfScnMono::VtxwDUV::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, pVtx, sizeof(CEfScnMono::VtxwDUV));
	
	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);

	m_pDev->SetTexture( 0, NULL);
}



int CEfScnMono::SetVal(void* pIn, char* sCmd)
{
	if(0==stricmp(sCmd, "MonoColor"))
	{
		memcpy(&m_dMonoColor, pIn, sizeof m_dMonoColor);
		return 1;
	}

	return -1;
}

int CEfScnMono::GetVal(void* pOut, char* sCmd) const
{
	if(0==stricmp(sCmd, "MonoColor"))
	{
		memcpy(pOut, &m_dMonoColor, sizeof m_dMonoColor);
		return 1;
	}

	return -1;
}

