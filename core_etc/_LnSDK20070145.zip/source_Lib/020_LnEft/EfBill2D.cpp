// Implementation of the CEfBill2D class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/_Cmm/LnVtxFmt.h>

#include <Ln/Euclid/LnEuclid.h>
#include <ln/Util/LnUtil.h>
#include <ln/Util/LnUtilDx.h>

#include "EfBase.h"

#include "EfBill2D.h"
#include "EftLoader.h"


CEfBill2D::CEfBill2D()
{
	m_pDev		= NULL;
	
	m_pTx		= NULL;
	m_nImgX		= 1;
	m_nImgY		= 1;
	m_iImgN		= 1;
	
	m_iN		= 0;
	m_iC		= 0;
	m_fWdth		= 0.f;
	m_fTimeTck	= 33.33f;

	m_pMdData	= NULL;
}


CEfBill2D::~CEfBill2D()
{
	Destroy();
}


void CEfBill2D::Destroy()
{
	if(m_pMdData)
	{
		IMtMedia*	pMdData = (IMtMedia*)m_pMdData;
		delete pMdData;
		m_pMdData	= NULL;
	}
}


INT CEfBill2D::Create(void* p1, void* p2, void* p3)
{
	if(p2)
		memcpy(this, (CEfBill2D*)p2, sizeof(CEfBill2D) );

	m_pDev = (PDEV)p1;

	int	nCreateOpt =(int)p3;

	if(1 == nCreateOpt && m_iN>0)
	{
	}

	Stop();

	return 1;
}



INT CEfBill2D::LoadEnvFromFile(void* pLoader, char* sFile, char* sApp)
{
	char	sTemp[MAX_PATH];

	LnUtil_INIReadString(sFile, sApp, "ClassName", m_sCls, sizeof m_sCls, 0);

	m_nImgX		= LnUtil_INIReadINT(sFile, sApp, "ImageX");
	m_nImgY		= LnUtil_INIReadINT(sFile, sApp, "ImageY");
	m_iImgN		= LnUtil_INIReadINT(sFile, sApp, "ImageNum");

	m_fWdth		= LnUtil_INIReadFloat(sFile, sApp, "Width");
	m_fHght		= LnUtil_INIReadFloat(sFile, sApp, "Height");
	m_fTimeTck	= LnUtil_INIReadFloat(sFile, sApp, "TimeTick");

	LnUtil_INIReadSscanf(sFile, sApp, "ColorWeight", "%f %f %f %f", &m_xWght.r, &m_xWght.g, &m_xWght.b, &m_xWght.a);
	
	
	LnUtil_INIReadString(sFile, sApp, "Texture", sTemp, sizeof sTemp, 0);
	m_pTx = ((CEftLoader*)pLoader)->LoadTexture(sTemp);


	LnUtil_INIReadString(sFile, sApp, "Sound", m_pMdFile, sizeof m_pMdFile, 0);



	m_iN	= m_iImgN;
	m_fU	= 1.f/FLOAT(m_nImgX);
	m_fV	= 1.f/FLOAT(m_nImgY);
	
	return 1;
}


INT CEfBill2D::LoadEnvFromString(void* pLoader, char* sStr)
{
	sscanf(sStr,
		
		" %f %f"
		" %f"
		"%f %f %f %f"

		, &m_fWdth, &m_fHght
		, &m_fTimeTck
		, &m_xWght.r, &m_xWght.g, &m_xWght.b, &m_xWght.a
		);

	return 1;
}




INT CEfBill2D::FrameMove()
{
	if(!m_bFm)
	{
		m_nFrmR = EFT_STATE_UPDATE_NONE;
		return m_nFrmR;
	}

	
	m_fTimeCrn = LnUtil_TimeGetTime();

	if( m_fTimeCrn >= (m_fTimeBgn+m_fTimeTck) )
	{
		m_fTimeBgn = m_fTimeCrn;
		++m_iC;

		if(m_iC>=m_iN)
		{
			if(0xFFFFFFFF==m_dRpt)
			{
				m_iC = 0;
			}
			else
			{
				Stop();
				m_nFrmR = EFT_STATE_UPDATE_END;
				return m_nFrmR;
			}
		}

		m_nFrmR = EFT_STATE_UPDATE_PLAY;
	}


	MATA mtView;
	
	m_pDev->GetTransform(D3DTS_VIEW, &mtView);

	VEC3 fX = VEC3(mtView._11, mtView._21, mtView._31);
	VEC3 fY = VEC3(mtView._12, mtView._22, mtView._32);
	VEC3 fZ = VEC3(mtView._13, mtView._23, mtView._33);


	DWORD	d	= m_xWght;
	FLOAT	w	= m_fWdth;
	FLOAT	h	= m_fHght;

//	p0-----------p1
//	|           /|
//	|         /  |
//	|       /    |
//	|     /      |
//	|   /        |
//	| /          |
//	p2-----------p3

	VEC3	p1 = +(fX+fY);		D3DXVec3Normalize(&p1, &p1);
	VEC3	p3 = +(fX-fY);		D3DXVec3Normalize(&p3, &p3);
	VEC3	p2 = -p1;
	VEC3	p0 = -p3;

	INT		nX = (m_iC%m_nImgX);
	INT		nY = (m_iC/m_nImgX);

	FLOAT	x0 = (nX+0) * m_fU;
	FLOAT	y0 = (nY+0) * m_fV;
	FLOAT	x1 = (nX+1) * m_fU;
	FLOAT	y1 = (nY+1) * m_fV;

	m_pVtx[0].p = m_vcI + VEC3(p0.x * w, p0.y * h, p0.z * w);
	m_pVtx[1].p = m_vcI + VEC3(p1.x * w, p1.y * h, p1.z * w);
	m_pVtx[2].p = m_vcI + VEC3(p2.x * w, p2.y * h, p2.z * w);
	m_pVtx[3].p = m_vcI + VEC3(p3.x * w, p3.y * h, p3.z * w);

	m_pVtx[0].u =  x0;	m_pVtx[0].v =  y0;
	m_pVtx[1].u =  x1;	m_pVtx[1].v =  y0;
	m_pVtx[2].u =  x0;	m_pVtx[2].v =  y1;
	m_pVtx[3].u =  x1;	m_pVtx[3].v =  y1;

	m_pVtx[0].d = d;
	m_pVtx[1].d = d;
	m_pVtx[2].d = d;
	m_pVtx[3].d = d;


	return m_nFrmR;
}


void CEfBill2D::Render()
{
	if(!m_bRn)
		return;

	LnD3D_SetWorldIdentity(m_pDev);

	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
	
	
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_ONE);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	
	m_pDev->SetTexture(0, m_pTx);
	m_pDev->SetTexture(1, 0);
	m_pDev->SetFVF(VtxDUV1::FVF);
	
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, m_pVtx, sizeof(VtxDUV1));
	
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
}



void CEfBill2D::OnReset()
{
	m_iC = 0;
	m_fTimeBgn = LnUtil_TimeGetTime();
	m_fTimeCrn = m_fTimeBgn;

	
	if(m_pMdData)
	{
		IMtMedia*	pMedia = (IMtMedia*)m_pMdData;
		pMedia->Reset();
		pMedia->Play();
	}
}


void CEfBill2D::OnPlay()
{
	if(m_pMdData)
	{
		IMtMedia*	pMdData = (IMtMedia*)m_pMdData;
		pMdData->Play();
	}
}



int CEfBill2D::SetVal(void* pIn, char* sCmd)
{
	if(0==stricmp(sCmd, "AddSound"))
	{
		m_pMdData = pIn;
		return 1;
	}

	return -1;
}

int CEfBill2D::GetVal(void* pOut, char* sCmd) const
{
	if(0==stricmp(sCmd, "Media"))
	{
		lsEfMdaEnt* pvEnt = (lsEfMdaEnt*)pOut;

		EfMdaEntry	ent( (IEfBase*)this, (char*)m_pMdFile, m_pMdData);
		(*pvEnt).push_back(ent);

		return 1;
	}

	return -1;
}


