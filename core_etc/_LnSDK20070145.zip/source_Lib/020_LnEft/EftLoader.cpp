// Implementation of the CEftLoader class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/_Cmm/LnVtxFmt.h>

#include <Ln/Euclid/LnEuclid.h>
#include <ln/Util/LnString.h>
#include <ln/Util/LnUtil.h>
#include <ln/Util/LnUtilDx.h>

#include "EfBase.h"
#include "EfExpose.h"
#include "EfAccptSp.h"
#include "EfAccptEx.h"
#include "EfAccptHl.h"
#include "EfCloud.h"
#include "EfDryIce.h"
#include "EfSpark.h"
#include "EfSprnkl.h"
#include "EfLaser.h"
#include "EfRocket.h"
#include "EfShell.h"
#include "EfBill2D.h"


#include "EfScnBlur.h"
#include "EfScnLght.h"
#include "EfScnMono.h"
#include "EfScnSprd.h"


#include "EftLoader.h"

using namespace std;






CEftLoader::CEftLoader()
{
	m_pDev = NULL;

	memset(m_sFileS, 0, sizeof m_sFileS);
	memset(m_sFileM, 0, sizeof m_sFileM);
}

CEftLoader::~CEftLoader()
{
	Destroy();
}


PDEV CEftLoader::GetDevice() const
{
	return m_pDev;
}

PDSP CEftLoader::GetSprite() const
{
	return m_pSpr;
}

void CEftLoader::Destroy()
{
	{
		for(map<string, PDTX >::iterator vIt= m_mpTxF.begin(); vIt != m_mpTxF.end(); ++vIt)
		{
			PDTX p = (*vIt).second;

			if(p)
			{
				p->Release();
				(*vIt).second = NULL;
			}
		}
	}


	{
		for(map<string,IEfBase* >::iterator vIt= m_mpEfSgl.begin(); vIt != m_mpEfSgl.end(); ++vIt)
		{
			IEfBase* p = (*vIt).second;

			if(p)
			{
				delete p;
				(*vIt).second = NULL;
			}
		}
	}


	m_mpTxF.clear();
	m_mpEfSgl.clear();
	m_mpEfLnk.clear();	
}



IEfBase* CEftLoader::CreateNew(char* sName)
{
	IEfBase* pEft = NULL;

	if(		0 == _stricmp(sName, "EfAccptSp"))	pEft = new CEfAccptSp;
	else if(0 == _stricmp(sName, "EfAccptEx"))	pEft = new CEfAccptEx;
	else if(0 == _stricmp(sName, "EfAccptHl"))	pEft = new CEfAccptHl;

	else if(0 == _stricmp(sName, "EfCloud"	))	pEft = new CEfCloud ;
	else if(0 == _stricmp(sName, "EfDryIce"	))	pEft = new CEfDryIce;
	else if(0 == _stricmp(sName, "EfExpose"	))	pEft = new CEfExpose;
	else if(0 == _stricmp(sName, "EfSpark"	))	pEft = new CEfSpark ;
	else if(0 == _stricmp(sName, "EfSprnkl"	))	pEft = new CEfSprnkl;
	else if(0 == _stricmp(sName, "EfLaser"	))	pEft = new CEfLaser ;
	else if(0 == _stricmp(sName, "EfRocket"	))	pEft = new CEfRocket;
	else if(0 == _stricmp(sName, "EfShell"	))	pEft = new CEfShell ;
	else if(0 == _strnicmp(sName, "Ef2D"
							, strlen("Ef2D"	)))	pEft = new CEfBill2D;

	return pEft;
}



INT CEftLoader::Create(PDSP pSpr, char* sFile)
{
	m_pSpr	= pSpr;

	if(FAILED(m_pSpr->GetDevice(&m_pDev)))
		return -1;
		
	strcpy(m_sFileS, sFile);
	strcpy(m_sFileM, sFile+strlen(m_sFileS)+1);


	int		i = 0;
	int		j = 0;
	int		nSubClss = 0;
	char	sTemp[MAX_PATH]={0};


	
	std::vector<std::string >	vEfSgl;

	nSubClss = LnUtil_INIReadINT(m_sFileS, "SglEfList", "SubClassNum");

	// Read Sigle Effect List
	for(i=0; i<nSubClss; ++i)
	{
		LnUtil_INIReadString(m_sFileS, "SglEfList", LnStr_Format("SubClass%d", i+1), sTemp, sizeof sTemp, 0);
		vEfSgl.push_back(sTemp);
	}

	// Create and Load Sigle Effect
	for(i=0; i<nSubClss; ++i)
	{
		IEfBase*	pEft = NULL;
		char		sApp[MAX_PATH];
		
		strcpy(sApp, vEfSgl[i].c_str());

		pEft = CreateNew( sApp  );
		pEft->LoadEnvFromFile(this, m_sFileS, sApp  );
		
		pair<string, IEfBase* >	pItm(sApp  , pEft);
		m_mpEfSgl.insert(pItm);
	}

	
	
	
	
	// Load Multi Effect
	std::vector<std::string >	vEfMulti;

	nSubClss = LnUtil_INIReadINT(m_sFileM, "LnkEfList", "SubClassNum");

	// Multi Effect ����Ʈ�� ��´�.
	for(i=0; i<nSubClss; ++i)
	{
		LnUtil_INIReadString(m_sFileM, "LnkEfList", LnStr_Format("SubClass%d", i+1), sTemp, sizeof sTemp, 0);
		vEfMulti.push_back(sTemp);
	}


	int iSize = vEfMulti.size();


	// ������ Multi Effect�� ���� �׸��� ��´�.
	for(i=0; i<iSize; ++i)
	{
		char sApp[128]={0};
		strcpy(sApp, vEfMulti[i].c_str());

		CEftLoader::EfLnkData	lnk;

		LnUtil_INIReadString(m_sFileM, sApp, "ClassName", sTemp, sizeof sTemp, 0);

		lnk.m_sCls = sTemp;

		nSubClss = LnUtil_INIReadINT(m_sFileM, sApp, "SubClassNum");

		for(j=0; j<nSubClss; ++j)
		{
			CEftLoader::EfLnkData::EfLnkDataS	lnkSub;
			
			int		nLnkPrn	=0;
			char	sEftName[256]={0};
			char*	pData=NULL;

			LnUtil_INIReadString(m_sFileM, sApp, LnStr_Format("SubClass%d", j+1), sTemp, sizeof sTemp, 0);
			sscanf(sTemp, "%d %s", &nLnkPrn, sEftName);

			pData = strstr(sTemp, sEftName)+ strlen(sEftName);

			lnkSub.nLnkPrn = nLnkPrn;
			lnkSub.sEfName = sEftName;
			lnkSub.sEfData = pData;

			lnk.m_vSubCls.push_back(lnkSub);
		}

		pair<string, EfLnkData > pItm(vEfMulti[i].c_str(), lnk);
		m_mpEfLnk.insert(pItm);		
	}

	return 1;
}



IEfBase* CEftLoader::SelectSgl(char* sName, int nCreateOpt)
{
	IEfBase* pSrc = NULL;
	IEfBase* pEft = NULL;

	// 1. ����Ʈ�� ����Ʈ�� �ִ°�?
	pSrc = m_mpEfSgl[sName];

	if(NULL == pSrc)
		return NULL;

	pEft = CreateNew(sName);

	if(NULL == pEft)
		return NULL;


	if(FAILED(pEft->Create(m_pDev, pSrc, (void*)nCreateOpt)))
	{
		delete pEft;
		return NULL;
	}

	return pEft;
}



IEfBase* CEftLoader::SelectLnk(char* sName)
{
	EfLnkData pSrc;
	IEfBase* pEft = NULL;

	// 1. ����Ʈ�� ����Ʈ�� �ִ°�?
	pSrc = m_mpEfLnk[sName];


	pEft = new IEfLnk ;

	int iSizeSub = pSrc.m_vSubCls.size();

	INT			pType[32]= {0};
	IEfBase*	ppEf [32]= {0};

	for(int i=0; i<iSizeSub; ++i)
	{
		IEfBase* pEfSub = NULL;
		pEfSub = this->SelectSgl((char*)pSrc.m_vSubCls[i].sEfName.c_str(), 0);		// ������ ����Ʈ�� �������� ��ƼŬ�� �������� �ʴ´�.
		pEfSub->LoadEnvFromString(this, (char*)pSrc.m_vSubCls[i].sEfData.c_str());	// ȯ���� �ε��ϰ�..
		pEfSub->OnReset();															// ����ƼŬ�� ���� �޸𸮸� �ε��Ѵ�. ���� Play�Լ��� ȣ���ϸ� �ٷ� ������ �ȴ�.

		ppEf [i] = pEfSub;
		pType[i] = pSrc.m_vSubCls[i].nLnkPrn;
		
	}
	
	if(FAILED(pEft->Create((void*)ppEf, (void*)pType, (void*)&iSizeSub)))
	{
		delete pEft;
		return NULL;
	}

	return pEft;
}




PDTX CEftLoader::LoadTexture(char* sFile)
{
	PDTX pTx = m_mpTxF[_strlwr(sFile)];

	LnD3D_TextureLoadFile(m_pDev, sFile, pTx);

	if(pTx)
	{
		pair<string, PDTX >	prItm(_strlwr(sFile), pTx);
		m_mpTxF.insert( prItm );
	}

	return pTx;
}





INT LnEft_CreateEffectFromRsc(void* pL,	IEfBase** pOut,	char* sName)
{
	CEftLoader*	pEfL	= (CEftLoader*)pL;
	IEfBase*	pEft	= NULL;

	*pOut = NULL;

	if(0== _strnicmp(sName, "Ef", 2))
	{
		pEft	= pEfL->SelectSgl( sName	);

		if(NULL == pEft)
			return -1;
	}

	else if(0== _strnicmp(sName, "LnkEf", 5))
	{
		pEft	= pEfL->SelectLnk( sName	);
				
		if(NULL == pEft)
			return -1;
	}

	*pOut = pEft;

	return 1;
}





INT LnEft_GetMediaEntryFromEffect(lsEfMdaEnt* pEntry, IEfBase* pEft)
{
	return pEft->GetVal((void*)pEntry, "Media");
}












// Screen Effect

INT LnEft_CreateScreenEffect(void* pL,	IEfScnBase** pOut,	char* sName, void* pFunc)
{
	CEftLoader*	pEfL	= (CEftLoader*)pL;
	IEfScnBase*	pEft	= NULL;

	PDEV pDev = pEfL->GetDevice();
	PDSP pSpr = pEfL->GetSprite();

	*pOut = NULL;

	char*	sScnEft[] =
	{
		"ScreenBlur",
		"ScreenLight",
		"ScreenMono",
		"ScreenSpread",
	};

	
	if(0== _strnicmp(sName, sScnEft[0], strlen(sScnEft[0])))
	{
		SAFE_NEWCREATE2( pEft, CEfScnBlur,	pSpr, pFunc );

		*pOut = pEft;

		return 1;
	}

	else if(0== _strnicmp(sName, sScnEft[1], strlen(sScnEft[1])))
	{
		SAFE_NEWCREATE2( pEft, CEfScnLght,	pDev, pFunc );

		*pOut = pEft;

		return 1;
	}

	else if(0== _strnicmp(sName, sScnEft[2], strlen(sScnEft[2])))
	{
		SAFE_NEWCREATE2( pEft, CEfScnMono,	pDev, pFunc );

		*pOut = pEft;

		return 1;
	}

	else if(0== _strnicmp(sName, sScnEft[3], strlen(sScnEft[3])))
	{
		SAFE_NEWCREATE2( pEft, CEfScnSprd,	pDev, pFunc );

		*pOut = pEft;

		return 1;
	}


	
	return -1;
}

