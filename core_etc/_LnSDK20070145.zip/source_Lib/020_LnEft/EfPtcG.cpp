// Implementation of the CEfPtcG class.
//
////////////////////////////////////////////////////////////////////////////////

// STL
#pragma warning( disable : 4786)
#include <vector>
#include <algorithm>
#include <functional>


#include <windows.h>
#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnVtxFmt.h>

#include <Ln/Util/LnUtil.h>

#include "EfBase.h"
#include "EfPtcS.h"

#include "EfPtcG.h"



CEfPtcG::CEfPtcG()
{
	m_iN	= 0;
	m_iC	= 0;
	m_pPrt	= NULL;
	m_pVtx	= NULL;

	m_pDev	= NULL;
	m_mtVwI	= NULL;
	m_pTx	= NULL;
}


CEfPtcG::~CEfPtcG()
{
	Destroy();
}


INT	CEfPtcG::Init()
{
	return 1;
}

void CEfPtcG::Destroy()
{
	SAFE_DEL_LST(	m_vPtc	);

	SAFE_FREE(	m_pPrt	);
	SAFE_FREE(	m_pVtx	);
}


INT CEfPtcG::FrameMove()
{
	if(!IsFrmMov())
	{
		m_nFrmR = EFT_STATE_UPDATE_NONE;
		return m_nFrmR;
	}


	PtcUpdate();																// 1. particle Update
	PtcCopy();																	// 2. Particle Copy

	if(m_iC<1)
	{
		m_nFrmR = EFT_STATE_UPDATE_END;
		return m_nFrmR;
	}

	std::sort(&m_pPrt[0], &m_pPrt[m_iC], TsrtG<EfPtc >());						// 3. sorting
	VtxUpdate();																// 4. Update Vertex
	
	m_nFrmR = EFT_STATE_UPDATE_PLAY;
	
	return m_nFrmR;
}


void CEfPtcG::Render()
{
	if(!IsFrmMov() || m_iC<1)
		return;

	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);

	m_pDev->SetRenderState(D3DRS_ZENABLE, D3DZB_TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_DESTALPHA);

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);

	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->SetTexture(0, m_pTx);
	
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, m_iC * 2, m_pVtx, sizeof(VtxDUV1) );

	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
}



void CEfPtcG::SetDevice(PDEV pDev)
{
	m_pDev = pDev;
}


void CEfPtcG::SetTx(PDTX pTx)
{
	m_pTx = pTx;
}

void CEfPtcG::SetMatrixViwI(MATA* mtViwI)
{
	m_mtVwI = mtViwI;
}



INT CEfPtcG::Update()
{
	if(!IsFrmMov())
		return 1;

	PtcUpdate();
	
	return 1;
}



INT CEfPtcG::PtcUpdate()
{
	INT i;
	INT iSize;

	if(!IsFrmMov())
		return 1;

	iSize = m_vPtc.size();

	for(i=0; i<iSize; ++i)
	{
		CEfPtcS *pPtR = m_vPtc[i];
		pPtR->SetTx(m_pTx);
		pPtR->SetDevice(m_pDev);
		pPtR->SetMatrixViwI(m_mtVwI);
		pPtR->PtcUpdate();		
	}

	return 1;
}


INT CEfPtcG::PtcCopy()
{
	INT i, j;
	INT iSize;
	INT iNum;

	if(!IsFrmMov())
		return 1;

	if(!m_pPrt)
	{
		m_pPrt = (EfPtc*) malloc(m_iN * sizeof(EfPtc));
		memset(m_pPrt, 0, m_iN * sizeof(EfPtc));
	}

	if(!m_pVtx)
	{
		m_pVtx = (VtxDUV1*) malloc(m_iN*6 * sizeof(VtxDUV1));
		memset(m_pVtx, 0, m_iN*6 * sizeof(VtxDUV1));
	}


	m_iC= 0;
	iSize = m_vPtc.size();

	for(j=0; j<iSize; ++j)
	{
		EfPtc*	pPt = m_vPtc[j]->m_pPrt;
		iNum = m_vPtc[j]->GetNum();

		for(i=0; i<iNum; ++i)
		{
			if(pPt[i].fStlSrtR< 1.f)											// ī�޶� ���ʿ� �ִ� �ѵ��� ����	1.f�� Near value
				continue;

			m_pPrt[m_iC] = pPt[i];
			++m_iC;
		}
	}

	return 1;
}



INT CEfPtcG::VtxUpdate()
{
	INT		i;
	VEC2	uv0;
	VEC2	uv1;
	DWORD	d;
	FLOAT	w;
	FLOAT	h;
	FLOAT	x;
	FLOAT	y;
	FLOAT	z;
	MATA	mtB;
	VEC3	vcX;
	VEC3	vcY;
	VEC3	vcZ;
	VEC3	vcC;

	VEC3	p00;
	VEC3	p10;
	VEC3	p20;
	VEC3	p30;

	VEC3	p0;
	VEC3	p1;
	VEC3	p2;
	VEC3	p3;

	FLOAT	fCos;
	FLOAT	fSin;
	MATA	mR;

	if(!IsFrmMov())
		return 1;

	mtB = *m_mtVwI;
	mtB._41 = mtB._42 = mtB._43 =0.f;

	vcX = VEC3(m_mtVwI->_11, m_mtVwI->_12, m_mtVwI->_13) ;
	vcY = VEC3(m_mtVwI->_21, m_mtVwI->_22, m_mtVwI->_23) ;
	vcZ = VEC3(m_mtVwI->_31, m_mtVwI->_32, m_mtVwI->_33) ;
	vcC = VEC3(m_mtVwI->_41, m_mtVwI->_42, m_mtVwI->_43) ;

	for(i=0; i<m_iC; ++i)
	{
		uv0	= m_pPrt[i].uv0;
		uv1	= m_pPrt[i].uv1;
		d	= m_pPrt[i].xcC;
		w	= m_pPrt[i].fW;
		h	= m_pPrt[i].fH;

		if(0 == m_pPrt[i].nBt)
		{
			m_pVtx[i*6 + 0] = VtxDUV1( -w, +h, 0, uv0.x, uv0.y, d);
			m_pVtx[i*6 + 1] = VtxDUV1( +w, +h, 0, uv1.x, uv0.y, d);
			m_pVtx[i*6 + 2] = VtxDUV1( -w, -h, 0, uv0.x, uv1.y, d);
			m_pVtx[i*6 + 3] = VtxDUV1( +w, -h, 0, uv1.x, uv1.y, d);

			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 0].p), &(m_pVtx[i*6 + 0].p), &m_pPrt[i].mtW);
			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 1].p), &(m_pVtx[i*6 + 1].p), &m_pPrt[i].mtW);
			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 2].p), &(m_pVtx[i*6 + 2].p), &m_pPrt[i].mtW);
			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 3].p), &(m_pVtx[i*6 + 3].p), &m_pPrt[i].mtW);
		}

		else if(1 == m_pPrt[i].nBt)														// Y �࿡ ���� ������
		{
			p00 = -(vcX * m_pPrt[i].vcS.x - vcY * m_pPrt[i].vcS.y);
			p10 = +(vcX * m_pPrt[i].vcS.x + vcY * m_pPrt[i].vcS.y);
			p20 = -(vcX * m_pPrt[i].vcS.x + vcY * m_pPrt[i].vcS.y);
			p30 = +(vcX * m_pPrt[i].vcS.x - vcY * m_pPrt[i].vcS.y);
			
			fCos = cosf(DEGtoRAD(m_pPrt[i].vcR.x));
			fSin = sinf(DEGtoRAD(m_pPrt[i].vcR.x));
			
			D3DXMatrixRotationAxis(&mR, &vcZ, m_pPrt[i].vcR.x);

			D3DXVec3TransformCoord(&p0, &p00, &mR);
			D3DXVec3TransformCoord(&p1, &p10, &mR);
			D3DXVec3TransformCoord(&p2, &p20, &mR);
			D3DXVec3TransformCoord(&p3, &p30, &mR);

			m_pVtx[i*6+0].p = m_pPrt[i].vcP + VEC3(p0.x * w, p0.y * h, p0.z * w);
			m_pVtx[i*6+1].p = m_pPrt[i].vcP + VEC3(p1.x * w, p1.y * h, p1.z * w);
			m_pVtx[i*6+2].p = m_pPrt[i].vcP + VEC3(p2.x * w, p2.y * h, p2.z * w);
			m_pVtx[i*6+3].p = m_pPrt[i].vcP + VEC3(p3.x * w, p3.y * h, p3.z * w);

			m_pVtx[i*6+0].u = uv0.x;
			m_pVtx[i*6+1].u = uv1.x;
			m_pVtx[i*6+2].u = uv0.x;
			m_pVtx[i*6+3].u = uv1.x;

			m_pVtx[i*6+0].v = uv0.y;
			m_pVtx[i*6+1].v = uv0.y;
			m_pVtx[i*6+2].v = uv1.y;
			m_pVtx[i*6+3].v = uv1.y;

			m_pVtx[i*6+0].d = d;
			m_pVtx[i*6+1].d = d;
			m_pVtx[i*6+2].d = d;
			m_pVtx[i*6+3].d = d;
		}


		else if(2 == m_pPrt[i].nBt)
		{
			m_pVtx[i*6 + 0] = VtxDUV1( -w, +h, 0, uv0.x, uv0.y, d);
			m_pVtx[i*6 + 1] = VtxDUV1( +w, +h, 0, uv1.x, uv0.y, d);
			m_pVtx[i*6 + 2] = VtxDUV1( -w, -h, 0, uv0.x, uv1.y, d);
			m_pVtx[i*6 + 3] = VtxDUV1( +w, -h, 0, uv1.x, uv1.y, d);

			x = m_pPrt[i].mtW._41;
			y = m_pPrt[i].mtW._42;
			z = m_pPrt[i].mtW._43;

			m_pPrt[i].mtW._41 = 0;
			m_pPrt[i].mtW._42 = 0;
			m_pPrt[i].mtW._43 = 0;

			m_pPrt[i].mtW *= mtB;

			m_pPrt[i].mtW._41 = x;
			m_pPrt[i].mtW._42 = y;
			m_pPrt[i].mtW._43 = z;

			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 0].p), &(m_pVtx[i*6 + 0].p), &m_pPrt[i].mtW);
			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 1].p), &(m_pVtx[i*6 + 1].p), &m_pPrt[i].mtW);
			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 2].p), &(m_pVtx[i*6 + 2].p), &m_pPrt[i].mtW);
			D3DXVec3TransformCoord (&(m_pVtx[i*6 + 3].p), &(m_pVtx[i*6 + 3].p), &m_pPrt[i].mtW);
		}

		m_pVtx[i*6 + 4] = m_pVtx[i*6 + 2];
		m_pVtx[i*6 + 5] = m_pVtx[i*6 + 1];
	}

	return 1;
}





void CEfPtcG::Set(lsEfPtcB& _vS)
{
	INT		i;
	

	SAFE_DEL_LST(	m_vPtc	);

	for(i=0; i<_vS.size(); ++i)
		m_vPtc.push_back(new CEfPtcS);

	for(i=0; i<_vS.size(); ++i)
	{
		EfPtcB* pPtB = _vS[i];
		m_vPtc[i]->PtcSet(pPtB);
		m_vPtc[i]->VtxSet();
	}

	// vertex ����
	SAFE_FREE(	m_pVtx	);
	SAFE_FREE(	m_pPrt	);
	m_iN = 0;

	for(i=0; i<_vS.size(); ++i)
		m_iN += m_vPtc[i]->GetNum();
}


void CEfPtcG::OnStop()
{
	for(int i=0; i<m_vPtc.size(); ++i)
		m_vPtc[i]->Stop();
}


void CEfPtcG::OnPlay()
{
	for(INT i=0; i<m_vPtc.size(); ++i)
		m_vPtc[i]->Reset();
}