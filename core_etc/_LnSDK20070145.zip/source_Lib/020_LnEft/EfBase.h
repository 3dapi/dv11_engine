#ifndef _EFBASE_H_
#define _EFBASE_H_


#pragma warning( disable : 4786)
#include <vector>


// Particle Structure

struct EfPtc
{
	FLOAT	fStlSrtR;															// Distance from Camera z direction

	INT		bAct;																// Active (Yes/No)

	VEC3	vcP;																// Position
	VEC3	vcV;																// Velocity
	VEC3	vcA;																// X acceleration

	VEC3	vcR;																// rotation Euler Angle 
	VEC3	vcRv;																// rotation Euler Angle Velocity

	VEC3	vcG;
	VEC3	vcGx;																// purtubation	X	x: Amplitude y: Angle z: Angle adding
	VEC3	vcGy;																// purtubation	Y	x: Amplitude y: Angle z: Angle adding
	VEC3	vcGz;																// purtubation	Z 	x: Amplitude y: Angle z: Angle adding

	VEC3	vcS;																// scale
	VEC3	vcSv;																// Scale Velocity

	MATA	mtW;																// World matrix

	VEC2	uv0;
	VEC2	uv1;
		
	DCLR	xcC;																// Color
	DCLR	xcV;																// Color Velocity

	FLOAT	fLf;																// Particle fLife
	FLOAT	fFd;																// Fade Speed
	
	FLOAT	fW;																	// Width
	FLOAT	fH;																	// Height
	FLOAT	fFp;																// Flapping Triangle
	FLOAT	fDr;																// Flap Direction (Increase Value)
	
	INT		nBt;																// Billboarding Type
	
	EfPtc();
};


// Particle Boundary
struct EfPtcB
{
	INT		iN;																	// Particle Number
	INT		iNR;																// Recycling	0�� ����(Delay time�� ����), ������(Delay Ÿ�Ӱ� ����)�� ��ȯ �ݼ� Ƚ��
	INT		nBt;																// Billboard type
	DWORD	dSt;																// Start Time

	VEC3	vcP;																// Position

	INT		nCp;																// coordinate Position
	VEC3	vcPx,	vcPy,	vcPz;												// Position X,Y,Z. Random Parameter

	INT		nCv;																// coordinate velocity
	VEC3	vcVx,	vcVy,	vcVz;												// Velocity X,Y,Z. Random Parameter

	INT		nCa;																// coordinate Accelation
	VEC3	vcAx,	vcAy,	vcAz;												// Accelation X,Y,Z. Random Parameter

	VEC3	vcRx,	vcRy,	vcRz;												// Rotation X,Y,Z. Random Parameter
	VEC3	vcRvx,	vcRvy,	vcRvz;												// Rotation Velocity X, Y, Z. Random Parameter

	VEC3	vcSx,	vcSy,	vcSz;												// Scaling X, Y, Z Random Parameter
	VEC3	vcSvx,	vcSvy,	vcSvz;												// Scaling Velocity X, Y, Z Random Parameter

	VEC3	vcGx,	vcGy,	vcGz;												// Position	 X, Y, Z. ���� Pertubation	x: Amplitude y: Angle z: Angle adding
	VEC3	vcCr,	vcCg,	vcCb,	vcCa;										// Color R G B A Random Parameter
	VEC3	vcCvr,	vcCvg,	vcCvb,	vcCva;										// Color velocity R G B A Random Parameter

	VEC3	vcWx,	vcWy;														// 2D Width, Height Random Parameter
	VEC3	vcB0, 	vcB1;														// �׷����� ���� (����) �ּ�, �ִ�

	INT		iNIm;																// Image Num
	lsINT	vIm;																// ImageList


	EfPtcB();
};

typedef std::vector<EfPtcB*>	lsEfPtcB;
typedef lsEfPtcB::iterator		itEfPtcB;



#define EFT_OVER_MAX_REPEAT		0x00000010

#define EFT_STATE_UPDATE_FAIL	-1
#define EFT_STATE_UPDATE_NONE	0
#define EFT_STATE_UPDATE_PLAY	1
#define EFT_STATE_UPDATE_END	2


class IEfBase
{
protected:
	BOOL	m_bFm;																// FrameMove
	BOOL	m_bRn;																// ������ �� ���ΰ�?

	VEC3	m_vcI;																// Initial Position
	VEC3	m_vcC;																// Current Position
	VEC3	m_vcT;																// Target Position
	VEC3	m_vcD;																// Direction Position

	INT		m_nFrmR;															// FrameMove Resoult ����: 0, �÷���: 1 ��:2
	DWORD	m_dRpt;																// Repeat: 0is Once 0xFFFFFFFF => Infinite

public:
	IEfBase();
	virtual ~IEfBase();

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL);
	virtual void	Destroy();

	virtual INT		FrameMove();												//������ ���� ���°� �ƴ϶��: 0, �÷���: 1, ��: 2
	virtual void	Render();

	virtual INT		Restore();
	virtual void	Invalidate();

	virtual INT		LoadEnvFromFile(void* pLoader, char* sFile, char* sApp);	// Load Environment From File
	virtual INT		LoadEnvFromString(void* pLoader, char* sStr);				// Load Environment From String

	virtual	void	SetPosI(const VEC3* vcP);									// Set Initial Position
	virtual	VEC3	GetPosI();													// Get Initial Position

	virtual	void	SetPosC(const VEC3* vcP);									// Set Current Position
	virtual	VEC3	GetPosC();													// Get Current Position

	virtual	void	SetPosT(const VEC3* vcP);									// Set Target Position
	virtual	VEC3	GetPosT();													// Get Target Position

	virtual	void	SetPosD(const VEC3* vcP);									// Set Direction
	virtual	VEC3	GetPosD();													// Get Direction

	void	SetFrmMov(BOOL bFm=TRUE);
	BOOL	IsFrmMov();

	void	SetRender(BOOL bRn=TRUE);
	BOOL	IsRender();

	INT		GetFrmResult();

public:
	virtual int	SetVal(void* pIn, char* sCmd=NULL/*command*/);					// If there is a command and succeed then return 1 else -1
	virtual int	GetVal(void* pOut, char* sCmd=NULL/*command*/) const;			// If there is a command and succeed then return 1 else -1


// For control
public:
	void	Play();
	void	Stop();
	void	Reset();
	void	Pause();
	void	SetRepeat(DWORD dRpt=0xFFFFFFFF);
	DWORD	GetRepeat();

	virtual void	OnPlay();
	virtual void	OnStop();
	virtual void	OnReset();
	virtual void	OnPause();
};


typedef std::vector<IEfBase* >		lsEfBase;



class IEfLnk : public IEfBase													// Effect Linker
{
public:
	struct SEfLnk
	{
		int			m_nType;
		IEfBase*	m_pEft;
		IEfBase*	m_pPrn;

		SEfLnk(int nType=-1, IEfBase* pEft= NULL, IEfBase* pPrn= NULL)
		{
			m_nType	= nType;
			m_pEft	= pEft;
			m_pPrn	= pPrn;
		}
	};

	typedef std::vector<SEfLnk >	lsEfLnkSrc;


protected:
	lsEfLnkSrc		m_vEft;


public:
	IEfLnk();
	virtual ~IEfLnk();

	virtual INT		Create(	void* p1=NULL// IEfBase* array
						,	void* p2=NULL// IEfBase* Action Type. mustbe INT Array.
						,	void* p3=NULL// IEfBase* counter
							);

	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		Restore();
	virtual void	Invalidate();


	virtual	void	SetPosI(const VEC3* vcP);									// Set Initial Position
	virtual	void	SetPosC(const VEC3* vcP);									// Set Current Position
	virtual	void	SetPosT(const VEC3* vcP);									// Set Target Position
	virtual	void	SetPosD(const VEC3* vcP);									// Set Direction

	virtual void	OnReset();
	virtual void	OnPlay();

	virtual INT		SetVal(void* pIn, char* =NULL/*command*/);
	virtual INT		GetVal(void* pOut, char* =NULL/*command*/) const;

	// Set and Get Val Command
	// 1. Command: "push_back Type", "Push" is Add IEfBase* instance and Type is 0 or 1. 0: is Action without order but 1 is Order. Ex) pInst->SetVal( pData, "push_back 1")

};




struct EfMdaEntry
{
	IEfBase*		m_pEftSrc;
	void*			m_pMdData;
	char			m_sMdFile[MAX_PATH];

	EfMdaEntry();
	EfMdaEntry(IEfBase*	pEftSrc, char* sMdFile, void* pMdData);
};

typedef std::vector<EfMdaEntry >	lsEfMdaEnt;














class IEfScnBase : public IEfBase
{
protected:

public:
	IEfScnBase();
	virtual ~IEfScnBase();

//	virtual INT		Create(	void* p1=NULL		// ID3DXSprite or Device
//						,	void* pFunc=NULL	// Function Pointer
//						,	void* p3=NULL);

protected:
	void	(*RenderPtr)();

public:
	void	SetRenderPtr(void* pFunc);
};


#endif


