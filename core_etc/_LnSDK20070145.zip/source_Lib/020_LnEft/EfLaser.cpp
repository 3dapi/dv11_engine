// Implementation of the CEfLaser class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/_Cmm/LnVtxFmt.h>

#include <Ln/Euclid/LnEuclid.h>
#include <ln/Util/LnUtil.h>
#include <ln/Util/LnUtilDx.h>

#include "EfBase.h"

#include "EfLaser.h"
#include "EftLoader.h"


CEfLaser::CEfLaser()
{
	m_pDev		= NULL;
	
	m_pTx		= NULL;
	m_nImgX		= 1;
	m_nImgY		= 1;
	m_iImgN		= 1;
	
	m_nColor	= 1;
	m_nRnd		= 1;

	m_fInc		= 1.f/15.f;
	m_fWdth		= 15.f;

	m_pMdData	= NULL;
}


CEfLaser::~CEfLaser()
{
	Destroy();
}



void CEfLaser::Destroy()
{
	if(m_pMdData)
	{
		IMtMedia*	pMdData = (IMtMedia*)m_pMdData;
		delete pMdData;
		m_pMdData	= NULL;
	}
}



INT CEfLaser::Create(void* p1, void* p2, void* p3)
{
	if(p2)
		memcpy(this, (CEfLaser*)p2, sizeof(CEfLaser) );

	m_pDev = (PDEV)p1;

	Stop();

	RenderLaser[0] = RenderLaser1;
	RenderLaser[1] = RenderLaser2;

	return 1;
}


INT CEfLaser::LoadEnvFromFile(void* pLoader, char* sFile, char* sApp)
{
	char	sTemp[MAX_PATH];

	LnUtil_INIReadString(sFile, sApp, "ClassName", m_sCls, sizeof m_sCls, 0);

	
	m_nColor	= LnUtil_INIReadINT(sFile, sApp, "ColorType");
	m_nRnd		= LnUtil_INIReadINT(sFile, sApp, "RenderType");

	m_fWdth		= LnUtil_INIReadFloat(sFile, sApp, "Width");
	m_fInc		= LnUtil_INIReadFloat(sFile, sApp, "Increase");


	LnUtil_INIReadString(sFile, sApp, "Texture", sTemp, sizeof sTemp, 0);
	m_pTx = ((CEftLoader*)pLoader)->LoadTexture(sTemp);


	LnUtil_INIReadString(sFile, sApp, "Sound", m_pMdFile, sizeof m_pMdFile, 0);

	return 1;
}


INT CEfLaser::LoadEnvFromString(void* pLoader, char* sStr)
{
	sscanf(sStr,
		
		" %d"
		" %d"
		" %f"
		" %f"
		
		, &m_nColor
		, &m_nRnd
		, &m_fWdth
		, &m_fInc
		);

	return 1;
}



INT CEfLaser::FrameMove()
{
	if(FALSE==m_bFm)
	{
		m_nFrmR = EFT_STATE_UPDATE_NONE;
		return m_nFrmR;
	}


	m_vcC = m_vcT;

	m_nFrmR = EFT_STATE_UPDATE_PLAY;


	if(0==m_nSt)
	{
		m_fAt +=m_fInc;
		m_fAh +=m_fInc;

		if(m_fAh>1.f)
			m_fAh = 1.f;

		if(m_fAt>1.f)
		{
			m_fAt = 1.f;

			m_fInc *= -1.f;
			m_nSt =1;
		}
	}

	else if(1== m_nSt)
	{
		m_fAt +=m_fInc;

		if(m_fAt<0.f)
		{
			m_nSt	= 2;
			m_fAt	= 0.f;
			m_nFrmR = EFT_STATE_UPDATE_END;
		}
	}


	else if(2== m_nSt)
	{
		m_fAh +=m_fInc;

		if(m_fAh<0.f)
		{
			m_nSt	= -1;
			m_fAh	= 0.f;
		}
	}

	if(-1 ==m_nSt)
	{
		Stop();

		m_nFrmR = EFT_STATE_UPDATE_NONE;

		return m_nFrmR;
	}
	


	MATA mtView;
	MATA mtViewI;
	
	m_pDev->GetTransform(D3DTS_VIEW, &mtView);
	D3DXMatrixInverse(&mtViewI, NULL, &mtView);

	VEC3 fX = VEC3(mtView._11, mtView._21, mtView._31);
	VEC3 fY = VEC3(mtView._12, mtView._22, mtView._32);
	VEC3 fZ = VEC3(mtView._13, mtView._23, mtView._33);

	VEC3 vcPcam= VEC3(mtViewI._41, mtViewI._42, mtViewI._43);

	VEC3	vcN;
	VEC3	vcA1 = vcPcam - m_vcI;

	D3DXVec3Cross(&vcN, &vcA1, &m_vcD);
	D3DXVec3Normalize(&vcN, &vcN);

	int i, j;

	for(i=0; i<=4; ++i)
	{
		m_pVtx[0][ i*2 + 0].p = m_vcT + vcN * (i-2) * m_fWdth;
		m_pVtx[0][ i*2 + 1].p = m_vcI + vcN * (i-2) * m_fWdth;
	}

	memcpy(m_pVtx[1], m_pVtx[0], sizeof m_pVtx[1]);
	memcpy(m_pVtx[2], m_pVtx[0], sizeof m_pVtx[2]);
	memcpy(m_pVtx[3], m_pVtx[0], sizeof m_pVtx[3]);
	memcpy(m_pVtx[4], m_pVtx[0], sizeof m_pVtx[4]);
	memcpy(m_pVtx[5], m_pVtx[0], sizeof m_pVtx[5]);


	for(j=0; j<6; ++j)
	{
		for(i=0; i<10; i+=2)
		{
			D3DXCOLOR xclr = m_pRGB[j][ i] * m_fAh;
			m_pVtx[j][ i].d = xclr;
		}

		for(i=1; i<10; i+=2)
		{
			D3DXCOLOR xclr = m_pRGB[j][ i] * m_fAt;
			m_pVtx[j][ i].d = xclr;
		}
	}

	
	return m_nFrmR;
}


void CEfLaser::Render()
{
	if(!m_bRn)
		return;

	LnD3D_SetWorldIdentity(m_pDev);
	
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	m_pDev->SetRenderState(D3DRS_ZENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	
	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->SetTexture(0, m_pTx);


	(this->*RenderLaser[m_nRnd])();

	
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
}



void CEfLaser::RenderLaser1()
{
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_ONE);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	
	for(int i=0; i<2; ++i)
		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 8, m_pVtx[m_nColor], sizeof(VtxDUV1) );
}


void CEfLaser::RenderLaser2()
{
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 8, m_pVtx[2+m_nColor], sizeof(VtxDUV1) );
		
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_ONE);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);

	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 8, m_pVtx[4+m_nColor], sizeof(VtxDUV1) );
}




void CEfLaser::OnReset()
{
	int i=0;

	m_fAt	= 0;
	m_fAh	= 0;
	m_nSt	= 0;

	m_fInc	= fabsf(m_fInc);

	m_vcD	= m_vcT - m_vcI;

	D3DXVec3Normalize(&m_vcD, &m_vcD);

	memset(m_pVtx, 0, sizeof m_pVtx);
	
	m_pVtx[0][0] = VtxDUV1( 0, -2, 0, 1, 1.0F, 0x0);
	m_pVtx[0][1] = VtxDUV1( 0, -2, 0, 0, 1.0F, 0x0);
	m_pVtx[0][2] = VtxDUV1( 0, -1, 0, 1, .75F, 0x0);
	m_pVtx[0][3] = VtxDUV1( 0, -1, 0, 0, .75F, 0x0);

	m_pVtx[0][4] = VtxDUV1( 0,  0, 0, 1, .50F, 0x0);
	m_pVtx[0][5] = VtxDUV1( 0,  0, 0, 0, .50F, 0x0);
	
	m_pVtx[0][6] = VtxDUV1( 0,  1, 0, 1, .25F, 0x0);
	m_pVtx[0][7] = VtxDUV1( 0,  1, 0, 0, .25F, 0x0);
	m_pVtx[0][8] = VtxDUV1( 0,  2, 0, 1, .00F, 0x0);
	m_pVtx[0][9] = VtxDUV1( 0,  2, 0, 0, .00F, 0x0);


	memcpy(m_pVtx[1], m_pVtx[0], sizeof m_pVtx[1]);
	memcpy(m_pVtx[2], m_pVtx[0], sizeof m_pVtx[2]);
	memcpy(m_pVtx[3], m_pVtx[0], sizeof m_pVtx[3]);
	memcpy(m_pVtx[4], m_pVtx[0], sizeof m_pVtx[4]);
	memcpy(m_pVtx[5], m_pVtx[0], sizeof m_pVtx[5]);


	
	// for Blue
	m_pRGB[0][ 0] = D3DXCOLOR( .0F, .0F, .0F, .0F);
	m_pRGB[0][ 1] = D3DXCOLOR( .0F, .0F, .0F, .0F);
	m_pRGB[0][ 2] = D3DXCOLOR( .0F, .0F, .3F, .3F);
	m_pRGB[0][ 3] = D3DXCOLOR( .0F, .0F, .3F, .3F);

	m_pRGB[0][ 4] = D3DXCOLOR( .0F, .4F, .8F, .8F);
	m_pRGB[0][ 5] = D3DXCOLOR( .0F, .4F, .8F, .8F);
	
	m_pRGB[0][ 6] = D3DXCOLOR( .0F, .0F, .3F, .3F);
	m_pRGB[0][ 7] = D3DXCOLOR( .0F, .0F, .3F, .3F);
	m_pRGB[0][ 8] = D3DXCOLOR( .0F, .0F, .0F, .0F);
	m_pRGB[0][ 9] = D3DXCOLOR( .0F, .0F, .0F, .0F);

	
	m_pRGB[2][ 0] = D3DXCOLOR( .0F, .0F, .8F, .8F);
	m_pRGB[2][ 1] = D3DXCOLOR( .0F, .0F, .8F, .8F);
	m_pRGB[2][ 2] = D3DXCOLOR( .0F, .0F, .8F, .8F);
	m_pRGB[2][ 3] = D3DXCOLOR( .0F, .0F, .8F, .8F);

	m_pRGB[2][ 4] = D3DXCOLOR( .0F, .0F, .8F, .8F);
	m_pRGB[2][ 5] = D3DXCOLOR( .0F, .0F, .8F, .8F);
	
	m_pRGB[2][ 6] = D3DXCOLOR( .0F, .0F, .8F, .8F);
	m_pRGB[2][ 7] = D3DXCOLOR( .0F, .0F, .8F, .8F);
	m_pRGB[2][ 8] = D3DXCOLOR( .0F, .0F, .8F, .8F);
	m_pRGB[2][ 9] = D3DXCOLOR( .0F, .0F, .8F, .8F);

	
	m_pRGB[4][ 0] = D3DXCOLOR( .0F, .0F, .0F, .4F);
	m_pRGB[4][ 1] = D3DXCOLOR( .0F, .0F, .0F, .4F);
	m_pRGB[4][ 2] = D3DXCOLOR( .0F, .0F, .0F, .4F);
	m_pRGB[4][ 3] = D3DXCOLOR( .0F, .0F, .0F, .4F);

	m_pRGB[4][ 4] = D3DXCOLOR( .0F, .3F, .9F, .4F);
	m_pRGB[4][ 5] = D3DXCOLOR( .0F, .3F, .9F, .4F);
	
	m_pRGB[4][ 6] = D3DXCOLOR( .0F, .0F, .0F, .4F);
	m_pRGB[4][ 7] = D3DXCOLOR( .0F, .0F, .0F, .4F);
	m_pRGB[4][ 8] = D3DXCOLOR( .0F, .0F, .0F, .4F);
	m_pRGB[4][ 9] = D3DXCOLOR( .0F, .0F, .0F, .4F);

	
	// for Red
	m_pRGB[1][ 0] = D3DXCOLOR( .0F, .0F, .0F, .0F);
	m_pRGB[1][ 1] = D3DXCOLOR( .0F, .0F, .0F, .0F);
	m_pRGB[1][ 2] = D3DXCOLOR( .3F, .0F, .0F, .3F);
	m_pRGB[1][ 3] = D3DXCOLOR( .3F, .0F, .0F, .3F);

	m_pRGB[1][ 4] = D3DXCOLOR( .8F, .0F, .4F, .8F);
	m_pRGB[1][ 5] = D3DXCOLOR( .8F, .0F, .4F, .8F);
	
	m_pRGB[1][ 6] = D3DXCOLOR( .3F, .0F, .0F, .3F);
	m_pRGB[1][ 7] = D3DXCOLOR( .3F, .0F, .0F, .3F);
	m_pRGB[1][ 8] = D3DXCOLOR( .0F, .0F, .0F, .0F);
	m_pRGB[1][ 9] = D3DXCOLOR( .0F, .0F, .0F, .0F);

	
	m_pRGB[3][ 0] = D3DXCOLOR( .8F, .0F, .0F, .0F);
	m_pRGB[3][ 1] = D3DXCOLOR( .8F, .0F, .0F, .0F);
	m_pRGB[3][ 2] = D3DXCOLOR( .8F, .0F, .0F, .8F);
	m_pRGB[3][ 3] = D3DXCOLOR( .8F, .0F, .0F, .8F);

	m_pRGB[3][ 4] = D3DXCOLOR( .8F, .0F, .0F, .8F);
	m_pRGB[3][ 5] = D3DXCOLOR( .8F, .0F, .0F, .8F);
	
	m_pRGB[3][ 6] = D3DXCOLOR( .8F, .0F, .0F, .8F);
	m_pRGB[3][ 7] = D3DXCOLOR( .8F, .0F, .0F, .8F);
	m_pRGB[3][ 8] = D3DXCOLOR( .8F, .0F, .0F, .0F);
	m_pRGB[3][ 9] = D3DXCOLOR( .8F, .0F, .0F, .0F);

	
	m_pRGB[5][ 0] = D3DXCOLOR( .0F, .0F, .0F, .4F);
	m_pRGB[5][ 1] = D3DXCOLOR( .0F, .0F, .0F, .4F);
	m_pRGB[5][ 2] = D3DXCOLOR( .0F, .0F, .0F, .4F);
	m_pRGB[5][ 3] = D3DXCOLOR( .0F, .0F, .0F, .4F);

	m_pRGB[5][ 4] = D3DXCOLOR( .9F, .0F, .3F, .4F);
	m_pRGB[5][ 5] = D3DXCOLOR( .9F, .0F, .3F, .4F);
	
	m_pRGB[5][ 6] = D3DXCOLOR( .0F, .0F, .0F, .4F);
	m_pRGB[5][ 7] = D3DXCOLOR( .0F, .0F, .0F, .4F);
	m_pRGB[5][ 8] = D3DXCOLOR( .0F, .0F, .0F, .4F);
	m_pRGB[5][ 9] = D3DXCOLOR( .0F, .0F, .0F, .4F);


	
	if(m_pMdData)
	{
		IMtMedia*	pMedia = (IMtMedia*)m_pMdData;
		pMedia->Reset();
		pMedia->Play();
	}
}


void CEfLaser::OnPlay()
{
	if(m_pMdData)
	{
		IMtMedia*	pMdData = (IMtMedia*)m_pMdData;
		pMdData->Play();
	}
}




int CEfLaser::SetVal(void* pIn, char* sCmd)
{
	if(0==stricmp(sCmd, "AddSound"))
	{
		m_pMdData = pIn;
		return 1;
	}

	return -1;
}

int CEfLaser::GetVal(void* pOut, char* sCmd) const
{
	if(0==stricmp(sCmd, "Media"))
	{
		lsEfMdaEnt* pvEnt = (lsEfMdaEnt*)pOut;

		EfMdaEntry	ent( (IEfBase*)this, (char*)m_pMdFile, m_pMdData);
		(*pvEnt).push_back(ent);

		return 1;
	}

	return -1;
}

