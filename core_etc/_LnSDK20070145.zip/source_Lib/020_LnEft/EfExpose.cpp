// Implementation of the CEfExpose class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/_Cmm/LnVtxFmt.h>

#include <Ln/Euclid/LnEuclid.h>
#include <ln/Util/LnUtil.h>
#include <ln/Util/LnUtilDx.h>
#include <ln/Util/LnUtilFile.h>

#include "EfBase.h"

#include "EfExpose.h"
#include "EftLoader.h"


CEfExpose::CEfExpose()
{
	m_pDev		= NULL;
	
	m_pTx		= NULL;
	m_nImgX		= 1;
	m_nImgY		= 1;
	m_iImgN		= 1;
	
	m_iN		= 0;
	m_iC		= 0;
	m_pPtc		= NULL;
	m_pVtx		= NULL;

	m_xWght		= D3DXCOLOR(1,1,1,1);

	m_pMdData	= NULL;
}

CEfExpose::~CEfExpose()
{
	Destroy();
}


void CEfExpose::Destroy()
{
	SAFE_FREE(	m_pPtc	);
	SAFE_FREE(	m_pVtx	);

	if(m_pMdData)
	{
		IMtMedia*	pMdData = (IMtMedia*)m_pMdData;
		delete pMdData;
		m_pMdData	= NULL;
	}
}



INT CEfExpose::Create(void* p1, void* p2, void* p3)
{
	if(p2)
		memcpy(this, (CEfExpose*)p2, sizeof(CEfExpose) );

	m_pDev = (PDEV)p1;

	int	nCreateOpt =(int)p3;

	if(1 == nCreateOpt && m_iN>0)
	{
		m_pPtc =(EfPtc*) malloc(m_iN*1 * sizeof(EfPtc  ));
		m_pVtx=(VtxDUV1*)malloc(m_iN*6 * sizeof(VtxDUV1));

		memset(m_pPtc, 0, m_iN*1 * sizeof(EfPtc  ));
		memset(m_pVtx, 0, m_iN*6 * sizeof(VtxDUV1));
	}

	Stop();

	return 1;
}


INT CEfExpose::LoadEnvFromFile(void* pLoader, char* sFile, char* sApp)
{
	char	sTemp[MAX_PATH];

	LnUtil_INIReadString(sFile, sApp, "ClassName", m_sCls, sizeof m_sCls, 0);

	m_iN	= LnUtil_INIReadINT(sFile, sApp, "PartileNum");

	m_nImgX	= LnUtil_INIReadINT(sFile, sApp, "ImageX");
	m_nImgY	= LnUtil_INIReadINT(sFile, sApp, "ImageY");
	m_iImgN	= LnUtil_INIReadINT(sFile, sApp, "ImageNum");


	LnUtil_INIReadSscanf(sFile, sApp, "ColorWeight",	"%f %f %f", &m_xWght.r, &m_xWght.g, &m_xWght.b);
//	LnUtil_INIReadSscanf(sFile, sApp, "Position",		"%f %f %f", &m_vcI.x, &m_vcI.y, &m_vcI.z);

	LnUtil_INIReadString(sFile, sApp, "Texture", sTemp, sizeof sTemp, 0);
	m_pTx = ((CEftLoader*)pLoader)->LoadTexture(sTemp);


	LnUtil_INIReadString(sFile, sApp, "Sound", m_pMdFile, sizeof m_pMdFile, 0);

	return 1;
}


INT CEfExpose::LoadEnvFromString(void* pLoader, char* sStr)
{
	sscanf(sStr,
		
		" %d"
		" %f %f %f"

		, &m_iN
		, &m_xWght.r, &m_xWght.g, &m_xWght.b
		);

	return 1;
}



INT CEfExpose::FrameMove()
{
	if(FALSE==m_bFm)
	{
		m_nFrmR = EFT_STATE_UPDATE_NONE;
		return m_nFrmR;
	}


	INT i=0;

	m_vcC = m_vcI;

	for (i=0;i<m_iN;++i)					// Loop Through All The Particles
	{
		m_pPtc[i].vcR.x+=m_pPtc[i].vcRv.x;

		m_pPtc[i].vcV += m_pPtc[i].vcA;
		m_pPtc[i].vcP += m_pPtc[i].vcV;
		
		m_pPtc[i].xcC.a += m_pPtc[i].xcV.a;

		if(m_pPtc[i].xcC.a>1.f)	m_pPtc[i].xcC.a= 1.f;
		if(m_pPtc[i].xcC.a<0.f)	m_pPtc[i].xcC.a= 0.f;

		m_pPtc[i].xcC.r = m_pPtc[i].xcC.a * m_xWght.r;
		m_pPtc[i].xcC.g = m_pPtc[i].xcC.a * m_xWght.g;
		m_pPtc[i].xcC.b = m_pPtc[i].xcC.a * m_xWght.b;

		m_pPtc[i].fLf += m_pPtc[i].fFd;

		
		
		if(m_pPtc[i].xcC.a>=1.f)
			m_pPtc[i].xcV.a *= -1.f;


		if(m_pPtc[i].fLf <0.f ||m_pPtc[i].xcC.a<0.001f)
		{
			m_pPtc[i].bAct = FALSE;
		}
	}


	MATA mR;
	MATA mtView;
	
	m_pDev->GetTransform(D3DTS_VIEW, &mtView);

	VEC3 fX = VEC3(mtView._11, mtView._21, mtView._31);
	VEC3 fY = VEC3(mtView._12, mtView._22, mtView._32);
	VEC3 fZ = VEC3(mtView._13, mtView._23, mtView._33);


	VEC2	uv0;
	VEC2	uv1;
	DWORD	d;
	FLOAT	w;
	FLOAT	h;
	
	m_iC = 0;

	for (i=0;i<m_iN; ++i)					// Loop Through All The Particles
	{
		if(FALSE == m_pPtc[i].bAct)
			continue;

		VEC3 p0 = -(fX-fY);
		VEC3 p1 = +(fX+fY);
		VEC3 p2 = -(fX+fY);
		VEC3 p3 = +(fX-fY);

		uv0	= m_pPtc[i].uv0;
		uv1	= m_pPtc[i].uv1;
		d	= m_pPtc[i].xcC;
		w	= m_pPtc[i].fW;
		h	= m_pPtc[i].fH;

		D3DXMatrixRotationAxis(&mR, &fZ, m_pPtc[i].vcR.x);
		D3DXVec3TransformCoord(&p0, &p0, &mR);
		D3DXVec3TransformCoord(&p1, &p1, &mR);
		D3DXVec3TransformCoord(&p2, &p2, &mR);
		D3DXVec3TransformCoord(&p3, &p3, &mR);

		m_pVtx[m_iC*6 + 0].p = m_pPtc[i].vcP + VEC3(p0.x * w, p0.y * h, p0.z * w);
		m_pVtx[m_iC*6 + 1].p = m_pPtc[i].vcP + VEC3(p1.x * w, p1.y * h, p1.z * w);
		m_pVtx[m_iC*6 + 2].p = m_pPtc[i].vcP + VEC3(p2.x * w, p2.y * h, p2.z * w);
		m_pVtx[m_iC*6 + 3].p = m_pPtc[i].vcP + VEC3(p3.x * w, p3.y * h, p3.z * w);

		m_pVtx[m_iC*6 + 0].u =  uv0.x;
		m_pVtx[m_iC*6 + 1].u =  uv1.x;
		m_pVtx[m_iC*6 + 2].u =  uv0.x;
		m_pVtx[m_iC*6 + 3].u =  uv1.x;

		m_pVtx[m_iC*6 + 0].v =  uv0.y;
		m_pVtx[m_iC*6 + 1].v =  uv0.y;
		m_pVtx[m_iC*6 + 2].v =  uv1.y;
		m_pVtx[m_iC*6 + 3].v =  uv1.y;

		m_pVtx[m_iC*6 + 0].d = d;
		m_pVtx[m_iC*6 + 1].d = d;
		m_pVtx[m_iC*6 + 2].d = d;
		m_pVtx[m_iC*6 + 3].d = d;
		
		m_pVtx[m_iC*6 + 4] = m_pVtx[m_iC*6 + 2];
		m_pVtx[m_iC*6 + 5] = m_pVtx[m_iC*6 + 1];

		++m_iC;
	}


	if(m_iC<1)
	{
		m_bRn = FALSE;
		m_bFm = FALSE;
		m_nFrmR = EFT_STATE_UPDATE_END;
	
		return m_nFrmR;
	}

	m_nFrmR = EFT_STATE_UPDATE_PLAY;
	
	return m_nFrmR;
}


void CEfExpose::Render()
{
	if(!m_bRn || m_iC<1)
		return;

	LnD3D_SetWorldIdentity(m_pDev);

	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE);
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

	
	
	
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);
	
	m_pDev->SetTexture(0, m_pTx);
	m_pDev->SetTexture(1, 0);

	m_pDev->SetFVF(VtxDUV1::FVF);
	
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, m_iC*2, m_pVtx, sizeof(VtxDUV1));
	
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
}



void CEfExpose::Set(INT i)
{
	FLOAT	fR	= 100 + rand()%100;

	fR	*=.05f;

	FLOAT fT = DEGtoRAD(rand()%360 * 0.5f);
	FLOAT fP = DEGtoRAD(rand()%720 * 0.5f);

	m_pPtc[i].vcV = VEC3(0,0,0);

	m_pPtc[i].vcV.x	= fR * sinf(fT) * sinf(fP);
	m_pPtc[i].vcV.y	= fR * cosf(fT);
	m_pPtc[i].vcV.z	= fR * sinf(fT) * cosf(fP);

	m_pPtc[i].vcA	= -m_pPtc[i].vcV * 0.01f;

	m_pPtc[i].vcP =m_vcI;

	FLOAT	fDir = rand()%2 -0.5f;
	m_pPtc[i].vcR.x		=fT;
	m_pPtc[i].vcRv.x	= fP * fDir*0.1f;


	m_pPtc[i].xcC.a	=  (50+rand()%51) * 0.02f;
	m_pPtc[i].xcV.a = -(50+rand()%51) * 0.0005f;


	m_pPtc[i].fLf = (50+rand()%151) * 0.01f;									// Particle fLife
	m_pPtc[i].fFd = -fR * 0.0001f;

	m_pPtc[i].fW = (10+rand()%21) * .5f;
	m_pPtc[i].fH=  m_pPtc[i].fW;
	m_pPtc[i].bAct=TRUE;


	INT nIdx = rand()%m_iImgN;

	INT	x = nIdx%m_nImgX;
	INT	y = nIdx/m_nImgX;


	m_pPtc[i].uv0.x = (x+0)/FLOAT(m_nImgX);
	m_pPtc[i].uv0.y = (y+0)/FLOAT(m_nImgY);
	m_pPtc[i].uv1.x = (x+1)/FLOAT(m_nImgX);
	m_pPtc[i].uv1.y = (y+1)/FLOAT(m_nImgY);
}




void CEfExpose::OnReset()
{
	if(NULL == m_pPtc && m_iN>0)
	{
		m_pPtc =(EfPtc*) malloc(m_iN*1 * sizeof(EfPtc  ));
		m_pVtx=(VtxDUV1*)malloc(m_iN*6 * sizeof(VtxDUV1));

		memset(m_pPtc, 0, m_iN*1 * sizeof(EfPtc  ));
		memset(m_pVtx, 0, m_iN*6 * sizeof(VtxDUV1));
	}

	for(INT i=0; i<m_iN; ++i)
		Set(i);

	
	if(m_pMdData)
	{
		IMtMedia*	pMedia = (IMtMedia*)m_pMdData;
		pMedia->Reset();
		pMedia->Play();
	}
}


void CEfExpose::OnPlay()
{
	if(m_pMdData)
	{
		IMtMedia*	pMdData = (IMtMedia*)m_pMdData;
		pMdData->Play();
	}
}




int CEfExpose::SetVal(void* pIn, char* sCmd)
{
	if(0==stricmp(sCmd, "AddSound"))
	{
		m_pMdData = pIn;
		return 1;
	}

	return -1;
}

int CEfExpose::GetVal(void* pOut, char* sCmd) const
{
	if(0==stricmp(sCmd, "Media"))
	{
		lsEfMdaEnt* pvEnt = (lsEfMdaEnt*)pOut;

		EfMdaEntry	ent( (IEfBase*)this, (char*)m_pMdFile, m_pMdData);
		(*pvEnt).push_back(ent);

		return 1;
	}

	return -1;
}


