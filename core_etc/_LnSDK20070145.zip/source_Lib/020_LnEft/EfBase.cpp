// Implementation of the IEfBase class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <Ln/_Cmm/LnType.h>

#include "EfBase.h"



EfPtc::EfPtc()
{
	vcP.x=0.f;	vcP.y=0.f;	vcP.z=0.f;
	vcV.x=0.f;	vcV.y=0.f;	vcV.z=0.f;
	vcA.x=0.f;	vcA.y=0.f;	vcA.z=0.f;
	xcC.r=1.f;	xcC.g=1.f;	xcC.b=1.f;	xcC.a=1.f;
	fLf=1.f;	fFd=0.f;	fW=0.5f;	fH=0.1f;

	bAct= TRUE;
	nBt	= 2;
}





EfPtcB::EfPtcB()
:	iN	(0)
,	iNR	(0)
,	nBt	(0)
,	dSt	(0)

,	nCp	(0)
,	nCv	(0)
,	nCa	(0)
,	iNIm(0)
,	vIm	(0)

{
	vcP		= VEC3(0, 0, 0);	vcPx	= VEC3(0, 0, 0);	vcPy	= VEC3(0, 0, 0);	vcPz	= VEC3(0, 0, 0);
	vcVx	= VEC3(0, 0, 0);	vcVy	= VEC3(0, 0, 0);	vcVz	= VEC3(0, 0, 0);
	vcAx	= VEC3(0, 0, 0);	vcAy	= VEC3(0, 0, 0);	vcAz	= VEC3(0, 0, 0);
	vcRx	= VEC3(0, 0, 0);	vcRy	= VEC3(0, 0, 0);	vcRz	= VEC3(0, 0, 0);
	vcRvx	= VEC3(0, 0, 0);	vcRvy	= VEC3(0, 0, 0);	vcRvz	= VEC3(0, 0, 0);
	vcSx	= VEC3(0, 0, 0);	vcSy	= VEC3(0, 0, 0);	vcSz	= VEC3(0, 0, 0);
	vcSvx	= VEC3(0, 0, 0);	vcSvy	= VEC3(0, 0, 0);	vcSvz	= VEC3(0, 0, 0);
	vcGx	= VEC3(0, 0, 0);	vcGy	= VEC3(0, 0, 0);	vcGz	= VEC3(0, 0, 0);
	vcCr	= VEC3(0, 0, 0);	vcCg	= VEC3(0, 0, 0);	vcCb	= VEC3(0, 0, 0);	vcCa	= VEC3(0, 0, 0);
	vcCvr	= VEC3(0, 0, 0);	vcCvg	= VEC3(0, 0, 0);	vcCvb	= VEC3(0, 0, 0);	vcCva	= VEC3(0, 0, 0);
	vcWx	= VEC3(0, 0, 0);	vcWy	= VEC3(0, 0, 0);
	vcB0	= VEC3(0, 0, 0);	vcB1	= VEC3(0, 0, 0);
}










IEfBase::IEfBase()
{
	m_bFm	= FALSE;
	m_bRn	= FALSE;
	m_dRpt	= 0;

	m_vcI.x	=0;
	m_vcI.y	=0;
	m_vcI.z	=0;

	m_vcC.x	=0;
	m_vcC.y	=0;
	m_vcC.z	=0;

	m_vcT.x	=0;
	m_vcT.y	=0;
	m_vcT.z	=0;

	m_vcD.x	=0;
	m_vcD.y	=0;
	m_vcD.z	=0;

	m_nFrmR	= -1;
}

IEfBase::~IEfBase()
{

}

INT IEfBase::Create(void* p1, void* p2, void* p3)
{
	return 1;
}

void IEfBase::Destroy()
{
}

INT IEfBase::FrameMove()
{
	return EFT_STATE_UPDATE_NONE;
}

void IEfBase::Render()
{
}

INT IEfBase::Restore()
{
	return 1;
}

void IEfBase::Invalidate()
{
}


INT IEfBase::LoadEnvFromFile(void* pLoader, char* sFile, char* sApp)
{
	return 1;
}


INT IEfBase::LoadEnvFromString(void* pLoader, char* sStr)
{
	return 1;
}


void IEfBase::SetPosI(const VEC3* vcP)
{
	m_vcI	=  *vcP;
}

VEC3 IEfBase::GetPosI()
{
	return m_vcI;
}

void IEfBase::SetPosC(const VEC3* vcP)
{
	m_vcC = * vcP;
}

VEC3 IEfBase::GetPosC()
{
	return m_vcC;
}

void IEfBase::SetPosT(const VEC3* vcP)
{
	m_vcT = * vcP;
}

VEC3 IEfBase::GetPosT()
{
	return m_vcC;
}


void IEfBase::SetPosD(const VEC3* vcP)
{
	m_vcD = * vcP;
}

VEC3 IEfBase::GetPosD()
{
	return m_vcD;
}



void IEfBase::SetFrmMov(BOOL _bFm)
{
	m_bFm	= _bFm;

	if(!m_bFm)
		m_nFrmR	= 0;
}

BOOL IEfBase::IsFrmMov()
{
	return m_bFm;
}

void IEfBase::SetRender(BOOL _bRn)
{
	m_bRn	= _bRn;
}

BOOL IEfBase::IsRender()
{
	return m_bRn;
}


INT IEfBase::GetFrmResult()
{
	return m_nFrmR;
}




int IEfBase::SetVal(void* pIn, char* sCmd/*command*/)
{
	return 1;
}

int IEfBase::GetVal(void* pOut, char* sCmd/*command*/) const
{
	return 1;
}





// For control
void IEfBase::Play()
{
	m_bFm	= TRUE;
	m_bRn	= TRUE;

	OnPlay();
}

void IEfBase::Stop()
{
	m_bFm	= FALSE;
	m_bRn	= FALSE;
	m_nFrmR	= 0;

	OnStop();
}

void IEfBase::Reset()
{
	m_bFm	= TRUE;
	m_bRn	= TRUE;
	
	OnReset();
}

void IEfBase::Pause()
{
	m_bFm	= FALSE;
	m_bRn	= TRUE;

	OnPause();
}

void IEfBase::SetRepeat(DWORD dRpt)
{
	m_dRpt	= dRpt;
}

DWORD IEfBase::GetRepeat()
{
	return m_dRpt;
}



void IEfBase::OnPlay()
{
}

void IEfBase::OnStop()
{
}

void IEfBase::OnReset()
{
}

void IEfBase::OnPause()
{
}




// Implementation of the IEfBase class.
//
////////////////////////////////////////////////////////////////////////////////

IEfLnk::IEfLnk()
{
}

IEfLnk::~IEfLnk()
{
	Destroy();
}

INT IEfLnk::Create(void* p1, void* p2, void* p3)
{
	INT		iSizeSub= *((INT*)p3);
	INT*	pType	= (INT*)p2;
	IEfBase** ppEf	= (IEfBase**)p1;
	

	for(int i=0; i<iSizeSub; ++i)
	{
		IEfBase*	pPrn = NULL;
		IEfBase*	pEft = ppEf[i];
		INT			nType= pType[i];

		if(nType>0)
			pPrn = ppEf[nType-1];

		IEfLnk::SEfLnk	lnk(nType, pEft, pPrn);

		m_vEft.push_back(lnk);
	}

	return 1;
}

void IEfLnk::Destroy()
{
	if(!m_vEft.empty())
	{
		int iSize = m_vEft.size();

		for(int i=0; i<iSize; ++i)
		{
			delete m_vEft[i].m_pEft;
		}

		m_vEft.clear();
	}
}

INT IEfLnk::FrameMove()
{
	if(!m_bFm)
	{
		m_nFrmR = EFT_STATE_UPDATE_NONE;

		return m_nFrmR;
	}


	int i=0;
	int iSize = m_vEft.size();

	// �θ� ���� ���� ���� ���� �Ѵ�.
	for(i=0; i<iSize; ++i)
	{
		if(0==m_vEft[i].m_pPrn)
		{
			m_vEft[i].m_pEft->FrameMove();
		}
	}

	// ���� ��ü���� ������ ����.
	for(i=0; i<iSize; ++i)
	{
		if(m_vEft[i].m_pPrn)
		{
			INT nPrnFrmR = m_vEft[i].m_pPrn->GetFrmResult();

			if(EFT_STATE_UPDATE_END == nPrnFrmR)
			{
				VEC3 vcPosCrn = m_vEft[i].m_pPrn->GetPosC();
				m_vEft[i].m_pEft->SetPosI( &vcPosCrn);
				m_vEft[i].m_pEft->Reset();
			}
		}
	}


	// ���� ��ü���� ����
	for(i=0; i<iSize; ++i)
	{
		if(m_vEft[i].m_pPrn)
		{
			m_vEft[i].m_pEft->FrameMove();
		}
	}


	m_nFrmR = EFT_STATE_UPDATE_END;

	// �ϳ��� �����ϰ� ������..
	for(i=0; i<iSize; ++i)
	{
		if(EFT_STATE_UPDATE_PLAY == m_vEft[i].m_pEft->GetFrmResult())
		{
			m_nFrmR = EFT_STATE_UPDATE_PLAY;
			break;
		}
	}

	if(EFT_STATE_UPDATE_END == m_nFrmR)
	{
//		m_bFm = FALSE;
//		m_bRn = FALSE;
		Stop();
	}

	return m_nFrmR;
}

void IEfLnk::Render()
{
	if(!m_bRn)
		return;

	// �θ� ���� �׸���..
	int i=0;
	int iSize = m_vEft.size();
	
	for(i=0; i<iSize; ++i)
	{
		if(0==m_vEft[i].m_pPrn)
		{
			m_vEft[i].m_pEft->Render();
		}
	}

	// ���� ��ü���� �׸���.
	for(i=0; i<iSize; ++i)
	{
		if(m_vEft[i].m_pPrn)
		{
			m_vEft[i].m_pEft->Render();
		}
	}
}


INT IEfLnk::Restore()
{
	if(m_vEft.empty())
		return 1;

	int iSize = m_vEft.size();

	for(int i=0; i<iSize; ++i)
	{
		if(FAILED(m_vEft[i].m_pEft->Restore()))
			return -1;
	}

	return 1;
}

void IEfLnk::Invalidate()
{
	if(m_vEft.empty())
		return;

	
	int iSize = m_vEft.size();

	for(int i=0; i<iSize; ++i)
	{
		m_vEft[i].m_pEft->Invalidate();
	}
}


INT IEfLnk::SetVal(void* pIn, char* sCmd)
{
	if(0==stricmp(sCmd, "push_back"))
	{
		int nType=-1;

		sscanf(sCmd, "%*s, %d", &nType);

		IEfLnk::SEfLnk	lnk = *((IEfLnk::SEfLnk*)pIn);

		m_vEft .push_back(lnk);

		return 1;
	}

	
	return -1;
}


INT IEfLnk::GetVal(void* pOut, char* sCmd) const
{
	if(0==stricmp(sCmd, "Media"))
	{
		lsEfMdaEnt* pvEnt = (lsEfMdaEnt*)pOut;
		
		int iSize = m_vEft.size();
	
		for(int i=0; i<iSize; ++i)
		{
			lsEfMdaEnt tEnt;
			m_vEft[i].m_pEft->GetVal(&tEnt, sCmd);

			int iSizeT = tEnt.size();

			for(int j=0; j<iSizeT; ++j)
			{
				EfMdaEntry	ent( tEnt[j].m_pEftSrc, tEnt[j].m_sMdFile, tEnt[j].m_pMdData);
				(*pvEnt).push_back(ent);
			}
		}

		if( (*pvEnt).empty())
			return -1;

		return 1;
	}

	return -1;
}








void IEfLnk::OnReset()
{
	// �θ� ���� �͸� ����
	int i=0;
	int iSize = m_vEft.size();

	for(i=0; i<iSize; ++i)
	{
		if(0==m_vEft[i].m_pPrn)
		{
			m_vEft[i].m_pEft->Reset();
		}
	}
}


void IEfLnk::OnPlay()
{
	// �θ� ���� �͸� Play
	int i=0;
	int iSize = m_vEft.size();

	for(i=0; i<iSize; ++i)
	{
		if(0==m_vEft[i].m_pPrn)
		{
			m_vEft[i].m_pEft->Play();
		}
	}
}


void IEfLnk::SetPosI(const VEC3* vcP)
{
	// �θ� ���� �͸� ����
	int i=0;
	int iSize = m_vEft.size();

	for(i=0; i<iSize; ++i)
	{
		if(0==m_vEft[i].m_pPrn)
		{
			m_vEft[i].m_pEft->SetPosI(vcP);
		}
	}
}


void IEfLnk::SetPosC(const VEC3* vcP)
{
	// �θ� ���� �͸� ����
	int i=0;
	int iSize = m_vEft.size();

	for(i=0; i<iSize; ++i)
	{
		if(0==m_vEft[i].m_pPrn)
		{
			m_vEft[i].m_pEft->SetPosC(vcP);
		}
	}
}


void IEfLnk::SetPosT(const VEC3* vcP)
{
	// �θ� ���� �͸� ����
	int i=0;
	int iSize = m_vEft.size();

	for(i=0; i<iSize; ++i)
	{
		if(0==m_vEft[i].m_pPrn)
		{
			m_vEft[i].m_pEft->SetPosT(vcP);
		}
	}
}


void IEfLnk::SetPosD(const VEC3* vcP)
{
	// �θ� ���� �͸� ����
	int i=0;
	int iSize = m_vEft.size();

	for(i=0; i<iSize; ++i)
	{
		if(0==m_vEft[i].m_pPrn)
		{
			m_vEft[i].m_pEft->SetPosD(vcP);
		}
	}
}










EfMdaEntry::EfMdaEntry()
{
	m_pEftSrc	= NULL;
	m_pMdData	= NULL;
}

EfMdaEntry::EfMdaEntry(IEfBase*	pEftSrc, char* sMdFile, void* pMdData)
{
	m_pEftSrc	= pEftSrc;
	m_pMdData	= pMdData;
	strcpy(m_sMdFile, sMdFile);
}





IEfScnBase::IEfScnBase()
{
	RenderPtr	= NULL;
}

IEfScnBase::~IEfScnBase()
{
	RenderPtr	= NULL;
}



void IEfScnBase::SetRenderPtr(void* pFunc)
{
	if(pFunc)
		RenderPtr = (void (*)())(pFunc);
	else
		RenderPtr = NULL;
}


