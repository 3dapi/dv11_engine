// Interface for the CEfPtcG class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EFPTCG_H_
#define _EFPTCG_H_


class CEfPtcG : public IEfBase
{
public:
	INT			m_iN;
	INT			m_iC;
	EfPtc*		m_pPrt;
	VtxDUV1*	m_pVtx;
	lsEfPtcS	m_vPtc;
	
	PDEV		m_pDev;
	PDTX		m_pTx;
	MATA*		m_mtVwI;					// Inverse View Matrix

public:
	CEfPtcG();
	virtual ~CEfPtcG();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();

	void	SetDevice(PDEV);
	void	SetTx(PDTX);
	void	SetMatrixViwI(MATA* mtView);

	INT		Update();
	INT		PtcUpdate();
	INT		PtcCopy();
	INT		VtxUpdate();

	void	Set(lsEfPtcB& _vS);

public:
	virtual void	OnStop();
	virtual void	OnPlay();
};


typedef std::vector<CEfPtcG*>	lsEfPtcG;
typedef lsEfPtcG::iterator		itEfPtcG;

#endif
