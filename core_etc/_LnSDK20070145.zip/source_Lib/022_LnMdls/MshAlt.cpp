// Implementation of the CMshAlt class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Ln/_PckLnComm.h>
#include <Ln/_PckLnD3D.h>

#include <Ln/PckLnUtil.h>

#include "ILnMdl.h"
#include "MshAlt.h"


CMshAlt::CMshAlt()
{
}

CMshAlt::~CMshAlt()
{
	Destroy();
}



INT CMshAlt::Create(CHAR* sFile)
{
	return 1;
}


void CMshAlt::Destroy()
{
}





void CMshAlt::SetMtl(MtlBase* pMtl)
{
}

MtlBase* CMshAlt::GetMtl()
{
	return NULL;
}

void CMshAlt::SetIdxNum(INT iNix)
{
}

INT CMshAlt::GetIdxNum()
{
	return NULL;
}

void CMshAlt::SetVtxNum(INT iNvx)
{
}

INT CMshAlt::GetVtxNum()
{
	return NULL;
}

void CMshAlt::SetFVF(DWORD dFVF)
{
}

DWORD CMshAlt::GetFVF()
{
	return NULL;
}

void CMshAlt::SetVtxSize(INT iSize)
{
}


INT CMshAlt::GetVtxSize()
{
	return NULL;
}

void CMshAlt::SetIdx(VtxIdx* pIdx)
{
}

VtxIdx* CMshAlt::GetIdx()
{
	return NULL;
}

void CMshAlt::SetVtx(void* pVtx)
{
}

void* CMshAlt::GetVtx()
{
	return NULL;
}

void CMshAlt::MshCopy(IMshBase* pRhs)
{
}