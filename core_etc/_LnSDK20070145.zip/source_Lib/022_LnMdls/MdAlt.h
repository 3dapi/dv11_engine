// Interface for the CMdAlt class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDALT_H_
#define _MDALT_H_


class CMdAlt : public IMdBase
{
protected:
	MtlAlt*			m_pMtl	;
	CMshAlt*		m_pMsh	;													// Mesh Dest Pointer


public:
	CMdAlt();
	virtual ~CMdAlt();

	virtual INT			Init();
	virtual void		Destroy();

	virtual INT			FrameMove();
	virtual void		Render();

public:
	virtual	MtlBase*	GetMtl();
	virtual	void		SetMtl(MtlBase* pM);

	virtual	IMshBase*	GetMsh();
	virtual	void		SetMsh(IMshBase* pM);
};

#endif

