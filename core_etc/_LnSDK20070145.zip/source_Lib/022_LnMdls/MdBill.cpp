// Implementation of the CMdBill class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Ln/_PckLnComm.h>
#include <Ln/_PckLnD3D.h>

#include <Ln/PckLnUtil.h>
#include <Ln/PckLnCam.h>														// Camera

#include "ILnMdl.h"

#include "MshSolid.h"
#include "MdBill.h"


CMdBill::CMdBill()
{
	m_nTp	= MDL_BILL;
}

CMdBill::~CMdBill()
{
	Destroy();
}

INT CMdBill::Init()
{
	return 1;
}

void CMdBill::Destroy()
{
	SAFE_DELETE(	m_pMsD	);
}


INT CMdBill::FrameMove()
{
	D3DXMATRIX mtB = m_mtViwI;
	mtB._41 = 0;
	mtB._42 = 0;
	mtB._43 = 0;

	VtxDUV1* pVtxD = (VtxDUV1*)(m_pMsD->GetVtx());
	VtxDUV1* pVtxS = (VtxDUV1*)(m_pMsS->GetVtx());

	float fY = -pVtxS[2].p.y*.99f;

	pVtxD[0].d = m_dC;
	pVtxD[1].d = m_dC;
	pVtxD[2].d = m_dC;
	pVtxD[3].d = m_dC;	
	
	D3DXVec3TransformCoord(&pVtxD[0].p, &pVtxS[0].p, &mtB);
	D3DXVec3TransformCoord(&pVtxD[1].p, &pVtxS[1].p, &mtB);
	D3DXVec3TransformCoord(&pVtxD[2].p, &pVtxS[2].p, &mtB);
	D3DXVec3TransformCoord(&pVtxD[3].p, &pVtxS[3].p, &mtB);
	
	pVtxD[0].p += m_vcP;
	pVtxD[1].p += m_vcP;
	pVtxD[2].p += m_vcP;
	pVtxD[3].p += m_vcP;

	pVtxD[0].p.y += fY;
	pVtxD[1].p.y += fY;
	pVtxD[2].p.y += fY;
	pVtxD[3].p.y += fY;

	return 1;
}

void CMdBill::Render()
{
	if(!m_pMsD)
		return;

	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	
	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHAREF, 0x80);
	m_pDev->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);
	
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

	
	MtlDiff* pMtl	= m_pMtl;
	INT		iNix	= m_pMsD->GetIdxNum();
	INT		iNvx	= m_pMsD->GetVtxNum();
	
	DWORD	dFVF	= m_pMsD->GetFVF();
	INT		iVxS	= m_pMsD->GetVtxSize();
	VtxIdx*	 pIdx	= m_pMsD->GetIdx();
	VtxDUV1* pVtx	= (VtxDUV1*)m_pMsD->GetVtx();

	pMtl->SetMaterial(m_pDev);
	m_pDev->SetFVF(dFVF);
	m_pDev->DrawIndexedPrimitiveUP(
		D3DPT_TRIANGLELIST, 0
		, iNvx, iNix
		, pIdx, D3DFMT_INDEX16
		, pVtx, iVxS);
	

	LnD3D_SetWorldIdentity(m_pDev);
}

MtlBase* CMdBill::GetMtl()
{
	return m_pMtl;
}


void CMdBill::SetMtl(MtlBase* pM)
{
	m_pMtl = (MtlDiff*)pM;
}

IMshBase* CMdBill::GetMsh()
{
	return m_pMsS;
}

void CMdBill::SetMsh(IMshBase* pMsh)
{
	m_pMsS = (CMshSld*)pMsh;

	m_pMsD = new CMshSld;
	m_pMsD->MshCopy(m_pMsS);
}


void CMdBill::SetColor(DWORD dc)
{
	m_dC= dc;
}


void CMdBill::SetMatrixViwI(D3DXMATRIX* mtViewI)
{
	m_mtViwI = *mtViewI;
}