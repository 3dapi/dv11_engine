// Implementation of the CMdQ3S class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Ln/_PckLnComm.h>
#include <Ln/_PckLnD3D.h>

#include <Ln/PckLnUtil.h>


#include "ILnMdl.h"

#include "MshQ3.h"
#include "MdQ3S.h"


CMdQ3S::CMdQ3S()
{
	m_nTp		= MDL_Q3MO;
	m_pMtl		= NULL;
	m_pMsh		= NULL;

	m_bCreate	= TRUE;
	m_iNmsh		= 0;
	m_pVtx		= NULL;
	m_pVtxN		= NULL;


	m_nFrmCur	= 0;
	m_nFrmNxt	= 0;
	m_nFrmEnd	= 0;
	m_fFrmWgt	= 0;
}


CMdQ3S::~CMdQ3S()
{
	Destroy();
}


INT CMdQ3S::Init()
{
	Destroy();

	m_iNmsh = m_pMsh->GetNumMesh()				;
	m_pVtx	= m_pMsh->CreateVertex(m_bCreate)	;
	m_pVtxN	= m_pMsh->CreateVertexN(m_bCreate)	;

	
	m_nFrmEnd	= m_pMsh->GetNumFrame()	;
	m_fFrmWgt	= 0						;
	m_nFrmCur	= rand()%m_nFrmEnd		;

	return 1;
}


void CMdQ3S::Destroy()
{
	if(m_bCreate)
	{
		SAFE_DELETE_ARRAY2(	m_pVtx, m_iNmsh);
		SAFE_DELETE_ARRAY2(	m_pVtxN, m_iNmsh);
	}
}


INT CMdQ3S::FrameMove()
{
	INT i;

	m_mtW = m_mtR * m_mtS * m_mtL;

	m_mtW._41 = this->m_vcP.x;
	m_mtW._42 = this->m_vcP.y;
	m_mtW._43 = this->m_vcP.z;

	++m_nFrmCur;
	m_nFrmCur %= m_nFrmEnd;
	m_nFrmNxt  = m_nFrmCur;

	for(i=0; i<m_iNmsh; ++i)
	{
		m_pMsh->InterpolateVtx(i, m_pVtx[i], m_nFrmCur, m_nFrmNxt, m_fFrmWgt);
	}

	
	return 1;
}


void CMdQ3S::Render()
{
	if(!m_pMsh)
		return;

	if(!m_iNmsh)
		return;


	INT i;

	m_pDev->SetTransform(D3DTS_WORLD, &m_mtW);

	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	
	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHAREF, 0x80);
	m_pDev->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);

	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );

	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE);
	

	for(i=0; i<m_iNmsh; ++i)
	{
		PDTX	 pTx	= m_pMtl->GetTexture(i);

		INT		iNfce	= m_pMsh->GetNumFce(i);
		INT		iNvtx	= m_pMsh->GetNumVtx(i);
		
		
		VtxIdx*	 pIdx	= m_pMsh->GetIndex(i);
		VtxNUV1* pVtx	= m_pVtx[i];

		m_pMtl->SetMaterial(m_pDev);
		m_pDev->SetTexture( 0, pTx);
	
		m_pDev->SetFVF(VtxNUV1::FVF);
		m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, iNvtx, iNfce, pIdx, D3DFMT_INDEX16, pVtx, sizeof (VtxNUV1) );

		m_pDev->SetTexture( 0, NULL);
	
		VtxD* pVtxN	= m_pVtxN[i];
		m_pDev->SetFVF(VtxD::FVF);
		m_pDev->DrawPrimitiveUP(D3DPT_LINELIST, iNvtx, pVtxN, sizeof (VtxD) );
	}


	LnD3D_SetWorldIdentity(m_pDev);
}



MtlBase* CMdQ3S::GetMtl()
{
	return m_pMtl;
}


void CMdQ3S::SetMtl(MtlBase* pM)
{
	m_pMtl = (MtlQ3S*)pM;
}

IMshBase* CMdQ3S::GetMsh()
{
	return m_pMsh;
}

void CMdQ3S::SetMsh(IMshBase* pMsh)
{
	m_pMsh = (CMshQ3S*)pMsh;
}


void CMdQ3S::SetCreate(BOOL bCreate)
{
	m_bCreate = bCreate;
}

BOOL CMdQ3S::GetCreate()
{
	return m_bCreate;
}