// Interface for the CMdRigid class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDRIGID_H_
#define _MDRIGID_H_


class CMdRigid : public IMdBase
{
public:
	
public:
	CMdRigid();
	virtual ~CMdRigid();

	virtual INT		Init();
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

public:
	virtual	MtlBase*	GetMtl();
	virtual	void		SetMtl(MtlBase* pM);

	virtual	IMshBase*	GetMsh();
	virtual	void		SetMsh(IMshBase* pM);
};

#endif

