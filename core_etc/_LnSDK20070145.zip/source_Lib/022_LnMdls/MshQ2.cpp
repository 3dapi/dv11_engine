// MdQ2Msh.cpp: implementation of the CMshQ2 class.
//
//////////////////////////////////////////////////////////////////////


#include <Ln/_PckLnComm.h>
#include <Ln/_PckLnD3D.h>

#include <Ln/PckLnUtil.h>

#include "ILnMdl.h"
#include "MshQ2.h"


CMshQ2::CMshQ2()
{
	m_pFce	= NULL;
	m_pUVs	= NULL;
	m_pPos	= NULL;
}


CMshQ2::~CMshQ2()
{
	Destroy();
}


void CMshQ2::Destroy()
{
	INT iNf		= m_Head.iNfrm;
	
	memset(&m_Head, 0, sizeof m_Head);

	SAFE_DELETE_ARRAY(	m_pFce	);
	SAFE_DELETE_ARRAY(	m_pUVs	);
	SAFE_DELETE_ARRAY2(	m_pPos, iNf);
}


INT CMshQ2::Create(CHAR* sFile)
{
	HANDLE		fp;				// file pointer
	INT			iFileSize;		// length of model file

	char*		pBuf;			// file buffer
	Md2Idx*		pIdx;			// index variables
	
	Md2UV*		pUV;			// texture Index data
	Md2Frm*		pFrm;			// pFrm data
	
	INT			i, j;			// index variables
	
	strcpy(m_sF, sFile);
	
	fp = LnFile_fopen(m_sF, "rb");
	
	if(INVALID_HANDLE_VALUE == fp)
		return -1;

	Destroy();
	
	iFileSize = LnFile_fsize(fp);
	
	pBuf = (char*)malloc( iFileSize);
	
	LnFile_fread(fp, pBuf, iFileSize);
	
	LnFile_fclose(fp);
	
	// Header �� �д´�.
	memcpy(&m_Head, pBuf, sizeof Md2Hdr);
	
	INT iNvx	= m_Head.iNvtx;
	INT iNf		= m_Head.iNfrm;
	INT nFs		= m_Head.iLfrm;
	INT iNuv	= m_Head.iNtvt;
	INT iNfce	= m_Head.iNfce;
	
	m_pPos = new VEC3*[m_Head.iNfrm];
	
	for(i=0; i< iNf; ++i)
		m_pPos[i] = new VEC3[m_Head.iNvtx];
	
	m_pUVs = new VEC2[iNuv];
	m_pFce = new Md2Idx[iNfce];
	
	for (j = 0; j < iNf; j++)
	{
		pFrm = (Md2Frm*)(pBuf + m_Head.nBgnFrm + nFs * j);
		
		for (i = 0; i < iNvx; i++)
		{
			m_pPos[j][i].x = pFrm->vScl[0] * pFrm->FrmP[i][0] + pFrm->vPos[0];
			m_pPos[j][i].y = pFrm->vScl[2] * pFrm->FrmP[i][2] + pFrm->vPos[2];
			m_pPos[j][i].z = pFrm->vScl[1] * pFrm->FrmP[i][1] + pFrm->vPos[1];
		}
	}
	
	
	pUV = (Md2UV*)(pBuf + m_Head.nBgnST);
	
	for (i = 0; i < iNuv; i++)
	{
		m_pUVs[i].x = pUV[i].u / FLOAT(m_Head.iSkinW);
		m_pUVs[i].y = pUV[i].v / FLOAT(m_Head.iSkinH);
	}
	
	// point to triangle indexes in buffer
	pIdx = (Md2Idx*)(pBuf + m_Head.nBgnTri);
	
	memcpy(m_pFce, pIdx, iNfce * sizeof (Md2Idx));
	free(pBuf);
	
	return 1;
}




void CMshQ2::BuildVertex(void* pVtx, INT nFrmC, INT nFrmN, FLOAT fWeight)
{
	VEC3*	vcCurLst;	// current pFrm vertices
	VEC3*	vcNxtLst;	// next pFrm vertices
	INT		i;			// index counter
	VEC3	p1;			// current pFrm point values
	VEC3	p2;			// next pFrm point values
	
	VEC3	vcP[3]; 

	INT iNvx	= m_Head.iNvtx;
	INT iNfce	= m_Head.iNfce;


	vcCurLst = m_pPos[nFrmC];
	vcNxtLst = m_pPos[nFrmN];
	
	for (i = 0; i < iNfce; i++)
	{
		p1 = vcCurLst[m_pFce[i].IdxFc[0]];
		p2 = vcNxtLst[m_pFce[i].IdxFc[0]];
		D3DXVec3Lerp(&vcP[0], &p1, &p2, fWeight);
		
		p1 = vcCurLst[m_pFce[i].IdxFc[1]];
		p2 = vcNxtLst[m_pFce[i].IdxFc[1]];
		D3DXVec3Lerp(&vcP[1], &p1, &p2, fWeight);

		p1 = vcCurLst[m_pFce[i].IdxFc[2]];
		p2 = vcNxtLst[m_pFce[i].IdxFc[2]];
		D3DXVec3Lerp(&vcP[2], &p1, &p2, fWeight);
		
		((VtxDUV1*)pVtx)[i*3 + 0].p = vcP[0];
		((VtxDUV1*)pVtx)[i*3 + 1].p = vcP[2];
		((VtxDUV1*)pVtx)[i*3 + 2].p = vcP[1];
	}
}


void* CMshQ2::GetVertex()
{
	INT i;

	INT iNfce	= m_Head.iNfce;
	INT iNvtx	= iNfce * 3;

	VtxDUV1* pVtx = new VtxDUV1[iNvtx];

	for(i = 0; i < iNfce; i++)
	{
		pVtx[i*3 + 0].u = m_pUVs[m_pFce[i].IdxUV[0]].x;
		pVtx[i*3 + 0].v = m_pUVs[m_pFce[i].IdxUV[0]].y;

		pVtx[i*3 + 1].u = m_pUVs[m_pFce[i].IdxUV[2]].x;
		pVtx[i*3 + 1].v = m_pUVs[m_pFce[i].IdxUV[2]].y;

		pVtx[i*3 + 2].u = m_pUVs[m_pFce[i].IdxUV[1]].x;
		pVtx[i*3 + 2].v = m_pUVs[m_pFce[i].IdxUV[1]].y;
	}

	return pVtx;
}



INT CMshQ2::GetNumFrame()
{
	return m_Head.iNfrm;
}


void CMshQ2::SetMtl(MtlBase* pMtl)
{
	m_pMtl = (MtlDiff*)pMtl;
}

MtlBase* CMshQ2::GetMtl()
{
	return m_pMtl;
}

void CMshQ2::SetIdxNum(INT iNix)
{
}

INT CMshQ2::GetIdxNum()
{
	return m_Head.iNfce;;
}

void CMshQ2::SetVtxNum(INT iNvx)
{
}

INT CMshQ2::GetVtxNum()
{
	return m_Head.iNvtx;
}

void CMshQ2::SetFVF(DWORD dFVF)
{
}

DWORD CMshQ2::GetFVF()
{
	return 0;
}

void CMshQ2::SetVtxSize(INT iSize)
{
}

INT CMshQ2::GetVtxSize()
{
	return 0;
}

void CMshQ2::SetIdx(VtxIdx* pIdx)
{
}

VtxIdx* CMshQ2::GetIdx()
{
	return NULL;
}

void CMshQ2::SetVtx(void* pVtx)
{
}

void* CMshQ2::GetVtx()
{
	return NULL;
}

void CMshQ2::MshCopy(IMshBase* pRhs)
{
}