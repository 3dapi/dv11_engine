// Implementation of the CMdSkin class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Ln/_PckLnComm.h>
#include <Ln/_PckLnD3D.h>

#include <Ln/PckLnUtil.h>


#include "ILnMdl.h"
#include "MdSkin.h"


CMdSkin::CMdSkin()
{
	m_nTp	= MDL_SKIN;
}

CMdSkin::~CMdSkin()
{
	Destroy();
}

INT CMdSkin::Init()
{
	return 1;
}

void CMdSkin::Destroy()
{
}


INT CMdSkin::FrameMove()
{
	return 1;
}

void CMdSkin::Render()
{
}




MtlBase* CMdSkin::GetMtl()
{
	return NULL;
}


void CMdSkin::SetMtl(MtlBase* pM)
{
}

IMshBase* CMdSkin::GetMsh()
{
	return NULL;
}

void CMdSkin::SetMsh(IMshBase* pMsh)
{
}

