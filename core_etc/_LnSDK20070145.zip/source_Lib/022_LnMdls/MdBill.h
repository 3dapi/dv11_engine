// Interface for the CMdBill class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDBILL_H_
#define _MDBILL_H_


class CMdBill : public IMdBase
{
protected:
	MtlDiff*		m_pMtl	;
	
	CMshSld*		m_pMsD	;													// Mesh Dest Pointer
	CMshSld*		m_pMsS	;													// Mesh Source Pointer

	DCLR			m_dC	;													// Color

	D3DXMATRIX		m_mtViwI;													// Camera Inverse View Matrix


public:
	CMdBill();
	virtual ~CMdBill();

	virtual INT			Init();
	virtual void		Destroy();

	virtual INT			FrameMove();
	virtual void		Render();

	virtual	MtlBase*	GetMtl();
	virtual	void		SetMtl(MtlBase* pM);

	virtual	IMshBase*	GetMsh();
	virtual	void		SetMsh(IMshBase* pM);

public:
	void	SetMatrixViwI(D3DXMATRIX* mtViewI);
	void	SetColor(DWORD dc);
};

#endif

