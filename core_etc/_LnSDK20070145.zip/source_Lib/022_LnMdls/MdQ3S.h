// Interface for the CMdQ3S class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDQ3S_H_
#define _MDQ3S_H_


class CMdQ3S : public IMdBase
{
protected:
	MtlQ3S*			m_pMtl		;
	CMshQ3S*		m_pMsh		;		// Original Mesh

	BOOL			m_bCreate	;		// �޽��� ���� ����� ����� ���ΰ�?(TRUE)
	INT				m_iNmsh		;		// Number of Mesh

	VtxNUV1**		m_pVtx		;
	VtxD**			m_pVtxN		;

	INT				m_nFrmCur	;		// Animation: Current Frame
	INT				m_nFrmNxt	;		// Animation: Current Frame
	INT				m_nFrmEnd	;		// Animation: End Frame
	FLOAT			m_fFrmWgt	;		// Animation: Weight

public:
	CMdQ3S();
	virtual ~CMdQ3S();

	virtual INT			Init();
	virtual void		Destroy();

	virtual INT			FrameMove();
	virtual void		Render();

	virtual	MtlBase*	GetMtl();
	virtual	void		SetMtl(MtlBase* pM);

	virtual	IMshBase*	GetMsh();
	virtual	void		SetMsh(IMshBase* pM);

public:
	void	SetCreate(BOOL bCreate);
	BOOL	GetCreate();

	INT		GetFrmCur()	{	return m_nFrmCur	;	}
	INT		GetFrmNxt()	{	return m_nFrmNxt	;	}
	INT		GetFrmEnd()	{	return m_nFrmEnd	;	}
	FLOAT	GetFrmWgt()	{	return m_fFrmWgt	;	}
};

#endif


