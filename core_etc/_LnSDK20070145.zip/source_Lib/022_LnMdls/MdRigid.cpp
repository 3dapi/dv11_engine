// Implementation of the CMdRigid class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Ln/_PckLnComm.h>
#include <Ln/_PckLnD3D.h>

#include <Ln/PckLnUtil.h>


#include "ILnMdl.h"
#include "MdRigid.h"


CMdRigid::CMdRigid()
{
	m_nTp	= MDL_RIGID;
}

CMdRigid::~CMdRigid()
{
	Destroy();
}

INT CMdRigid::Init()
{
	return 1;
}

void CMdRigid::Destroy()
{
}


INT CMdRigid::FrameMove()
{
	return 1;
}

void CMdRigid::Render()
{
}


MtlBase* CMdRigid::GetMtl()
{
	return NULL;
}


void CMdRigid::SetMtl(MtlBase* pM)
{
}

IMshBase* CMdRigid::GetMsh()
{
	return NULL;
}

void CMdRigid::SetMsh(IMshBase* pMsh)
{
}