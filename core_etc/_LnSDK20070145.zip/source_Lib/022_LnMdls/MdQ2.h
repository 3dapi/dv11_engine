// Interface for the CMdQ2 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDQ2_H_
#define _MDQ2_H_


class CMdQ2 : public IMdBase
{
protected:
	MtlDiff*		m_pMtl		;
	CMshQ2*			m_pMsh		;


	INT				m_eAniSt	;		// current model animation state
	INT				m_nFrmBgn	;		// Begin Frame
	INT				m_nFrmEnd	;		// Begin Frame
	FLOAT			m_fWeight	;		// Weight

	INT				m_nFrmCur	;		// current frame # in animation
	INT				m_nFrnNxt	;		// next frame # in animation
	FLOAT			m_fInc		;			// percent through current frame (interpolation)
	
	VtxDUV1*		m_pVtx		;
	
public:
	CMdQ2();
	virtual ~CMdQ2();
	
	virtual INT		Init()			;
	virtual void	Destroy()		;

	virtual INT		FrameMove()		;
	virtual void	Render()		;

	virtual	MtlBase*	GetMtl()			;
	virtual	void		SetMtl(MtlBase* pM)	;

	virtual	IMshBase*	GetMsh()			;
	virtual	void		SetMsh(IMshBase* pM);	

public:	
	void	SetState(int eSt)	;
	INT		GetState()			;
	void	SetFrame(INT nFrmBgn, INT nFrmEnd, FLOAT fWeight);
};


#endif

