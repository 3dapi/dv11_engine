// Interface for the CMdQ3M class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDQ3M_H_
#define _MDQ3M_H_


class CMdQ3M : public IMdBase
{
protected:
	enum EMdQ3Multi
	{
		MDQ3MUL_HEAD =0,
		MDQ3MUL_UPPER,
		MDQ3MUL_LOWER,
		MDQ3MUL_TOT,
	};

	union
	{
		struct 
		{
			CMdQ3S*	m_pQh	;				// Head
			CMdQ3S*	m_pQu	;				// Upper
			CMdQ3S*	m_pQl	;				// Lower
		};

		CMdQ3S*	m_pQ3[3]	;
	};


	MtlQ3M*			m_pMtl	;
	CMshQ3M*		m_pMsh	;
	

public:
	CMdQ3M();
	virtual ~CMdQ3M();

	virtual INT		Init();
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual	MtlBase*	GetMtl();
	virtual	void		SetMtl(MtlBase* pM);
	virtual	IMshBase*	GetMsh();
	virtual	void		SetMsh(IMshBase* pM);
	virtual	void		SetQ3Mono(INT nM, CMdQ3S* pM);
	virtual	CMdQ3S*	GetQ3Mono(INT nM);
};

#endif


