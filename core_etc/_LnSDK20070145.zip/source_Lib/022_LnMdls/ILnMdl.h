// Interface for the IMdBase class.
// Model�� ���� = ��Ƽ���� + �޽�
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _ILNMDL_H_
#define _ILNMDL_H_


#pragma warning(disable : 4786)
#include <vector>


// ��Ƽ���� ����ü
////////////////////////////////////////////////////////////////////////////////


// Material Base
struct MtlBase
{
	enum EMtlType
	{
		MTL_BASE	=0x00,
		MTL_DIFF	=0x01,

		// single
		MTL_MD3S	=0x02,

		// Multi
		MTL_MD3M	=0x03,

		MTL_TOON	=0x04,
		MTL_GLOS	=0x05,
	};

	EMtlType			nTp;															// Model Type

	MtlBase();
	virtual ~MtlBase();

	virtual INT LoadTexture(void* pMdlLdr);
	virtual INT SetMaterial(PDEV pDev);

	void		SetType(INT _nTp);
	INT			GetType();
};


typedef	std::vector<MtlBase* >	lsMtl;
typedef lsMtl::iterator			itMtl;


// Material Diffuse
struct MtlDiff : public MtlBase
{
	INT					nIdx;
	IDirect3DTexture9*	pTxDiff;
	CHAR				sDff[256];

	MtlDiff();
	virtual ~MtlDiff();

	virtual INT LoadTexture(void* pMdlLdr);
	virtual INT SetMaterial(PDEV pDev);
};



// Md3Mono Material Diffuse
struct MtlQ3S : public MtlBase
{
	INT					nIdx;

	PDTX*				pTxs;
	lsStr				vDff;

	MtlQ3S();
	virtual ~MtlQ3S();

	virtual INT LoadTexture(void* pMdlLdr);
	virtual INT SetMaterial(PDEV pDev);
	virtual PDTX GetTexture(INT nIdx);
	virtual void Push_Files(char* sFile);
};




// Md3Multi Material Diffuse
struct MtlQ3M : public MtlBase
{
	union
	{
		struct 	{MtlQ3S*	pMtl1; MtlQ3S* pMtl2; MtlQ3S*	pMtl3;	};
		MtlQ3S*		pMtl[3];
	};
	
	MtlQ3M();
	virtual ~MtlQ3M();

	virtual INT LoadTexture(void* pMdlLdr);
	virtual INT SetMaterial(PDEV pDev);
	
	virtual PDTX GetTexture(INT nM, INT nS);
	virtual void SetMaterial(INT nM, MtlQ3S* _pMtl);
	virtual MtlQ3S* GetMaterial(INT nM);
};


// Toon Shading
struct MtlToon : public MtlDiff
{
	PDTX	pTxToon	;
	FLOAT	Toon[16];															// Toon Shading Texture
	
	MtlToon();
	virtual ~MtlToon();

	virtual INT LoadTexture(void* pMdlLdr);
	virtual INT SetMaterial(PDEV pDev);
};


// ALT Model
struct MtlAlt : public MtlBase
{
	MtlAlt();
	virtual ~MtlAlt();
	virtual INT LoadTexture(void* pMdlLdr);
	virtual INT SetMaterial(PDEV pDev);
};





// Gloss Effect =  Base + Reflect * Gloss �ε�
// Reflect�� �ݻ� ��, Gloss�� Normal ���� �̿�
// Base * normal + Reflect�� ��ó
struct MtlGloss : public MtlDiff
{
	PDTX	pTxN;			// Normal map
	PDTX	pTxS;			// Specular Map(Reflect)
	
	CHAR	sNrm[128];
	CHAR	sSpc[128];
	
	MtlGloss();
	virtual ~MtlGloss();

	virtual INT LoadTexture(void* pMdlLdr);
};





// �޽� ����ü
////////////////////////////////////////////////////////////////////////////////

class IMshBase
{
public:
	IMshBase(){};
	virtual ~IMshBase(){};

	virtual void		SetMtl(MtlBase* pMtl)=0;
	virtual MtlBase*	GetMtl()=0;

	virtual void		SetIdxNum(INT iNix)=0;
	virtual INT			GetIdxNum()=0;

	virtual void		SetVtxNum(INT iNvx)=0;
	virtual INT			GetVtxNum()=0;

	virtual void		SetFVF(DWORD dFVF)=0;
	virtual DWORD		GetFVF()=0;

	virtual void		SetVtxSize(INT iSize)=0;
	virtual INT			GetVtxSize()=0;

	virtual void		SetIdx(VtxIdx* pIdx)=0;
	virtual VtxIdx*		GetIdx()=0;

	virtual void		SetVtx(void* pVtx)=0;
	virtual void*		GetVtx()=0;

	virtual void		MshCopy(IMshBase* pRhs)=0;
};


typedef	IMshBase				ILnMsh;
typedef std::vector<IMshBase*>	lsMsh;
typedef lsMsh::iterator			itMsh;








// �ӵ� Ŭ����
////////////////////////////////////////////////////////////////////////////////

class IMdBase
{
public:
	enum EMdlType
	{
		MDL_NONE	=0x00,
		MDL_BILL	=0x01,
		MDL_SOLID	=0x02,

		MDL_RIGID	=0x03,
		MDL_BONE	=0x04,
		MDL_SKIN	=0x05,

		MDL_Q2MO	=0x10,

		MDL_Q3MO	=0x11,
		MDL_Q3MU	=0x12,
		
		MDL_ALT		=0x20,
	};


protected:
	void*			m_pMdLdr;													// Model Loader

protected:
	EMdlType		m_nTp;														// Model Type
	
	D3DXVECTOR3		m_vcP;														// Position
	D3DXMATRIX		m_mtR;														// Rotation
	D3DXMATRIX		m_mtS;														// Scaling
	D3DXMATRIX		m_mtL;														// Local Matrix

	D3DXMATRIX		m_mtW;														// World which is mtW = mtR * mtS * mtL

	PDEV			m_pDev;														// Device

public:
	FLOAT			m_fBr;														// Radius of Bounding
	D3DXVECTOR3		m_vcBb;														// bound Box width, Height, depth
	D3DXVECTOR3		m_vcBc;														// bound Box Center

public:
	FLOAT			fStlSrtR;													// Z Direction Value
	FLOAT			fStlSrtD;													// Distance from Camera


	
public:
	IMdBase();

	virtual ~IMdBase();

	virtual INT			Init()=0;
	virtual void		Destroy()=0;

	virtual INT			FrameMove()=0;
	virtual void		Render()=0;

	virtual	MtlBase*	GetMtl()=0;
	virtual	void		SetMtl(MtlBase* pM)=0;

	virtual	IMshBase*	GetMsh()=0;
	virtual	void		SetMsh(IMshBase* pM)=0;

public:	
	virtual	INT		Load(char* sFile);
	virtual	INT		Save(char* sFile);

	void			SetLoader(void* pLoader);
	void			SetDevice(PDEV pDev);

	void			SetType(INT nTp);
	INT				GetType();

	void			SetPos(D3DXVECTOR3* p);
	D3DXVECTOR3*	GetPos() const;

	void			SetRot(D3DXMATRIX* mtR);
	D3DXMATRIX*		GetRot() const;

	void			SetScl(D3DXMATRIX* mtS);
	D3DXMATRIX*		GetScl() const;

	void			SetLcl(D3DXMATRIX* mtL);
	void			SetLclT(D3DXMATRIX* mtL);
	D3DXMATRIX*		GetLcl() const;

	void			SetDistCam(FLOAT _fR);
};



typedef	IMdBase					IMdBase;
typedef	IMdBase*				LPLNMDL;

typedef std::vector<IMdBase*>	lsMdl;
typedef lsMdl::iterator			itMdl;




#endif


