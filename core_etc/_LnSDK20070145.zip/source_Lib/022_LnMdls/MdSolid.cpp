// Implementation of the CMdSolid class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Ln/_PckLnComm.h>
#include <Ln/_PckLnD3D.h>

#include <Ln/PckLnUtil.h>
#include <Ln/PckLnCam.h>														// Camera

#include "ILnMdl.h"
#include "MshSolid.h"
#include "MdSolid.h"


CMdSolid::CMdSolid()
{
	m_nTp	= MDL_SOLID;
}

CMdSolid::~CMdSolid()
{
	Destroy();
}

INT CMdSolid::Init()
{
	return 1;
}

void CMdSolid::Destroy()
{
}


INT CMdSolid::FrameMove()
{
	m_mtW = m_mtR * m_mtS;

	m_mtW._41 = this->m_vcP.x;
	m_mtW._42 = this->m_vcP.y;
	m_mtW._43 = this->m_vcP.z;
	
	return 1;
}

void CMdSolid::Render()
{
	m_pDev->SetTransform(D3DTS_WORLD, &m_mtW);

	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	
	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHAREF, 0x80);
	m_pDev->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);

	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );

	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

	MtlDiff* pMtl	= m_pMtl;
	INT		iNix	= m_pMsS->GetIdxNum();
	INT		iNvx	= m_pMsS->GetVtxNum();

	DWORD	dFVF	= m_pMsS->GetFVF();
	INT		iVxS	= m_pMsS->GetVtxSize();
	VtxIdx*	 pIdx	= m_pMsS->GetIdx();
	VtxDUV1*	pVtx	= (VtxDUV1*)m_pMsS->GetVtx();

	PDTX	pTxDiff	= pMtl->pTxDiff;

	m_pDev->SetTexture(0, pTxDiff);

	m_pDev->SetFVF(dFVF);
	m_pDev->DrawIndexedPrimitiveUP(
		D3DPT_TRIANGLELIST, 0
		, iNvx, iNix
		, pIdx, D3DFMT_INDEX16
		, pVtx, iVxS);


	LnD3D_SetWorldIdentity(m_pDev);
}




MtlBase* CMdSolid::GetMtl()
{
	return m_pMtl;
}


void CMdSolid::SetMtl(MtlBase* pM)
{
	m_pMtl = (MtlDiff*)pM;
}

IMshBase* CMdSolid::GetMsh()
{
	return m_pMsS;
}

void CMdSolid::SetMsh(IMshBase* pMsh)
{
	m_pMsS = (CMshSld*)pMsh;
}