// Interface for the CMdBone class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDBONE_H_
#define _MDBONE_H_


class CMdBone : public IMdBase
{
public:
	
public:
	CMdBone();
	virtual ~CMdBone();

	virtual INT			Init();
	virtual void		Destroy();

	virtual INT			FrameMove();
	virtual void		Render();

public:
	virtual	MtlBase*	GetMtl();
	virtual	void		SetMtl(MtlBase* pM);

	virtual	IMshBase*	GetMsh();
	virtual	void		SetMsh(IMshBase* pM);
};

#endif

