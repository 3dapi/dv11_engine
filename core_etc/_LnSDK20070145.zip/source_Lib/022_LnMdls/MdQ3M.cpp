// Implementation of the CMdQ3M class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Ln/_PckLnComm.h>
#include <Ln/_PckLnD3D.h>

#include <Ln/PckLnUtil.h>


#include "ILnMdl.h"

#include "MshQ3.h"
#include "MdQ3S.h"
#include "MdQ3M.h"


CMdQ3M::CMdQ3M()
{
	m_nTp	= MDL_Q3MU;
	m_pMtl	= NULL;
	m_pMsh	= NULL;
	
	m_pQh	= NULL;
	m_pQu	= NULL;
	m_pQl	= NULL;	
}


CMdQ3M::~CMdQ3M()
{
	Destroy();
}


INT CMdQ3M::Init()
{
	for(int i=0; i<MDQ3MUL_TOT; ++i)
	{
		m_pQ3[i]	= new CMdQ3S;
		MtlQ3S*		pMtl = m_pMtl->GetMaterial(i);
		CMshQ3S*	pMsh = m_pMsh->GetQ3Msh(i);
	
		m_pQ3[i]->SetMtl(pMtl);
		m_pQ3[i]->SetMsh(pMsh);
		m_pQ3[i]->SetDevice(m_pDev);
		m_pQ3[i]->Init();
	}
	
	return 1;
}


void CMdQ3M::Destroy()
{
	for(int i=0; i<MDQ3MUL_TOT; ++i)
	{
		SAFE_DELETE(	m_pQ3[i]	);
	}
}


INT CMdQ3M::FrameMove()
{
	D3DXMatrixRotationY(&m_mtW, D3DXToRadian(0.f));
	
	m_mtW._41 = m_vcP.x;
	m_mtW._42 = m_vcP.y;
	m_mtW._43 = m_vcP.z;


	for(int i=0; i<MDQ3MUL_TOT; ++i)
	{
		SAFE_FRMOV(	m_pQ3[i]	);
	}
	
	return 1;
}


void CMdQ3M::Render()
{
	if(m_pQl)
	{
		m_pQl->SetLcl(&m_mtW);
		m_pQl->Render();
	}
	
	if(m_pQu)
	{
		INT			nFrm	= m_pQl->GetFrmCur();
		CMshQ3S*	pMsh	= (CMshQ3S*)m_pQl->GetMsh();
		MATA		mtTag	= pMsh->GetTag(0, nFrm);

		MATA		mtWld	= mtTag * m_mtW;
		
		m_pQu->SetLcl(&mtWld);
		m_pQu->Render();
	}
	
	if(m_pQh)
	{
		INT			nFrm1	= m_pQu->GetFrmCur();
		CMshQ3S*	pMsh1	= (CMshQ3S*)m_pQu->GetMsh();
		MATA		mtTag1	= pMsh1->GetTag(1, nFrm1);
		
		
		INT			nFrm2 = m_pQl->GetFrmCur();
		CMshQ3S*	pMsh2	= (CMshQ3S*)m_pQl->GetMsh();
		MATA		mtTag2	= pMsh2->GetTag(0, nFrm2);
		

		MATA		mtWld	= mtTag1 * mtTag2;
		

		mtWld	*= m_mtW;
		
		m_pQh->SetLcl(&mtWld);
		m_pQh->Render();
	}
}


MtlBase* CMdQ3M::GetMtl()
{
	return m_pMtl;
}

void CMdQ3M::SetMtl(MtlBase* pM)
{
	m_pMtl = (MtlQ3M*)pM;
}

IMshBase* CMdQ3M::GetMsh()
{
	return m_pMsh;
}

void CMdQ3M::SetMsh(IMshBase* pM)
{
	m_pMsh = (CMshQ3M*)pM;
}


void CMdQ3M::SetQ3Mono(INT nM, CMdQ3S* pM)
{
	m_pQ3[nM] = pM;
}

CMdQ3S* CMdQ3M::GetQ3Mono(INT nM)
{
	return m_pQ3[nM];
}

