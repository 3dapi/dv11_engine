// Implementation of the CMdQ2 class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Ln/_PckLnComm.h>
#include <Ln/_PckLnD3D.h>

#include <Ln/PckLnUtil.h>


#include "ILnMdl.h"

#include "MshQ2.h"
#include "MdQ2.h"


CMdQ2::CMdQ2()
{
	m_nTp	= MDL_Q2MO;

	m_pMtl = NULL;
	m_pMsh = NULL;

	m_eAniSt	= 0;

	m_nFrmBgn	= 0;
	m_nFrmEnd	= 0;
	m_fWeight	= 0;

	m_nFrmCur	= 0;
	m_nFrnNxt	= 1;
	m_fInc		= 0;
	
	m_pVtx = NULL;
}    


CMdQ2::~CMdQ2()
{
	Destroy();
}


void CMdQ2::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVtx	);
}


int CMdQ2::Init()
{
	m_pVtx = (VtxDUV1*)m_pMsh->GetVertex();
	SetFrame(  0,  39, 1/6.f);
	
	return 1;
}



int CMdQ2::FrameMove()
{
	if (m_nFrmCur < m_nFrmBgn)
		m_nFrmCur = m_nFrmBgn;
	
	if ((m_nFrmBgn < 0) || (m_nFrmEnd < 0))
		return -1;

	INT iNf		= m_pMsh->GetNumFrame();

	if ((m_nFrmBgn >= iNf) || (m_nFrmEnd >= iNf))
		return -1;
	
	if (m_fInc >= 1.0)
	{
		m_fInc = 0.0f;
		++m_nFrmCur;

		if (m_nFrmCur>= m_nFrmEnd)
			m_nFrmCur = m_nFrmBgn;
		
		m_nFrnNxt = m_nFrmCur + 1;
		
		if (m_nFrnNxt >= m_nFrmEnd)
			m_nFrnNxt = m_nFrmBgn;
	}

	m_fInc += m_fWeight;	// increase percentage of interpolation between frames

	m_pMsh->BuildVertex(m_pVtx, m_nFrmCur, m_nFrnNxt, m_fInc);



	D3DXMatrixScaling(&m_mtS, 2.f, 2.f, 2.f);

	m_mtW = m_mtR * m_mtS;

	m_mtW._41 = this->m_vcP.x;
	m_mtW._42 = this->m_vcP.y;
	m_mtW._43 = this->m_vcP.z;

	return 0;
}


void CMdQ2::Render()
{
	if(!m_pMsh)
		return;

	m_pDev->SetTransform(D3DTS_WORLD, &m_mtW);

	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	
	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHAREF, 0x80);
	m_pDev->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);

	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );

	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
	
	
	INT iNfce	= m_pMsh->GetIdxNum();

	if(m_pMtl)
		m_pMtl->SetMaterial(m_pDev);
	
	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, iNfce, m_pVtx, sizeof(VtxDUV1));


	LnD3D_SetWorldIdentity(m_pDev);
}



MtlBase* CMdQ2::GetMtl()
{
	return m_pMtl;
}


void CMdQ2::SetMtl(MtlBase* pM)
{
	m_pMtl = (MtlDiff*)pM;
}


IMshBase* CMdQ2::GetMsh()
{
	return m_pMsh;
}


void CMdQ2::SetMsh(IMshBase* pM)
{
	m_pMsh = (CMshQ2*)pM;
}


void CMdQ2::SetState(int eSt)
{
	m_eAniSt = eSt;
}


INT CMdQ2::GetState()
{
	return m_eAniSt;
}


void CMdQ2::SetFrame(INT nFrmBgn, INT nFrmEnd, FLOAT fWeight)
{
	m_nFrmBgn	= nFrmBgn;
	m_nFrmEnd	= nFrmEnd;
	m_fWeight	= fWeight;
}