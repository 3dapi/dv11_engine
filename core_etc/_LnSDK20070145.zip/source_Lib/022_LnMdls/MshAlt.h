// Interface for the CMshAlt class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MSHALT_H_
#define _MSHALT_H_

class CMshAlt : public IMshBase
{
public:
	
protected:
	MtlAlt*			m_pMtl		;
	
public:
	CMshAlt();
	virtual ~CMshAlt();

	INT		Create(CHAR* sFile);
	void	Destroy();

protected:


public:

	virtual void		SetMtl(MtlBase* pMtl);
	virtual MtlBase*	GetMtl();

	virtual void		SetIdxNum(INT iNix);	
	virtual INT			GetIdxNum();

	virtual void		SetVtxNum(INT iNvx);
	virtual INT			GetVtxNum();

	virtual void		SetFVF(DWORD dFVF);
	virtual DWORD		GetFVF();

	virtual void		SetVtxSize(INT iSize);
	virtual INT			GetVtxSize();

	virtual void		SetIdx(VtxIdx* pIdx);
	virtual VtxIdx*		GetIdx();

	virtual void		SetVtx(void* pVtx);
	virtual void*		GetVtx();

	virtual void		MshCopy(IMshBase* pRhs);
};

#endif

