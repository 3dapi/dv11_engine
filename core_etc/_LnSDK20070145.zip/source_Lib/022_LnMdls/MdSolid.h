// Interface for the CMdSolid class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDSOLID_H_
#define _MDSOLID_H_


class CMdSolid : public IMdBase
{
protected:
	MtlDiff*		m_pMtl	;
	CMshSld*		m_pMsS	;													// Mesh Source Pointer
	
public:
	CMdSolid();
	virtual ~CMdSolid();

	virtual INT			Init();
	virtual void		Destroy();

	virtual INT			FrameMove();
	virtual void		Render();

public:
	virtual	MtlBase*	GetMtl();
	virtual	void		SetMtl(MtlBase* pM);

	virtual	IMshBase*	GetMsh();
	virtual	void		SetMsh(IMshBase* pM);
};

#endif

