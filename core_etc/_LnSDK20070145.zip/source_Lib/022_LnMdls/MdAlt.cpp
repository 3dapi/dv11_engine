// Implementation of the CMdAlt class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Ln/_PckLnComm.h>
#include <Ln/_PckLnD3D.h>

#include <Ln/PckLnUtil.h>


#include "ILnMdl.h"

#include "MshAlt.h"
#include "MdAlt.h"


CMdAlt::CMdAlt()
{
	m_nTp	= MDL_ALT;
}

CMdAlt::~CMdAlt()
{
	Destroy();
}

INT CMdAlt::Init()
{
	return 1;
}

void CMdAlt::Destroy()
{
}


INT CMdAlt::FrameMove()
{
	return 1;
}

void CMdAlt::Render()
{
	if(!m_pMsh)
		return;
}

MtlBase* CMdAlt::GetMtl()
{
	return m_pMtl;
}


void CMdAlt::SetMtl(MtlBase* pM)
{
	m_pMtl = (MtlAlt*)pM;
}

IMshBase* CMdAlt::GetMsh()
{
	return m_pMsh;
}

void CMdAlt::SetMsh(IMshBase* pMsh)
{
	m_pMsh = (CMshAlt*)pMsh;
}
