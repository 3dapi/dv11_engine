// Implementation of the CMdBone class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Ln/_PckLnComm.h>
#include <Ln/_PckLnD3D.h>

#include <Ln/PckLnUtil.h>


#include "ILnMdl.h"

#include "MdBone.h"



CMdBone::CMdBone()
{
	m_nTp	= MDL_BONE;
}

CMdBone::~CMdBone()
{
	Destroy();
}

INT CMdBone::Init()
{
	return 1;
}

void CMdBone::Destroy()
{
}


INT CMdBone::FrameMove()
{
	return 1;
}

void CMdBone::Render()
{
}


MtlBase* CMdBone::GetMtl()
{
	return NULL;
}


void CMdBone::SetMtl(MtlBase* pM)
{
}

IMshBase* CMdBone::GetMsh()
{
	return NULL;
}

void CMdBone::SetMsh(IMshBase* pMsh)
{
}