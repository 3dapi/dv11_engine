// Implementation of the IMdBase class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Ln/_PckLnComm.h>														// Base
#include <Ln/_PckLnD3D.h>														// DirectX + Window

#include <Ln/PckLnUtil.h>														// Util


#include "ILnMdl.h"
#include "MtMdl.h"


// Material Base
MtlBase::MtlBase(): nTp(MTL_BASE)
{
}

MtlBase::~MtlBase()
{
}

INT MtlBase::LoadTexture(void* pMdlLdr)
{
	return -1;
}

INT MtlBase::SetMaterial(PDEV pDev)
{
	return -1;
}



void MtlBase::SetType(INT _nTp)
{
	nTp = (EMtlType)_nTp;
}

INT MtlBase::GetType()
{
	return (INT)nTp;
}


// Material Diffuse
MtlDiff::MtlDiff():pTxDiff(0)
{
	nTp = MTL_DIFF;
	memset(sDff, 0, sizeof(sDff));
}

MtlDiff::~MtlDiff()
{
//	SAFE_RELEASE(	pTxDiff	);
}

INT MtlDiff::LoadTexture(void* pMdlLdr)
{
	CMdlLoader* pLoader = (CMdlLoader*)pMdlLdr;
	pTxDiff = pLoader->LoadTexture(sDff);

	if(pTxDiff)
		return 1;

	return -1;
}


INT MtlDiff::SetMaterial(PDEV pDev)
{
	pDev->SetTexture(0, pTxDiff);
	
	return 1;
}



// Md3Mono Material Diffuse
MtlQ3S::MtlQ3S() : pTxs(0)
{
	nTp		= MTL_MD3S;
}

MtlQ3S::~MtlQ3S()
{
//	int iSize = vDff.size();
//	SAFE_RELEASE_ARRAY(	pTxs, iSize	);
//	vDff.clear();

	if(pTxs)
	{
		int iSize = vDff.size();

		for(int i=0; i<iSize; ++i)
		{
			if(pTxs[i])
			{
//				pTxs[i]->Release();
				pTxs[i] = NULL;
			}
		}

		delete[] pTxs;
		pTxs	= NULL;
	}
}

INT MtlQ3S::LoadTexture(void* pMdlLdr)
{
	CMdlLoader* pLoader = (CMdlLoader*)pMdlLdr;

	int iSize = vDff.size();
	
	if(!iSize)
		return 0;
	
	
	if(pTxs)		// �̹� �ε��Ǿ� ����
		return 0;
	
	pTxs = new PDTX[iSize];
	
	for(int i=0; i<iSize; ++i)
	{
		char	sFile[MAX_PATH]={0};
		strcpy(sFile, (char*)vDff[i].c_str());

		pTxs[i] = pLoader->LoadTexture(sFile);
	}
	
	return 1;
}


INT MtlQ3S::SetMaterial(PDEV pDev)
{
	return -1;
}


PDTX MtlQ3S::GetTexture(INT nIdx)
{
	if(!pTxs)
		return NULL;

	return pTxs[nIdx];
}


void MtlQ3S::Push_Files(char* sFile)
{
	vDff.push_back( sFile);
}


// Md3Mono Material Diffuse

MtlQ3M::MtlQ3M() : pMtl1(0), pMtl2(0), pMtl3(0)
{
	nTp		= MTL_MD3M;
}

MtlQ3M::~MtlQ3M()
{
	SAFE_DELETE(	pMtl1	);
	SAFE_DELETE(	pMtl2	);
	SAFE_DELETE(	pMtl3	);
}



INT MtlQ3M::LoadTexture(void* pMdlLdr)
{
	pMtl1->LoadTexture(pMdlLdr);
	pMtl2->LoadTexture(pMdlLdr);
	pMtl3->LoadTexture(pMdlLdr);
	
	return 1;
}


INT MtlQ3M::SetMaterial(PDEV pDev)
{
	return -1;
}


PDTX MtlQ3M::GetTexture(INT nM, INT nS)
{
	return pMtl[nM]->GetTexture(nS);
}


void MtlQ3M::SetMaterial(INT nM, MtlQ3S* _pMtl)
{
	pMtl[nM] = _pMtl;
}

MtlQ3S* MtlQ3M::GetMaterial(INT nM)
{
	return pMtl[nM];
}




MtlToon::MtlToon() : pTxToon(0)
{
	nTp = MTL_TOON;
	memset(Toon, 0, sizeof Toon);
}

MtlToon::~MtlToon()
{
//	SAFE_RELEASE(	pTxToon	);
}

INT MtlToon::LoadTexture(void* pMdlLdr)
{
	CMdlLoader* pLoader = (CMdlLoader*)pMdlLdr;
	pTxToon = pLoader->LoadTexture("AltToon01", sizeof(Toon)/sizeof(Toon[0]), 1);

	if(pTxToon)
		return 1;

	return -1;
}


INT MtlToon::SetMaterial(PDEV pDev)
{
	pDev->SetTexture(0, pTxDiff);
	pDev->SetTexture(1, pTxToon);
	return -1;
}




MtlAlt::MtlAlt()
{
}

MtlAlt::~MtlAlt()
{
}

INT MtlAlt::LoadTexture(void* pMdlLdr)
{
	return 1;
}


INT MtlAlt::SetMaterial(PDEV pDev)
{
	return 1;
}





// Gloss Effect =  Base + Reflect * Gloss �ε�
// Reflect�� �ݻ� ��, Gloss�� Normal ���� �̿�
// Base * normal + Reflect�� ��ó

MtlGloss::MtlGloss():pTxN(0),pTxS(0)
{
	nTp = MTL_GLOS;
	memset(sNrm, 0, sizeof(sNrm));
	memset(sSpc, 0, sizeof(sSpc));
}

MtlGloss::~MtlGloss()
{
//	SAFE_RELEASE(	pTxN	);
//	SAFE_RELEASE(	pTxS	);
}

INT MtlGloss::LoadTexture(void* pMdlLdr)
{
	CMdlLoader* pLoader = (CMdlLoader*)pMdlLdr;

	pTxDiff =pLoader->LoadTexture(sDff);
	
	if(NULL == pTxDiff)
		return -1;
	
	pTxN =pLoader->LoadTexture(sNrm);
	
	if(NULL == pTxN)
		return -1;
	
	pTxS =pLoader->LoadTexture(sSpc);
	
	if(NULL == pTxS)
		return -1;
	
	return 1;
}








IMdBase::IMdBase()
: m_nTp	((EMdlType)0)
, m_vcP	(0,0,0)
, m_mtR	(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
, m_mtS	(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
, m_mtL	(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
, m_mtW	(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
{
	m_pMdLdr	= NULL;													// Model Loader
	m_pDev		= NULL;
	fStlSrtR	= 0.f;
	fStlSrtD	= 0.f;
}

IMdBase::~IMdBase()
{
}

INT IMdBase::Load(char* sFile)
{
	return -1;
}

INT IMdBase::Save(char* sFile)
{
	return -1;
}

void IMdBase::SetLoader(void* pLoader)
{
	m_pMdLdr = pLoader;
}


void IMdBase::SetDevice(PDEV pDev)
{
	m_pDev = pDev;
}

void IMdBase::SetType(INT nTp)
{
	m_nTp = (EMdlType)nTp;
}

INT IMdBase::GetType()
{
	return (INT)m_nTp;
}

void IMdBase::SetPos(D3DXVECTOR3* p)
{
	m_vcP = *p;

	m_mtL._41 = m_vcP.x;
	m_mtL._42 = m_vcP.y;
	m_mtL._43 = m_vcP.z;
}

D3DXVECTOR3* IMdBase::GetPos() const
{
	return (D3DXVECTOR3*)&m_vcP;
}

void IMdBase::SetRot(D3DXMATRIX* mtR)
{
	m_mtR = *mtR;
}

D3DXMATRIX* IMdBase::GetRot() const
{
	return (D3DXMATRIX*)&m_mtR;
}

void IMdBase::SetScl(D3DXMATRIX* mtS)
{
	m_mtS = *mtS;
}

D3DXMATRIX* IMdBase::GetScl() const
{
	return (D3DXMATRIX*)&m_mtS;
}

void IMdBase::SetLcl(D3DXMATRIX* mtL)
{
	m_mtL = *mtL;

	m_vcP.x = m_mtL._41;
	m_vcP.y = m_mtL._42;
	m_vcP.z = m_mtL._43;
}

void IMdBase::SetLclT(D3DXMATRIX* mtL)
{
	m_mtL *= *mtL;
}

D3DXMATRIX* IMdBase::GetLcl() const
{
	return (D3DXMATRIX*)&m_mtL;
}


void IMdBase::SetDistCam(FLOAT _fR)
{
	fStlSrtR = _fR;
}