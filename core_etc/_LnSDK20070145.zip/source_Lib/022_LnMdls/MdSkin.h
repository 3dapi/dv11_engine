// Interface for the CMdSkin class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDSKIN_H_
#define _MDSKIN_H_


class CMdSkin : public IMdBase
{
public:
	
public:
	CMdSkin();
	virtual ~CMdSkin();

	virtual INT			Init();
	virtual void		Destroy();

	virtual INT			FrameMove();
	virtual void		Render();

public:
	virtual	MtlBase*	GetMtl();
	virtual	void		SetMtl(MtlBase* pM);

	virtual	IMshBase*	GetMsh();
	virtual	void		SetMsh(IMshBase* pM);
};

#endif

