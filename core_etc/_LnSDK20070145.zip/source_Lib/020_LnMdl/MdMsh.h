// Interface for the CMdMsh class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDMSH_H_
#define _MDMSH_H_


class CMdMsh
{
public:
	// For Rendering
	MdMtl*		pMtl	;

	INT			iNix	;														// Count Vertex Index
	INT			iNvx	;														// Count Vertex

	DWORD		dFVF	;														// FVF
	INT			iVxS	;														// vertex structure size

	VtxD		vbboxSrc[8];
	VtxD		vbboxDst[8];
	VtxIdx		vbboxIdx[12];

	VtxIdx*		pIdx	;														// Vertex Face Index
	void*		pVtx	;														// VtxD, VtxUV, VtxNUV, VtxNDUV	

	CMdMsh();
	virtual	~CMdMsh();

	void		SetMtrl	(MdMtl* _pMtl);
	MdMtl*		GetMtrl	();
	void		Render	();
	void		RenderBBox(INT nId);

	void		Copy(CMdMsh* pRhs);

	INT			PickingMouse(	VEC3  vcCamP									// Camera Position
							,	VEC3  vcRayD									// Picking Ray Direction
							);
	
	INT			UpdateBBox(MATA* mtWld);
};

#endif