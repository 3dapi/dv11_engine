// Interface for the CMd3 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _OBJREN_H_
#define _OBJREN_H_

class CAltMultiRen;
class CAltMonoRen : public CLnTree												// Md3 Section Class 
{
public:
	CAltMultiRen*	m_pMdPrnt;													// Parent Md3Render Data

public:
	INT			m_nAniTp;														// Animation Type (Model Type)
	INT			m_nPrt	;	//													// 1:HEAD 2:UPPER 3:LOWER 4:WEAPON

	// Mesh Data
	CMdMsh*		m_pMsh	;

	// Model Source Pointer
	AltMonoObj*	m_pMdoS	;														// Parsing Data Pointer

	INT			m_bWire	;
	INT			m_bLight	;
	INT			m_nCull	;

	MATA		m_mtSh0;
	MATA		m_mtSh1;

	MATA		m_mtLcl;
	MATA		m_mtWld;
	MATA		m_mtAni;

	MATA		m_mtViw;
	MATA		m_mtPrj;


	FLOAT		m_fBlendDt;
	DWORD		m_dwMdlBlend;

protected:
	virtual	INT		OnFrmMov();
	virtual void	OnRender();
	virtual void	OnRenderBBox(INT nId);
	virtual void	OnRenderEdge();

public:
	CAltMonoRen();
	virtual ~CAltMonoRen();
	

	MATA			GetWorldTm();
	INT				FrameMove();
	void			Render();
	void			RenderBBox(INT nId);
	void			RenderEdge();

	void			SetSilThk	(FLOAT vcDir);
	FLOAT			GetSilThk	();

	void			SetLgtDir	(VEC3 vcDir);
	VEC3			GetLgtDir	();

	void			SetMdlBlend(DWORD dw);
	void			SetWldMata(MATA mtWld)	{	m_mtWld = mtWld;	}

	CAltMonoRen*	SetMdPartPtr(INT	nPart);
	void			SetMdParent(CAltMultiRen*	pMdPrnt)	{	m_pMdPrnt = pMdPrnt;	}

	INT				SetPos(VEC3 pos);
	INT				SetRot(FLOAT fA);
	VEC3			GetPos();
	FLOAT			GetRot();
};


typedef	std::vector<CAltMonoRen*>	lsAltMonoRen;

#endif