// Implementation of the CMdMsh class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/_Cmm/LnVtxFmt.h>

#include <Ln/_D3D/D3DDriver.h>
#include <Ln/Util/LnUtil.h>

#include "AltMdStrt.h"
#include "MdMsh.h"


CMdMsh::CMdMsh()
:	dFVF	(0)
,	iNix	(0)	
,	iNvx	(0)
,	iVxS	(0)
,	pIdx	(0)
,	pMtl	(0)
,	pVtx	(0)
{
		//      /2----------------/3 //
		//     / |               /|  //
		//    /  |              / |  //
		//   /   |             /  |  //
		//  /0___|____________/1  |  //
		//  |    |6___________|___|7 //
		//  |   /             |   /  //
		//  |  /              |  /   //
		//  | /               | /    //
		//  |/4_______________|5     //

	vbboxIdx[ 0].a = 0; vbboxIdx[ 0].b = 1; vbboxIdx[ 0].c = 2;
	vbboxIdx[ 1].a = 3; vbboxIdx[ 1].b = 2; vbboxIdx[ 1].c = 3;
	vbboxIdx[ 2].a = 1; vbboxIdx[ 2].b = 5; vbboxIdx[ 2].c = 3;
	vbboxIdx[ 3].a = 7; vbboxIdx[ 3].b = 3; vbboxIdx[ 3].c = 5;
	vbboxIdx[ 4].a = 2; vbboxIdx[ 4].b = 6; vbboxIdx[ 4].c = 7;
	vbboxIdx[ 5].a = 2; vbboxIdx[ 5].b = 3; vbboxIdx[ 5].c = 7;
	vbboxIdx[ 6].a = 0; vbboxIdx[ 6].b = 4; vbboxIdx[ 6].c = 6;
	vbboxIdx[ 7].a = 0; vbboxIdx[ 7].b = 2; vbboxIdx[ 7].c = 6;
	vbboxIdx[ 8].a = 4; vbboxIdx[ 8].b = 6; vbboxIdx[ 8].c = 7;
	vbboxIdx[ 9].a = 4; vbboxIdx[ 9].b = 5; vbboxIdx[ 9].c = 7;
	vbboxIdx[10].a = 0; vbboxIdx[10].b = 4; vbboxIdx[10].c = 5;
	vbboxIdx[11].a = 0; vbboxIdx[11].b = 1; vbboxIdx[11].c = 5;


}

CMdMsh::~CMdMsh()
{
	SAFE_FREE(pIdx);
	SAFE_FREE(pVtx);
}

void	CMdMsh::SetMtrl(MdMtl* _pMtl)
{
	pMtl = _pMtl;
}

MdMtl*	CMdMsh::GetMtrl()
{
	return pMtl;
}


void CMdMsh::Render()
{
	///////////////////////////////////////////////////////////
	GDEVICE->SetFVF	(dFVF);
	GDEVICE->SetMaterial(&(pMtl->mtrl.m));
	GDEVICE->SetTexture(0, pMtl->pTxD);


	GDEVICE->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST
	, 0
	, iNvx
	, iNix
	, pIdx
	, D3DFMT_INDEX16
	, pVtx
	, iVxS	);

	GDEVICE->SetFVF	(VtxD::FVF);
}


void CMdMsh::Copy(CMdMsh* pRhs)
{
	this->pMtl = pRhs->pMtl;
	this->iNix = pRhs->iNix;
	this->iNvx = pRhs->iNvx;

	this->dFVF = pRhs->dFVF;
	this->iVxS = pRhs->iVxS;

	pIdx	= (VtxIdx*) malloc(iNix * sizeof(VtxIdx));
	pVtx	= malloc(iNvx * iVxS);

	memcpy(pIdx, pRhs->pIdx, iNix * sizeof(VtxIdx));
	memcpy(pVtx, pRhs->pVtx, iNvx * iVxS);
}

INT	CMdMsh::PickingMouse(VEC3  vcCamP, VEC3  vcRayD)
{
	FLOAT	U, V, D;

	VEC3	p0;
	VEC3	p1;
	VEC3	p2;

	for(INT i = 0 ; i < 12 ; i++)
	{
		p0 = vbboxSrc[vbboxIdx[i].a].p;
		p1 = vbboxSrc[vbboxIdx[i].b].p;
		p2 = vbboxSrc[vbboxIdx[i].c].p;

		if(D3DXIntersectTri( &p0, &p1, &p2, &vcCamP, &vcRayD, &U, &V, &D))
		{
			return 1;
		}
	}

	return -1;
}

void CMdMsh::RenderBBox(INT nId)
{
	///////////////////////////////////////////////////////////

	GDEVICE->SetFVF(VtxD::FVF);

	for(INT i = 0 ;  i < 8 ; i++)
		vbboxSrc[i].d = (DWORD)nId;

	GDEVICE->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST
	, 0
	, 8
	, 12
	, vbboxIdx
	, D3DFMT_INDEX16
	, vbboxSrc
	, sizeof(VtxD)	);

	GDEVICE->SetFVF	(VtxD::FVF);
}

INT	CMdMsh::UpdateBBox(MATA* mtWld)
{
	for(INT i = 0; i < 8 ; ++i)
	{
		// Character BBox Update
		D3DXVec3TransformCoord(&vbboxSrc[i].p, &vbboxDst[i].p, mtWld);
	}

	return 1; 
}