// Interface for the CAltMulti class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MD3_H_
#define _MD3_H_

class CAltMulti : public CMdB
{
public:


	TbAltMultiB*	m_pMdS;														// Model Source
	CAltMultiRen*	m_pMdO;
	lsMdRen			m_pMdR;														// Renderer Root

	BOOL			m_bAni;
	BOOL			m_bEdge;

	CAltMultiRen*	m_pMdHead;
	CAltMultiRen*	m_pMdUpper;
	CAltMultiRen*	m_pMdLower;

	VtxDUV1			m_VxShw[4];

	PDTX			m_pShwTx;
	BOOL			m_bShw;

	CAltMulti();
	virtual ~CAltMulti();

	INT				SetMdB(INT nM, INT nS, TbAltMultiB* pMdS);

	INT				GetNumVtx();
	INT				GetNumIdx();

	virtual	INT		Init();
	virtual	void	Destroy();
	virtual	INT		FrameMove();
	virtual	void	Render();

	virtual VEC3	GetPos();
	virtual void	SetPos(VEC3 pos);

	virtual void	RenderBBox();

	virtual FLOAT	GetRot();
	virtual void	SetRot(FLOAT fA);

	void			RenderShadow();
	INT				SetShadowTx(PDTX tx);

	FLOAT			GetSilThk();
	void			SetSilThk(FLOAT fThk);

	VEC3			GetLookVec();
	VEC3			GetRightVec();
	VEC3			GetUpVec();

	INT				SelectAni(INT Ani, BYTE type = 0);
	INT				SetPart();
	void			SetLgtDir	(VEC3 vcDir);
	void			SetMdlBlend(DWORD dw);

	INT				ChkBBox();

	VEC3			GetLgtDir	();


	CAltMultiRen*	FindPart(INT	nPrt);

	void			SetToonTxLv(D3DXCOLOR* t);
	void			SetToonTxLv(FLOAT* t);
	void			SetMtlToon(D3DXCOLOR* t);
	void			SetMtlToon(FLOAT* t);

	CAltMultiRen*	GetMdHead()		{	return m_pMdHead;	}
	CAltMultiRen*	GetMdUpper()	{	return m_pMdUpper;	}
	CAltMultiRen*	GetMdLower()	{	return m_pMdLower;	}
};

typedef std::vector<CAltMulti*>	lsMd3;
typedef	lsMd3::iterator			itMd3;

#endif