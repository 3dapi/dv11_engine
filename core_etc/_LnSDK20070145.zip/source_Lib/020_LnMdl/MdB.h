// Interface for the CMdB class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDB_H_
#define _MDB_H_

class CLnCam;
class CMdMsh;

class CMdB : public CLnRen
{
public:
	TCHAR		m_sFile[128];

	INT			m_nM;
	INT			m_nS;

	EMdlType	m_nTp;															// Model Type
	DWORD		m_iCode;														// Obj Code

	VEC3		m_vcP;															// Position
	VEC3		m_vcS;															// Scale
	MATA		m_mtW;															// World which is mtW = mtT * mtS * mtR

	FLOAT		fStlSrtD;														// Distance from Camera
	FLOAT		fStlSrtR;														// Z Direction Value

	FLOAT		m_fR;															// Rotation Radian Value

	FLOAT		m_fBr;															// Radius of Bounding
	VEC3		m_vcBb;															// bound Box width, Height, depth
	VEC3		m_vcBc;															// bound Box Center


	CMdB()
		: fStlSrtD	(0)
		, fStlSrtR	(0)
		, m_fR		(0)
		, m_fBr		(0)
		, m_vcBb	(0,0,0)
		, m_vcBc	(0,0,0)

		, m_vcP		(0,0,0)
		, m_vcS		(1,1,1)
		, m_mtW		(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
	{
		m_nTp	= MDL_NONE;
		m_iCode	= 0xFF006699;
	}

	virtual	INT		Init()=0;
	virtual	void	Destroy()=0;
	virtual	INT		FrameMove()=0;
	virtual	void	Render()=0;
	
	virtual	CMdMsh*	GetMsh()			{	return NULL;		}
	virtual	void	SetMsh(CMdMsh* pM)	{						}

	virtual	void	RenderBBox()=0;

public :
	virtual	FLOAT	GetSilThk() = 0;
	virtual	void	SetSilThk(FLOAT fThk) = 0;

	virtual	void	SetLgtDir	(VEC3 vcDir) = 0;
	virtual	void	SetMdlBlend(DWORD dw) = 0;

	virtual	VEC3	GetLgtDir	() = 0;

	virtual	void	SetToonTxLv(D3DXCOLOR* t) = 0;
	virtual	void	SetToonTxLv(FLOAT* t) = 0;
	virtual void	SetMtlToon(D3DXCOLOR* t) = 0;
	virtual void	SetMtlToon(FLOAT* t) = 0;

	virtual VEC3	GetPos()=0;
	virtual void	SetPos(VEC3 pos)=0;

	virtual FLOAT	GetRot()=0;
	virtual void	SetRot(FLOAT fA)=0;

public :
	void			SetCode(INT iCode)		{	m_iCode = iCode;	}
	INT				GetCode()				{	return m_iCode;		}

	void			SetType(INT nTp)		{	m_nTp = (EMdlType)nTp;	}
	INT				GetType()				{	return (INT)m_nTp;		}
};


typedef std::vector<CMdB*>	lsMdB;
typedef lsMdB::iterator		itMdB;

#endif