// Interface for the MdStructures.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MDSTRT_H_
#define _MDSTRT_H_


#define	TOON_DEVIDE_COUNT	16

enum EMdlType
{
	MDL_NONE	=0,
	MDL_Q3CHA	=1,
	MDL_Q3OBJ	=2,
	MDL_BILL	=12,
	MDL_SOLID	=13,
};

enum ETagPart
{
	NO_TAG =0,
	HEAD_TAG_HEAD,
	UPPER_TAG_HEAD,
	UPPER_TAG_WEAPON,
	UPPER_TAG_TORSO,
	LOWER_TAG_TORSO,
};

enum EMdlPart
{
	PART_HEAD = 1,
	PART_UPPER,
	PART_LOWER,
	PART_WEAPON,
};


enum EAniPart
{
	ANIPART_BOTH=1,
	ANIPART_TORSO,
	ANIPART_LEGS,
};

enum EFileType
{
	FILE_MULTIMD3 = 0,
	FILE_MULTIBIN,
	FILE_MONOMD3,
	FILE_MONOBIN,
};

#define EXT_MULTIMD3	"md3"
#define EXT_MULTIBIN	"q3b"
#define EXT_MONOMD3		"md3"
#define EXT_MONOBIN		"qwb"

typedef enum tagETbKeyMdl
{
	LNMDL,			
		MDNAME,		
		NUMTRK,		
		NUMTAG,		
		NUMMTL,		
		NUMOBJ,		
		TICKFR,		
		MDLTYPE,	
		ANITYPE,	
		TOTFRM,		
		TPATH,		
		TBLTRK,
		TBLTAG,
			NTGCD,
			STGNM,
			NTGFR,
			MTTAG,
		TBLMTR,
			DIFFU,	
			AMBIE,
			SPECU,
			EMISS,
			OPACI,
			TOONP,
			POWER,	
			TEXDF,
			TEXNR,
			TEXSP,
			TEXDS,
		TBLOBJ,		
			NAME,
			NOBJT,
			PRNTID,
			TMLCL0,
			TMLCL1,
			TMLCL2,
			TMLCL3,
			TMWLD0,
			TMWLD1,	
			TMWLD2,
			TMWLD3,
			BOXMAX,
			BOXMIN,
			BOXCEN,
			TMLCL	,
			TMWLD	,
			BBOX	,
			NUMKEY,
			NUMIDX,	
			NUMVTX,
			NUMUV	,
			NUMIXUV,
			NUMPKEY,
			NUMRKEY,
			NUMSKEY,
			DMTRL	,
			VCLGT	,
			SLTHK	,
			FCEIDX,
				LNRC,
			VERTEX,	
			VTXNR,
			VTXUV,
			FCEUVIDX,
			POSKEY,
			ROTKEY,
			SCLKEY,
			VTXUVT,
			FRM	,
			VTXFVF,
			VTXSZE,
}ETbKeyMdl;


typedef enum tagAniKey
{
	BOTH_DEATH1	= 0	,	//	0
	BOTH_DEAD1		,
	BOTH_DEATH2		,
	BOTH_DEAD2		,
	BOTH_SPAWN		,
	BOTH_SIT		,
	BOTH_WAKE		,
	BOTH_HANDLE		,
	BOTH_EXTRA0		,
	BOTH_EXTRA1		,
	BOTH_EXTRA2		,
	BOTH_EXTRA3		,
	TORSO_W0_IDLE1	,
	TORSO_W0_IDLE2	,
	TORSO_W0_WALK_IDLE1,
	TORSO_W0_RUN_IDLE1,
	TORSO_W0_BACK_IDLE1,
	TORSO_W0_JUMP_IDLE1,
	TORSO_W0_ATTACK1,
	TORSO_W0_ATTACK2,
	TORSO_W0_DAMAGE	,
	TORSO_W0_RAISE	,
	TORSO_W0_CLOSE	,
	TORSO_W1_IDLE1	,
	TORSO_W1_IDLE2	,
	TORSO_W1_WALK_IDLE1,
	TORSO_W1_RUN_IDLE1,
	TORSO_W1_BACK_IDLE1,
	TORSO_W1_JUMP_IDLE1,
	TORSO_W1_ATTACK1,
	TORSO_W1_ATTACK2,
	TORSO_W1_DAMAGE	,
	TORSO_W1_RAISE	,
	TORSO_W1_CLOSE	,
	TORSO_W2_IDLE1	,
	TORSO_W2_IDLE2	,
	TORSO_W2_WALK_IDLE1,
	TORSO_W2_RUN_IDLE1,
	TORSO_W2_BACK_IDLE1,
	TORSO_W2_JUMP_IDLE1,
	TORSO_W2_ATTACK1,
	TORSO_W2_ATTACK2,
	TORSO_W2_DAMAGE	,
	TORSO_W2_RAISE	,
	TORSO_W2_CLOSE	,
	LEGS_STAND		,
	LEGS_WALK		,
	LEGS_RUN		,
	LEGS_LEFTSTEP	,
	LEGS_RIGHTSTEP	,
	LEGS_BACK		,
	LEGS_JUMP		,
	LEGS_LAND		,
	MAX_ANIKEY
}AniKey;

///////////////////////////////	Md3	Bgn	////////////////////////////////////////

typedef struct stMdMtl
{
	INT		nIdx;
	XMTL	mtrl;
	FLOAT	fOpc;
	FLOAT	Toon[TOON_DEVIDE_COUNT];

	PDTX	pTxD;

	CHAR	sDff[128];

	stMdMtl():pTxD(0)
	{
		memset(Toon, 0, sizeof(FLOAT) * TOON_DEVIDE_COUNT);
		memset(sDff, 0, sizeof(sDff));
	}
	virtual ~stMdMtl()
	{
		SAFE_RELEASE(	pTxD	);
	}

	stMdMtl& operator=(const stMdMtl& v)		
	{
		nIdx	=	v.nIdx;
		mtrl	=	v.mtrl;
		fOpc	=	v.fOpc;

		memcpy(Toon, v.Toon, sizeof(FLOAT) * TOON_DEVIDE_COUNT);
		memcpy(pTxD, v.pTxD, sizeof(IDirect3DTexture9));

		memcpy(sDff, v.sDff, 128);
	}
}MdMtl;

typedef struct stMdTag
{
	TCHAR		sTgNm[128]	;													// Tag Name
	INT			nTgCd		;													// Tag Type	2:tag_head
																				//			3:tag_torso
																				//			4:tag_Weapon
																				//			-1:Object
	INT			nTgFr		;													// Tag Frame
	MATA*		mtTag		;													// Tag Matrix

	stMdTag()
	{
		memset(sTgNm, 0, sizeof(sTgNm));
		nTgCd = 0;
		nTgFr = 0;
		mtTag = 0;
	}
	virtual ~stMdTag()
	{
		SAFE_DELETE_ARRAY(mtTag);
	}
}MdTag;

typedef struct stAltMultiTrk
{
	INT		Index		;														// Animation Index
	TCHAR	sTrNm[128]	;														// Animation Name
	INT		nBgFr		;
	INT		nEdfr		;
	INT		iNloop		;
	INT		nTick		;
	INT		nPart		;														// Animation Part
																				// 1 : BOTH
																				// 2 : TORSO
																				// 3 : LEGS
	stAltMultiTrk()
		:	Index(0)
		,	nBgFr(0)
		,	nEdfr(0)
		,	iNloop(0)
		,	nTick(0)
		,	nPart(0)
	{
		memset(sTrNm, 0, sizeof(sTrNm));
	}

	virtual ~stAltMultiTrk()
	{
		
	}

}AltMultiTrk;


typedef struct stMdVec
{
	VEC3*	vec;
	stMdVec():	vec(0){}
	virtual ~stMdVec()
	{
		SAFE_DELETE_ARRAY(vec);
	}
}MdVec;

typedef struct stAltMultiAni
{
	FLOAT		nFm		;														// Maximum Frame
	FLOAT		nFc		;														// Current Frame
	FLOAT		nFn		;														// Next Frame
	FLOAT		nFb		;														// Begin Frame
	FLOAT		nFf		;														// Final Frame

	FLOAT		nFbPrev	;														// Previous Begin Frame
	FLOAT		nFfPrev	;														// Previous Final Frame 
	

	INT			nLc		;														// Current Loop Count
	INT			nLf		;														// Final Loop Count

	INT			nCAni	;														// Num Current Ani
	FLOAT		nTick	;														// Frame per second 
	FLOAT		fpol	;														// interpolation
	FLOAT		fRoll, fPitch, fYaw;
	VEC3		vCLook	;														// Current Look Vector
	VEC3		vPos	;

	BOOL		bWire	;														// Is Render by WireFrame
	BOOL		bLight	;														// is Lighting
	BOOL		nCull	;														// Cull Mode
	BOOL		bChangeAni; 

	stAltMultiAni()
	{
		nFm		= 0.f;
		nFc		= 0.f;
		nFn		= 0.f;
		nFb		= 0.f;
		nFf		= 0.f;
		nFbPrev	= 0.f;
		nFfPrev	= 0.f;
	
		nLc		= 0;
		nLf		= 0;

		nCAni	= 0;
		nTick	= 1;
		fpol	= 0.f;
		fRoll	= 0.f;
		fPitch	= 0.f;
		fYaw	= 0.f;
		vCLook	= VEC3(0,0,0);
		vPos	= VEC3(0,0,0);;

		bWire	= FALSE;
		bLight	= FALSE;
		nCull	= FALSE;
	}
}AltMultiAni;

class CMdMsh;
typedef struct stAltMultiObj
{
	INT			nIdx	;														// Object nID
	TCHAR		sObNm[64];														// Object Name
	INT			nObjT	;														// Object Type
																					//	1: Head
																					//	2: Upper
																					//	3: Lower

	INT			nIdPr	;														// Object Parent nID

	MATA		mtLcl	;														// Local Transform Matrix
	MATA		mtWld	;														// World Transform Matrix

	VEC3		vcBMa	;														// Bounding Box Maximum 
	VEC3		vcBMi	;														// Bounding Box Minimum
	VEC3		vcBCe	;														// Bounding Box Center

	INT			iNix	;														// Count Vertex Index
	INT			iNvx	;														// Count Vertex
	INT			iNvxN	;														// Count Vertex Normal
	INT			iNuv	;														// Count Texture UV

	INT			iNkey	;														// Frame Count
	INT			iNtag	;														// Tag Count
	INT			iNtrk	;														// Track Count

	DWORD		dFVF	;														// FVF

	INT			iSze	;														// sizeof vertex

	INT			nMtrl	;														// Material ID

	AltMultiTrk*	pTrk	;
	MdTag*		pTag	;														// Tag Struct

	MdMtl*		pMtrl	;														// Material Object

	VtxIdx*		pIdx	;														// Vertex Face Index
	MdVec*		pVtxP	;														// Vertex
	VEC3*		pVtxN	;														// Vertex Normal
	VEC2*		pUVT	;														// Texture UV

	PDVS		pVS		;														// Shader

	PDTX		pTxToon	;														// Toon Texture
	VEC3		vcLgt	;														// Lighting Direction

	FLOAT		fSilThk;														// toon edge Thick
	VtxNDUV1*	pvtxedge;														// toon edge (Silhouette)

	stAltMultiObj()
		:	nIdx	(-1)
		,	nIdPr	(-1)
		,	iNix	(0)
		,	iNvx	(0)
		,	iNvxN	(0)
		,	iNuv	(0)
		,	iNkey	(0)
		,	iNtag	(0)
		,	iNtrk	(0)
		,	dFVF	(0)
		,	iSze	(0)
		,	nMtrl	(0)
		,	pMtrl	(0)
		,	pTag	(0)
		,	pTrk	(0)
		,	pIdx	(0)
		,	pVtxP	(0)
		,	pVtxN	(0)
		,	pUVT	(0)
		,	pVS		(0)
		,	pTxToon	(0)
	{
		vcLgt = VEC3(0.f, 10.f, 1.f);
		memset(sObNm, 0, sizeof(sObNm));
		D3DXMatrixIdentity(&mtLcl);
		D3DXMatrixIdentity(&mtWld);
		fSilThk	= 3.f;
		pvtxedge	= NULL;
	}

	virtual ~stAltMultiObj()
	{
		SAFE_DELETE_ARRAY	(	pIdx	);
		SAFE_DELETE_ARRAY	(	pVtxP	);

		SAFE_DELETE_ARRAY	(	pVtxP	);
		SAFE_DELETE_ARRAY	(	pVtxN	);

		SAFE_DELETE_ARRAY	(	pvtxedge);

		SAFE_DELETE_ARRAY	(	pUVT	);
		SAFE_RELEASE		(	pVS		);
	}
}AltMultiObj;

typedef struct stAltMonoObj
{
	INT			nIdx	;														// Object nID
	TCHAR		sObNm[64];														// Object Name
	INT			nObjT	;														// Object Type
																					//	1: Head
																					//	2: Upper
																					//	3: Lower
																					//	4: Weapon

	INT			nIdPr	;														// Object Parent nID
	INT			iNix	;														// Count Vertex Index
	INT			iNvx	;														// Count Vertex
	INT			iNvxN	;														// Count Vertex Normal
	INT			iNuv	;														// Count Texture UV


	DWORD		dFVF	;														// FVF
	INT			iSze	;														// sizeof vertex

	INT			nMtrl	;														// Material ID

	MdMtl*		pMtrl	;														// Material Object

	VtxIdx*		pIdx	;														// Vertex Face Index
	VEC3*		pVtxP	;														// Vertex
	VEC3*		pVtxN	;														// Vertex Normal
	VEC2*		pUVT	;														// Texture UV

	PDVS		pVS		;														// Shader

	PDTX		pTxToon	;														// Toon Texture
	VEC3		vcLgt	;														// Lighting Direction

	FLOAT		fSilThk;														// toon edge Thick
	VtxNDUV1*	pvtxedge;														// toon edge (Silhouette)

	stAltMonoObj()
		:	nIdx	(-1)
		,	nIdPr	(-1)
		,	iNix	(0)
		,	iNvx	(0)
		,	iNvxN	(0)
		,	iNuv	(0)
		,	dFVF	(0)
		,	iSze	(0)
		,	nMtrl	(0)
		,	pMtrl	(0)
		,	pIdx	(0)
		,	pVtxP	(0)
		,	pVtxN	(0)
		,	pUVT	(0)
		,	pVS		(0)
		,	pTxToon	(0)
	{
		vcLgt		= VEC3(0.f, 10.f, 1.f);
		memset(sObNm, 0, sizeof(sObNm));
		fSilThk		= 3.f;
		pvtxedge	= NULL;
	}

	virtual ~stAltMonoObj()
	{
		SAFE_DELETE_ARRAY	(	pIdx	);
		SAFE_DELETE_ARRAY	(	pVtxP	);

		SAFE_DELETE_ARRAY	(	pVtxP	);
		SAFE_DELETE_ARRAY	(	pVtxN	);

		SAFE_DELETE_ARRAY	(	pvtxedge);

		SAFE_DELETE_ARRAY	(	pUVT	);
		SAFE_RELEASE		(	pVS		);
	}
}AltMonoObj;


typedef std::vector<AltMultiTrk>	lsMdTrk;


class CMdMsh;

typedef struct stTbAltMultiB														// Blame Model Resource for Parsing Data..
{
	TCHAR		sName[255];														// �� �̸�.
	INT			iNtrk	;														// Animation �� ���� (��� �ʿ����. ���� Fix)
	INT			iNtag	;														// Tag�� ����
	INT			iNmtl	;														// ��Ʈ������ ���� 
	INT			iNobj	;
	INT			iNfrm	;
	INT			nTick	;
	INT			nAniT	;														// 0 : Animation ����	1: KeyFrmae ���	2: Bone Frame ���
	INT			nMdlT	;														// 0 : Character		1: Object			2: Equipment

	CHAR		sV[16]	;

	VEC3		vBBox[8];														// Bounding Box

	AltMultiTrk*	pTrk	;														// Animation Track Data
	MdTag*			pTag	;														// Tag Struct

	MdMtl*			pMdM	;														// Material
	AltMultiObj*	pMdO	;														// Object

	CMdMsh*			pMsh	;

	stTbAltMultiB()
		:	iNmtl	(0)
		,	iNobj	(0)
		,	nAniT	(0)
		,	nMdlT	(0)
		,	iNtrk	(0)
		,	pTrk	(0)
		,	pTag	(0)
		,	pMdM	(0)
		,	pMdO	(0)
		,	pMsh	(0)
	{
		memset(sName, 0, sizeof(sName));
		memset(sV, 0, sizeof(sV));
	}
	virtual ~stTbAltMultiB()
	{
		SAFE_DELETE_ARRAY(	pTrk	);
		SAFE_DELETE_ARRAY(	pTag	);

		SAFE_DELETE_ARRAY(	pMdM	);
		SAFE_DELETE_ARRAY(	pMdO	);
	}
}TbAltMultiB;


typedef struct stTbAltMonoB														// Blame Model Resource for Parsing Data..
{
	TCHAR		sName[255];														// �� �̸�.
	INT			iNmtl	;														// ��Ʈ������ ���� 
	INT			iNobj	;
	INT			nTick	;
	INT			nAniT	;														// 0 : Animation ����	1: KeyFrmae ���	2: Bone Frame ���
	INT			nMdlT	;														// 0 : Character		1: Object			2: Equipment

	CHAR		sV[16]	;

	MdMtl*		pMdM	;														// Material
	AltMonoObj*	pMdO	;														// Object

	CMdMsh*		pMsh	;

	stTbAltMonoB()
		:	iNmtl	(0)
		,	iNobj	(0)
		,	nTick	(0)
		,	nAniT	(0)
		,	nMdlT	(0)
		,	pMdM	(0)
		,	pMdO	(0)
		,	pMsh	(0)
	{
		memset(sName, 0, sizeof(sName));
		memset(sV, 0, sizeof(sV));
	}
	virtual ~stTbAltMonoB()
	{
		SAFE_DELETE_ARRAY(	pMdM	);
		SAFE_DELETE_ARRAY(	pMdO	);
	}
}TbAltMonoB;


#endif