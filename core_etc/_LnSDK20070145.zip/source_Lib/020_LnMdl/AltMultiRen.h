// Interface for the CMd3 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MD3REN_H_
#define _MD3REN_H_


class CAltMultiRen : public CLnTree												// Md3 Section Class 
{
public:
	INT			m_nAniTp;														// Animation Type (Model Type)
	INT			m_nPrt	;														// 1:HEAD 2:UPPER 3:LOWER 4:WEAPON

	AltMultiAni*	m_pAni	;
	AltMultiObj*	m_pMdoS	;													// Parsing Data Pointer
	CMdMsh*		m_pMsh	;

	MATA		m_mtLcl	;														// Local Transform Matrix
	MATA		m_mtWld	;														// World Transform Matrix
	MATA		m_mtAni	;														// Animation Transform Matrix
	MATA		m_mtC		;														// Parent Current Frame Matrix
	MATA		m_mtN		;														// Parent Next Frame Matrix

	MATA		m_mtSh0;
	MATA		m_mtSh1;
	MATA		m_mtViw;
	MATA		m_mtPrj;

	INT			m_bWire	;
	INT			m_bLight	;
	INT			m_nCull	;
	FLOAT		m_fBlendDt;
	DWORD		m_dwMdlBlend;

protected:
	virtual	INT		OnFrmMov();
	virtual void	OnRender();
	virtual void	OnRenderEdge();
	virtual void	OnRenderBBox(INT nId);

	virtual INT		OnSelectAni(INT nAni, BYTE type);
	virtual INT		OnChkBBox();

public:
	CAltMultiRen();
	virtual ~CAltMultiRen();
	

	MATA			GetWorldTm();
	INT				FrameMove();
	void			Render();
	void			RenderEdge();
	void			RenderBBox(INT nId);

	INT				ChkBBox();
	CAltMultiRen*	SetMdPartPtr(INT	nPart);

	void			SetSilThk	(FLOAT vcDir);
	FLOAT			GetSilThk	();

	void			SetLgtDir	(VEC3 vcDir);
	VEC3			GetLgtDir	();

	INT				SelectAni(INT nAni, BYTE type = 0);
	INT				GetKey();


	void			SetMdlBlend(DWORD dw);

	INT				SetPos(VEC3 pos);
	INT				SetRot(FLOAT fA);
	VEC3			GetPos();
	FLOAT			GetRot();

	VEC3			GetLookVec();
	VEC3			GetRightVec();
	VEC3			GetUpVec();
};


typedef	std::vector<CAltMultiRen*>	lsMdRen;

#endif