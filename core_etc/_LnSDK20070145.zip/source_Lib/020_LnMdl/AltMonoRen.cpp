
#include <windows.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/_Cmm/LnTree.h>
#include <Ln/_Cmm/LnVtxFmt.h>

#include <Ln/Euclid/LnEuclid.h>

#include <Ln/Util/LnUtil.h>
#include <Ln/Util/LnUtilDx.h>

#include <Ln/_D3D/D3DDriver.h>

#include "AltMdStrt.h"
#include "MdMsh.h"
#include "MdB.h"																// Model
#include "AltMonoRen.h"															// Model
#include "AltMultiRen.h"															// Model Md3

CAltMonoRen::CAltMonoRen()
:	m_nAniTp	(0)
,	m_nPrt		(0)
,	m_pMsh		(0)
,	m_pMdPrnt	(0)
,	m_pMdoS		(0)
,	m_bWire		(0)
,	m_bLight	(1)
,	m_nCull		(0)
{
	m_fBlendDt = -0.01f;
	D3DXMatrixIdentity(&m_mtSh0);
	D3DXMatrixIdentity(&m_mtSh1);
	D3DXMatrixIdentity(&m_mtLcl);
	D3DXMatrixIdentity(&m_mtWld);
	D3DXMatrixIdentity(&m_mtAni);
	D3DXMatrixIdentity(&m_mtViw);
	D3DXMatrixIdentity(&m_mtPrj);

	m_dwMdlBlend = 0xFFFFFFFF;
}

CAltMonoRen::~CAltMonoRen()
{
	SAFE_DELETE(m_pMsh);
}

INT CAltMonoRen::FrameMove()
{
	OnFrmMov();

	if (HasChild())
	{
		((CAltMonoRen*)pC)->FrameMove();
	}	
	if (HasParent() && !IsSiblingL())
	{
		((CAltMonoRen*)pN)->FrameMove();
	}

	return 1;
}

void	CAltMonoRen::RenderEdge()
{
	OnRenderEdge();																// �ڽ��� ���� �׸���.
	
	if (HasChild())																// �ڽ��� �׸���.
		((CAltMonoRen*)pC)->RenderEdge();
	
	if (HasParent() && !IsSiblingL())											// �̿��� ���Ḧ �׸���.
		((CAltMonoRen*)pN)->RenderEdge();
}

void CAltMonoRen::Render()														// ������...
{
	OnRender();																	// �ڽ��� ���� �׸���.

	if (HasChild())																// �ڽ��� �׸���.
		((CAltMonoRen*)pC)->Render();

	if (HasParent() && !IsSiblingL())											// �̿��� ���Ḧ �׸���.
		((CAltMonoRen*)pN)->Render();
}

void CAltMonoRen::RenderBBox(INT nId)											// Bounding Box Rendering
{
	OnRenderBBox(nId);															// �ڽ��� ���� �׸���.

	if (HasChild())																// �ڽ��� �׸���.
		((CAltMultiRen*)pC)->RenderBBox(nId);

	if (HasParent() && !IsSiblingL())											// �̿��� ���Ḧ �׸���.
		((CAltMultiRen*)pN)->RenderBBox(nId);
}

void	CAltMonoRen::SetSilThk(FLOAT fThk)
{
	m_pMdoS->fSilThk = fThk;

	if (HasChild())																// �ڽ��� �׸���.
		((CAltMonoRen*)pC)->SetSilThk(fThk);

	if (HasParent() && !IsSiblingL())											// �̿��� ���Ḧ �׸���.
		((CAltMonoRen*)pN)->SetSilThk(fThk);

}

FLOAT	CAltMonoRen::GetSilThk()
{
	return m_pMdoS->fSilThk;
}


VEC3	CAltMonoRen::GetLgtDir()
{
	return m_pMdoS->vcLgt;
}

void	CAltMonoRen::SetLgtDir(VEC3 vcDir)
{
	m_pMdoS->vcLgt = vcDir;
	
	if (HasChild())																// �ڽ��� �׸���.
		((CAltMonoRen*)pC)->SetLgtDir(vcDir);

	if (HasParent() && !IsSiblingL())											// �̿��� ���Ḧ �׸���.
		((CAltMonoRen*)pN)->SetLgtDir(vcDir);
}

void CAltMonoRen::SetMdlBlend(DWORD dw)
{
	m_dwMdlBlend = dw;

	if (HasChild())																// �ڽ��� �׸���.
		((CAltMonoRen*)pC)->SetMdlBlend(dw);

	if (HasParent() && !IsSiblingL())											// �̿��� ���Ḧ �׸���.
		((CAltMonoRen*)pN)->SetMdlBlend(dw);	
}

CAltMonoRen*	CAltMonoRen::SetMdPartPtr(INT	nPart)
{
	CAltMonoRen* pPrt = 0;
	if(m_nPrt == nPart)
		return this;

	if (HasChild())
	{
		pPrt = ((CAltMonoRen*)pC)->SetMdPartPtr(nPart);
		if(pPrt)
			return pPrt;
	}	
	if (HasParent() && !IsSiblingL())
	{
		pPrt = ((CAltMonoRen*)pN)->SetMdPartPtr(nPart);
		if(pPrt)
			return pPrt;
	}

	return NULL;
}

INT CAltMonoRen::OnFrmMov()
{
	MATA mtR;
	D3DXMatrixIdentity(&mtR);

	if(m_pMdPrnt)
	{
		for(INT i = 0 ; i < m_pMdPrnt->m_pMdoS->iNtag ; ++i)
		{
			if(m_pMdPrnt->m_pMdoS->pTag[i].nTgCd == UPPER_TAG_WEAPON)
			{
				FLOAT	fcp = 0.f ;
				FLOAT	fnp = 0.f ;

				fcp = m_pMdPrnt->m_pAni->nFc;
				fnp = m_pMdPrnt->m_pAni->nFn;

				MATA	mtC = m_pMdPrnt->m_pMdoS->pTag[i].mtTag[(INT)fcp];
				MATA	mtN = m_pMdPrnt->m_pMdoS->pTag[i].mtTag[(INT)fnp];

				FLOAT	fpol = m_pMdPrnt->m_pAni->fpol;
				QUAT	quatFromMatrix, quatFromMatrix2, quatResult;

				// quaternion m_pAni->fpolation 
				D3DXQuaternionRotationMatrix(&quatFromMatrix, &mtC);
				D3DXQuaternionRotationMatrix(&quatFromMatrix2, &mtN);
				D3DXQuaternionSlerp(&quatResult, &quatFromMatrix, &quatFromMatrix2, fpol);
				D3DXMatrixRotationQuaternion(&m_mtAni, &quatResult);

				m_mtAni._41 = mtC._41 + fpol * (mtN._41 - mtC._41);
				m_mtAni._42 = mtC._42 + fpol * (mtN._42 - mtC._42);
				m_mtAni._43 = mtC._43 + fpol * (mtN._43 - mtC._43);
				m_mtAni._44 = 1.0f; m_mtAni._14 = m_mtAni._24 = m_mtAni._34 = 0.f;

				m_mtWld = m_mtLcl * m_mtAni;

				// ���� posŰ���� ������ local TM�� ��ǥ�� ����Ѵ�
				if( (m_mtAni._41 == 0.0f) && (m_mtAni._42 == 0.0f) && (m_mtAni._43 == 0.0f) )
				{
					m_mtWld._41 = m_mtLcl._41;
					m_mtWld._42 = m_mtLcl._42;
					m_mtWld._43 = m_mtLcl._43;
				}
				else																		// posŰ���� ��ǥ������ �����Ѵ�(�̷��� ���� ������ TM�� pos������ �ι�����ȴ�)
				{
					m_mtWld._41 = m_mtAni._41;
					m_mtWld._42 = m_mtAni._42;
					m_mtWld._43 = m_mtAni._43;
				}

				m_mtWld	= m_mtWld * m_pMdPrnt->m_mtWld;								// �θ� ��Ʈ������ ���Ѵ�.

			}
		}
	}



	mtR = m_mtWld;

	mtR._41 = 0.f;
	mtR._42 = 0.f;
	mtR._43 = 0.f;

	for(INT i = 0; i < m_pMsh->iNvx ; ++i)
	{
		if( m_pMsh->dFVF == (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX1))
		{
			if((m_pMsh->iNvx == m_pMdoS->iNvx) || (m_pMdoS->iNuv == 0))
			{
				D3DXVec3TransformCoord(&(((VtxNDUV1*)(m_pMsh->pVtx))[i].p), &m_pMdoS->pVtxP[i], &m_mtWld);
				D3DXVec3TransformCoord(&(((VtxNDUV1*)(m_pMsh->pVtx))[i].n), &m_pMdoS->pVtxN[i], &mtR);
			}
		}

		((VtxNDUV1*)(m_pMsh->pVtx))[i].d = m_dwMdlBlend;
	}

	return 1;
}


void CAltMonoRen::OnRenderBBox(INT nId)
{
	if(!m_pMsh->pVtx)
		return;


// Set the constants...
	for(int i=0; i<8; ++i)
	{
		GDEVICE->SetTexture(i, 0);
		GDEVICE->SetTextureStageState (i, D3DTSS_COLOROP, D3DTOP_DISABLE);
		GDEVICE->SetTextureStageState (i, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	}

	GDEVICE->SetTextureStageState(0, D3DTSS_COLOROP,  D3DTOP_SELECTARG2);
	GDEVICE->SetTextureStageState(0, D3DTSS_COLORARG2,  D3DTA_DIFFUSE);
	GDEVICE->SetTextureStageState(0, D3DTSS_ALPHAOP,  D3DTOP_DISABLE);

	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	GDEVICE->SetRenderState(D3DRS_ZENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_AMBIENT, 0xFFFFFFFF);

	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	GDEVICE->SetRenderState(D3DRS_LIGHTING,	FALSE);

///////////////////////////Blend///////////////////////////
	GDEVICE->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	GDEVICE->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );
////////////////////////////////////////////////////////////////////////////

	GDEVICE->SetTexture(0, 0);

	m_pMsh->RenderBBox(nId);

//	GDEVICE->SetSamplerState(1, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
//	GDEVICE->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
//	GDEVICE->SetSamplerState(1, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
}

void CAltMonoRen::OnRenderEdge()
{
	if(!m_pMsh->pVtx)
		return;

	// Set the constants...
	for(int i=0; i<8; ++i)
	{
		GDEVICE->SetTexture(i, 0);
		GDEVICE->SetTextureStageState (i, D3DTSS_COLOROP, D3DTOP_DISABLE);
		GDEVICE->SetTextureStageState (i, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	}


	memcpy(m_pMdoS->pvtxedge,m_pMsh->pVtx, sizeof(VtxNDUV1) * m_pMsh->iNvx);

	for(INT x = 0 ; x < m_pMsh->iNvx ; x++)
	{
		D3DXVec3Normalize(&m_pMdoS->pvtxedge[x].n, &m_pMdoS->pvtxedge[x].n);
		m_pMdoS->pvtxedge[x].p +=  ((m_pMdoS->pvtxedge[x].n / 8.f) + m_pMdoS->pvtxedge[x].n / m_pMdoS->fSilThk);
	}

	D3DMATERIAL9 pmtr;

	pmtr.Ambient.r = 0.f;
	pmtr.Ambient.g = 0.f;
	pmtr.Ambient.b = 0.f;
	pmtr.Ambient.a = 0.5f;

	pmtr.Diffuse.r = 0.f;
	pmtr.Diffuse.g = 0.f;
	pmtr.Diffuse.b = 0.f;
	pmtr.Diffuse.a = 0.5f;

	pmtr.Emissive.r = 0.f;
	pmtr.Emissive.g = 0.f;
	pmtr.Emissive.b = 0.f;
	pmtr.Emissive.a = 0.5f;

	pmtr.Specular.r = 0.f;
	pmtr.Specular.g = 0.f;
	pmtr.Specular.b = 0.f;
	pmtr.Specular.a = 0.5f;

//	pmtr.Power		= 1.f;

	GDEVICE->SetMaterial(&pmtr);


	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
	GDEVICE->SetRenderState(D3DRS_AMBIENT, 0xFFFFFFFF);
	GDEVICE->SetRenderState(D3DRS_LIGHTING,	TRUE);

	GDEVICE->SetRenderState(D3DRS_ALPHATESTENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_ALPHAREF, 0x80);
	GDEVICE->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);

	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	GDEVICE->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	GDEVICE->SetFVF	(m_pMsh->dFVF);
	GDEVICE->SetTexture(0, m_pMdoS->pTxToon);
	GDEVICE->DrawIndexedPrimitiveUP( D3DPT_TRIANGLELIST
	, 0
	, m_pMsh->iNvx
	, m_pMsh->iNix
	, m_pMsh->pIdx
	, D3DFMT_INDEX16
	, m_pMdoS->pvtxedge
	, m_pMsh->iVxS	);

	GDEVICE->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
}

void CAltMonoRen::OnRender()															// Rendering ���� ����
{
	m_mtViw = GDRIV->GetMatrixView();
	m_mtPrj = GDRIV->GetMatrixProj();

	m_mtSh0 = m_mtViw * m_mtPrj;

	if(!m_pMsh->pVtx)
		return;

	GDEVICE->SetVertexShader(m_pMdoS->pVS);											// Shader Code

// Set the constants...
	VEC4 vclgt = VEC4(m_pMdoS->vcLgt.x, m_pMdoS->vcLgt.y, m_pMdoS->vcLgt.z, 0.f);
	LnD3D_SetVertexShaderConstant(GDEVICE, 0, m_mtSh0);
	LnD3D_SetVertexShaderConstant(GDEVICE, 5, vclgt);

	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	GDEVICE->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	GDEVICE->SetSamplerState(1, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	GDEVICE->SetSamplerState(1, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	GDEVICE->SetSamplerState(1, D3DSAMP_MINFILTER, D3DTEXF_NONE);
	GDEVICE->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_NONE);
	GDEVICE->SetSamplerState(1, D3DSAMP_MIPFILTER, D3DTEXF_NONE);

	for(int i=0; i<8; ++i)
	{
		GDEVICE->SetTexture(i, 0);
		GDEVICE->SetTextureStageState (i, D3DTSS_COLOROP, D3DTOP_DISABLE);
		GDEVICE->SetTextureStageState (i, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	}

	GDEVICE->SetTextureStageState(0, D3DTSS_COLOROP,  D3DTOP_MODULATE);
	GDEVICE->SetTextureStageState(0, D3DTSS_COLORARG1,  D3DTA_TEXTURE);
	GDEVICE->SetTextureStageState(0, D3DTSS_COLORARG2,  D3DTA_DIFFUSE);
	GDEVICE->SetTextureStageState(0, D3DTSS_ALPHAOP,  D3DTOP_DISABLE);
	GDEVICE->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 0);

	GDEVICE->SetTextureStageState(1, D3DTSS_COLOROP,  D3DTOP_MODULATE);
	GDEVICE->SetTextureStageState(1, D3DTSS_COLORARG1,  D3DTA_TEXTURE);
	GDEVICE->SetTextureStageState(1, D3DTSS_COLORARG2,  D3DTA_CURRENT);
	GDEVICE->SetTextureStageState(1, D3DTSS_ALPHAOP,  D3DTOP_DISABLE);
	GDEVICE->SetTextureStageState(1, D3DTSS_TEXCOORDINDEX, 0);

	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	GDEVICE->SetRenderState(D3DRS_ZENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_AMBIENT, 0xFFFFFFFF);

	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	GDEVICE->SetRenderState(D3DRS_LIGHTING,	FALSE);

///////////////////////////Blend///////////////////////////
	GDEVICE->SetRenderState(D3DRS_ALPHATESTENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_ALPHAREF, 0x80);
	GDEVICE->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);

	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	GDEVICE->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	GDEVICE->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );
////////////////////////////////////////////////////////////////////////////

	GDEVICE->SetTexture(1, m_pMdoS->pTxToon);

	m_pMsh->SetMtrl	(m_pMdoS->pMtrl);
	m_pMsh->Render	();

	GDEVICE->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);

	GDEVICE->SetSamplerState(1, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(1, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	GDEVICE->SetVertexShader( NULL);
}

INT CAltMonoRen::SetPos(VEC3 vP)
{
	m_mtLcl._41	= vP.x;
	m_mtLcl._42 = vP.y;
	m_mtLcl._43 = vP.z;

	return 1;
}

INT CAltMonoRen::SetRot(FLOAT fA)
{
	D3DXMATRIX matYaw;
	D3DXVECTOR3 vRight, vUp, vLook;

	vRight.x = m_mtLcl._11;
	vRight.y = m_mtLcl._12;
	vRight.z = m_mtLcl._13;
	vUp.x = m_mtLcl._21;
	vUp.y = m_mtLcl._22;
	vUp.z = m_mtLcl._23;
	vLook.x = m_mtLcl._31;
	vLook.y = m_mtLcl._32;
	vLook.z = m_mtLcl._33;

	D3DXMatrixRotationY(&matYaw, fA ); 
	D3DXVec3TransformCoord(&vLook, &VEC3(0,0,1), &matYaw); 
	D3DXVec3TransformCoord(&vRight, &VEC3(1,0,0), &matYaw); 

	m_mtLcl._11 = vRight.x;
	m_mtLcl._12 = vRight.y;
	m_mtLcl._13 = vRight.z;
	m_mtLcl._31 = vLook.x;
	m_mtLcl._32 = vLook.y;
	m_mtLcl._33 = vLook.z;

	return 1;
}

VEC3 CAltMonoRen::GetPos()
{
	VEC3 Pos(0,0,0);
	Pos.x	= m_mtLcl._41;
	Pos.y 	= m_mtLcl._42;
	Pos.z 	= m_mtLcl._43;

	return Pos;
}

FLOAT	CAltMonoRen::GetRot()
{
	FLOAT fA = 0.f;

//	fA = m_pAni->fYaw;
	return fA;
}
