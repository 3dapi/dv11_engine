// Implementation of the CAltMono class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>

#include <Ln/_Cmm/LnType.h>
#include <Ln/_Cmm/LnArch.h>
#include <Ln/_Cmm/LnTree.h>
#include <Ln/_Cmm/LnVtxFmt.h>

#include <Ln/Euclid/LnEuclid.h>

#include <Ln/Util/LnUtil.h>
#include <Ln/Util/LnUtilDx.h>

#include <Ln/_D3D/D3DDriver.h>

#include "AltMdStrt.h"
#include "MdMsh.h"
#include "MdB.h"																// Model
#include "AltMonoRen.h"															// Model Obj
#include "AltMono.h"																// Model Obj

const char sShaderExam[] =
"vs_1_1											\n"

"dcl_position	v0								\n"
"dcl_normal		v3								\n"
"dcl_color		v5								\n"
"dcl_texcoord	v7								\n"

"m4x4 r0, v0, c0								\n"
"mov  oPos, r0									\n"
"mov oD0, v5									\n"
"mov oT0, v7									\n"


"dp3 oT1.x, v3, -c5								\n"
;

CAltMono::CAltMono()
{
	memset(m_sFile, 0,sizeof(m_sFile));
	m_nM	= -1;
	m_nS	= -1;
	m_pMdO	= 0;
	m_pMdS	= 0;
	m_pMdR.clear();
	m_bEdge	= TRUE;

	m_pAltMono	=	NULL;
}

CAltMono::~CAltMono()
{
	Destroy();
}

INT	CAltMono::Init()
{
	return 1;
}

INT CAltMono::FrameMove()
{
	if(m_pMdR.empty())
		return 1;

	for(INT i = 0 ; i < m_pMdR.size() ; ++i)
	{
		m_pMdR[i]->FrameMove();
	}

	return 1;
}

void CAltMono::Render()
{
	if(!m_pMdR.empty())
	{
		for(INT i = 0 ; i < m_pMdR.size() ; ++i)
		{
			if(m_bEdge)
				m_pMdR[i]->RenderEdge();
		}
	}

	if(!m_pMdR.empty())
	{
		for(INT i = 0 ; i < m_pMdR.size() ; ++i)
		{
			m_pMdR[i]->Render();
		}
	}
}
void CAltMono::RenderBBox()
{
	if(!m_pMdR.empty())
	{
		for(INT i = 0 ; i < m_pMdR.size() ; ++i)
		{
			m_pMdR[i]->RenderBBox(m_iCode);
		}
	}
}

void CAltMono::Destroy()
{
	if(m_pMdO) 
	{ 
		delete[] m_pMdO;
		m_pMdO = NULL;
	}
	m_pMdS = NULL;
}

INT CAltMono::SetMdB(INT nM, INT nS, TbAltMonoB* pMdS)
{
	m_pMdS = pMdS;
	INT	n = 0, i = 0, j = 0;	//, nprntcnt = 0;


	SAFE_DELETE_ARRAY(m_pMdO);
	m_pMdO = new CAltMonoRen[m_pMdS->iNobj];
	m_pMdR.clear();


	for(i=0; i< m_pMdS->iNobj; ++i)												// 1. Build Tree
	{
		INT nIdPrn = m_pMdS->pMdO[i].nIdPr;

		if(nIdPrn>-1)
		{
			CAltMonoRen*	pPrn = &m_pMdO[nIdPrn];
			pPrn->Attach(	&m_pMdO[i]);
		}
		else
		{
			m_pMdR.push_back(&m_pMdO[i]);
		}
	}

	for(i=0; i< m_pMdS->iNobj; ++i)												// 2. Build Rendering Data
	{
		CAltMonoRen* pMdbDst = &m_pMdO[i];
		AltMonoObj* pMdbSrc = &(m_pMdS->pMdO[i]);									// Model Source

		pMdbDst->m_pMsh	=	new CMdMsh;

		pMdbDst->m_pMdoS	= pMdbSrc;

		pMdbDst->m_nPrt	= pMdbSrc->nObjT;
		pMdbDst->m_pMsh->iNix = pMdbSrc->iNix;

		pMdbDst->m_pMsh->iNvx = pMdbSrc->iNvx;

		if( pMdbSrc->pUVT != NULL)
		{
			pMdbDst->m_pMsh->dFVF = D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX1;
			pMdbDst->m_pMsh->iVxS = sizeof(VtxNDUV1);
		}
	}

	for(i=0; i< m_pMdS->iNobj; ++i)												// 2. ReBuild Rendering Data
	{
		CAltMonoRen*	pMdbDst = &m_pMdO[i];
		AltMonoObj*	pMdbSrc = &(m_pMdS->pMdO[i]);								// Model Source
		float Top = 0.f, Bottom = 0.f, Left = 0.f, Right = 0.f, Front = 0.f, Rare = 0.f;
		if(0 == pMdbDst->m_pMsh->iNix)
			continue;

		// Create Index Memory
		pMdbDst->m_pMsh->pIdx = (VtxIdx*) malloc( pMdbDst->m_pMsh->iNix * sizeof(VtxIdx));
		memcpy(pMdbDst->m_pMsh->pIdx, pMdbSrc->pIdx, pMdbDst->m_pMsh->iNix * sizeof(VtxIdx));

		// Create Vtx && Nrm && UV Memory
		if( (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX1) == pMdbDst->m_pMsh->dFVF)
		{
			pMdbDst->m_pMsh->pVtx = malloc(pMdbSrc->iNvx * pMdbDst->m_pMsh->iVxS);

			for(j=0; j < pMdbSrc->iNvx; ++j)
			{
				((VtxNDUV1*)(pMdbDst->m_pMsh->pVtx))[j].p = pMdbSrc->pVtxP[j];			// Position ����
				((VtxNDUV1*)(pMdbDst->m_pMsh->pVtx))[j].n = pMdbSrc->pVtxN[j];	 		// Normal ����
				((VtxNDUV1*)(pMdbDst->m_pMsh->pVtx))[j].d = 0XFFFFFFFF;	 				// Diffuse
				((VtxNDUV1*)(pMdbDst->m_pMsh->pVtx))[j].u = pMdbSrc->pUVT[j].x;			// UV�� u ����
				((VtxNDUV1*)(pMdbDst->m_pMsh->pVtx))[j].v = pMdbSrc->pUVT[j].y;			// UV�� v ����
			}
		}
		pMdbDst->m_pMsh->iNvx = pMdbSrc->iNvx;

		// Create Toon Texture
		if (FAILED(D3DXCreateTexture(GDEVICE,128,1, 0, 0, D3DFMT_A8R8G8B8, D3DPOOL_MANAGED, &pMdbSrc->pTxToon)))
			return FALSE;
		if(!(pMdbSrc->pVS	= (PDVS)LnD3D_BuildShader(GDEVICE, (char*)sShaderExam, sizeof(sShaderExam)-1, "vs")))
			return -1;

		pMdbDst->m_pMdoS->pvtxedge	=	new VtxNDUV1[pMdbSrc->iNvx];
		pMdbDst->m_pMdoS->fSilThk		=	pMdbSrc->fSilThk;

	}

	// Set Toon Texture
	SetToonTxLv(m_pMdS->pMdM[0].Toon);
	SetLgtDir(m_pMdS->pMdO[0].vcLgt);

	SetPart();
	return 1;
}

INT	CAltMono::GetNumVtx()
{
	INT iNvx = 0;

	for(INT i = 0 ; i < m_pMdS->iNobj ; ++i)
	{
		if(!m_pMdO)
			return -1;
		iNvx += m_pMdO[i].m_pMsh->iNvx;
	}

	return iNvx;
}

INT	CAltMono::GetNumIdx()
{
	INT iNix = 0;

	for(INT i = 0 ; i < m_pMdS->iNobj ; ++i)
	{
		if(!m_pMdO)
			return -1;
		iNix += m_pMdO[i].m_pMsh->iNix;
	}

	return iNix;
}


void	CAltMono::SetSilThk(FLOAT fThk)
{
	if(!m_pMdR.empty())
	{
		for(INT i = 0 ; i < m_pMdR.size() ; ++i)
			m_pMdR[i]->SetSilThk(fThk);
	}
}

FLOAT	CAltMono::GetSilThk()
{
	if(!m_pMdR.empty())
	{
		return m_pMdR[0]->GetSilThk();
	}
	return 0.f;
}


VEC3	CAltMono::GetLgtDir()
{
	if(!m_pMdR.empty())
	{
		return m_pMdR[0]->GetLgtDir();
	}
	return VEC3(0.f,0.f,0.f);
}

void	CAltMono::SetLgtDir(VEC3 vcDir)
{
	if(!m_pMdR.empty())
	{
		for(INT i = 0 ; i < m_pMdR.size() ; ++i)
		{
			m_pMdR[i]->SetLgtDir(vcDir);
		}
	}
}


void	CAltMono::SetMdlBlend(DWORD dw)
{
	if(!m_pMdR.empty())
	{
		for(INT i = 0 ; i < m_pMdR.size() ; ++i)
		{
			m_pMdR[i]->SetMdlBlend(dw);
		}
	}
}

INT	CAltMono::SetPart()
{
	if(!m_pMdR.empty())
	{
		for(INT i = 0 ; i < m_pMdR.size() ; ++i)
		{
			m_pAltMono = m_pMdR[i]->SetMdPartPtr(PART_WEAPON);
		}
	}

	return 1;
}

VEC3	CAltMono::GetPos()
{
	VEC3 vP(0,0,0);

	if(!m_pMdR.empty())
	{
		for(INT i = 0 ; i < m_pMdR.size() ; ++i)
		{
			vP = m_pMdR[i]->GetPos();
		}
	}

	return vP;
}

FLOAT	CAltMono::GetRot()
{
	if(!m_pMdR.empty())
	{
		return m_pMdR[0]->GetRot();
	}
	
	return 0;
}

void	CAltMono::SetPos(VEC3 vP)
{
	if(!m_pMdR.empty())
	{
		for(INT i = 0 ; i < m_pMdR.size() ; ++i)
			m_pMdR[i]->SetPos(vP);
	}
}

void	CAltMono::SetRot(FLOAT fA)
{
	if(!m_pMdR.empty())
	{
		for(INT i = 0 ; i < m_pMdR.size() ; ++i)
		{
			m_pMdR[i]->SetRot(fA);
		}
	}
}

void CAltMono::SetToonTxLv(D3DXCOLOR* t)
{
	if(m_pMdS)
	{
		for(INT i=0; i< m_pMdS->iNobj; ++i)												// 2. ReBuild Rendering Data
		{
			AltMonoObj*	pMdbSrc = &(m_pMdS->pMdO[i]);
		// Set Toon Texture
			PDSF	pTxSf;
			pMdbSrc->pTxToon->GetSurfaceLevel(0, &pTxSf);

			D3DSURFACE_DESC dsc;

			pTxSf->GetDesc(&dsc);

			D3DLOCKED_RECT rt;
			pTxSf->LockRect(&rt, 0, 0);

			DWORD*	pData = (DWORD*) rt.pBits;

			memset(pData, 0xff, sizeof(DWORD)* dsc.Width * dsc.Height);

			INT z = 0;
			pData[0] = t[0];
			for( z = 1; z < 2 ; z++)				pData[z] = t[1];
			for( z = 2; z < 10 ; z++)				pData[z] = t[2];
			for( z = 10; z < 20 ; z++)				pData[z] = t[3];
			for( z = 20; z < 30 ; z++)				pData[z] = t[4];
			for( z = 30; z < 40 ; z++)				pData[z] = t[5];
			for( z = 40; z < 50 ; z++)				pData[z] = t[6];
			for( z = 50; z < 60 ; z++)				pData[z] = t[7];
			for( z = 60; z < 70 ; z++)				pData[z] = t[8];
			for( z = 70; z < 80 ; z++)				pData[z] = t[9];
			for( z = 80; z < 90 ; z++)				pData[z] = t[10];
			for( z = 90; z < 100 ; z++)				pData[z] = t[11];
			for( z = 100; z < 110 ; z++)			pData[z] = t[12];
			for( z = 110; z < 120 ; z++)			pData[z] = t[13];
			for( z = 120; z < 127 ; z++)			pData[z] = t[14];
			for( z = 127; z < 128 ; z++)			pData[z] = t[15];

			pTxSf->UnlockRect();

			SAFE_RELEASE(pTxSf);
		// Set Toon Texture End
		}
	}
}

void CAltMono::SetToonTxLv(FLOAT* t)
{
	if(m_pMdS)
	{
		for(INT i=0; i< m_pMdS->iNobj; ++i)												// 2. ReBuild Rendering Data
		{
			AltMonoObj*	pMdbSrc = &(m_pMdS->pMdO[i]);
		// Set Toon Texture
			PDSF	pTxSf;

			pMdbSrc->pTxToon->GetSurfaceLevel(0, &pTxSf);
			
			D3DSURFACE_DESC dsc;
			pTxSf->GetDesc(&dsc);

			D3DLOCKED_RECT rt;
			pTxSf->LockRect(&rt, 0, 0);

			DWORD*	pData = (DWORD*) rt.pBits;

			INT size = dsc.Width * dsc.Height;
			memset(pData, 0xff, sizeof(DWORD)* size);

			INT z = 0;
			pData[0] = D3DXCOLOR(t[0],t[0],t[0],1.f);
			for( z = 1; z < 2 ; z++)				pData[z] = D3DXCOLOR(t[1],t[1],t[1],1.f);
			for( z = 2; z < 10 ; z++)				pData[z] = D3DXCOLOR(t[2],t[2],t[2],1.f);
			for( z = 10; z < 20 ; z++)				pData[z] = D3DXCOLOR(t[3],t[3],t[3],1.f);
			for( z = 20; z < 30 ; z++)				pData[z] = D3DXCOLOR(t[4],t[4],t[4],1.f);
			for( z = 30; z < 40 ; z++)				pData[z] = D3DXCOLOR(t[5],t[5],t[5],1.f);
			for( z = 40; z < 50 ; z++)				pData[z] = D3DXCOLOR(t[6],t[6],t[6],1.f);
			for( z = 50; z < 60 ; z++)				pData[z] = D3DXCOLOR(t[7],t[7],t[7],1.f);
			for( z = 60; z < 70 ; z++)				pData[z] = D3DXCOLOR(t[8],t[8],t[8],1.f);
			for( z = 70; z < 80 ; z++)				pData[z] = D3DXCOLOR(t[9],t[9],t[9],1.f);
			for( z = 80; z < 90 ; z++)				pData[z] = D3DXCOLOR(t[10],t[10],t[10],1.f);
			for( z = 90; z < 100 ; z++)				pData[z] = D3DXCOLOR(t[11],t[11],t[11],1.f);
			for( z = 100; z < 110 ; z++)			pData[z] = D3DXCOLOR(t[12],t[12],t[12],1.f);
			for( z = 110; z < 120 ; z++)			pData[z] = D3DXCOLOR(t[13],t[13],t[13],1.f);
			for( z = 120; z < 127 ; z++)			pData[z] = D3DXCOLOR(t[14],t[14],t[14],1.f);
			for( z = 127; z < 128 ; z++)			pData[z] = D3DXCOLOR(t[15],t[15],t[15],1.f);


			pTxSf->UnlockRect();
			SAFE_RELEASE(pTxSf);
		// Set Toon Texture End
		}
	}
}
void CAltMono::SetMtlToon(D3DXCOLOR* t)
{
	for(INT i = 0; i < m_pMdS->iNmtl ; i++)
	{
		for(INT n = 0 ; n < TOON_DEVIDE_COUNT ; n++)
			m_pMdS->pMdM[i].Toon[n] = t[n].r;
	}
}

void CAltMono::SetMtlToon(FLOAT* t)
{
	for(INT i = 0; i < m_pMdS->iNmtl ; i++)
	{
		for(INT n = 0 ; n < TOON_DEVIDE_COUNT ; n++)
			m_pMdS->pMdM[i].Toon[n] = t[n];
	}	
}
