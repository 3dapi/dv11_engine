// Interface for the CAltMulti class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _OBJ_H_
#define _OBJ_H_


class CAltMono : public CMdB
{
public:
	TCHAR			m_sFile[128];

	INT				m_nM;
	INT				m_nS;

	TbAltMonoB*		m_pMdS;													// Model Source
	CAltMonoRen*	m_pMdO;
	lsAltMonoRen	m_pMdR;													// Renderer Root

	BOOL			m_bEdge;

	CAltMonoRen*	m_pAltMono;

public:
	CAltMono();
	virtual ~CAltMono();

	virtual	INT		Init();
	virtual	void	Destroy();
	virtual	INT		FrameMove();
	virtual	void	Render();
	virtual void	RenderBBox();

	virtual VEC3	GetPos();
	virtual void	SetPos(VEC3 pos);

	virtual FLOAT	GetRot();
	virtual void	SetRot(FLOAT fA);

public:
	INT				SetMdB(INT nM, INT nS, TbAltMonoB* pMdS);

	FLOAT			GetSilThk();
	void			SetSilThk(FLOAT fThk);

	void			SetLgtDir	(VEC3 vcDir);
	void			SetMdlBlend(DWORD dw);

	VEC3			GetLgtDir	();

	void			SetToonTxLv(D3DXCOLOR* t);
	void			SetToonTxLv(FLOAT* t);
	void			SetMtlToon(D3DXCOLOR* t);
	void			SetMtlToon(FLOAT* t);

	INT				GetNumVtx();
	INT				GetNumIdx();

	CAltMonoRen*	GetAltMono()						{	return m_pAltMono;				}
	void			SetMdParent(CAltMultiRen* pPrnt)	{	m_pAltMono->SetMdParent(pPrnt);	}
	INT				SetPart();
};

typedef std::vector<CAltMono*>	lsAltMono;
typedef	lsAltMono::iterator		itAltMono;

#endif