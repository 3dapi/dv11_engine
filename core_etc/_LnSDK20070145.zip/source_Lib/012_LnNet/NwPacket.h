// Interface for the CNwPacket class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _NWPACKET_H_
#define _NWPACKET_H_

class CNwPacket
{
protected:
	INT			m_iHead;					// ��Ŷ ����� ����
	INT			m_iKeep;					// Keep Size
	
	CNwRingBuf*	m_pKeep;					// ���� ��Ŷ�� ��Ƶδ� ��

public:
	CNwPacket();
	CNwPacket(INT iKeep);
	virtual ~CNwPacket();

	void	SetPckHeaderLength(INT iLen);
	INT		GetPckHeaderLength();
	
	INT		PushBack(BYTE* sBuf, INT iSize);
	INT		PopFront(BYTE* sBuf);
	INT		GetUsed();
};

#endif