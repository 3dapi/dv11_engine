// Interface for the NwUtil class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _NWUTIL_H_
#define _NWUTIL_H_

#ifndef SAFE_DELETE
#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#endif

#ifndef SAFE_DELETE_ARRAY
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#endif


#define PCK_HAEAD_LEN	2
#define PCK_HAEAD_KIN	4
#define PCK_HAEAD_TOT	(PCK_HAEAD_LEN + PCK_HAEAD_KIN)

//#define PCK_MAX_BUF	1400
#define PCK_MAX_BUF		4096

//#define PCK_MAX_TMP		(PCK_MAX_BUF + PCK_MAX_BUF)
#define PCK_MAX_TMP		(PCK_MAX_BUF)



typedef unsigned (__stdcall* _PBEGIN_THREAD_EX)(void*);
typedef _PBEGIN_THREAD_EX LPBEGIN_THREAD_EX;



void	NwUtil_FormatMessage(char* sMsg);										// Format Message
void	NwUtil_GetNetworkError(DWORD hr);
INT		NwUtil_WSAGetError();

INT		NwUtil_WSAStartup();
void	NwUtil_WSACleanup();

INT		NwUtil_SocketTcpCreate(SOCKET* pScH, BOOL bOverLapped=FALSE);			// Create Socket
void	NwUtil_SocketClose(SOCKET* scH);

INT		NwUtil_SocketBind(SOCKET scH, SOCKADDR_IN* pSdH);						// Binding Socket
INT		NwUtil_SocketListen(SOCKET scH);										// Listen

INT		NwUtil_SocketAccept(  SOCKET* pscOut		// Output Socket
							, SOCKADDR_IN* psdOut	// Output Socket Address
							, SOCKET scListen		// Listen socket
							);													// Accept


INT		NwUtil_SocketConnect(SOCKET scH, SOCKADDR_IN* psdH);					// Connect
INT		NwUtil_TCPSend(SOCKET scH, BYTE* sBuf, INT iLen, INT flags=0);			// TCP Send
INT		NwUtil_TCPRecv(SOCKET scH, BYTE* sBuf, INT iBuf, INT flags=0);			// TCP Recv


void	NwUtil_SetSocketAddr(SOCKADDR_IN* pOut, char* sIp, char* sPort);		// Set Socket Address
INT		NwUtil_SetSocketNonBlocking(SOCKET scH, BOOL bOn=TRUE);					// Set NonBlocking
INT		NwUtil_SetSocketNaggleOff(SOCKET scH, BOOL bOff=TRUE);					// Off nagle Algorithm

INT		NwUtil_Select(FD_SET* readfds, FD_SET* writefds, FD_SET* exceptfds, TIMEVAL* timeout);

HANDLE	NwUtil_ThreadCreate(LPTHREAD_START_ROUTINE pFunc,void* pParam, ULONG dFlag=0, DWORD* dId= NULL);	// Thread Create
void	NwUtil_ThreadClose(HANDLE* hThread);																// Thread Close

HANDLE	NwUtil_WSAEventCreate();
void	NwUtil_WSAEventClose(HANDLE* hEvent);





HANDLE	NwUtil_CreateIoPort(SOCKET scH, HANDLE hIocp, void* pAddress);


INT		NwUtil_GetSystemProcessNumber();
INT		NwUtil_GetLocalIp(char* sIp/*IP List*/, INT* piN/*IP Count*/, INT* iWidth);


WORD	NwUtil_PacketEncode(BYTE* pOut						// Output Packet
						  , BYTE* sMsg						// Packet contents
						  , INT nMsg						// Send Message Kind
						  , int iSnd						// Pakcet contents length
						  , int iHeadLen=(PCK_HAEAD_LEN)	// Packet Length =2(WORD)
						  , int iHeadMsg=(PCK_HAEAD_KIN)	// pACKET Msg = 4(INT)
						  );


WORD 	NwUtil_PacketDecode(BYTE* sMsg						// Output Message
						  , INT* nMsg						// Receive Message Kind
						  , BYTE* pIn						// Receive Packets
						  , int iRcv						// Receive Packet Length
						  , int iHeadLen=(PCK_HAEAD_LEN)	// Packet Length =2(WORD)
						  , int iHeadMsg=(PCK_HAEAD_KIN)	// pACKET Msg = 4(INT)
						  );



// Circular Queue
template<class T>
class TqueCirc
{
protected:
	int		F;						// Header
	int		L;						// Rear(Last)
	int		N;						// Queue Count
	int		W;						// Width
	
	int		S;						// Space (Unused Memory)

	T*		B;						// Buffer

public:
	TqueCirc(INT iSize): F(0), L(0), N(0), W(0), S(0), B(0)
	{
		W	= iSize;
		B	= new T[W];

		memset(B, 0, W* sizeof(T));
	}
	
	~TqueCirc()
	{
		if(B)	{	delete [] B; B= NULL;	}
	}
	
	void SetSize(int iSize)
	{
		F	= 0;
		L	= 0;
		N	= 0;
		W	= iSize;
		S	= W;		
		
		if(B)	{	delete [] B; B= NULL;	}
		
		B	= new T[W];
		memset(B, 0, W* sizeof(T));
	}
	
	
	int PushBack(T* t)
	{
		// *(B+L) = *t;
		memcpy((B+L), t, sizeof T);

		--S;
		++L;
		L %= W;
		++N;
		
		return 1;
	}
	
	void PopFront(T* t)
	{
		if(N<=0)
			return;
		
		// *t = *(B+L);
		memcpy(t, (B+F), sizeof T);

		++S;
		++F;
		F %= W;
		--N;
	}


	int		GetSize()	{	return N;		}

	int		End()		{	return L;		}
	int		Front()		{	return F;		}
	BOOL	IsEmpty()	{	return !N;		}
};




template<class T> inline
T NwUtil_Socket_Find(T _F, T _L, SOCKET scH)
{
	for (; _F != _L; ++_F)
	{
		if (scH == (*_F)->GetSocket())
			return (_F);
	}
	
	return 0;
}



template<class T> inline
INT NwUtil_Find_Idx(T _F, T _L, void* p)
{
	for (INT i=0; _F != _L; ++_F, ++i)
	{
		if (p == (void*)(*_F))
			return i;
	}
	
	return -1;
}



#endif


