// Implementation of the CNwRingBuf class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>
#include <memory.h>

#include "NwRingBuf.h"




CNwRingBuf::CNwRingBuf(): F(0), L(0), R(0), W(0)
{
	B	= NULL;
}


CNwRingBuf::CNwRingBuf(INT iSize): F(0), L(0), R(0), W(iSize)
{
	B	= new BYTE[W];
	memset(B, 0, W);
}


CNwRingBuf::~CNwRingBuf()
{
	if(B){	delete [] B; B= NULL;	}
}

void CNwRingBuf::SetSize(INT iSize)
{
	F	= 0;
	L	= 0;
	W	= iSize;
	R	= W;
	
	if(B){	delete [] B; B= NULL;	}
	
	B	= new BYTE[W];
	memset(B, 0, W);
}


INT CNwRingBuf::PushBack(BYTE* /*In*/pBuf, INT iT/*Length*/)
{
	if(iT>(W-R))
		return 0;

	if((L+iT)>W)
	{
		memcpy(B+L, pBuf, W-L);
		memcpy(B, pBuf+W-L, iT - (W-L));
	}
	else
	{
		memcpy(B+L, pBuf, iT);
	}

	R += iT;
	L += iT;
	L %= W;

	return R;
}


INT CNwRingBuf::PopFront(BYTE* /*Out*/pBuf, INT iT/*Length*/)
{
	if(R<1)
		return 0;

	if((F+iT)>W)
	{
		memcpy(pBuf, B+F, W-F);
	//	memset(B+F, '*', W-F);
		memcpy(pBuf+W-F, B, iT - (W-F));
	//	memset(B, '*', iT - (W-F));
	}
	else
	{
		memcpy(pBuf, B+F, iT);
	//	memset(B+F, '*', iT);
	}

	R -= iT;
	F += iT;
	F %= W;

	// ����� ũ�⸦ �����ش�.
	return R;
}


INT	CNwRingBuf::GetHead2Byte()
{
	INT		Temp0=F+0;						// Header
	INT		Temp1=((F+1)%W);					// Header
	INT		iSize = 0;

	*(((BYTE*) &iSize)+0) = *(B + Temp0);
	*(((BYTE*) &iSize)+1) = *(B + Temp1);

	return iSize;
}
