// Interface for the CNwIocpSvr class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _NWIOCPSVR_H_
#define _NWIOCPSVR_H_

class CNwIocpSvr
{
public:
	struct PckMsg
	{
		SOCKET		nScH;
		INT			nMsg;		// �� �κ��� �ʿ� ���� ���� �𸥴�.
		
		PckMsg()
		{
			nScH = 0;
			nMsg =0;
		}
		
		PckMsg(SOCKET _scH, INT _nMsg)
		{
			nScH	= _scH;
			nMsg	= _nMsg;
		}
	};

protected:
	SOCKET			m_scH;									// ȣ��Ʈ ����
	SOCKADDR_IN		m_sdH;									// ȣ��Ʈ ��巹��
	
	CHAR			m_sPt[8];								// Port

	HANDLE			m_hIocp;								// IOCP Handle

	INT				m_iNcpu;								// Number of CPU
	HANDLE*			m_hTh;									// Thread Handle
	DWORD*			m_dTh;

	lsHost			m_vrmH;									// Client List

	TqueCirc<PckMsg>* m_pMsg;

public:
	CNwIocpSvr();
	CNwIocpSvr(CHAR* sPt);
	virtual ~CNwIocpSvr();

	INT		Init();
	void	Destroy();

	INT		FrameMove();

	
	static DWORD WINAPI WorkThread(void* pParam);
	DWORD	WorkProc(void* pParam);


public:
	void	MsgPush(SOCKET scH, INT nMsg);
	INT		MsgPop(SOCKET* scH, INT* nMsg);

	INT		Recv(BYTE* sMsg, int* nMsg, int* iRcv, SOCKET scH);

	lsHost* const GetHostList()	{	return &m_vrmH;		}							// Client List

protected:
	void	SendAllData();

public:
	HANDLE	GetIocpHandle();
};


#endif


