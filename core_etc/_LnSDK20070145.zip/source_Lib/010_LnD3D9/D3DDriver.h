// Interface for the CD3DDriver class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _D3DDRIVER_H_
#define _D3DDRIVER_H_


class CD3DDriver  
{
public:
	CD3DDriver();
	virtual ~CD3DDriver();

	virtual void	SetScnW(INT	iScnW)	;
	virtual void	SetScnH(INT	iScnH)	;

	virtual INT		GetScnW()			;
	virtual INT		GetScnH()			;

	virtual void	SetScnX(INT iScnX)	;
	virtual void	SetScnY(INT iScnY)	;

	virtual INT		GetScnX()			;
	virtual INT		GetScnY()			;

	virtual void	SetClassName(char*)	;
	virtual void	SetStartFull(BOOL)	;
	virtual void	ToggleFull()		;


	virtual BOOL		IsWindowMode()	;
	virtual BOOL		IsActive()		;
	virtual HINSTANCE	GetInst()		;
	virtual HWND		GetHwnd()		;
	virtual HDC			GetHDC()		;

	virtual LPDIRECT3DDEVICE9	GetDevice()		;
	virtual D3DCAPS9*			GetCaps()		;
	virtual D3DSURFACE_DESC*	GetSurfaceDesc();
	virtual LPD3DXSPRITE		GetSprite()		;
	virtual LPDIRECT3DSURFACE9	GetBackSurface();
	virtual DWORD				GetClearMode()	;

	virtual UINT	GetBackW()			;
	virtual UINT	GetBackH()			;
	virtual DWORD	GetFMTBackBuffer()	;
	virtual DWORD	GetFMTDepthStencil();

	virtual UINT	GetDepthBit()		;
	virtual UINT	GetStencilBit()		;

	virtual DOUBLE	GetTimeStored()		;
	virtual DOUBLE	GetTimeStoredNoPause();
	
	virtual FLOAT	GetFPS()			;
	virtual FLOAT	GetTimeAv()			;
	
	virtual void	SetMaxFrame(FLOAT v);
	virtual FLOAT	GetMaxFrame()		;

	virtual void	SetLoadingRnd(INT _R);
	virtual BOOL	GetLoadingRnd()		;

	virtual HRESULT	SpriteBegin()=0		;
	virtual HRESULT	SpriteEnd()=0		;

	virtual HRESULT	SpriteDraw(LPDIRECT3DTEXTURE9  pTx
				   , RECT* pSrcRc
				   , D3DXVECTOR2* pvcPos
				   , D3DXVECTOR2* pvcScl
				   , D3DXVECTOR2* pvcRot
				   , FLOAT fRot
				   , DWORD dColor)=0;


	virtual HRESULT		FontCreate(void**pOut, HFONT)=0;

	virtual HRESULT		FontCreate(
									void**	pOut
								,	char*	sName
								,	INT		lHeight=12
								,	INT		lWeight=FW_NORMAL
								,	INT		lItalic=FALSE
								,	INT		eType= -1							// -1: ID3DXFont 0: ID3DXFont Width MtFnt 1: LnFont
								,	DWORD	dS=0xFFFFFFFF
								,	DWORD	dB=0xFFFFFFFF
								,	INT		iThckX=0
								,	INT		iThckY=0
								)=0;

	virtual HRESULT		FontBegin(ID3DXFont* pFnt)=0;
	virtual HRESULT		FontDraw(ID3DXFont* pFnt, char* pString, LPRECT pRect, DWORD Format=DT_NOCLIP, D3DCOLOR Color=0xFFFFFFFF, INT Count=-1)=0;
	virtual HRESULT		FontEnd(ID3DXFont* pFnt)=0;

	virtual INT			SoundCreate(void** pSndOut,char* sFile, DWORD dFlag=0, GUID = GUID_NULL,DWORD=1)=0;	// dFlag: 0 General, Etc: 3D Sound
	virtual void*		SoundManager()=0;

	virtual	INT			ScriptCreate(char* sCmd)=0;


	virtual D3DXVECTOR3	GetMainCamPos(int nIdx=0);								// Main Camera Position
	virtual D3DXVECTOR3	GetMainCamDir(int nIdx=0);								// Main Camera Direction
	virtual D3DXVECTOR3	GetPickRayDir(int nIdx=0);								// Picking Ray Direction

	virtual D3DXMATRIX	GetMatrixView(int nIdx=0);								// Main Camera View Matrix
	virtual D3DXMATRIX	GetMatrixViewI(int nIdx=0);								// Main Camera View Matrix Inverse
	virtual D3DXMATRIX	GetMatrixProj(int nIdx=0);								// Projection Matrix

	virtual D3DLIGHT9*	GetLighting();											// Lighting


	virtual HRESULT BeginScene()=0;
    virtual HRESULT EndScene()=0;
	virtual HRESULT Present()=0;

	virtual HRESULT Clear(DWORD Count,D3DRECT* pRects,DWORD Flags,D3DCOLOR Color,float Z,DWORD Stencil)=0;
	virtual	HRESULT SetTexture(DWORD Stage,LPDIRECT3DTEXTURE9 pTx)=0;
	virtual HRESULT SetFVF(DWORD FVF)=0;
	virtual HRESULT DrawPrimitiveUP(int pt,UINT nCnt, void* pVtx,UINT nSize)=0;

protected:

};


#define GDRIV		g_pDrv

#define GHINST		g_pDrv->GetInst()
#define GHWND		g_pDrv->GetHwnd()
#define GHDC		g_pDrv->GetHDC()

#define GDEVICE		g_pDrv->GetDevice()
#define GBACKSF		g_pDrv->GetBackSurface()
#define GSPRITE		g_pDrv->GetSprite()

extern CD3DDriver*	g_pDrv;

#endif


