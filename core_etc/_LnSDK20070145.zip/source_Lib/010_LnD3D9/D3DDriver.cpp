// Implementation of the CD3DDriver class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>

#include <D3D9.h>
#include <d3dx9.h>


#include "D3DDriver.h"


CD3DDriver*		g_pDrv = NULL;


CD3DDriver::CD3DDriver()
{
	g_pDrv = this;
}

CD3DDriver::~CD3DDriver()
{
}


void CD3DDriver::SetScnW(INT iScnW)
{
}

void CD3DDriver::SetScnH(INT iScnH)
{
}

INT CD3DDriver::GetScnW()
{
	return 0;
}

INT	CD3DDriver::GetScnH()
{
	return 0;
}

void CD3DDriver::SetScnX(INT iScnX)
{
}

void CD3DDriver::SetScnY(INT iScnY)
{
}

INT	CD3DDriver::GetScnX()
{
	return 0;
}

INT	CD3DDriver::GetScnY()
{
	return 0;
}

void CD3DDriver::SetClassName(char* sN)
{
}

void CD3DDriver::SetStartFull(BOOL bFull)
{
}

void CD3DDriver::ToggleFull()
{
}



BOOL CD3DDriver::IsWindowMode()
{
	return FALSE;
}

BOOL CD3DDriver::IsActive()
{
	return FALSE;
}

HINSTANCE CD3DDriver::GetInst()
{
	return NULL;
}

HWND CD3DDriver::GetHwnd()
{
	return NULL;
}

HDC CD3DDriver::GetHDC()
{
	return NULL;
}


LPDIRECT3DDEVICE9 CD3DDriver::GetDevice()
{
	return NULL;
}

D3DCAPS9* CD3DDriver::GetCaps()
{
	return NULL;
}

D3DSURFACE_DESC* CD3DDriver::GetSurfaceDesc()
{
	return NULL;
}

LPD3DXSPRITE CD3DDriver::GetSprite()
{
	return NULL;
}

LPDIRECT3DSURFACE9 CD3DDriver::GetBackSurface()
{
	return NULL;
}

DWORD CD3DDriver::GetClearMode()
{
	return NULL;
}

UINT CD3DDriver::GetBackW()
{
	return 0;
}

UINT CD3DDriver::GetBackH()
{
	return 0;
}

DWORD CD3DDriver::GetFMTBackBuffer()
{
	return 0xFFffFFFF;
}

DWORD CD3DDriver::GetFMTDepthStencil()
{
	return 0xFFFFFFFF;
}

UINT CD3DDriver::GetDepthBit()
{
	return 0;
}

UINT CD3DDriver::GetStencilBit()
{
	return 0;
}

DOUBLE CD3DDriver::GetTimeStored()
{
	return 0.;
}
DOUBLE CD3DDriver::GetTimeStoredNoPause()
{
	return 0.;
}

FLOAT CD3DDriver::GetFPS()
{
	return 0.f;
}

FLOAT CD3DDriver::GetTimeAv()
{
	return 0.f;
}

void CD3DDriver::SetMaxFrame(FLOAT v)
{
}

FLOAT CD3DDriver::GetMaxFrame()
{
	return 0.f;
}

void CD3DDriver::SetLoadingRnd(INT _R)
{
}

BOOL CD3DDriver::GetLoadingRnd()
{
	return FALSE;
}




D3DXVECTOR3 CD3DDriver::GetMainCamPos(int nIdx)
{
	return D3DXVECTOR3(FLT_MAX, FLT_MAX, FLT_MAX);
}

D3DXVECTOR3 CD3DDriver::GetMainCamDir(int nIdx)
{
	return D3DXVECTOR3(FLT_MAX, FLT_MAX, FLT_MAX);
}


D3DXVECTOR3 CD3DDriver::GetPickRayDir(int nIdx)
{
	return D3DXVECTOR3(FLT_MAX, FLT_MAX, FLT_MAX);
}

D3DXMATRIX CD3DDriver::GetMatrixView(int nIdx)
{
	return D3DXMATRIX(FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX
					, FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX
					, FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX
					, FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX);
}

D3DXMATRIX CD3DDriver::GetMatrixViewI(int nIdx)
{
	return D3DXMATRIX(FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX
					, FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX
					, FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX
					, FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX);
}

D3DXMATRIX CD3DDriver::GetMatrixProj(int nIdx)
{
	return D3DXMATRIX(FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX
					, FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX
					, FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX
					, FLT_MAX, FLT_MAX, FLT_MAX, FLT_MAX);
}




D3DLIGHT9* CD3DDriver::GetLighting()
{
	return NULL;
}
