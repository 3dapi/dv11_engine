// Interface for the CD3DApplication class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _D3DAPP_H_
#define _D3DAPP_H_


class CD3DApplication : public CD3DDriver
{
protected:
	CD3DEnum			m_d3dEnum			;
	CD3DSettings		m_d3dSettings		;

protected:
	// Internal variables for the state of the app
	BOOL				m_bWindowed			;
	BOOL				m_bActive			;
	BOOL				m_bDeviceLost		;
	BOOL				m_bMinimized		;
	BOOL				m_bMaximized		;
	BOOL				m_bIgnoreSizeChange	;
	BOOL				m_bDeviceInited		;
	BOOL				m_bDeviceRestored	;

	// Internal variables used for timing
	BOOL				m_bFrameMoving		;
	BOOL				m_bSingleStep		;

	// ��Ÿ..
	BOOL				m_bLoadingApp		;									// TRUE, if the app is loading

	BOOL				m_bDragFullUse		;									// FALSE, Childâ�� ���콺�� ���� ���� â���� ǥ��. TRUE�̸� �ӵ� ����.
	BOOL				m_bDragFullWin		;									// ���� ������ Childâ�� ���콺�� ���� ���� â���� ǥ���ΰ�?
	BOOL				m_bLoadingRnd		;									// TRUE, if the Loading Scene Rendering


	// Internal functions to manage and render the 3D scene
	static BOOL			ConfirmDeviceHelper(D3DCAPS9*, INT nType, void* );
	HRESULT				ConfirmDevice(D3DCAPS9*,DWORD,D3DFORMAT,D3DFORMAT);

	void				BuildPresentParamsFromSettings();
	BOOL				FindBestWindowedMode( BOOL, BOOL);
	BOOL				FindBestFullscreenMode( BOOL, BOOL);
	HRESULT				ChooseInitialD3DSettings();
	HRESULT				Initialize3DEnvironment();
	HRESULT				HandlePossibleSizeChange();
	HRESULT				Reset3DEnvironment();
	HRESULT				ToggleFullscreen();
	HRESULT				ForceWindowed();
	HRESULT				UserSelectNewDevice();
	void				Cleanup3DEnvironment();
	HRESULT				Render3DEnvironment();
	virtual HRESULT		AdjustWindowForChange();
	virtual void		UpdateStats();

	HRESULT				DisplayErrorMsg( HRESULT, DWORD);						// Internal error handling function
	INT					MonitorMaxHz(INT nScnW, INT nScnH, INT nBits);			// Max Hz for screen width and Height

protected:
	// Main objects used for creating and rendering the 3D scene
	DWORD					m_dHicon					;						// Icon Int value
	DWORD					m_dHmenu					;						// Menu Int value
	DWORD					m_dHaccel					;						// Accelator Int value
	DWORD					m_dHchagedev				;						// Change Device Int value
	DWORD					m_dHfullscn					;						// Toggle Full Screen Device Int value
	DWORD					m_dHexitm					;						// Exit_M Int value


	HINSTANCE				m_hInst						;
	HWND					m_hWnd						;						// The main app window
	HWND					m_hWndFocus					;						// The D3D focus window (usually same as m_hWnd)
	HDC						m_hDC						;						// Backbuffer DC
	HMENU					m_hMenu						;						// App menu bar (stored here when fullscreen)

	LPDIRECT3D9				m_pD3D						;						// The main D3D object
	LPDIRECT3DDEVICE9		m_pd3dDevice				;						// The D3D rendering device
	LPDIRECT3DSURFACE9		m_pBackBuffer				;						// Backbuffer point
	LPD3DXSPRITE			m_pd3dSprite				;						// 2D Sprite
	DWORD					m_dwClr						;						// Clear Mode

	D3DPRESENT_PARAMETERS	m_d3dpp						;						// Parameters for CreateDevice/Reset
	D3DCAPS9				m_d3dCaps					;						// Caps for the device
	D3DSURFACE_DESC			m_d3dsdBackBuffer			;						// Surface desc of the backbuffer

protected:
	DWORD					m_dwCreateFlags				;						// Indicate sw or hw vertex processing
	DWORD					m_dwWindowStyle				;						// Saved window style for mode switches
	RECT					m_rcWindowBounds			;						// Saved window bounds for mode switches
	RECT					m_rcWindowClient			;						// Saved client area size for mode switches

	// Variables for timing
	DOUBLE					m_fTime						;						// Current time in seconds
	DOUBLE					m_fTimeNoPause				;						// Current time. no pause
	DOUBLE					m_fElapsedTime				;						// Time elapsed since last frame

	FLOAT					m_fFPS						;						// Instanteous frame rate
	FLOAT					m_fTimeAv					;						// Time Average
	FLOAT					m_fMaxFrame					;

	TCHAR					m_strDeviceStats[90]		;						// String to hold D3D device stats
	TCHAR					m_strFrameStats[90]			;						// String to hold frame stats

	// Overridable variables for the app
	TCHAR					m_strWindowTitle[260]		;						// Title for the app's window

	INT						m_iScnPosX					;						// Width used to create window
	INT						m_iScnPosY					;						// Height used to create window

	DWORD					m_dwCreationW				;						// Width used to create window
	DWORD					m_dwCreationH				;						// Height used to create window
	BOOL					m_bShowCursorWhenFullscreen	;						// Whether to show cursor when fullscreen
	BOOL					m_bClipCursorWhenFullscreen	;						// Whether to limit cursor pos when fullscreen
	BOOL					m_bStartFullscreen			;						// Whether to start up the app in fullscreen mode

public:
	// Overridable functions for the 3D scene created by the app
	virtual HRESULT OneTimeSceneInit();
	virtual HRESULT Init()					{ return S_OK; }
	virtual HRESULT Restore()				{ return S_OK; }
	virtual HRESULT FrameMove()				{ return S_OK; }
	virtual HRESULT Render()				{ return S_OK; }
	virtual HRESULT Invalidate()			{ return S_OK; }
	virtual HRESULT Destroy()				{ return S_OK; }
	virtual HRESULT FinalCleanup();

public:
	CD3DApplication();

	virtual HRESULT				Create( HINSTANCE);
	virtual INT					Run();
	virtual void				Pause(BOOL bPause);
	virtual LRESULT				MsgProc(HWND,UINT,WPARAM,LPARAM);
	static	LRESULT CALLBACK	WndProc(HWND,UINT,WPARAM,LPARAM);

public:
	virtual void	SetScnW(INT	iScnW);
	virtual void	SetScnH(INT	iScnH);

	virtual INT		GetScnW();
	virtual INT		GetScnH();

	virtual void	SetScnX(INT iScnX);
	virtual void	SetScnY(INT iScnY);

	virtual INT		GetScnX();
	virtual INT		GetScnY();

	virtual void	SetClassName(char*);
	virtual void	SetStartFull(BOOL);
	virtual void	ToggleFull();

	virtual BOOL		IsWindowMode();
	virtual BOOL		IsActive();
	virtual HINSTANCE	GetInst();
	virtual HWND		GetHwnd();
	virtual HDC			GetHDC();

	virtual LPDIRECT3DDEVICE9	GetDevice();
	virtual D3DCAPS9*			GetCaps();
	virtual D3DSURFACE_DESC*	GetSurfaceDesc();
	virtual LPD3DXSPRITE		GetSprite();
	virtual LPDIRECT3DSURFACE9	GetBackSurface();
	virtual DWORD				GetClearMode();

	virtual UINT	GetBackW();									// Back Buffer Width
	virtual UINT	GetBackH();									// Back Buffer Height
	virtual DWORD	GetFMTBackBuffer();							// Depth Buffer Format
	virtual DWORD	GetFMTDepthStencil();						// Stencil Buffer Format

	virtual UINT	GetDepthBit();
	virtual UINT	GetStencilBit();

	virtual DOUBLE	GetTimeStored();							// Stored Time
	virtual DOUBLE	GetTimeStoredNoPause();						// Stored Time No pause

	virtual FLOAT	GetFPS();									// Average FPS
	virtual FLOAT	GetTimeAv();								// Time Average

	virtual void	SetMaxFrame(FLOAT fV);
	virtual FLOAT	GetMaxFrame();

	virtual void	SetLoadingRnd(INT _bR);
	virtual BOOL	GetLoadingRnd();


	virtual HRESULT	SpriteBegin()	;
	virtual HRESULT	SpriteEnd()		;

	virtual HRESULT SpriteDraw(
					LPDIRECT3DTEXTURE9  pTx							// Texture
				   , RECT* pSrcRc									// Source Image Local RECT
				   , D3DXVECTOR2* pvcPos							// Draw Position. NULL is (0,0) Position
				   , D3DXVECTOR2* pvcScl							// Draw Scale. NULL is Non Scaling
				   , D3DXVECTOR2* pvcRot							// Draw Rotation. NULL is Non rotation
				   , FLOAT fRot										// Rotation Angle(Radian)
				   , DWORD dColor									// Color
				   );


	virtual HRESULT		FontCreate(void**pOut, HFONT);

	virtual HRESULT		FontCreate(
									void**	pOut
								,	char*	sName					// Font Name
								,	INT		lHeight=12				// Font Height
								,	INT		lWeight=FW_NORMAL		// Font Weight Thin, Normal, Bold... See Go to Definition FW_NORMAL
								,	INT		lItalic=FALSE			// Italic?
								,	INT		eType=-1				// Font  -1: ID3DXFont 0: ID3DXFont Width MtFnt 1: LnFont
								,	DWORD	dS=0xFFFFFFFF			// String Color for LnFont
								,	DWORD	dB=0xFFFFFFFF			// Background Color for LnFont
								,	INT		iThckX=0				// Thick Font for LnFont
								,	INT		iThckY=0				// Thick Font for LnFont
								);

	virtual HRESULT		FontBegin(ID3DXFont* pFnt);

	virtual HRESULT		FontDraw(ID3DXFont* pFnt					// Font Object
								, char* pString						// String
								, LPRECT pRect						// Font Rect
								, DWORD Format=DT_NOCLIP			// format
								, D3DCOLOR Color=0xFFFFFFFF
								, INT Count=-1);

	virtual HRESULT		FontEnd(ID3DXFont* pFnt);



	virtual INT			SoundCreate(void** pSndOut				// This Function is Null Return. So You have to redefine child class.
								, char* sFile
								, DWORD dFlag=0					// dFlag: 0 General, Etc: 3D Sound
								, GUID = GUID_NULL
								, DWORD=1);

	virtual void*		SoundManager();							// This Functions is NULL Return. Sou You have to redefine child class.

	virtual	INT			ScriptCreate(char* sCmd);

	virtual HRESULT		BeginScene();
    virtual HRESULT 	EndScene();
	virtual HRESULT 	Present();

	virtual HRESULT 	Clear(DWORD Count
							, D3DRECT* pRects
							, DWORD Flags
							, D3DCOLOR Color
							, float Z
							, DWORD Stencil);

	virtual	HRESULT 	SetTexture(DWORD Stage, LPDIRECT3DTEXTURE9 pTx);
	virtual HRESULT 	SetFVF(DWORD FVF);

	virtual HRESULT 	DrawPrimitiveUP(INT ptType,UINT nCnt, void* pVtx,UINT nSize);
};


#ifndef GHINST
	#define GHINST		g_pD3DApp->GetInst()
#endif

#ifndef GHWND
	#define GHWND		g_pD3DApp->GetHwnd()
#endif

#ifndef GHDC
	#define GHDC		g_pD3DApp->GetHDC()
#endif



#ifndef GDEVICE
	#define GDEVICE		g_pD3DApp->GetDevice()
#endif

#ifndef GHWND
	#define GHWND		g_pD3DApp->GetHwnd()
#endif

#ifndef GHDC
	#define GHDC		g_pD3DApp->GetHDC()
#endif

#ifndef GBACKSF
	#define GBACKSF		g_pD3DApp->GetBackSurface()
#endif

#ifndef GSPRITE
	#define GSPRITE		g_pD3DApp->GetSprite()
#endif


#ifndef	GDRIV
	#define GDRIV		g_pD3DApp
#endif

extern CD3DApplication* g_pD3DApp;

#endif



