// Implementation of the CD3DApplication class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>

#include <tchar.h>
#include <stdio.h>

#include <D3D9.h>
#include <d3dx9.h>
#include <dxerr9.h>

#include "DXUtil.h"

#include "D3DEnum.h"

#include "D3DDriver.h"
#include "D3DApp.h"


LRESULT CD3DApplication::MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	WPARAM wLo = LOWORD(wParam);

	switch( uMsg )
	{
	case WM_PAINT:
		// Handle paint messages when the app is paused
		if( m_pd3dDevice && !m_bActive && m_bWindowed &&
			m_bDeviceInited && m_bDeviceRestored )
		{
			Render();

			if(!m_bLoadingRnd)
				m_pd3dDevice->Present( NULL, NULL, NULL, NULL );
		}
		break;

	case WM_GETMINMAXINFO:
		((MINMAXINFO*)lParam)->ptMinTrackSize.x = 100;
		((MINMAXINFO*)lParam)->ptMinTrackSize.y = 100;
		break;

	case WM_ENTERSIZEMOVE:
		// Halt frame movement while the app is sizing or moving
		Pause( TRUE );
		break;

	case WM_SIZE:
		// Pick up possible changes to window style due to maximize, etc.
		if( m_bWindowed && m_hWnd != NULL )
			m_dwWindowStyle = GetWindowLong( m_hWnd, GWL_STYLE );

		if( SIZE_MINIMIZED == wParam )
		{
			if( m_bClipCursorWhenFullscreen && !m_bWindowed )
				ClipCursor( NULL );
			Pause( TRUE ); // Pause while we're minimized
			m_bMinimized = TRUE;
			m_bMaximized = FALSE;
		}
		else if( SIZE_MAXIMIZED == wParam )
		{
			if( m_bMinimized )
				Pause( FALSE ); // Unpause since we're no longer minimized
			m_bMinimized = FALSE;
			m_bMaximized = TRUE;
			HandlePossibleSizeChange();
		}
		else if( SIZE_RESTORED == wParam )
		{
			if( m_bMaximized )
			{
				m_bMaximized = FALSE;
				HandlePossibleSizeChange();
			}
			else if( m_bMinimized)
			{
				Pause( FALSE ); // Unpause since we're no longer minimized
				m_bMinimized = FALSE;
				HandlePossibleSizeChange();
			}
			else
			{
				// If we're neither maximized nor minimized, the window size
				// is changing by the user dragging the window edges.  In this
				// case, we don't reset the device yet -- we wait until the
				// user stops dragging, and a WM_EXITSIZEMOVE message comes.
			}
		}
		break;

	case WM_EXITSIZEMOVE:
		Pause( FALSE );
		HandlePossibleSizeChange();
		break;

	case WM_SETCURSOR:
		// Turn off Windows cursor in fullscreen mode
		if( m_bActive && !m_bWindowed )
		{
			SetCursor( NULL );
			if( m_bShowCursorWhenFullscreen )
				m_pd3dDevice->ShowCursor( TRUE );
			return TRUE; // prevent Windows from setting cursor to window class cursor
		}
		break;

	case WM_MOUSEMOVE:
		if( m_bActive && m_pd3dDevice != NULL )
		{
			POINT ptCursor;
			GetCursorPos( &ptCursor );
			if( !m_bWindowed )
				ScreenToClient( m_hWnd, &ptCursor );
			m_pd3dDevice->SetCursorPosition( ptCursor.x, ptCursor.y, 0 );
		}
		break;

	case WM_ENTERMENULOOP:
		// Pause the app when menus are displayed
		Pause(TRUE);
		break;

	case WM_EXITMENULOOP:
		Pause(FALSE);
		break;

	case WM_NCHITTEST:
		// Prevent the user from selecting the menu in fullscreen mode
		if( !m_bWindowed )
			return HTCLIENT;
		break;

	case WM_POWERBROADCAST:
		switch( wParam )
		{
#ifndef PBT_APMQUERYSUSPEND
#define PBT_APMQUERYSUSPEND 0x0000
#endif
		case PBT_APMQUERYSUSPEND:
			// At this point, the app should save any data for open
			// network connections, files, etc., and prepare to go into
			// a suspended mode.
			return TRUE;

#ifndef PBT_APMRESUMESUSPEND
#define PBT_APMRESUMESUSPEND 0x0007
#endif
		case PBT_APMRESUMESUSPEND:
			// At this point, the app should recover any data, network
			// connections, files, etc., and resume running from when
			// the app was suspended.
			return TRUE;
		}
		break;

		case WM_SYSCOMMAND:
			// Prevent moving/sizing and power loss in fullscreen mode
			switch( wParam )
			{
				case SC_CLOSE:
				{
					for(int iCnt=0; iCnt<500; ++iCnt)
					{
						Sleep(10);

						if(0==m_bLoadingRnd)
						{
							Sleep(10);
							break;
						}
					}

					break;
				}

				case SC_MOVE:
				case SC_SIZE:
				case SC_MAXIMIZE:
				case SC_KEYMENU:
				case SC_MONITORPOWER:
					if( FALSE == m_bWindowed )
						return 1;
					break;
			}
			break;

			case WM_COMMAND:
			{
				if(m_dHchagedev && m_dHchagedev == wLo)
				{
					// Prompt the user to select a new device or mode
					Pause(TRUE);
					UserSelectNewDevice();
					Pause(FALSE);
					return 0;
				}

				if(m_dHfullscn && m_dHfullscn == wLo)
				{
					if(0==m_bLoadingRnd)
					{
						// Toggle the fullscreen/window mode
						Pause( TRUE );
						ToggleFullscreen();
						Pause( FALSE );
					}
					return 0;
				}

				if(m_dHexitm && m_dHexitm == wLo)
				{
					// Recieved key/menu command to exit app
					SendMessage( hWnd, WM_CLOSE, 0, 0 );
					return 0;
				}
				
				break;
			}

			case WM_CLOSE:
			{
				HMENU hMenu;

				Cleanup3DEnvironment();
				SAFE_RELEASE( m_pD3D );
				FinalCleanup();
				
				hMenu = GetMenu(hWnd);
				
				if( hMenu != NULL )
					DestroyMenu( hMenu );
				
				DestroyWindow( hWnd );
				PostQuitMessage(0);
				m_hWnd = NULL;
				
				return 0;
			}
	}


	return DefWindowProc( hWnd, uMsg, wParam, lParam );
}
