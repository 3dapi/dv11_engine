
#include <windows.h>
#include <stdio.H>

#include "include/LnLib/ILnDev.h"


INT		GameInit()		{	printf("Call GameInit()\n");		return 0;	}
void	GameDestroy()	{	printf("Call GameDestroy()\n");		return;		}

INT		GameRestore()	{	printf("Call GameRestore()\n");		return 0;	}
void	GameInvalidate(){	printf("Call GameInvalidate()\n");	return;		}

INT		GameFrameMove()	{	printf("Call GameFrameMove()\n");	return 0;	}
void	GameRender()	{	printf("Call GameRender()\n");		return;		}


void main()
{
	ILnDev* pDev;

	LnInst_CreateDevice("Create Direct3D9", &pDev);

	pDev->Query("SetFuncInit", GameInit);
	pDev->Query("SetFuncDestoy", GameDestroy);
	pDev->Query("SetFuncRestore", GameRestore);
	pDev->Query("SetFuncInvalidate", GameInvalidate);
	pDev->Query("SetFuncFrameMove", GameFrameMove);
	pDev->Query("SetFuncRender", GameRender);

	printf("\n");

	pDev->Create(NULL);
	pDev->Destroy();

	pDev->Restore();
	pDev->Invalidate();

	pDev->FrameMove();
	pDev->Render();

	delete pDev;

	printf("\n");

	return;
}




