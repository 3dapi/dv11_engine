// Implementation of the CLnDev class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnDev.h"
#include "LnDevBase.h"


CLnDev::CLnDev()
{
	
}

CLnDev::~CLnDev()
{
	Destroy();
}


INT CLnDev::Create(void* p1)
{
	printf("CLnDev Create\n");
	return 0;
}

void CLnDev::Destroy()
{
	printf("CLnDev Destroy\n");
}



INT CLnDev::Restore()
{
	printf("CLnDev Restore\n");
	return 0;
}

void CLnDev::Invalidate()
{
	printf("CLnDev Invalidate\n");
}


INT	CLnDev::FrameMove()
{
	printf("CLnDev FrameMove\n");
	return 0;
}

void CLnDev::Render()
{
	printf("CLnDev Render\n");
}


INT CLnDev::Query(char* sCmd, void* pData)
{
	printf("CLnDev Query:%s\n", sCmd);
	return 0;
}
