// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


class CMain : public CD3DApplication
{
public:
	ID3DXFont*			m_pD3DXFont	;											// D3DX font
	CMcInput*			m_pInput	;
	IMcCam*				m_pCam		;
	
	CMcField*			m_pField	;


	LPD3DXMESH			m_pMsh		;
	
public:
	virtual HRESULT Init();
	virtual HRESULT Destroy();

	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	
	virtual HRESULT FrameMove();
	virtual HRESULT Render();
	
	HRESULT RenderText();
	
public:
	LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);
	CMain();
};