// Interface for the CMcCamF class.
// FPS Camera
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCCAMF_H_
#define _MCCAMF_H_


class CMcCamF : public CMcCam  
{
public:
	CMcCamF();
	virtual ~CMcCamF();

public:
	virtual INT	Init();
	virtual INT	FrameMove();

protected:
	void	MoveSideward(FLOAT	fSpeed);
	void	MoveForward	(FLOAT	fSpeed, FLOAT fY=0);
	virtual INT	Query(char* sCmd, void* pData);
};

#endif