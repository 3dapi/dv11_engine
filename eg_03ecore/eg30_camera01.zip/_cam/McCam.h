// Interface for the CMcCam class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCCAMERA_H_
#define _MCCAMERA_H_

enum EMcCamera
{
	MC_CAM_1,
	MC_CAM_3,
};

typedef D3DVIEWPORT9	DVIEWPORT;

class CMcCam : public IMcCam
{
protected:
	char			m_sName[128];												// Camera Name
	EMcCamera		m_eType;													// Camera Type
	
	LPDIRECT3DDEVICE9	m_pDev;


	D3DXMATRIX		m_mtViw;													// View Matrix
	D3DXMATRIX		m_mtPrj;													// Projection Matrix
	

	// For View Matrix
	D3DXVECTOR3		m_vcEye;													// Camera position
	D3DXVECTOR3		m_vcLook;													// Look vector
	D3DXVECTOR3		m_vcUp;														// up vector

	FLOAT			m_fYaw;
	FLOAT			m_fPitch;


	// For Projection Matrix
	FLOAT			m_fFov;														// Field of View
	FLOAT			m_fAsp;														// Aspect
	FLOAT			m_fNr;														// Near
	FLOAT			m_fFr;														// Far

public:
	CMcCam();
	virtual ~CMcCam();

	void		SetName(char* sName)	{	strcpy(m_sName, sName);			}
	char*		GetName()				{	return m_sName;					}

	void		SetType(INT	eType)		{	m_eType = EMcCamera(eType);		}
	EMcCamera	GetType()				{	return m_eType;					}

	D3DXMATRIX	GetMatrixView()			{	return m_mtViw;		}
	D3DXMATRIX	GetMatrixProj()			{	return m_mtPrj;		}

	
	
	virtual D3DXVECTOR3	GetEye()	{	return m_vcEye;		}
	virtual D3DXVECTOR3	GetLook()	{	return m_vcLook;	}
	virtual D3DXMATRIX*	GetView()	{	return &m_mtViw;		}
	virtual D3DXMATRIX*	GetProj()	{	return &m_mtPrj;		}

	virtual D3DXVECTOR3	GetBasis()	{	return D3DXVECTOR3( FLT_MAX, FLT_MAX, FLT_MAX);	}

	D3DXVECTOR3 GetUP()					{	return m_vcUp;		}

	FLOAT		GetYaw()				{	return m_fYaw;		}
	FLOAT		GetPitch()				{	return m_fPitch;	}


	void		SetFov(FLOAT _fFov)		{	m_fFov = _fFov;		}
	FLOAT		GetFov()				{	return m_fFov;		}

	void		SetAspect(FLOAT _fAsp)	{	m_fAsp = _fAsp;		}
	FLOAT		GetAspect()				{	return m_fAsp;		}

	void		SetNear(FLOAT _fNear)	{	m_fNr  = _fNear;	}
	FLOAT		GetNear()				{	return m_fNr;		}

	void		SetFar(FLOAT _fFar)		{	m_fFr  = _fFar;		}
	FLOAT		GetFar()				{	return m_fFr;		}


	void		SetParamView(	D3DXVECTOR3 vcEye
							,	D3DXVECTOR3 vcLook
							,	D3DXVECTOR3 vcUp)
	{
		m_vcEye		= vcEye;
		m_vcLook	= vcLook;
		m_vcUp		= vcUp;
	}

	void		SetParamProjection(FLOAT fFov,FLOAT fAsp,FLOAT fNear,FLOAT fFar)
	{
		m_fFov	= fFov;
		m_fAsp	= fAsp;
		m_fNr	= fNear;
		m_fFr	= fFar;
	}
	
	void		UpdateViewProj();

public:
	virtual void	SetDevice(void* pDev)		{	m_pDev= (LPDIRECT3DDEVICE9)pDev;	}
	virtual INT	Init()							{	return 1;		}
	virtual INT	FrameMove()						{	return 1;		}


	virtual INT	Query(char* sCmd, void* pData)	{	return -1;		}
};

#endif
