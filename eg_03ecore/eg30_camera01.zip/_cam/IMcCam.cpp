// IMcCam.cpp: implementation of the IMcCam class.
//
//////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "IMcCam.h"

#include "McCam.h"
#include "McCamF.h"
#include "McCamT.h"




INT LnCam_Create(char* sCmd, IMcCam** pData)
{
	*pData = NULL;

	if(0==_stricmp(sCmd, "First"))
	{
		CMcCamF * pCam = new CMcCamF;

		if(FAILED(pCam->Init()))
		{
			delete pCam;
			return -1;
		}

		(*pData) = pCam;
		return 0;
	}

	else if(0==_stricmp(sCmd, "Third"))
	{
		CMcCamT * pCam = new CMcCamT;

		if(FAILED(pCam->Init()))
		{
			delete pCam;
			return -1;
		}

		(*pData) = pCam;
		return 0;
	}

	return -1;
}