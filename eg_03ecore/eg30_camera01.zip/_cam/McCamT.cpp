// Implementation of the CMcCamT class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "IMcCam.h"

#include "McCam.h"
#include "McCamT.h"


CMcCamT::CMcCamT()
{
	strcpy(m_sName, "MC_3rd_CAMERA");
	m_eType		= MC_CAM_3;

	m_vcBasis	= D3DXVECTOR3( 0, 0, 0);
	m_fEpslnY	=  20.f;
	m_fGap		= 100.f;
}

CMcCamT::~CMcCamT()
{

}


INT CMcCamT::Init()
{
	m_vcBasis	= D3DXVECTOR3( 60, 50, 60);
	m_fYaw		= D3DXToRadian(60.f);

	D3DXVECTOR3	vcR( cosf(m_fYaw), 0, sinf(m_fYaw));

	vcR			*=m_fGap;

	D3DXVECTOR3 vcLook	= m_vcBasis + D3DXVECTOR3(0, m_fEpslnY, 0);
	D3DXVECTOR3 vcEye	= m_vcBasis + vcR;

	SetParamView(vcEye, vcLook, D3DXVECTOR3(0,1,0));

	return 1;
}


INT CMcCamT::FrameMove()
{
	UpdateViewProj();

	m_pDev->SetTransform(D3DTS_VIEW, &m_mtViw);
	m_pDev->SetTransform(D3DTS_PROJECTION, &m_mtPrj);	

	return 1;
}

void CMcCamT::MoveSideward(FLOAT fSpeed)
{
	D3DXVECTOR3 tmp(m_mtViw._11, 0, m_mtViw._31);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcBasis+= tmp * fSpeed;
	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}


void CMcCamT::MoveForward(FLOAT fSpeed, FLOAT fY)
{
	D3DXVECTOR3 tmp(m_mtViw._13, m_mtViw._23*fY, m_mtViw._33);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcBasis+= tmp * fSpeed;
	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}




INT	CMcCamT::Query(char* sCmd, void* pVal)
{
	float* pData =(float*) pVal;

	if(0==_stricmp(sCmd, "MoveForward"))
	{
		MoveForward(pData[0], pData[1]);
	}

	else if(0==_stricmp(sCmd, "MoveSideward"))
	{
		MoveSideward(pData[0]);
	}

	else if(0==_stricmp(sCmd, "Rotate"))
	{
		m_fYaw	= pData[0];
		m_fPitch= pData[1];
		
		D3DXMATRIX rot;
		D3DXVECTOR3 vcR = m_vcEye - m_vcLook;
		D3DXVECTOR3 vcX;

		D3DXMatrixRotationY(&rot, m_fYaw);
		D3DXVec3TransformCoord(&vcR, &vcR, &rot);
		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);
		
		m_vcEye		= m_vcLook + vcR;

		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);

		vcR = m_vcEye - m_vcLook;
		vcX =D3DXVECTOR3(m_mtViw._11, m_mtViw._21, m_mtViw._31);
		
		D3DXMatrixRotationAxis(&rot, & vcX, m_fPitch);
		D3DXVec3TransformCoord(&vcR, &vcR, &rot);
		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);

		m_vcEye		= m_vcLook + vcR;
	}


	
	return -1;
}