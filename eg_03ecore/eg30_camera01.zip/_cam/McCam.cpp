// Implementation of the CMcCam class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "IMcCam.h"

#include "McCam.h"



CMcCam::CMcCam()
{
	strcpy(m_sName, "MC_DEFAULT_CAMERA");
	m_eType	= MC_CAM_1;
	
	D3DXMatrixIdentity(&m_mtViw);
	D3DXMatrixIdentity(&m_mtPrj);
	

	m_vcEye		= D3DXVECTOR3(0,0,-1);													// Camera position
	m_vcLook	= D3DXVECTOR3(0,0, 0);													// Look vector
	m_vcUp		= D3DXVECTOR3(0,1, 0);														// up vector

	m_fYaw		= 0.f;
	m_fPitch	= 0.f;

	m_fFov		= D3DX_PI/4.f;
	m_fAsp		= 800.f/600.f;
	m_fNr		= 1.f;
	m_fFr		= 10000.f;

	m_pDev		= NULL;
}

CMcCam::~CMcCam()
{

}



void CMcCam::UpdateViewProj()
{
	D3DXMatrixPerspectiveFovLH(&m_mtPrj, m_fFov, m_fAsp, m_fNr, m_fFr);
	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
}