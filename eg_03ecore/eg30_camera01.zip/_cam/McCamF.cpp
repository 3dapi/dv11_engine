// Implementation of the CMcCamF class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "IMcCam.h"

#include "McCam.h"
#include "McCamF.h"



CMcCamF::CMcCamF()
{
	strcpy(m_sName, "MC_FPS_CAMERA");
	m_eType	= MC_CAM_1;
}

CMcCamF::~CMcCamF()
{

}


INT CMcCamF::Init()
{
	SetParamView(D3DXVECTOR3(0,50,-100), D3DXVECTOR3( 0, 0, 0), D3DXVECTOR3(0,1,0));

	return 1;
}


INT CMcCamF::FrameMove()
{
	UpdateViewProj();

	m_pDev->SetTransform(D3DTS_VIEW, &m_mtViw);
	m_pDev->SetTransform(D3DTS_PROJECTION, &m_mtPrj);	

	return 1;
}

void CMcCamF::MoveSideward(FLOAT fSpeed)
{
	D3DXVECTOR3 tmp(m_mtViw._11, 0, m_mtViw._31);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}


void CMcCamF::MoveForward(FLOAT fSpeed, FLOAT fY)
{
	D3DXVECTOR3 tmp(m_mtViw._13, m_mtViw._23*fY, m_mtViw._33);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}




INT	CMcCamF::Query(char* sCmd, void* pVal)
{
	float* pData =(float*) pVal;

	if(0==_stricmp(sCmd, "MoveForward"))
	{
		MoveForward(pData[0], pData[1]);
	}

	else if(0==_stricmp(sCmd, "MoveSideward"))
	{
		MoveSideward(pData[0]);
	}

	else if(0==_stricmp(sCmd, "Rotate"))
	{
		m_fYaw	= pData[0];
		m_fPitch= pData[1];
		
		D3DXMATRIX rot;
		D3DXVECTOR3 vcZ = m_vcLook-m_vcEye;
		D3DXVECTOR3 vcX;
		D3DXMatrixRotationY(&rot, m_fYaw);
		D3DXVec3TransformCoord(&vcZ, &vcZ, &rot);
		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);
		
		m_vcLook = vcZ + m_vcEye;
		D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);

		
		vcZ = m_vcLook - m_vcEye;
		vcX =D3DXVECTOR3(m_mtViw._11, m_mtViw._21, m_mtViw._31);
		
		D3DXMatrixRotationAxis(&rot, & vcX, m_fPitch);
		D3DXVec3TransformCoord(&vcZ, &vcZ, &rot);
		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);

		m_vcLook = vcZ + m_vcEye;
	}


	
	return -1;
}