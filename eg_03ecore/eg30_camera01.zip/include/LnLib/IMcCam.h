// IMcCam.h: interface for the IMcCam class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _IMCCAM_H_
#define _IMCCAM_H_


#ifndef interface
#define interface struct
#endif


interface IMcCam  
{
	virtual INT	Init()=0;
	virtual INT	FrameMove()=0;

	virtual D3DXVECTOR3	GetEye()=0;
	virtual D3DXVECTOR3	GetLook()=0;
	virtual D3DXMATRIX*	GetView()=0;
	virtual D3DXMATRIX*	GetProj()=0;


	virtual D3DXVECTOR3	GetBasis()=0;

	virtual void	SetDevice(void* pDev)=0;

	virtual INT	Query(char* sCmd, void* pData)=0;
};


INT LnCam_Create(char* sCmd, IMcCam** pData);

#ifndef _DEBUG
#pragma comment(lib, "McCam.lib")
#else
#pragma comment(lib, "McCam_.lib")
#endif

#endif