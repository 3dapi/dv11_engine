

#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "include/LnLib/ILnDev.h"

#include "Main.h"
#include "resource.h"


// MainŬ���� �ν��Ͻ�
CMain*	g_pApp=NULL;
ILnDev*	g_pDev;

int main()
{
	

	// �̷� ����� ����ϱ� ���ؼ� CMain�� �Ҹ��ڿ�����
	// ��� �ϵ� �ؼ��� �ȵȴ�.
	CMain	mainApp;
	g_pApp	= &mainApp;

	printf("\n���� �غ�--------------------\n");
	LnDev_CreateDevice("Create Direct3D9", &g_pDev);

	g_pDev->Query("SetFuncInit", CMain::pFuncInit);
	g_pDev->Query("SetFuncDestoy", CMain::pFuncDestroy);
	g_pDev->Query("SetFuncRestore", CMain::pFuncRestore);
	g_pDev->Query("SetFuncInvalidate", CMain::pFuncInvalidate);
	g_pDev->Query("SetFuncFrameMove", CMain::pFuncFrameMove);
	g_pDev->Query("SetFuncRender", CMain::pFuncRender);


	DWORD dIcon		= IDI_MAIN_ICON;
	DWORD dAccel	= IDR_MAIN_ACCEL;
	DWORD dToggle	= IDM_TOGGLEFULLSCREEN;
	DWORD dExit		= IDM_EXIT;
	DWORD dStyle	= WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_VISIBLE|WS_MINIMIZEBOX | WS_MAXIMIZEBOX;

	g_pDev->Query("SetScnStyle", &dStyle);
	g_pDev->Query("SetScnIcon", &dIcon);
	g_pDev->Query("SetScnAccelator", &dAccel);
	g_pDev->Query("SetScnToggle", &dToggle);
	g_pDev->Query("SetScnExit", &dExit);

	
	printf("\n\n���� ����--------------------\n");


	LnDev	sDev(-1, -1, 1024, 768, "LnEngineApp1");
	g_pDev->Create(&sDev);
	
	g_pDev->Run();

	printf("\n���� ����--------------------\n");

	delete g_pDev;

	printf("\n");

	return 1;
}




