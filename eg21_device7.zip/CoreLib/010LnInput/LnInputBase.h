// Interface for the CLnInput class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnInput_H_
#define _LnInput_H_


class CLnInput : public ILnInput
{
protected:
	INT		nId;

public:
	CLnInput();
	virtual ~CLnInput();
	
	virtual INT		Create(void* p1);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		Query(char* sCmd, void* pData);
};

#endif
