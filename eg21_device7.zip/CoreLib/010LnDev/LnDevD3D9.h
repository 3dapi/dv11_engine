// Interface for the CLnDevD3D9 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnDevD3D9_H_
#define _LnDevD3D9_H_


class CLnDevD3D9 : public CLnDev
{
protected:
	INT		nId;

	INT		(*pFuncInit)();
	INT		(*pFuncDestroy)();
	INT		(*pFuncRestore)();
	INT		(*pFuncInvalidate)();
	INT		(*pFuncFrameMove)();
	INT		(*pFuncRender)();

public:
	CLnDevD3D9();
	virtual ~CLnDevD3D9();
	
	virtual INT		Create(void* p1);
	virtual void	Destroy();

	virtual INT		Restore();
	virtual void	Invalidate();

	virtual INT		FrameMove();
	virtual INT		Render();

	virtual	INT		Run();

	virtual INT		Query(char* sCmd, void* pData);

protected:
	void*			m_pd3dApp	;

public:
	virtual INT		BeginScene();
	virtual INT		EndScene();
	virtual INT		Clear(DWORD Count,CONST RECT* pRects,DWORD Flags,DWORD Color,float Z,DWORD Stencil);

	virtual INT		SpriteBegin();
	virtual INT		SpriteEnd();
	virtual INT		SpriteDraw(void* pTx
						   , CONST RECT* pSrcRect
						   , CONST FLOAT* pScaling
						   , CONST FLOAT* pRotationCenter
						   , FLOAT Rotation
						   , CONST FLOAT* pTranslation
						   , DWORD Color);

	virtual LPDIRECT3DDEVICE9	GetDevice();
	virtual LPD3DXSPRITE		GetSprite();
};

#endif