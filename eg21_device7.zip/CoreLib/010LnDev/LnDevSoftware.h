// Interface for the CLnDevSoftwafe class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnDevSoftwafe_H_
#define _LnDevSoftwafe_H_


class CLnDevSoftwafe : public CLnDev
{
protected:
	INT		nId;

public:
	CLnDevSoftwafe();
	virtual ~CLnDevSoftwafe();

	virtual INT		Create(void* p1);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual INT		Render();
};

#endif