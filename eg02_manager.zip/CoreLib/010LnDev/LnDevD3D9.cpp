// Implementation of the CLnDevD3D9 class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnDev.h"
#include "LnDevBase.h"
#include "LnDevD3D9.h"


CLnDevD3D9::CLnDevD3D9()
{
	
}

CLnDevD3D9::~CLnDevD3D9()
{
	Destroy();
}

INT CLnDevD3D9::Create(void* p1)
{
	printf("CLnDevD3D9 Create\n");
	return 0;
}

void CLnDevD3D9::Destroy()
{
	printf("CLnDevD3D9 Destroy\n");
}

INT	CLnDevD3D9::FrameMove()
{
	printf("CLnDevD3D9 FrameMove\n");
	return 0;
}

void CLnDevD3D9::Render()
{
	printf("CLnDevD3D9 Render\n");
}
