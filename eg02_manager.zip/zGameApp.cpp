
#include <windows.h>
#include <stdio.H>

#include "include/LnLib/ILnDev.h"
#include "include/LnLib/ILnInput.h"
#include "include/LnLib/ILnFont.h"
#include "include/LnLib/ILnTex.h"
#include "include/LnLib/ILnMed.h"


void main()
{
	ILnDev* pDev;

	LnObj_CreateDevice("Create Direct3D9", &pDev);

	pDev->FrameMove();
	pDev->Render();
	pDev->Query("Device Query", NULL);

	delete pDev;

	printf("\n--------------\n\n");


	ILnInput* pInput;

	LnObj_CreateInput("Create Input", &pInput);

	pInput->FrameMove();
	pInput->Render();
	pDev->Query("Input Query", NULL);

	delete pInput;

	printf("\n--------------\n\n");

	ILnFont* pFont;

	LnObj_CreateFont("Create Font", &pFont);

	pFont->FrameMove();
	pFont->Render();
	pDev->Query("Font Query", NULL);

	delete pFont;

	printf("\n--------------\n\n");

	ILnTex* pTex;

	LnObj_CreateTex("Create Texture", &pTex);

	pTex->FrameMove();
	pTex->Render();
	pDev->Query("Texture Query", NULL);

	delete pTex;

	printf("\n--------------\n\n");

	ILnMed* pMedia;

	LnObj_CreateMed("Create Media", &pMedia);

	pMedia->FrameMove();
	pMedia->Render();
	pMedia->Query("Media Query", NULL);

	delete pMedia;

	printf("\n--------------\n\n");

	return;
}




