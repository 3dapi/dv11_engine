// Interface for the IMyObject class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _IMYOBJECT_H_
#define _IMYOBJECT_H_

#ifndef interface
#define interface struct
#endif




interface IMyObject
{
	virtual INT		Create(void* p1/*In put value*/)=0;
	virtual void	Destroy()=0;

	virtual INT		FrameMove()=0;
	virtual void	Render()=0;


	virtual INT		Query(char* sCmd, void* pData)=0;
};


INT LnObj_CreateObject(char* sCmd, IMyObject** pData);


#ifdef _DEBUG
	#pragma comment(lib, "CoreLib_.lib")
#else
	#pragma comment(lib, "CoreLib.lib")
#endif


#endif

