// Interface for the CMyBaseObject class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MYBASEOBJECT_H_
#define _MYBASEOBJECT_H_


class CMyBaseObject : public IMyObject
{
protected:
	INT		nId;

public:
	CMyBaseObject();
	virtual ~CMyBaseObject();
	
	virtual INT		Create(void* p1);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		Query(char* sCmd, void* pData);
};

#endif
