// Implementation of the CMyBaseObject class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "IMyObject.h"
#include "MyBaseObject.h"


CMyBaseObject::CMyBaseObject()
{
	
}

CMyBaseObject::~CMyBaseObject()
{
	Destroy();
}


INT CMyBaseObject::Create(void* p1)
{
	printf("CMyBaseObject Create\n");
	return 0;
}

void CMyBaseObject::Destroy()
{
	printf("CMyBaseObject Destroy\n");
}

INT	CMyBaseObject::FrameMove()
{
	printf("CMyBaseObject FrameMove\n");
	return 0;
}

void CMyBaseObject::Render()
{
	printf("CMyBaseObject Render\n");
}


INT CMyBaseObject::Query(char* sCmd, void* pData)
{
	printf("CMyBaseObject Query:%s\n", sCmd);
	return 0;
}
