// Implementation of the IMyObject class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include "IMyObject.h"
#include "MyBaseObject.h"
#include "MyDrivenObj1.h"
#include "MyDrivenObj2.h"


INT LnObj_CreateObject(char* sCmd, IMyObject** pData)
{
	(*pData) = NULL;

	if(0==_stricmp("CMyDrivenObj1", sCmd))
	{
		CMyDrivenObj1* pObj = NULL;

		pObj = new CMyDrivenObj1;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}

	else if(0==_stricmp("CMyDrivenObj2", sCmd))
	{
		CMyDrivenObj2* pObj = NULL;

		pObj = new CMyDrivenObj2;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}


	return -1;
}
