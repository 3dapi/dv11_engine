// Interface for the CMyDrivenObj2 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MYDRIVENOBJ2_H_
#define _MYDRIVENOBJ2_H_


class CMyDrivenObj2 : public CMyBaseObject
{
protected:
	INT		nId;

public:
	CMyDrivenObj2();
	virtual ~CMyDrivenObj2();

	virtual INT		Create(void* p1);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();
};

#endif