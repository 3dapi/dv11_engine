// Interface for the CLnDevOpenGL class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnDevOpenGL_H_
#define _LnDevOpenGL_H_


class CLnDevOpenGL : public CLnDev
{
protected:
	INT		nId;

public:
	CLnDevOpenGL();
	virtual ~CLnDevOpenGL();

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual INT		Render();
};

#endif