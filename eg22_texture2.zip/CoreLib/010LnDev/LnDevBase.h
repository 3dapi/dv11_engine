// Interface for the CLnDev class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnDev_H_
#define _LnDev_H_


class CLnDev : public ILnDev
{
protected:
	INT		nId;

public:
	CLnDev();
	virtual ~CLnDev();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();

	virtual INT		Restore();
	virtual void	Invalidate();

	virtual INT		FrameMove();
	virtual INT		Render();

	virtual	INT		Run();

	virtual INT		Query(char* sCmd, void* pData);

public:
	virtual INT		BeginScene();
	virtual INT		EndScene();
	virtual INT		Clear(DWORD Count,CONST RECT* pRects,DWORD Flags,DWORD Color,float Z,DWORD Stencil);

	virtual INT		SpriteBegin();
	virtual INT		SpriteEnd();
	virtual INT		SpriteDraw(void* pTx
						   , CONST RECT* pSrcRect
						   , CONST FLOAT* pScaling
						   , CONST FLOAT* pRotationCenter
						   , FLOAT Rotation
						   , CONST FLOAT* pTranslation
						   , DWORD Color);
};

#endif
