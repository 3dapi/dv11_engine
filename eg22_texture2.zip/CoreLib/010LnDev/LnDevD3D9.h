// Interface for the CLnDevD3D9 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnDevD3D9_H_
#define _LnDevD3D9_H_


class CLnDevD3D9 : public CLnDev
{
protected:
	INT		nId;

	INT		(*pFuncInit)();
	INT		(*pFuncDestroy)();
	INT		(*pFuncRestore)();
	INT		(*pFuncInvalidate)();
	INT		(*pFuncFrameMove)();
	INT		(*pFuncRender)();

public:
	CLnDevD3D9();
	virtual ~CLnDevD3D9();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();

	virtual INT		Restore();
	virtual void	Invalidate();

	virtual INT		FrameMove();
	virtual INT		Render();

	virtual	INT		Run();

	virtual INT		Query(char* sCmd, void* pData);

protected:
	char					m_sCls[256]	;
	HINSTANCE				m_hInst		;
	HWND					m_hWnd		;
	DWORD					m_dWinStyle	;

	DWORD					m_dPosX		;			// Window Position X
	DWORD					m_dPosY		;			// Window Position Y
	DWORD					m_dScnX		;			// Screen Width
	DWORD					m_dScnY		;			// Screen Height
	
	BOOL					m_bShowCusor;			// Show Cusor
	BOOL					m_bWindow	;			// Window mode

	D3DPRESENT_PARAMETERS	m_d3dpp		;
	LPDIRECT3D9				m_pD3D		;			// D3D
	LPDIRECT3DDEVICE9		m_pd3dDevice;			// Device
	LPD3DXSPRITE			m_pd3dSprite;			// 2D Sprite


	BOOL					m_bAlive	;

public:
	virtual	LRESULT MsgProc(HWND, UINT, WPARAM, LPARAM);
	static LRESULT WINAPI WndProc(HWND, UINT, WPARAM, LPARAM);


public:
	virtual INT		BeginScene();
	virtual INT		EndScene();
	virtual INT		Clear(DWORD Count,CONST RECT* pRects,DWORD Flags,DWORD Color,float Z,DWORD Stencil);

	virtual INT		SpriteBegin();
	virtual INT		SpriteEnd();
	virtual INT		SpriteDraw(void* pTx
						   , CONST RECT* pSrcRect
						   , CONST FLOAT* pScaling
						   , CONST FLOAT* pRotationCenter
						   , FLOAT Rotation
						   , CONST FLOAT* pTranslation
						   , DWORD Color);

	virtual LPDIRECT3DDEVICE9	GetDevice();
	virtual LPD3DXSPRITE		GetSprite();
};

#endif