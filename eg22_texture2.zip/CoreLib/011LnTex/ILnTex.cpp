// Implementation of the ILnTex class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include "../../include/LnLib/LnType.h"
#include "ILnTex.h"
#include "LnTexBase.h"
#include "LnTexMng.h"


INT LnTex_CreateTexMng(void* pDev, ILnTexMng** pData)
{

	PDEV		pd3dDev = (PDEV)pDev;
	CLnTexMng*	pTxMng=NULL;

	*pData = NULL;

	pTxMng = new CLnTexMng;

	if(pTxMng->Create(pd3dDev))
	{
		delete pTxMng;
		return -1;
	}

	*pData = pTxMng;
	
	return 1;
}