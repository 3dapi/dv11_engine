// Interface for the CLnTexMng class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnTexMng_H_
#define _LnTexMng_H_

#pragma warning( disable : 4786)
#include <string>
#include <map>


typedef	std::map<std::string, ILnTex* >	mpTLnTex;
typedef	mpTLnTex::iterator				itTLnTex;

class CLnTexMng : public ILnTexMng
{
protected:
	INT			m_nId;					// Manager Id
	char		m_sName[MAX_PATH];		// Manager Name

	mpTLnTex	m_lsTex;
	PDEV		m_pDev;

public:
	CLnTexMng();
	virtual ~CLnTexMng();
	
	// Basic Interface
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();

	virtual INT		Query(char* sCmd, void* pData);


	// Management Interface
	virtual INT		Find(char* sName, ILnTex** pData);
	virtual INT		FindCreate(char* sCmd
								, ILnTex** pData
								, void* pVal1
								, void* pVal2 = NULL
								, DWORD dColorKey=0x00FFFFFF
								, DWORD dFilter= D3DX_FILTER_NONE
								, DWORD Pool= D3DPOOL_MANAGED);
};


#endif
