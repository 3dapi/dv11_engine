// Implementation of the CLnInput class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnInput.h"
#include "LnInputBase.h"


CLnInput::CLnInput()
{
	
}

CLnInput::~CLnInput()
{
	Destroy();
}


INT CLnInput::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnInput Create\n");
	return 0;
}

void CLnInput::Destroy()
{
	printf("CLnInput Destroy\n");
}

INT	CLnInput::FrameMove()
{
	printf("CLnInput FrameMove\n");
	return 0;
}

void CLnInput::Render()
{
	printf("CLnInput Render\n");
}


INT CLnInput::Query(char* sCmd, void* pData)
{
	printf("CLnInput Query:%s\n", sCmd);
	return 0;
}
