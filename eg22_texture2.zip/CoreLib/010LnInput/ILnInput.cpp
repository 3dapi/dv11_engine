// Implementation of the ILnInput class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include "ILnInput.h"
#include "LnInputBase.h"


INT LnInst_CreateInput(char* sCmd, ILnInput** pData)
{
	(*pData) = NULL;

	if(0==_stricmp("Create Input", sCmd))
	{
		CLnInput* pObj = NULL;

		pObj = new CLnInput;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}

	return -1;
}
