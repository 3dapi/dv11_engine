// Interface for the CLnInput class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnInput_H_
#define _LnInput_H_


class CLnInput : public ILnInput
{
protected:
	INT		nId;

public:
	CLnInput();
	virtual ~CLnInput();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		Query(char* sCmd, void* pData);
};

#endif
