// Implementation of the CLnFont class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnFont.h"
#include "LnFontBase.h"


CLnFont::CLnFont()
{
	
}

CLnFont::~CLnFont()
{
	Destroy();
}


INT CLnFont::Create(void* p1, void* p2, void* p3, void* p4)
{
	printf("CLnFont Create\n");
	return 0;
}

void CLnFont::Destroy()
{
	printf("CLnFont Destroy\n");
}

INT	CLnFont::FrameMove()
{
	printf("CLnFont FrameMove\n");
	return 0;
}

void CLnFont::Render()
{
	printf("CLnFont Render\n");
}


INT CLnFont::Query(char* sCmd, void* pData)
{
	printf("CLnFont Query:%s\n", sCmd);
	return 0;
}
