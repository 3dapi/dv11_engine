// Implementation of the ILnMed class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include "ILnMed.h"
#include "LnMedBase.h"


INT LnInst_CreateMed(char* sCmd, ILnMed** pData)
{
	(*pData) = NULL;

	if(0==_stricmp("Create Media", sCmd))
	{
		CLnMed* pObj = NULL;

		pObj = new CLnMed;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}

	return -1;
}
