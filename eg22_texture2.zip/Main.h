// Interface for the CCMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _Main_H_
#define _Main_H_


class CMain
{
public:
	static INT		pFuncInit();
	static void		pFuncDestroy();

	static INT		pFuncRestore();
	static void		pFuncInvalidate();

	static INT		pFuncFrameMove();
	static void		pFuncRender();




protected:
	PDEV		m_pDev;

	ILnTexMng*	m_MngTx;
	ILnTex*		m_pTx;

public:
	CMain();
	virtual ~CMain();

	virtual INT		Init();
	virtual void	Destroy();

	virtual INT		Restore();
	virtual void	Invalidate();

	virtual INT		FrameMove();
	virtual void	Render();
};

#endif
