

// Host Program���� �̿�

#include <windows.h>
#include <stdio.H>

#include "MyMdl.h"


void main()
{
	IMyMdl* pData;


	LnMdl_Create("Static", &pData);

	pData->FrameMove();
	pData->Render();
	delete pData;



	LnMdl_Create("Skin", &pData);

	pData->FrameMove();
	pData->Render();

	pData->Query("Hello world", NULL);

	delete pData;

	printf("\n--------------\n\n");


	LnMdl_Create("Bone", &pData);

	pData->FrameMove();
	pData->Render();

	pData->Query("Hi", NULL);

	delete pData;

	printf("\n--------------\n\n");

	return;
}




