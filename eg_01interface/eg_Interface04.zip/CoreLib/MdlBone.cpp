// Implementation of the CMdlBone class.
// Core Progam���� �۾�
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "MyMdl.h"
#include "MdlBase.h"
#include "MdlSkin.h"
#include "MdlBone.h"


CMdlBone::CMdlBone()
{
	
}

CMdlBone::~CMdlBone()
{
	Destroy();
}

INT CMdlBone::Create(void* p1)
{
	printf("CMdlBone Create\n");
	return 0;
}

void CMdlBone::Destroy()
{
	printf("CMdlBone Destroy\n");
}

INT	CMdlBone::FrameMove()
{
	printf("CMdlBone FrameMove\n");
	return 0;
}

void CMdlBone::Render()
{
	printf("CMdlBone Render\n");
}
