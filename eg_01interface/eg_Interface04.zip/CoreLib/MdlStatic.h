// Interface for the CMdlStatic class.
// Core Progam���� �۾�
////////////////////////////////////////////////////////////////////////////////

#ifndef _MdlStatic_H_
#define _MdlStatic_H_


class CMdlStatic : public CMdlBase
{
protected:
	INT		m_nId;

public:
	CMdlStatic();
	virtual ~CMdlStatic();

	virtual INT		Create(void* p1);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();
};

#endif