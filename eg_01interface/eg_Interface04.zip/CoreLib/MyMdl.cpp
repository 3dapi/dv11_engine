// Implementation of the IMyMdl class.
// Core Progam���� �۾�
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include "MyMdl.h"
#include "MdlBase.h"
#include "MdlStatic.h"
#include "MdlSkin.h"
#include "MdlBone.h"


INT LnMdl_Create(char* sCmd, IMyMdl** pData)
{
	(*pData) = NULL;

	if(0==_stricmp("Static", sCmd))
	{
		CMdlStatic* pObj = NULL;

		pObj = new CMdlStatic;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}

	else if(0==_stricmp("Skin", sCmd))
	{
		CMdlSkin* pObj = NULL;

		pObj = new CMdlSkin;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}

	else if(0==_stricmp("Bone", sCmd))
	{
		CMdlBone* pObj = NULL;

		pObj = new CMdlBone;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}


	return -1;
}
