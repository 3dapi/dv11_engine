// Implementation of the CMdlBase class.
// Core Progam���� �۾�
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "MyMdl.h"
#include "MdlBase.h"


CMdlBase::CMdlBase()
{
	
}

CMdlBase::~CMdlBase()
{
	Destroy();
}


INT CMdlBase::Create(void* p1)
{
	printf("CMdlBase Create\n");
	return 0;
}

void CMdlBase::Destroy()
{
	printf("CMdlBase Destroy\n");
}

INT	CMdlBase::FrameMove()
{
	printf("CMdlBase FrameMove\n");
	return 0;
}

void CMdlBase::Render()
{
	printf("CMdlBase Render\n");
}


INT CMdlBase::Query(char* sCmd, void* pData)
{
	printf("CMdlBase Query:%s\n", sCmd);
	return 0;
}
