// Interface for the CMdlBone class.
// Core Progam���� �۾�
////////////////////////////////////////////////////////////////////////////////

#ifndef _MdlBone_H_
#define _MdlBone_H_


class CMdlBone : public CMdlBase
{
protected:
	INT		m_nId;

public:
	CMdlBone();
	virtual ~CMdlBone();

	virtual INT		Create(void* p1);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();
};

#endif