// Interface for the CMdlSkin class.
// Core Progam���� �۾�
////////////////////////////////////////////////////////////////////////////////

#ifndef _MdlSkin_H_
#define _MdlSkin_H_


class CMdlSkin : public CMdlBase
{
protected:
	INT		m_nId;

public:
	CMdlSkin();
	virtual ~CMdlSkin();
	
	virtual INT		Create(void* p1);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();
};

#endif