// Interface for the CMdlBase class.
// Core Progam���� �۾�
////////////////////////////////////////////////////////////////////////////////

#ifndef _MdlBase_H_
#define _MdlBase_H_


class CMdlBase : public IMyMdl
{
protected:
	INT		m_nId;

public:
	CMdlBase();
	virtual ~CMdlBase();
	
	virtual INT		Create(void* p1);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		Query(char* sCmd, void* pData);
};

#endif
