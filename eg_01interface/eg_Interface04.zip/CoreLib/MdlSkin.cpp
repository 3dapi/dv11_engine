// Implementation of the CMdlSkin class.
// Core Progam���� �۾�
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "MyMdl.h"
#include "MdlBase.h"
#include "MdlSkin.h"


CMdlSkin::CMdlSkin()
{
	
}

CMdlSkin::~CMdlSkin()
{
	Destroy();
}

INT CMdlSkin::Create(void* p1)
{
	printf("CMdlSkin Create\n");
	return 0;
}

void CMdlSkin::Destroy()
{
	printf("CMdlSkin Destroy\n");
}

INT	CMdlSkin::FrameMove()
{
	printf("CMdlSkin FrameMove\n");
	return 0;
}

void CMdlSkin::Render()
{
	printf("CMdlSkin Render\n");
}
