// Implementation of the CMdlStatic class.
// Core Progam���� �۾�
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "MyMdl.h"
#include "MdlBase.h"
#include "MdlSkin.h"
#include "MdlStatic.h"


CMdlStatic::CMdlStatic()
{
	
}

CMdlStatic::~CMdlStatic()
{
	Destroy();
}

INT CMdlStatic::Create(void* p1)
{
	printf("CMdlStatic Create\n");
	return 0;
}

void CMdlStatic::Destroy()
{
	printf("CMdlStatic Destroy\n");
}

INT	CMdlStatic::FrameMove()
{
	printf("CMdlStatic FrameMove\n");
	return 0;
}

void CMdlStatic::Render()
{
	printf("CMdlStatic Render\n");
}
