// Implementation of the CMyDrivenObj2 class.
// Core Progam���� �۾�
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "IMyObject.h"
#include "MyBaseObject.h"
#include "MyDrivenObj1.h"
#include "MyDrivenObj2.h"


CMyDrivenObj2::CMyDrivenObj2()
{
	
}

CMyDrivenObj2::~CMyDrivenObj2()
{
	Destroy();
}

INT CMyDrivenObj2::Create(void* p1)
{
	printf("CMyDrivenObj2 Create\n");
	return 0;
}

void CMyDrivenObj2::Destroy()
{
	printf("CMyDrivenObj2 Destroy\n");
}

INT	CMyDrivenObj2::FrameMove()
{
	printf("CMyDrivenObj2 FrameMove\n");
	return 0;
}

void CMyDrivenObj2::Render()
{
	printf("CMyDrivenObj2 Render\n");
}
