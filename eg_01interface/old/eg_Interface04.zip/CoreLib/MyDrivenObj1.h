// Interface for the CMyDrivenObj1 class.
// Core Progam���� �۾�
////////////////////////////////////////////////////////////////////////////////

#ifndef _MYDRIVENOBJ1_H_
#define _MYDRIVENOBJ1_H_


class CMyDrivenObj1 : public CMyBaseObject
{
protected:
	INT		nId;

public:
	CMyDrivenObj1();
	virtual ~CMyDrivenObj1();
	
	virtual INT		Create(void* p1);
	virtual void	Destroy();
	virtual INT		FrameMove();
	virtual void	Render();
};

#endif