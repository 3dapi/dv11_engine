// Implementation of the CMyDrivenObj1 class.
// Core Progam���� �۾�
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "IMyObject.h"
#include "MyBaseObject.h"
#include "MyDrivenObj1.h"


CMyDrivenObj1::CMyDrivenObj1()
{
	
}

CMyDrivenObj1::~CMyDrivenObj1()
{
	Destroy();
}

INT CMyDrivenObj1::Create(void* p1)
{
	printf("CMyDrivenObj1 Create\n");
	return 0;
}

void CMyDrivenObj1::Destroy()
{
	printf("CMyDrivenObj1 Destroy\n");
}

INT	CMyDrivenObj1::FrameMove()
{
	printf("CMyDrivenObj1 FrameMove\n");
	return 0;
}

void CMyDrivenObj1::Render()
{
	printf("CMyDrivenObj1 Render\n");
}
