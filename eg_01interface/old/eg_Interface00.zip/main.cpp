
// Core Progam���� �۾�
#include <windows.h>
#include <stdio.H>


#ifndef interface
#define interface struct
#endif

interface IMyInterface
{
	virtual INT		Create(void* p1/*In put value*/)=0;
	virtual void	Destroy()=0;

	virtual INT		FrameMove()=0;
	virtual void	Render()=0;

	virtual ~IMyInterface(){};
};


INT LnObj_CreateObject(IMyInterface** pData);



// Host Program���� �̿�
#include <windows.h>
#include <stdio.H>

void main()
{
	IMyInterface* pData;

	LnObj_CreateObject(&pData);

	pData->FrameMove();
	pData->Render();

	delete pData;

	return;
}












// Core Progam������ �۾�
class CMyBaseObject : public IMyInterface
{
protected:
	INT		nId;

public:
	virtual ~CMyBaseObject()
	{
		Destroy();
	}

	virtual INT Create(void* p1)
	{
		printf("CMyBaseObject Create\n");
		return 0;
	}

	virtual void Destroy()
	{
		printf("CMyBaseObject Destroy\n");
	}

	virtual INT	FrameMove()
	{
		printf("CMyBaseObject FrameMove\n");
		return 0;
	}

	virtual void Render()
	{
		printf("CMyBaseObject Render\n");
	}
};


class CMyDrivenObject : public CMyBaseObject
{
protected:
	INT		nId;

public:
	virtual INT Create(void* p1)
	{
		printf("CMyDrivenObject Create\n");
		return 0;
	}

	virtual void Destroy()
	{
		printf("CMyDrivenObject Destroy\n");
	}

	virtual INT	FrameMove()
	{
		printf("CMyDrivenObject FrameMove\n");
		return 0;
	}

	virtual void Render()
	{
		printf("CMyDrivenObject Render\n");
	}
};



INT LnObj_CreateObject(IMyInterface** pData)
{
	CMyDrivenObject* pObj = NULL;

	(*pData) = NULL;

	pObj = new CMyDrivenObject;

	if(FAILED(pObj->Create(NULL)))
	{
		// Return Error Notification
		delete pObj;
		return -1;
	}

	(*pData) = pObj;

	return 0;
}
