

// Host Program���� �̿�

#include <windows.h>
#include <stdio.H>

#include "IMyInterface.h"


void main()
{
	IMyInterface* pData;

	LnObj_CreateObject("CMyDrivenObj1", &pData);

	pData->FrameMove();
	pData->Render();
//	pData->Destroy();

	delete pData;

	printf("\n--------------\n\n");


	LnObj_CreateObject("CMyDrivenObj2", &pData);

	pData->FrameMove();
	pData->Render();
	delete pData;

	printf("\n--------------\n\n");

	return;
}




