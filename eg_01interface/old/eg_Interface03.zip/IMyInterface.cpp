// Implementation of the IMyInterface class.
// Core Progam���� �۾�
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include "IMyInterface.h"




class CMyBaseObject : public IMyInterface
{
protected:
	INT		nId;

public:
	virtual ~CMyBaseObject()
	{
		Destroy();
	}

	virtual INT Create(void* p1)
	{
		printf("CMyBaseObject Create\n");
		return 0;
	}

	virtual void Destroy()
	{
		printf("CMyBaseObject Destroy\n");
	}

	virtual INT	FrameMove()
	{
		printf("CMyBaseObject FrameMove\n");
		return 0;
	}

	virtual void Render()
	{
		printf("CMyBaseObject Render\n");
	}
};



class CMyDrivenObj1 : public CMyBaseObject
{
protected:
	INT		nId;

public:
	virtual ~CMyDrivenObj1()
	{
		Destroy();
	}

	virtual INT Create(void* p1)
	{
		printf("CMyDrivenObj1 Create\n");
		return 0;
	}

	virtual void Destroy()
	{
		printf("CMyDrivenObj1 Destroy\n");
	}

	virtual INT	FrameMove()
	{
		printf("CMyDrivenObj1 FrameMove\n");
		return 0;
	}

	virtual void Render()
	{
		printf("CMyDrivenObj1 Render\n");
	}
};


class CMyDrivenObj2 : public CMyBaseObject
{
protected:
	INT		nId;

public:
	virtual ~CMyDrivenObj2()
	{
		Destroy();
	}

	virtual INT Create(void* p1)
	{
		printf("CMyDrivenObj2 Create\n");
		return 0;
	}

	virtual void Destroy()
	{
		printf("CMyDrivenObj2 Destroy\n");
	}

	virtual INT	FrameMove()
	{
		printf("CMyDrivenObj2 FrameMove\n");
		return 0;
	}

	virtual void Render()
	{
		printf("CMyDrivenObj2 Render\n");
	}
};



INT LnObj_CreateObject(char* sCmd, IMyInterface** pData)
{
	(*pData) = NULL;

	if(0==_stricmp("CMyDrivenObj1", sCmd))
	{
		CMyDrivenObj1* pObj = NULL;

		pObj = new CMyDrivenObj1;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}

	else if(0==_stricmp("CMyDrivenObj2", sCmd))
	{
		CMyDrivenObj2* pObj = NULL;

		pObj = new CMyDrivenObj2;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}


	return -1;
}
