// Interface for the IMyInterface class.
// Core Progam���� �۾�
////////////////////////////////////////////////////////////////////////////////

#ifndef _IMYINTERFACE_H_
#define _IMYINTERFACE_H_

#ifndef interface
#define interface struct
#endif




interface IMyInterface
{
	virtual INT		Create(void* p1/*In put value*/)=0;
	virtual void	Destroy()=0;

	virtual INT		FrameMove()=0;
	virtual void	Render()=0;

	virtual ~IMyInterface(){};
};


INT LnObj_CreateObject(IMyInterface** pData);


#endif

