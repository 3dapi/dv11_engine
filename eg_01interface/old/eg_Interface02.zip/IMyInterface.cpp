// Implementation of the IMyInterface class.
// Core Progam���� �۾�
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include "IMyInterface.h"





class CMyBaseObject : public IMyInterface
{
protected:
	INT		nId;

public:
	virtual ~CMyBaseObject()
	{
		Destroy();
	}

	virtual INT Create(void* p1)
	{
		printf("CMyBaseObject Create\n");
		return 0;
	}

	virtual void Destroy()
	{
		printf("CMyBaseObject Destroy\n");
	}

	virtual INT	FrameMove()
	{
		printf("CMyBaseObject FrameMove\n");
		return 0;
	}

	virtual void Render()
	{
		printf("CMyBaseObject Render\n");
	}
};


class CMyDrivenObject : public CMyBaseObject
{
protected:
	INT		nId;

public:
	virtual ~CMyDrivenObject()
	{
		Destroy();
	}

	virtual INT Create(void* p1)
	{
		printf("CMyDrivenObject Create\n");
		return 0;
	}

	virtual void Destroy()
	{
		printf("CMyDrivenObject Destroy\n");
	}

	virtual INT	FrameMove()
	{
		printf("CMyDrivenObject FrameMove\n");
		return 0;
	}

	virtual void Render()
	{
		printf("CMyDrivenObject Render\n");
	}
};



INT LnObj_CreateObject(IMyInterface** pData)
{
	CMyDrivenObject* pObj = NULL;

	(*pData) = NULL;

	pObj = new CMyDrivenObject;

	if(FAILED(pObj->Create(NULL)))
	{
		// Return Error Notification
		delete pObj;
		return -1;
	}

	(*pData) = pObj;

	return 0;
}
