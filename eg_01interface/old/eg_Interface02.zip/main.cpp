
// Host Program���� �̿�

#include <windows.h>
#include <stdio.H>

#include "IMyInterface.h"


void main()
{
	IMyInterface* pData;

	LnObj_CreateObject(&pData);

	pData->FrameMove();
	pData->Render();
//	pData->Destroy();

	delete pData;

	return;
}




