// Implementation of the IMyMdl class.
// Core Progam���� �۾�
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include "MyMdl.h"





class CMdlBase : public IMyMdl
{
protected:
	INT		m_nId;

public:
	virtual ~CMdlBase()
	{
		Destroy();
	}

	virtual INT Create(void* p1)
	{
		printf("CMdlBase Create\n");
		return 0;
	}

	virtual void Destroy()
	{
		printf("CMdlBase Destroy\n");
	}

	virtual INT	FrameMove()
	{
		printf("CMdlBase FrameMove\n");
		return 0;
	}

	virtual void Render()
	{
		printf("CMdlBase Render\n");
	}
};


class CMdlSkin : public CMdlBase
{
protected:
	INT		m_nId;

public:
	virtual ~CMdlSkin()
	{
		Destroy();
	}

	virtual INT Create(void* p1)
	{
		printf("CMdlSkin Create\n");
		return 0;
	}

	virtual void Destroy()
	{
		printf("CMdlSkin Destroy\n");
	}

	virtual INT	FrameMove()
	{
		printf("CMdlSkin FrameMove\n");
		return 0;
	}

	virtual void Render()
	{
		printf("CMdlSkin Render\n");
	}
};



INT LnMdl_Create(IMyMdl** pData)
{
	CMdlSkin* pObj = NULL;

	(*pData) = NULL;

	pObj = new CMdlSkin;

	if(FAILED(pObj->Create(NULL)))
	{
		// Return Error Notification
		delete pObj;
		return -1;
	}

	(*pData) = pObj;

	return 0;
}
