
// Host Program���� �̿�

#include <windows.h>
#include <stdio.H>

#include "MyMdl.h"


void main()
{
	IMyMdl* pData;

	LnMdl_Create(&pData);

	pData->FrameMove();
	pData->Render();

	delete pData;

	return;
}




