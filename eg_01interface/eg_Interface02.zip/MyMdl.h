// Interface for the IMyMdl class.
// Core Progam���� �۾�
////////////////////////////////////////////////////////////////////////////////

#ifndef _MyMdl_H_
#define _MyMdl_H_

#ifndef interface
#define interface struct
#endif




interface IMyMdl
{
	virtual INT		Create(void* p1/*In put value*/)=0;
	virtual void	Destroy()=0;

	virtual INT		FrameMove()=0;
	virtual void	Render()=0;
};


INT LnMdl_Create(IMyMdl** pData);


#endif

