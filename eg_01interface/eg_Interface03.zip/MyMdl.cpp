// Implementation of the IMyMdl class.
// Core Progam���� �۾�
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include "MyMdl.h"




class CMdlBase : public IMyMdl
{
protected:
	INT		m_nId;

public:
	virtual ~CMdlBase()
	{
		Destroy();
	}

	virtual INT Create(void* p1)
	{
		printf("CMdlBase Create\n");
		return 0;
	}

	virtual void Destroy()
	{
		printf("CMdlBase Destroy\n");
	}

	virtual INT	FrameMove()
	{
		printf("CMdlBase FrameMove\n");
		return 0;
	}

	virtual void Render()
	{
		printf("CMdlBase Render\n");
	}
};



class CMdlSkin : public CMdlBase
{
protected:
	INT		m_nId;

public:
	virtual ~CMdlSkin()
	{
		Destroy();
	}

	virtual INT Create(void* p1)
	{
		printf("CMdlSkin Create\n");
		return 0;
	}

	virtual void Destroy()
	{
		printf("CMdlSkin Destroy\n");
	}

	virtual INT	FrameMove()
	{
		printf("CMdlSkin FrameMove\n");
		return 0;
	}

	virtual void Render()
	{
		printf("CMdlSkin Render\n");
	}
};


class CMdlBone : public CMdlBase
{
protected:
	INT		m_nId;

public:
	virtual ~CMdlBone()
	{
		Destroy();
	}

	virtual INT Create(void* p1)
	{
		printf("CMdlBone Create\n");
		return 0;
	}

	virtual void Destroy()
	{
		printf("CMdlBone Destroy\n");
	}

	virtual INT	FrameMove()
	{
		printf("CMdlBone FrameMove\n");
		return 0;
	}

	virtual void Render()
	{
		printf("CMdlBone Render\n");
	}
};



INT LnMdl_Create(char* sCmd, IMyMdl** pData)
{
	(*pData) = NULL;

	if(0==_stricmp("Skin", sCmd))
	{
		CMdlSkin* pObj = NULL;

		pObj = new CMdlSkin;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}

	else if(0==_stricmp("Bone", sCmd))
	{
		CMdlBone* pObj = NULL;

		pObj = new CMdlBone;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}


	return -1;
}
