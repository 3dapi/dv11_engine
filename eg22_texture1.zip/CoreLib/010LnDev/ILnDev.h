// Interface for the ILnDev class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILnDev_H_
#define _ILnDev_H_

#ifndef interface
#define interface struct
#endif


struct LnDev
{
	INT			PosX;		// Position X
	INT			PosY;		// Position Y
	INT			ScnX;		// Client Rect Width
	INT			ScnY;		// Client Rect Height

	HINSTANCE	hInst;
	HWND		hWnd;		// Window Handle. In, out value

	char		sCls[256];	// Class Name
	

	LnDev();
	LnDev(INT _PosX, INT _PosY, INT _Wx, INT _Wy, const char* _sCls, HINSTANCE _hInst=NULL, HWND _hWnd= NULL);
};



interface ILnDev
{
	virtual INT		Create(void* p1/*In put value*/)=0;
	virtual void	Destroy()=0;

	virtual INT		Restore()=0;
	virtual void	Invalidate()=0;

	virtual INT		FrameMove()=0;
	virtual INT		Render()=0;

	virtual	INT		Run()=0;

	virtual INT		Query(char* sCmd, void* pData)=0;


	virtual INT		BeginScene()=0;
	virtual INT		EndScene()=0;
	virtual INT		Clear(DWORD Count,CONST RECT* pRects,DWORD Flags,DWORD Color,float Z,DWORD Stencil)=0;


	virtual INT		SpriteBegin()=0;
	virtual INT		SpriteEnd()=0;
	virtual INT		SpriteDraw(void* pTx
						   , CONST RECT* pSrcRect
						   , CONST FLOAT* pScaling
						   , CONST FLOAT* pRotationCenter
						   , FLOAT Rotation
						   , CONST FLOAT* pTranslation
						   , DWORD Color)=0;
};


INT		LnDev_CreateDevice(char* sCmd, ILnDev** pData);
void*	LnDev_GetD3Device(ILnDev** pData);
void*	LnDev_GetD3Sprite(ILnDev** pData);


#ifdef _DEBUG
	#pragma comment(lib, "LnDev_.lib")
#else
	#pragma comment(lib, "LnDev.lib")
#endif


#endif

