// Implementation of the ILnTex class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include "../../include/LnLib/LnType.h"
#include "ILnTex.h"
#include "LnTexBase.h"



