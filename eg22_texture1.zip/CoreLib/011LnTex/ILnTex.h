// Interface for the ILnTex class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILnTex_H_
#define _ILnTex_H_

#ifndef interface
#define interface struct
#endif


interface ILnTex
{
	virtual INT		Create(void* p1/*In put value*/)=0;
	virtual void	Destroy()=0;
	virtual INT		Query(char* sCmd, void* pData)=0;

	virtual DWORD	GetWidth()=0;				// Get Width
	virtual DWORD	GetHeight()=0;				// Get Height
	virtual DWORD	GetDepth()=0;				// Get Depth
	virtual DWORD	GetMipLevel()=0;			// Get Creation MipLevel
	virtual DWORD	GetFormat()=0;				// Get enumeration from D3DFORMAT
	virtual DWORD	GetResourceType()=0;		// Get enumeration from D3DRESOURCETYPE
	virtual DWORD	GetFileFormat()=0;			// Get enumeration from D3DXIMAGE_FILEFORMAT
	virtual char*	GetSourceName()=0;			// Get Source Name or File Name

	virtual void*	GetTex()=0;					// Get D3DTexture Pointer
	virtual DWORD	GetColorKey()=0;			// Get Creation color Key
	virtual DWORD	GetFilter()=0;				// Get Creation Filter
};


typedef ILnTex*		PLNTEX;


//	INT		LnTex_CreateTexture("File", "Test.jpg", NULL, ILnTex** pData);
//	INT		LnTex_CreateTexture("ResourceBmp", &ResourceId, NULL, ILnTex** pData);
//	INT		LnTex_CreateTexture("ResourceCustom", &ResourceId, "UserCustomDefineType", ILnTex** pData);
//	INT		LnTex_CreateTexture("ResourceCustom", &ResourceId, "PNG", ILnTex** pData);
//	INT		LnTex_CreateTexture("Memory", pSrcData, &dSourceSize, ILnTex** pData);

#ifndef D3DX_FILTER_NONE
#define D3DX_FILTER_NONE		(1 << 0)
#endif

#ifndef D3DX_FILTER_POINT
#define D3DX_FILTER_POINT		(2 << 0)
#endif

#ifndef D3DX_FILTER_LINEAR
#define D3DX_FILTER_LINEAR		(3 << 0)
#endif

#ifndef D3DX_FILTER_TRIANGLE
#define D3DX_FILTER_TRIANGLE	(4 << 0)
#endif

#ifndef D3DX_FILTER_MIRROR_U
#define D3DX_FILTER_MIRROR_U	(1 << 16)
#endif

#ifndef D3DX_FILTER_MIRROR_V
#define D3DX_FILTER_MIRROR_V	(2 << 16)
#endif

#ifndef D3DX_FILTER_MIRROR_W
#define D3DX_FILTER_MIRROR_W	(4 << 16)
#endif

INT		LnTex_CreateD3DTexture(char* sCmd, ILnTex** pData
							   , void* pD3Device, void* pVal1, void* pVal2 = NULL
							   , DWORD dColorKey=0x00FFFFFF, DWORD dFilter= D3DX_FILTER_NONE);




#ifdef _DEBUG
	#pragma comment(lib, "LnTex_.lib")
#else
	#pragma comment(lib, "LnTex.lib")
#endif


#endif

