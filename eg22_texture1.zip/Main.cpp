// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include <Windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "include/LnLib/LnType.h"
#include "include/LnLib/ILnDev.h"

#include "include/LnLib/ILnTex.h"
#include "Main.h"


CMain*	g_pAppMain;

extern ILnDev*	g_pDev;




INT CMain::pFuncInit()
{
	if(g_pAppMain)
		return g_pAppMain->Init();

	return 0;
}

void CMain::pFuncDestroy()
{
	if(g_pAppMain)
		g_pAppMain->Destroy();
}

INT CMain::pFuncRestore()
{
	if(g_pAppMain)
		return g_pAppMain->Restore();
	
	return 0;
}

void CMain::pFuncInvalidate()
{
	if(g_pAppMain)
		g_pAppMain->Invalidate();
}

INT CMain::pFuncFrameMove()
{
	if(g_pAppMain)
		return g_pAppMain->FrameMove();
	
	return 0;
}

void CMain::pFuncRender()
{
	if(g_pAppMain)
		g_pAppMain->Render();
}



CMain::CMain()
{
	g_pAppMain = this;


	m_pTx	= NULL;
}


CMain::~CMain()
{
}


INT CMain::Init()
{
	m_pDev	= (LPDIRECT3DDEVICE9)LnDev_GetD3Device(&g_pDev);

	LnTex_CreateD3DTexture("File", &m_pTx, m_pDev, "dx5_logo.bmp");

	return 0;
}

void CMain::Destroy()
{
	printf("Call CMain::Destroy()\n");

	if(m_pTx)
	{
		delete m_pTx;
		m_pTx = NULL;
	}
}


INT CMain::Restore()
{
	printf("Call CMain::Restore()\n");

	return 0;
}


void  CMain::Invalidate()
{
	printf("Call CMain::Invalidate()\n");
}


INT  CMain::FrameMove()
{
	static int c=0;

	if(++c>100)
	{
		return -1;
	}

	printf("Call CMain::FrameMove(%d)\n", c);
	
	return 0;
}


void  CMain::Render()
{
	g_pDev->BeginScene();

	printf("Call CMain::Render()\n");

	g_pDev->Clear(0, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0XFF006699, 1, 0L);

	RECT rc={0};
	rc.right = m_pTx->GetWidth();
	rc.bottom= m_pTx->GetHeight();
	void* pTx = m_pTx->GetTex();

	D3DXVECTOR2	vcP(200, 100);
	
	g_pDev->SpriteDraw(pTx, &rc, NULL, NULL, 0, (FLOAT*)&vcP, 0XFFFFFFFF);

	g_pDev->EndScene();
}