// Implementation of the CLnTex class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnTex.h"
#include "LnTexBase.h"


CLnTex::CLnTex()
{
	
}

CLnTex::~CLnTex()
{
	Destroy();
}


INT CLnTex::Create(void* p1)
{
	printf("CLnTex Create\n");
	return 0;
}

void CLnTex::Destroy()
{
	printf("CLnTex Destroy\n");
}

INT	CLnTex::FrameMove()
{
	printf("CLnTex FrameMove\n");
	return 0;
}

void CLnTex::Render()
{
	printf("CLnTex Render\n");
}


INT CLnTex::Query(char* sCmd, void* pData)
{
	printf("CLnTex Query:%s\n", sCmd);
	return 0;
}
