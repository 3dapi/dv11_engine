// Implementation of the CLnMed class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnMed.h"
#include "LnMedBase.h"


CLnMed::CLnMed()
{
	
}

CLnMed::~CLnMed()
{
	Destroy();
}


INT CLnMed::Create(void* p1)
{
	printf("CLnMed Create\n");
	return 0;
}

void CLnMed::Destroy()
{
	printf("CLnMed Destroy\n");
}

INT	CLnMed::FrameMove()
{
	printf("CLnMed FrameMove\n");
	return 0;
}

void CLnMed::Render()
{
	printf("CLnMed Render\n");
}


INT CLnMed::Query(char* sCmd, void* pData)
{
	printf("CLnMed Query:%s\n", sCmd);
	return 0;
}
