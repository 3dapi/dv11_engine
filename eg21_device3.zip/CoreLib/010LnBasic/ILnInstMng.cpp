// Implementation of the ILnInstMng class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include "ILnInstMng.h"


INT LnInst_CreateMng(char* sCmd, ILnInstMng** pData)
{
	(*pData) = NULL;

	if(0==_stricmp("Create Font", sCmd))
	{
		return 0;
	}


	else if(0==_stricmp("Create Texture", sCmd))
	{
		return 0;
	}

	if(0==_stricmp("Create Media", sCmd))
	{
		return 0;
	}

	return -1;
}
