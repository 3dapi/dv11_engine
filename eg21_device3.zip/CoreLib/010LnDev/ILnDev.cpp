// Implementation of the ILnDev class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.H>

#include "ILnDev.h"
#include "LnDevBase.h"
#include "LnDevD3D9.h"
#include "LnDevOpenGL.h"
#include "LnDevSoftware.h"



INT LnInst_CreateDevice(char* sCmd, ILnDev** pData)
{
	(*pData) = NULL;

	if(0==_stricmp("Create Direct3D9", sCmd))
	{
		CLnDevD3D9* pObj = NULL;

		pObj = new CLnDevD3D9;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}

	else if(0==_stricmp("Create OpenGL", sCmd))
	{
		CLnDevOpenGL* pObj = NULL;

		pObj = new CLnDevOpenGL;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}

	else if(0==_stricmp("Create Software Device", sCmd))
	{
		CLnDevSoftwafe* pObj = NULL;

		pObj = new CLnDevSoftwafe;

		if(FAILED(pObj->Create(NULL)))
		{
			// Return Error Notification
			delete pObj;
			return -1;
		}

		(*pData) = pObj;
		
		return 0;
	}


	return -1;
}
