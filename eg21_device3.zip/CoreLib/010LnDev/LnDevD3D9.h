// Interface for the CLnDevD3D9 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnDevD3D9_H_
#define _LnDevD3D9_H_


class CLnDevD3D9 : public CLnDev
{
protected:
	INT		nId;

	INT		(*pFuncInit)();
	INT		(*pFuncDestroy)();
	INT		(*pFuncRestore)();
	INT		(*pFuncInvalidate)();
	INT		(*pFuncFrameMove)();
	INT		(*pFuncRender)();

public:
	CLnDevD3D9();
	virtual ~CLnDevD3D9();
	
	virtual INT		Create(void* p1);
	virtual void	Destroy();

	virtual INT		Restore();
	virtual void	Invalidate();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual	INT		Run();

	virtual INT		Query(char* sCmd, void* pData);
};

#endif