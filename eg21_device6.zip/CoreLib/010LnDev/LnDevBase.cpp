// Implementation of the CLnDev class.
//
//////////////////////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>

#include "ILnDev.h"
#include "LnDevBase.h"


CLnDev::CLnDev()
{
	
}

CLnDev::~CLnDev()
{
	Destroy();
}


INT CLnDev::Create(void* p1)
{
	printf("CLnDev Create\n");
	return 0;
}

void CLnDev::Destroy()
{
	printf("CLnDev Destroy\n");
}



INT CLnDev::Restore()
{
	printf("CLnDev Restore\n");
	return 0;
}

void CLnDev::Invalidate()
{
	printf("CLnDev Invalidate\n");
}


INT	CLnDev::FrameMove()
{
	printf("CLnDev FrameMove\n");
	return 0;
}

INT CLnDev::Render()
{
	printf("CLnDev Render\n");

	return 0;
}


INT CLnDev::Run()
{
	printf("CLnDev Run\n");
	return 0;
}

INT CLnDev::Query(char* sCmd, void* pData)
{
	printf("CLnDev Query:%s\n", sCmd);
	return 0;
}




INT CLnDev::BeginScene()
{
	printf("CLnDev BeginScene()\n");
	return 0;
}


INT CLnDev::EndScene()
{
	printf("CLnDev EndScene()\n");
	return 0;
}


INT CLnDev::Clear(DWORD Count,CONST RECT* pRects,DWORD Flags, DWORD Color,float Z,DWORD Stencil)
{
	printf("CLnDev EndScene()\n");
	return 0;
}



INT CLnDev::SpriteBegin()
{
	printf("CLnDev SpriteBegin()\n");
	return 0;
}


INT CLnDev::SpriteEnd()
{
	printf("CLnDev SpriteEnd()\n");
	return 0;
}


INT CLnDev::SpriteDraw(void* pTx
						   , CONST RECT* pSrcRect
						   , CONST FLOAT* pScaling
						   , CONST FLOAT* pRotationCenter
						   , FLOAT Rotation
						   , CONST FLOAT* pTranslation
						   , DWORD Color)
{
	printf("CLnDev SpriteDraw()\n");
	return 0;
}

