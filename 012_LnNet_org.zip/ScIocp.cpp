// Implementation of the LnNetIocpHost class.
//
////////////////////////////////////////////////////////////////////////////////

#include <vector>

#include <winsock2.h>
#include <windows.h>
#include <process.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "NwUtil.h"
#include "NwRingBuf.h"
#include "NwPacket.h"
#include "ScIocp.h"




LnNetIocpHost::LnNetIocpHost()
{
	m_scH = 0;
	
	memset(&m_sdH, 0, sizeof(m_sdH));
	memset(&m_sRcv, 0, sizeof(m_sRcv));
	memset(&m_sSnd, 0, sizeof(m_sSnd));

	m_wsRcv.buf=(char*)m_sRcv;
	m_wsRcv.len=sizeof(m_sRcv);

	m_wsSnd.buf=(char*)m_sSnd;
	m_wsSnd.len=sizeof(m_sSnd);

	memset(&m_olRcv, 0, sizeof(OVERLAPPED));

	m_PckRcv	= NULL;
	m_PckSnd	= NULL;
}


LnNetIocpHost::LnNetIocpHost(SOCKET scH, SOCKADDR_IN* sdH)
{
	m_scH = scH;
	
	memcpy(&m_sdH, sdH, sizeof(SOCKADDR_IN));
	memset(&m_sRcv, 0, sizeof(m_sRcv));
	memset(&m_sSnd, 0, sizeof(m_sSnd));
	
	m_wsRcv.buf=(char*)m_sRcv;
	m_wsRcv.len=sizeof(m_sRcv);

	m_wsSnd.buf=(char*)m_sSnd;
	m_wsSnd.len=sizeof(m_sSnd);

	memset(&m_olRcv, 0, sizeof(OVERLAPPED));

	m_PckRcv	= NULL;
	m_PckSnd	= NULL;
}

LnNetIocpHost::~LnNetIocpHost()
{
	Destroy();
}


INT LnNetIocpHost::Init(INT iKeepRcv, INT iKeepSnd)
{
	memset(&m_olRcv, 0, sizeof(OVERLAPPED));
	m_wsRcv.len=sizeof(m_sRcv);
	m_wsSnd.len=sizeof(m_sSnd);

	m_PckRcv	= new CNwPacket(iKeepRcv);
	m_PckSnd	= new CNwPacket(iKeepSnd);
	
	return 1;
}

void LnNetIocpHost::Destroy()
{
	if(m_PckRcv)
	{
		delete m_PckRcv;
		m_PckRcv = NULL;
	}

	if(m_PckSnd)
	{
		delete m_PckSnd;
		m_PckSnd = NULL;
	}

	LnNet_SocketClose(&m_scH);
}

INT LnNetIocpHost::AsyncSend(BYTE* sBuf, INT iLen)
{
	INT		hr = -1;
	DWORD	dSnd;
	DWORD	dFlg=0;
	
	memcpy(m_sSnd, sBuf, iLen);
	m_wsSnd.len=iLen;
	
	hr = WSASend(m_scH, &m_wsSnd, 1, &dSnd, dFlg, NULL, NULL);
	
	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();
		
		if(!(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK ==hr))
		{
			return -1;
		}
	}
	
	return 1;
}

INT LnNetIocpHost::AsyncRecv()
{
	INT		hr = -1;
	DWORD	dRcv;
	DWORD	dFlg=0;
	memset(&m_olRcv, 0, sizeof(OVERLAPPED));
	m_wsRcv.len=sizeof(m_sRcv);
	
	hr = WSARecv(m_scH, &m_wsRcv, 1,	&dRcv,	&dFlg,	&m_olRcv, NULL);
	
	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();
		
		if( !(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK ==hr) )
		{
			LnNet_GetNetworkError(hr);
			return -1;
		}
	}
	
	return 1;
}



SOCKET LnNetIocpHost::GetSocket()
{
	return m_scH;
}


SOCKADDR_IN* const LnNetIocpHost::GetSocketAddr()
{
	return &m_sdH;
}


BYTE* const LnNetIocpHost::GetRecvBuf()
{
//	return m_sRcv;
	return (BYTE*)m_wsRcv.buf;
}



int LnNetIocpHost::Send(BYTE* sMsg,INT nMsg, int iSnd)
{
	// ���� ��Ŷ�� �����͸� �Ѵ´�.
	INT hr=-1;
	BYTE	sBuf[PCK_MAX_TMP];
	WORD	iLen=0;

	// iLen�� iSnd + 6�� �Ǿ�� �Ѵ�.
	iLen = LnNet_PacketEncode(sBuf, sMsg, nMsg, iSnd);
	hr = m_PckSnd->PushBack(sBuf, iLen);
	
	return hr;
}


INT LnNetIocpHost::Recv(BYTE* sMsg, int* nMsg, int* iRcv)
{
	INT		iSize;
	BYTE	sBuf[PCK_MAX_TMP];

	*iRcv = 0;
	*nMsg = 0;

	// ��Ŷ�� ���� ���
	if(!m_PckRcv || m_PckRcv->GetUsed()<1)
		return -1;

	iSize = m_PckRcv->PopFront(sBuf);

	if(iSize<1)
		return -1;

	iSize = LnNet_PacketDecode(sMsg, nMsg, sBuf, NULL);
	
	*iRcv = iSize;

//	if(iSize)
//		printf("Recv:%u %s\n\n", iSize-PCK_HAEAD_TOT, sMsg+ PCK_HAEAD_TOT);


	// ���� �ִ� ��Ŷ ������ ���� ����
	INT iCnt = m_PckRcv->GetUsed();

	return iCnt;
}


void LnNetIocpHost::SendAllData()
{
	// �����ۿ� �ִ� ��Ŷ�� ������.
	if(!m_PckSnd || m_PckSnd->GetUsed()<1)
		return;

	while(1)
	{
		INT iCnt = m_PckSnd->GetUsed();

		if(iCnt<1)
			break;

		BYTE	sBuf[PCK_MAX_TMP];
		
		INT		hr		= 0;
		INT		iSnd	= 0;

		iSnd = m_PckSnd->PopFront(sBuf);
		hr = this->AsyncSend(sBuf, iSnd);
	}
}


void LnNetIocpHost::FowardRingBuffer(INT iRcv)
{
	// �Ϸ�(����)�� ���۳����� �����ۿ� ����.
	if(!m_PckRcv)
		return;

	m_PckRcv->PushBack((BYTE*)m_wsRcv.buf, iRcv);
}




INT LnNetIocpHost::GetPacketCount()
{
	if(!m_PckRcv)
		return -1;

	return m_PckRcv->GetUsed();
}