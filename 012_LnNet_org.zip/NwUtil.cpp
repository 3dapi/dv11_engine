// Implementation of the NwUtil class.
//
////////////////////////////////////////////////////////////////////////////////

#include <winsock2.h>
#include <windows.h>
#include <process.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "NwUtil.h"




void LnNet_FormatMessage(char* sMsg)
{
	LPVOID	pBuf;
	DWORD	hr= GetLastError();

	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		hr,
		0,
		(LPTSTR) &pBuf,
		0,
		NULL 
	);

	sprintf(sMsg, "%s", (char*)pBuf);
	LocalFree( pBuf );
}



void LnNet_GetNetworkError(DWORD hr)
{
	char	sMsg[512];

	LnNet_FormatMessage(sMsg);

	printf("Error Line:%3d ", __LINE__);
	printf("%s	", __DATE__);
	printf("%s	", __TIME__);
	printf("%s	", __FILE__);

	printf("%s\n", sMsg);

	LocalFree( sMsg );
}



INT LnNet_WSAGetError()
{
	INT		hr = 0;
	char	sMsg[512];

	hr = WSAGetLastError();

	if(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK==hr || WSAEISCONN==hr)
		return -1;

	LnNet_FormatMessage(sMsg);

	printf("Line:%d	", __LINE__);
	printf("%s	", __DATE__);
	printf("%s	", __TIME__);
	printf("%s	", __FILE__);

	printf("%s\n", sMsg);

	return 1;
}



INT LnNet_WSAStartup()
{
	INT		hr;
	WORD	wVersion;
	WSADATA wsaData;

	DWORD	iBuf =0;
	INT		nTCP[2] = {IPPROTO_TCP, IPPROTO_UDP};
 
	wVersion = MAKEWORD( 2, 2 );
 
	if ( 0 != WSAStartup( wVersion, &wsaData ))
		return -1;
 
	if ( LOBYTE( wsaData.wVersion ) != 2 || HIBYTE( wsaData.wVersion ) != 2 )
	{
		WSACleanup();
		return -1; 
	}

	// ������ ũ�⸸ ��ȯ�ϰ� ������ �߻��ؾ� �ȴ�.
	hr = WSAEnumProtocols(0, 0, &iBuf);

	if( (SOCKET_ERROR != hr) && (WSAENOBUFS != WSAGetLastError()) )
	{
		WSACleanup();
		return -1;
	}

	LPWSAPROTOCOL_INFO	pProtoInfo = (LPWSAPROTOCOL_INFO)malloc(iBuf);

	hr = WSAEnumProtocols(nTCP, pProtoInfo, &iBuf);
	free(pProtoInfo);

	if(SOCKET_ERROR ==hr)
	{
		WSACleanup();
		return -1; 
	}

	return 1;
}


void LnNet_WSACleanup()
{
	WSACleanup();
}


INT LnNet_SocketTcpCreate(SOCKET* pScH, BOOL bOverLapped)
{
	if(bOverLapped)
		*pScH = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, WSA_FLAG_OVERLAPPED);
	else
		*pScH = socket(AF_INET, SOCK_STREAM, 0);

	
	if(INVALID_SOCKET == *pScH)
		return -1;

	return 1;
}


void LnNet_SocketClose(SOCKET* scH)
{
	if(*scH<1)
		return;

	::shutdown(*scH, SD_BOTH);
	closesocket(*scH);
	*scH = 0;
}



INT LnNet_SocketBind(SOCKET scH, SOCKADDR_IN* pSdH)
{
	INT hr=-1;

	hr = bind(scH, (SOCKADDR*)pSdH, sizeof(SOCKADDR_IN));

	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();

		if(WSAEWOULDBLOCK !=hr)
		{
			return -1;
		}
	}

	return 1;
}


INT LnNet_SocketListen(SOCKET scH)
{
	INT hr=-1;

	hr = listen(scH, SOMAXCONN);

	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();

		if(WSAEWOULDBLOCK !=hr)
		{
			return -1;
		}
	}

	return 1;
}



INT LnNet_SocketAccept(SOCKET* pscOut, SOCKADDR_IN* psdOut, SOCKET scListen)
{
	INT		hr=-1;
	SOCKET	scCln;
	INT		iSizeAdd = sizeof(SOCKADDR_IN);

	scCln = accept(scListen, (SOCKADDR*)psdOut, &iSizeAdd);
//	scCln = WSAAccept(m_scH, (SOCKADDR*)&sdCln, &iSizeAdd, NULL, NULL);
	
	// ���������� �񵿱� �ϰ�� �̰��� �ݵ�� Ȯ��
	if(SOCKET_ERROR == scCln || INVALID_SOCKET ==scCln)
	{
		hr = WSAGetLastError();

		if( !(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK==hr || WSAEISCONN==hr) )
		{
			return -1;
		}

		// �񵿱���� ��� ���� �ִ�.
		*pscOut =0;
		return 0;
	}

	*pscOut = scCln;

	// ������ ����
	return 1;
}



INT LnNet_SocketConnect(SOCKET scH, SOCKADDR_IN* psdH)
{
	INT	hr=-1;

	hr = connect(scH, (SOCKADDR*)psdH, sizeof(SOCKADDR_IN));
	
	// ������ �񵿱��� ��� �̰��� �ݵ�� Ȯ��
	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();

		if( !(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK==hr || WSAEISCONN==hr) )
		{
			return -1;
		}
	}

	return 1;
}


INT LnNet_TCPSend(SOCKET scH, BYTE* sBuf, INT iLen, INT flags)
{
	INT hr = send(scH, (char*)sBuf, iLen, flags);

	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();

		if( !(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK==hr) )
		{
			return -1;
		}
	}

	return hr;
}


INT LnNet_TCPRecv(SOCKET scH, BYTE* sBuf, INT iBuf, INT flags)
{
	INT hr = recv(scH, (char*)sBuf, iBuf, flags);

	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();

		if( !(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK==hr) )
		{
			return -1;
		}
	}

	return hr;
}




void LnNet_SetSocketAddr(SOCKADDR_IN* pOut, char* sIp, char* sPort)
{
	memset(pOut, 0, sizeof(SOCKADDR_IN));
	pOut->sin_family=AF_INET;

	pOut->sin_addr.s_addr = (sIp) ? inet_addr(sIp): htonl(INADDR_ANY);
	pOut->sin_port=htons(atoi(sPort));
}


int LnNet_SetSocketNonBlocking(SOCKET scH, BOOL bOn)
{
	u_long on =bOn? 1: 0;
	return ioctlsocket(scH, FIONBIO, &on);
}



INT LnNet_SetSocketNaggleOff(SOCKET scH, BOOL bOff)
{
	BOOL bNagle = bOff? 1: 0; // Nagle �˰����� �۵� ����
	return setsockopt(scH, IPPROTO_TCP, TCP_NODELAY, (char*)&bNagle, sizeof bNagle);
}


INT LnNet_SocketSelect(FD_SET* readfds, FD_SET* writefds, FD_SET* exceptfds, TIMEVAL* timeout)
{
	INT hr=-1;

	hr = select(0, readfds, writefds, exceptfds, timeout);

	if(SOCKET_ERROR == hr)
	{
		hr = WSAGetLastError();

		if( !(WSA_IO_PENDING ==hr || WSAEWOULDBLOCK==hr || WSAEISCONN==hr) )
		{
			return -1;
		}
	}

	return hr;
}


HANDLE LnNet_ThreadCreate(LPTHREAD_START_ROUTINE pFunc,PVOID pParam, ULONG dFlag, DWORD* dId)
{
	return (HANDLE)_beginthreadex(NULL, 0, (LPBEGIN_THREAD_EX)pFunc, pParam, dFlag, (unsigned*)dId);
}


void LnNet_ThreadClose(HANDLE* hThread)
{
	DWORD	dExit= 0;
	INT		hr	 = 0;
	
	if(0==hThread || 0 == *hThread)
		return;

	GetExitCodeThread(*hThread, &dExit);
	
	if(dExit)
	{
		SuspendThread(*hThread);

		if(0==TerminateThread(*hThread, dExit))
		{
			char	sMsg[512];
			LnNet_FormatMessage(sMsg);
			printf("%s\n", sMsg);
		}
	}

	//	WaitForSingleObject(m_hTh, INFINITE);
	CloseHandle(*hThread);
	*hThread = NULL;
}


HANDLE	LnNet_WSAEventCreate()
{
	return WSACreateEvent();
}

void LnNet_WSAEventClose(WSAEVENT* hEvent)
{
	if(*hEvent == 0)
		return;

	if(FALSE == (WSACloseEvent(*hEvent)))
	{
		LnNet_GetNetworkError(WSAGetLastError());
		*hEvent = 0;
		return;
	}

	*hEvent = 0;
}





HANDLE LnNet_IocpPortCreate(SOCKET scH, HANDLE hIocp, void* pAddress)
{
	return CreateIoCompletionPort((HANDLE)(scH), hIocp, (DWORD)pAddress, 0);
}




INT LnNet_GetLocalIp(char* sIp/*IP List*/, INT* piN/*IP Count*/, INT* iWidth)
{
	SOCKADDR_IN sdH;
	HOSTENT*	pHost=0;
	char		sHost[512];
	INT			i=0;

	*piN = 0;
	*iWidth = 16;

	memset(sHost, 0, sizeof sHost);

	if(::gethostname(sHost, sizeof sHost))
		return -1;

	pHost = ::gethostbyname(sHost);

	if(!pHost)
		return -1;

	//���� ��Ʈ��ũ �����Ǹ� 32�� �̻� ���� �༮�� ���� ��!!!!!
	for(i=0;pHost->h_addr_list[i] && i<32; ++i)
	{
		memcpy(&sdH.sin_addr, pHost->h_addr_list[i], pHost->h_length);
		strcpy(sIp + i* (*iWidth), inet_ntoa(sdH.sin_addr));
		++(*piN);
	}

	return 1;
}


INT	LnNet_GetSystemProcessNumber()
{
	SYSTEM_INFO SystemInfo;

	GetSystemInfo(&SystemInfo);
	
	return INT(SystemInfo.dwNumberOfProcessors);
}



WORD 	LnNet_PacketEncode(BYTE* pOut						// Output Packet
						  , BYTE* sMsg						// Packet contents
						  , INT nMsg						// Send Message Kind
						  , int iSnd						// Pakcet contents length
						  , int iHeadLen					// Packet Length =2(WORD)
						  , int iHeadMsg					// pACKET Msg = 4(INT)
						  )
{
	// ������ ����
	//	+-----------+------------+------------ 
	//	|����(2Byte)| ����(4Byte)| �޽��� 
	//	+-----------+------------+------------ 

	INT		iPckHeadTot = iHeadLen + iHeadMsg;
	WORD	iLen = iSnd + iPckHeadTot;			// ���̸� ����

	if(nMsg)
	{
		memcpy(pOut + 0, &iLen, iHeadLen);
		memcpy(pOut + iHeadLen, &nMsg, iHeadMsg);
		memcpy(pOut + iPckHeadTot, sMsg, iSnd);
	}

	else
	{
		// Msg�� 0�̸� �״�� ����...
		iLen = iSnd;
		memcpy(pOut, sMsg, iLen);
	}

	// ��Ŷ ��ü ���� ����
	return iLen;
}


WORD 	LnNet_PacketDecode(BYTE* sMsg						// Output Message
						  , INT* nMsg						// Receive Message Kind
						  , BYTE* pIn						// Receive Packets
						  , int iRcv						// Receive Packet Length
						  , int iHeadLen					// Packet Length =2(WORD)
						  , int iHeadMsg					// pACKET Msg = 4(INT)
						  )
{
	// ��Ŷ�� ����.

	INT		iPckHeadTot = iHeadLen + iHeadMsg;
	WORD	iLen = 0;

	memcpy(&iLen, pIn, iHeadLen);
	memcpy(nMsg,  pIn + iHeadLen, iHeadMsg);

	// ���̸� ����	
	iLen -= iPckHeadTot;

	memcpy(sMsg, pIn + iPckHeadTot, iLen);

	// �޽��� ���� ����
	return iLen;
}
