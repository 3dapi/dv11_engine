// Implementation of the CNwEventCln class.
//
////////////////////////////////////////////////////////////////////////////////

#include <winsock2.h>
#include <windows.h>
#include <process.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "NwUtil.h"
#include "NwRingBuf.h"
#include "NwPacket.h"
#include "NwEventCln.h"




CNwEventCln::CNwEventCln()
{
	m_scH	= 0;
	m_bConn	= 0;

	m_hTh	= 0;
	m_dTh	= 0;

	m_hEvnt	= 0;
	m_dEvnt	= 0xFFFFFFFF;

	memset(&m_sIp, 0, sizeof m_sIp);
	memset(&m_sPt, 0, sizeof m_sPt);
}

CNwEventCln::CNwEventCln(CHAR* sIp, CHAR* sPt)
{
	CNwEventCln();

	strcpy(m_sIp, sIp);
	strcpy(m_sPt, sPt);
}



CNwEventCln::~CNwEventCln()
{
	Destroy();
}


INT CNwEventCln::Init()
{
	INT hr=-1;

	//2. ���� ���� ����
	if(FAILED(LnNet_SocketTcpCreate(&m_scH)))
		return -1;


	//3. Setting Socket Address
	LnNet_SetSocketAddr(&m_sdH, m_sIp, m_sPt);


	//4. EventSelect Create
	// Ŀ�ؼ� ���� �̺�Ʈ �����忡�� ����� �Ѵٸ� �̸� ���Ͽ� �̺�Ʈ�� ����ؾ� �Ѵ�.
	m_hEvnt = LnNet_WSAEventCreate();
	
	if(SOCKET_ERROR == WSAEventSelect(m_scH, m_hEvnt, (FD_CONNECT|FD_READ|FD_CLOSE) ))
		return -1;

		
	//5. ������ ���� ��û
	INT nCnt=5;
	
	while(--nCnt)
	{
		if(SUCCEEDED(LnNet_SocketConnect(m_scH, &m_sdH)))
		{
			m_bConn = TRUE;
			break;
		}

		Sleep(200);
	}

	if(!m_bConn)
		goto ERROR_END;

	
	//6. Non blocking ���, �׸��� Nagle�˰����� �۵��� ���� ��Ų��.
	hr = LnNet_SetSocketNonBlocking(m_scH);
	hr = LnNet_SetSocketNaggleOff(m_scH);

	//7. Event �� ���� ������ ����.
	m_hTh = LnNet_ThreadCreate(ThreadRecv, this, 0, &m_dTh);
	
	return 1;

ERROR_END:
	Destroy();
	return -1;
}


void CNwEventCln::Destroy()
{
	m_bConn = 0;

	// ������ �ݴ´�.
	LnNet_SocketClose(&m_scH);

	m_bConn = 0;

	LnNet_WSAEventClose(&m_hEvnt);
	LnNet_ThreadClose(&m_hTh);
}


INT CNwEventCln::FrameMove()
{
	// Send Process
	if(!m_bConn)
		return -1;
	
	if(m_bConn)
	{
		// ��Ʈ��ũ�� �� �� �ִٸ� �����͸� ������.
		SendAllData();
	}

	return 1;
}



//�� ��� �Ϸ� ó��
DWORD WINAPI CNwEventCln::ThreadRecv(void* pParam)
{
	return ((CNwEventCln*)pParam)->ProcRecv(pParam);
}


DWORD CNwEventCln::ProcRecv(void* pParam)
{
	INT	hr=-1;
	
	while(m_bConn)
	{
		if(FAILED(hr=EventWait()))
			continue;
		
		if(FAILED(hr=EventEnum()))
			break;
		
		switch(m_dEvnt)
		{
		case FD_CONNECT:
//			m_bConn = TRUE;
			printf("Connection Event\n");
			break;

		case FD_READ:
			if(FAILED(hr=EventRecv()))
				return 0;
			break;

		case FD_CLOSE:
			printf("Close Socket\n");
			m_bConn = 0;

			break;
		}
	}
	
	_endthreadex(0);

	return 1;
}




INT CNwEventCln::EventWait()
{
	m_dEvnt	= 0xFFFFFFFF;
	
	int	nIdx =0;
	nIdx = WSAWaitForMultipleEvents( 1, &m_hEvnt, FALSE, WSA_INFINITE, FALSE);
	
	if( WSA_WAIT_FAILED == nIdx || WSA_WAIT_TIMEOUT == nIdx)
	{
		if(FAILED(LnNet_WSAGetError()))
		{
			printf("Error Waite...\n");
			return -1;
		}
		
		else
			return 1;
	}
	
	nIdx -= WSA_WAIT_EVENT_0;
	
	return nIdx;
}


INT CNwEventCln::EventEnum()
{
	WSANETWORKEVENTS	wsEvnt;
	
	WSAEnumNetworkEvents(m_scH, m_hEvnt, &wsEvnt);
	
	if( FD_CONNECT & wsEvnt.lNetworkEvents)									// case Connect
	{
		if( wsEvnt.iErrorCode[FD_CONNECT_BIT])
		{
			if(FAILED(LnNet_WSAGetError()))
			{
				printf("Connect Error\n");
				return -1;
			}
		}
		
		m_dEvnt = FD_CONNECT;
	}
	
	else if( FD_CLOSE & wsEvnt.lNetworkEvents)								// case Close
	{
		if( wsEvnt.iErrorCode[FD_CLOSE_BIT])
		{
			if(FAILED(LnNet_WSAGetError()))
			{
				printf("Close Event Error\n");
				return -1;
			}
		}
		
		m_bConn = 0;
		
		m_dEvnt = FD_CLOSE;
	}
	
	else if( FD_READ & wsEvnt.lNetworkEvents)								// case Read
	{
		if( wsEvnt.iErrorCode[FD_READ_BIT])
		{
			if(FAILED(LnNet_WSAGetError()))
			{
				printf("Read Error\n");
				return -1;
			}
		}
		
		m_dEvnt = FD_READ;
	}
	
	else
	{
		printf("Other Message.\n");
	}
	
	return 1;
}




INT CNwEventCln::EventRecv()
{
	BYTE	sBufRcv[PCK_MAX_TMP];
	INT		iBuf = sizeof(sBufRcv);
	int		iRcv= LnNet_TCPRecv(m_scH, sBufRcv, iBuf);

	if(iRcv>0)
	{
		sBufRcv[iRcv]=0;
		m_PckRcv.PushBack(sBufRcv, iRcv);
	}
	else
	{
		// ����
		m_bConn =0;
		return -1;
	}
	
	return 1;
}



int CNwEventCln::Send(BYTE* sMsg,INT nMsg, int iSnd)
{
	// ���� ��Ŷ�� �����͸� �Ѵ´�.
	INT hr=-1;
	BYTE	sBuf[PCK_MAX_TMP];
	WORD	iLen=0;

	// iLen�� iSnd + 6�� �Ǿ�� �Ѵ�.
	iLen = LnNet_PacketEncode(sBuf, sMsg, nMsg, iSnd);
	hr = m_PckSnd.PushBack(sBuf, iLen);
	
	return hr;
}


INT CNwEventCln::Recv(BYTE* sMsg, int* nMsg, int* iRcv)
{
	*iRcv = 0;
	*nMsg = 0;

	// ��Ŷ�� ���� ���
	if(m_PckRcv.GetUsed()<1)
		return -1;

	INT		iSize;
	BYTE	sBuf[PCK_MAX_TMP];

	iSize = m_PckRcv.PopFront(sBuf);

	if(iSize<1)
		return -1;

	iSize = LnNet_PacketDecode(sMsg, nMsg, sBuf, NULL);
	
	*iRcv = iSize;

//	if(iSize)
//		printf("Recv:%u %s\n\n", iSize-PCK_HAEAD_TOT, sMsg+ PCK_HAEAD_TOT);


	// ���� �ִ� ��Ŷ ������ ���� ����
	INT iCnt = m_PckRcv.GetUsed();

	return iCnt;
}


void CNwEventCln::SendAllData()
{
	// �����ۿ� �ִ� ��Ŷ�� ������.
	if(m_PckSnd.GetUsed()<1)
		return;

	while(1)
	{
		INT iCnt = m_PckSnd.GetUsed();

		if(iCnt<1)
			break;

		BYTE	sBuf[PCK_MAX_TMP];

		INT		hr		= 0;
		INT		iSnd	= 0;
		INT		iWrite	= 0;

		iSnd = m_PckSnd.PopFront(sBuf);

		while(iSnd>0)
		{ 
			if(FAILED(hr = LnNet_TCPSend(m_scH, sBuf+iWrite, iSnd)))
				return;

			iSnd	-= hr;
			iWrite	+= hr;
		}
	}
}

BOOL CNwEventCln::IsConnect()
{
	return m_bConn;
}

INT CNwEventCln::GetPacketCount()
{
	return m_PckRcv.GetUsed();
}
