// NwQue.h: interface for the CNwRingBuf class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _NWRINGBUF_H_
#define _NWRINGBUF_H_

#define BUF_MAX_QUEUE	65536

class CNwRingBuf
{
protected:
	INT		F;						// Header
	INT		L;						// Rear(Last)
	INT		W;						// Width
	INT		R;						// Stored(Registered) memory Lenth

	BYTE*	B;						// Buffer

public:
	CNwRingBuf();
	CNwRingBuf(INT iSize);
	virtual ~CNwRingBuf();

	void	SetSize(INT iSize);
	INT		GetUsed()	{	return R;		}

	INT		End()		{	return L;		}
	INT		Front()		{	return F;		}
	BOOL	IsEmpty()	{	return R;		}

	INT		PushBack(BYTE* /*In*/pBuf, INT iT/*Length*/);
	INT		PopFront(BYTE* /*Out*/pBuf, INT iT/*Length*/);
	INT		GetHead2Byte();
};

#endif
